function out=run_gracefo(day,out)
% Fresh native MATLAB run from bundled original GPS1A, JAXA SSR and RINEX.
% Example: out=run_gracefo('2023-01-02'); No saved results are read.
if nargin<1,day='2023-01-02';end
root=fileparts(mfilename('fullpath'));savedPath=path;clean=onCleanup(@()path(savedPath));
restoredefaultpath;addpath(root,fullfile(root,'gracefo','code'));
if nargin<2,out=fullfile(root,'runs',['gracefo_' erase(day,'-') '_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);end
assert(~isfolder(out),'Fresh run requires a new output folder. Use resume_gracefo only for your own interrupted run.');
mkdir(out);c=fo_case(day,out);settings=struct('date',day,'created',char(datetime('now')),'mode','raw_input_native_MATLAB');
f=fopen(fullfile(out,'run_settings.json'),'w');fprintf(f,'%s',jsonencode(settings,PrettyPrint=true));fclose(f);
diary(fullfile(out,'run.log'));diaryCleanup=onCleanup(@()diary('off'));
fprintf('Fresh raw-input GRACE-FO run: %s\n',out);check_runtime;
fixed=fo_run_case(c);validate_fo_reproduction(c,fixed);fprintf('Results: %s\n',fixed);
end
