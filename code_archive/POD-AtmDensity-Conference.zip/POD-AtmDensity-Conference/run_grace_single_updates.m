function out=run_grace_single_updates(updated,includeScreening)
% Rebuild the single-receiver correction from original products. Optional
% UPDATED resumes a generated run, never a shipped estimator checkpoint.
root=fileparts(mfilename('fullpath'));core=fullfile(root,'grace2015');addpath(root,core,fullfile(core,'updates','code'),fullfile(core,'single_updates','code'));
if nargin<1,updated=run_grace_updates;end
if nargin<2,includeScreening=false;end
baseline=grace_update_baseline(updated);inputs=grace_update_input_root(updated);source=fullfile(updated,'code_history20_run');out=fullfile(updated,'single_satellite_update');if ~isfolder(out),mkdir(out);end
grace_single_products(inputs,baseline,updated,fullfile(inputs,'raw','final_gps'),fullfile(out,'final_products'));
if includeScreening
grace_single_weights(inputs,source,out);grace_single_continuity(inputs,source,out);
grace_single_density(inputs,baseline,updated,out);
grace_single_publish(inputs,updated,out,fullfile(out,'plots','robust'),'robust');
grace_single_publish(inputs,updated,out,fullfile(out,'plots','continuous_robust'),'continuous_robust');
end
fprintf('Single-satellite results: %s\n',out);
end
