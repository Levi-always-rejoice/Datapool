function report=compare_grace_runs(old,new,outJson)
% Post-run diagnostic only; both inputs are outputs of completed raw runs.
if nargin<3,outJson=fullfile(new,'repeat_diagnostic.json');end
report=struct;
for sat='AB'
 a=load(fullfile(old,[sat '_raw_design.mat']),'q');b=load(fullfile(new,[sat '_raw_design.mat']),'q');
 for ff={'t','r','v','known','rad','K','phase','code','h','good','labels','B0','pod_r'}
  key=ff{1};if ~isfield(a.q,key)||~isfield(b.q,key),continue;end;x=a.q.(key);y=b.q.(key);
  if ~isequal(size(x),size(y)),report.(sat).(key)=struct('shape_old',size(x),'shape_new',size(y));continue;end
  ok=isfinite(x)&isfinite(y);delta=double(x(ok))-double(y(ok));report.(sat).(key)=struct('max_abs',max(abs(delta)),'RMS',rms(delta),'different_nonfinite',nnz(isfinite(x)~=isfinite(y)));
 end
 a=load(fullfile(old,[sat '_float_model.mat']),'F');b=load(fullfile(new,[sat '_float_model.mat']),'F');
 for ff={'values','ambiguities'},key=ff{1};delta=a.F.(key)-b.F.(key);report.(sat).(['float_' key])=struct('RMS',rms(delta(:)),'max_abs',max(abs(delta),[],'all'));end
end
a=load(fullfile(old,'R_integer_validation.mat'),'integers');b=load(fullfile(new,'R_integer_validation.mat'),'integers');x=a.integers;y=b.integers;
report.R_integer_H=struct('same_matrix',isequal(x.H,y.H),'rank_old',rank(x.H),'rank_new',rank(y.H),'combined_rank',rank([x.H;y.H]),'new_constraint_on_old_solution_m',max(abs(y.H*x.fixedB-y.target)),'old_constraint_on_new_solution_m',max(abs(x.H*y.fixedB-x.target)));
for ff={'selected','integers','target','history'},key=ff{1};report.(['R_' key])=struct('same',isequal(x.(key),y.(key)),'old_size',size(x.(key)),'new_size',size(y.(key)));end
f=fopen(outJson,'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report.R_integer_H);
end
