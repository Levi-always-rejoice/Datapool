function fixed=resume_gracefo(out)
% Resume checkpoints created by run_gracefo in the specified run folder.
root=fileparts(mfilename('fullpath'));savedPath=path;clean=onCleanup(@()path(savedPath));
restoredefaultpath;addpath(root,fullfile(root,'gracefo','code'));
s=jsondecode(fileread(fullfile(out,'run_settings.json')));c=fo_case(s.date,out);
diary(fullfile(out,'run.log'));d=onCleanup(@()diary('off'));check_runtime;
fixed=fo_run_case(c);validate_fo_reproduction(c,fixed);
end
