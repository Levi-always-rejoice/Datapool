function verify_package()
% Verify distribution integrity only. No estimator results are loaded.
root=fileparts(mfilename('fullpath'));items=jsondecode(fileread(fullfile(root,'MANIFEST_SHA256.json')));
for k=1:numel(items)
 fpath=fullfile(root,strrep(items(k).path,'/',filesep));assert(isfile(fpath),'Missing: %s',items(k).path);
 f=fopen(fpath,'rb');assert(f>=0);clean=onCleanup(@()fclose(f));md=java.security.MessageDigest.getInstance('SHA-256');
 while true,b=fread(f,8*1024*1024,'*uint8');if isempty(b),break;end;md.update(typecast(b,'int8'));end
 digest=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));clear clean;
 assert(strcmp(digest,items(k).sha256),'Checksum mismatch: %s',items(k).path);
 if mod(k,100)==0,fprintf('Verified %d/%d files\n',k,numel(items));end
end
fprintf('All %d distributed files passed SHA-256 verification.\n',numel(items));
end
