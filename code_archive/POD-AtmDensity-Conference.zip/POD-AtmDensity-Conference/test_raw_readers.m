function report=test_raw_readers()
% Standalone smoke test of ORIGINAL mission observations, no prepared arrays.
root=fileparts(mfilename('fullpath'));old=path;cleanup=onCleanup(@()path(old));restoredefaultpath;
addpath(root,fullfile(root,'grace2015'),fullfile(root,'gracefo','code'));
report=struct;for sat='AB'
 x=read_grace_gps1b(fullfile(root,'grace2015','raw',sprintf('GPS1B_2015-03-15_%s_02.dat',sat)));
 t=unique(x.values(:,1));dt=median(diff(t));assert(abs(dt-10)<.01&&numel(t)>7000);
 report.GRACE.(sat)=struct('records',x.records,'unique_epochs',numel(t),'median_interval_s',dt);
end
for day={'2023-01-01','2023-01-02'}
 mjd=juliandate(datetime(day{1}))-2400000.5;base=(mjd-51544.5)*86400;
 for sat='CD'
  x=read_fo_raw(fullfile(root,'gracefo','raw',day{1},sprintf('GPS1A_%s_%s_04.txt',day{1},sat)),base);
  assert(abs(x.report.phase_interval_s-1)<.01&&x.report.epochs>85000&&x.report.good_published_phase>500000);
  report.(['FO_' erase(day{1},'-')]).(sat)=x.report;
 end
end
disp(report);fprintf('Original GRACE 10-s GPS1B and GRACE-FO 1-Hz GPS1A readers passed.\n');
end
