function outputs=run_all()
% Full raw-input reproduction; this can take hours and creates large outputs.
outputs=struct;outputs.GRACE=run_grace_updates;
outputs.GRACE_manuscript=strtrim(fileread(fullfile(outputs.GRACE,'baseline_path.txt')));
outputs.GRACE_single=run_grace_single_updates(outputs.GRACE);
outputs.GRACEFO_20230102=run_gracefo('2023-01-02');
outputs.GRACEFO_20230101=run_gracefo('2023-01-01');
outputs.comparison_figure=plot_gracefo_days(outputs.GRACEFO_20230101,outputs.GRACEFO_20230102);
end
