function check_runtime()
assert(~isempty(ver('aero')),'Aerospace Toolbox is required.');
assert(exist('gravitysphericalharmonic','file')==2,'Aerospace Toolbox gravity function unavailable');
% Fails early if the separately installed Aerospace EGM2008 model is absent.
[x,y,z]=gravitysphericalharmonic([6900000 0 0],'EGM2008',120);assert(all(isfinite([x y z])));
fprintf('MATLAB %s; Aerospace Toolbox and EGM2008 model available.\n',version);
end
