function out=run_grace_updates()
% Complete updated GRACE 2015 route from bundled original products.
% No example CSV/JSON or saved estimator arrays are used as inputs.
root=fileparts(mfilename('fullpath'));saved=path;clean=onCleanup(@()path(saved));
restoredefaultpath;addpath(root,fullfile(root,'grace2015'));maxNumCompThreads(2);check_runtime;
base=run_manuscript;
out=fullfile(root,'runs',['grace2015_updated_' datestr(now,'yyyymmdd_HHMMSS')]);
addpath(fullfile(root,'grace2015','updates','code'));
grace_update_pipeline(fullfile(root,'grace2015'),base,out);
fprintf('Updated 2015 results: %s\n',out);
end
