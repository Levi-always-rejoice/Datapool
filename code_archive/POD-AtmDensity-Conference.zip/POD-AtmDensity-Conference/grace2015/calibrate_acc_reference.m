function density=calibrate_acc_reference(density)
% Recompute one body-X ACC offset using the raw-GNV control only.
% The bias response passes through the identical density-window operator.
% No old calibration or GNSS estimate is used to determine the offset.
v=density.values;valid=density.supported&all(isfinite(v(:,[3 4 6])),2);assert(nnz(valid)>10);
y=v(valid,4)-v(valid,3);h=v(valid,6);coef=h\y;
for j=1:10
 residual=y-h*coef;scale=max(1e-14,1.4826*median(abs(residual-median(residual))));w=min(1,1.5*scale./max(abs(residual),realmin));coef=sum(w.*h.*y)/sum(w.*h.^2);
end
density.uncalibrated_ACC_density=v(:,4);density.ACC_bias_mps2=coef*1e-6;
density.values(:,4)=v(:,4)-coef*v(:,6);density.ACC_calibration='One robust constant SRF-X bias fitted against GNV density control; independent of GNSS target';
end
