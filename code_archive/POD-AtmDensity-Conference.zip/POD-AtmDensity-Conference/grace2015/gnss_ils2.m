function [integer,costs]=gnss_ils2(ifdelta,si,wide,sw)
% Exact two-best 2D integer search in (Delta N1, Delta N1-Delta N2).
% Objective: independent IF and MW marginal approximations used by prototype.
c=299792458;f1=1575.42e6;f2=1227.6e6;ln=c/(f1+f2);cf=f2/(f1+f2)*c/(f1-f2);
w0=round(wide);n0=round((ifdelta-cf*w0)/ln);seed=[];
for z=n0-1:n0+1,seed(end+1,:)=[((ln*z+cf*w0-ifdelta)/si)^2+((w0-wide)/sw)^2,z,w0];end %#ok<AGROW>
seed=sortrows(seed,1);radius=sw*sqrt(seed(2,1));all=[];
for w=ceil(wide-radius):floor(wide+radius)
 n=round((ifdelta-cf*w)/ln);
 for z=n-1:n+1,all(end+1,:)=[((ln*z+cf*w-ifdelta)/si)^2+((w-wide)/sw)^2,z,w];end %#ok<AGROW>
end
all=sortrows(all,1);integer=all(1,2:3);costs=all(1:2,1);
end
