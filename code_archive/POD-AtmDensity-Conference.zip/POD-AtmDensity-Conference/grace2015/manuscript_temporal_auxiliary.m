function manuscript_temporal_auxiliary(out)
% Auxiliary 10-minute single-spacecraft temporal integer experiment.
% Uses this run's raw design and common force reconstruction, never old arrays.
summary=struct;
for sat='AB'
 x=load(fullfile(out,[sat '_raw_design.mat']),'q');q=x.q;model=gnss_navigation(q,600,false);
 T0=gnss_condition_navigation(model,[],[]);splits=cell(2,1);
 for k=0:1
  qs=q;qs.good=qs.good & mod((0:numel(q.t)-1)',2)==k;
  m=gnss_navigation(qs,600,false);splits{k+1}=struct('B',m.B0+m.db,'Q',m.Q);clear m;
 end
 integers=gnss_resolve_temporal(q,model,splits);T1=gnss_condition_navigation(model,integers.H,integers.target);
 assisted=gnss_resolve_temporal(q,model);TP=gnss_condition_navigation(model,assisted.H,assisted.target);
 x=load(fullfile(out,[sat '_all_density.mat']),'d','bias');
 density=gnss_density_many(x.d,struct('T0',T0,'T1',T1,'TP',TP));
 support=q.t(sum(q.good,2)>=4);names=fieldnames(density);
 for j=1:numel(names)
  name=names{j};v=density.(name).values;v(:,4)=v(:,4)-x.bias/1e-6*v(:,6);mask=false(size(v,1),1);
  for e=1:size(v,1),t=v(e,1);ss=support(support>=t-600&support<t+600);mask(e)=numel(ss)>=108&&max(diff([t-600;ss(:);t+600]))<=30;end
  density.(name).values=v;density.(name).supported=mask;nav=eval(name); %#ok<EVLDIR>
  p=ppval(gnss_hermite(x.d.pod_t,x.d.pod_r,x.d.pod_v),nav.values(:,1)')';
  summary.(sat).(name)=struct('orbit_RMS_m',rms(vecnorm(nav.values(:,2:4)-p,2,2)),'density_RMS',rms(v(mask,2)-v(mask,4)));
 end
 summary.(sat).GNSS_integer_links=size(integers.H,1);summary.(sat).POD_integer_links=size(assisted.H,1);
 save(fullfile(out,[sat '_temporal_auxiliary.mat']),'T0','T1','TP','integers','assisted','density','-v7.3');
end
f=fopen(fullfile(out,'temporal_auxiliary_metrics.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
