function out=read_grace_gps1b(path,day)
% Original big-endian GRACE GPS1B RL02 binary. Phase fields are metres.
% Rows: seconds since GPS midnight, PRN, quality, 16 presence-masked fields.
if nargin<2, day=datetime(2015,3,15); end
origin=seconds(day-datetime(2000,1,1,12,0,0));
f=fopen(path,'r','ieee-be');assert(f>=0,'Cannot open GPS1B');c=onCleanup(@()fclose(f));
header={};found=false;
while ~feof(f)
 s=fgetl(f);header{end+1}=s; %#ok<AGROW>
 if contains(s,'END OF HEADER'),found=true;break,end
end
assert(found,'Missing GPS1B header terminator');
a=nan(100000,19);n=0;records=0;
while true
 sec=fread(f,1,'int32=>double');if isempty(sec),break,end
 us=fread(f,1,'int32=>double');meta=fread(f,3,'uint8=>double');
 prod=fread(f,1,'uint16=>uint16');qual=fread(f,1,'uint8=>double');
 assert(~isempty(us)&&numel(meta)==3&&~isempty(prod)&&~isempty(qual),'Truncated GPS1B header');
 v=nan(1,16);
 for j=0:15
  if bitget(prod,j+1)
   if j<6 || ismember(j,[12 13]),typ='double=>double';else,typ='uint16=>double';end
   z=fread(f,1,typ);assert(~isempty(z),'Truncated GPS1B field');v(j+1)=z;
  end
 end
 records=records+1;
 if meta(3)==0 && meta(2)>=1 && meta(2)<=32
  n=n+1;a(n,:)=[sec+us*1e-6-origin,meta(2),qual,v];
 end
end
out=struct('values',a(1:n,:),'header',{header},'records',records,'time_system','GPS');
end
