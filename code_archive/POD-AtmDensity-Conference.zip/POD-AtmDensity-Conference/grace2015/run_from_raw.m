function report=run_from_raw(satellites,stopSeconds)
% Complete raw observation/model-file path; generated outputs are never inputs.
% 2015-03-15 only. Default full-day A/B. Pilot example: run_from_raw('A',3600).
% Validation and scientific limitations are documented in VALIDATION.md.
if nargin<1,satellites='AB';end;if nargin<2,stopSeconds=86400;end
assert(stopSeconds>=2400&&stopSeconds<=86400);root=fileparts(mfilename('fullpath'));raw=fullfile(root,'raw');models=fullfile(root,'models');
out=fullfile(root,['generated_' datestr(now,'yyyymmdd_HHMMSS')]);assert(~exist(out,'dir'));mkdir(out);diary(fullfile(out,'run.log'));cleanup=onCleanup(@()diary('off'));report=struct;
fprintf('RAW PIPELINE: no prepared-array input; outputs %s\n',out);
sp3=read_jaxa_sp3(fullfile(raw,'madoca18360.sp3.gz'));bias=read_jaxa_code_bias(fullfile(raw,'ssr18360.rtcm3'));
t=(0:10:stopSeconds-1)';tx=raw_transmitters(sp3,t,models);clear sp3;
for sat=satellites
 tic;fprintf('GRACE %s: raw observations and independent orbit\n',sat);obs=raw_observation_grid(sat,raw,bias);fields=fieldnames(obs);
 for k=1:numel(fields),obs.(fields{k})=obs.(fields{k})(1:numel(t),:);end
 [rot,age]=raw_attitude(sat,t,raw);[receiver,ants]=raw_antennas(sat,models);bootstrap=raw_bootstrap(obs,tx,rot,receiver,ants,age);
 fprintf('GRACE %s: raw force/measurement preparation\n',sat);q=raw_navigation_design(sat,obs,tx,bootstrap,receiver,ants,raw,models);
 fprintf('GRACE %s: 10-minute reduced dynamics, temporal integer resolution\n',sat);model=gnss_navigation(q,600,false);float=gnss_condition_navigation(model,[],[]);integers=gnss_resolve_temporal(q,model);nav=gnss_condition_navigation(model,integers.H,integers.target);
 save(fullfile(out,[sat '_navigation.mat']),'bootstrap','float','integers','nav','-v7');
 % Recompute all force terms on this run's fitted absolute orbit, sampled at 5s.
 z=float.values;ii=unique([1:5:size(z,1),size(z,1),find(diff(z(:,1))>1)',find(diff(z(:,1))>1)'+1]);
 frot=raw_attitude(sat,z(ii,1),raw);d=raw_forces(sat,z(ii,1),z(ii,2:4),z(ii,5:7),frot,models);
 pod=raw_pod_reference(sat,raw,models);d.pod_t=pod.t;d.pod_r=pod.r;d.pod_v=pod.v;
 acc=read_grace_ascii(fullfile(raw,sprintf('ACC1B_2015-03-15_%s_02.asc',sat)),[1 3 4 5]);
 ax=interp1(acc.values(:,1),acc.values(:,2),d.t,'spline');radbody=reshape(pagemtimes(permute(frot,[2 1 3]),reshape(d.rad',3,1,[])),3,[])';abody=reshape(pagemtimes(permute(frot,[2 1 3]),reshape((d.K.*d.drag)',3,1,[])),3,[])';
 % Uncalibrated ACC reference: preserve its unknown absolute bias explicitly.
 d.acc_rho=(ax-radbody(:,1))./abody(:,1);d.acc_bias_template_rho=1e-6./abody(:,1);
 fprintf('GRACE %s: 20-minute density retrieval\n',sat);density=gnss_density(d,nav.values);support=q.t(sum(q.good,2)>=4);keep=false(size(density.values,1),1);
 for j=1:numel(keep)
  center=density.values(j,1);ss=support(support>=center-600&support<center+600);keep(j)=numel(ss)>=108&&max(diff([center-600;ss(:);center+600]))<=30;
 end
 density.supported=keep;density=calibrate_acc_reference(density);save(fullfile(out,[sat '_density.mat']),'density','-v7');
 R=gnss_hermite(pod.t,pod.r,pod.v);err=vecnorm(nav.values(:,2:4)-ppval(R,nav.values(:,1)')',2,2);v=density.values;good=density.supported&all(isfinite(v(:,2:4)),2);a=v(good,2);b=v(good,4);C=corrcoef(a,b);
 report.(sat)=struct('orbit_RMS_m',sqrt(mean(err.^2)),'partial_integer_links',size(integers.H,1),'density_ACC_correlation',C(1,2),'density_ACC_RMS_kg_m3',sqrt(mean((a-b).^2)),'density_ACC_demeaned_RMS_kg_m3',std(a-b,1),'density_centers',numel(a),'seconds',toc,'ACC_bias_mps2',density.ACC_bias_mps2,'ACC_reference','one constant body-X offset recomputed from GNV control; no GNSS density used');
 writematrix(v,fullfile(out,[sat '_density.csv']));writematrix(v(good,:),fullfile(out,[sat '_supported_density.csv']));disp(report.(sat));
end
f=fopen(fullfile(out,'metrics.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
plot_raw_results(out);fprintf('Generated results: %s\n',out);
end
