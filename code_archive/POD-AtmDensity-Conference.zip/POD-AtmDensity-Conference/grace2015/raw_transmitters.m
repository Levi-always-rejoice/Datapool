function out=raw_transmitters(sp3,t,models)
% Four-point local cubic position; bracketing linear clocks, no gap bridging.
t=t(:)-.075;N=numel(t);assert(isequal(sp3.t,(0:86399)'),'Requires daily 1-Hz SP3');
k=floor(t);ix=k+(-1:2);ok=ix(:,1)>=0&ix(:,4)<86400;ix=max(0,min(86399,ix))+1;u=t-k;
w=[-u.*(u-1).*(u-2)/6,(u+1).*(u-1).*(u-2)/2,-(u+1).*u.*(u-2)/2,(u+1).*u.*(u-1)/6];
dw=[-(3*u.^2-6*u+2)/6,(3*u.^2-4*u-1)/2,-(3*u.^2-2*u-2)/2,(3*u.^2-1)/6];ddw=[1-u,3*u-2,1-3*u,u];
R=raw_earth_rotation(t,models);Rp=raw_earth_rotation(t+1,models);Rm=raw_earth_rotation(t-1,models);
out=struct('ps',nan(N,33,3),'vs',nan(N,33,3),'acc',nan(N,33,3),'clock',nan(N,33),'clock_rate',nan(N,33));
for p=2:33
 good=ok&all(isfinite(reshape(sp3.clock(ix(:),p),N,4)),2);r=zeros(N,3);v=r;a=r;
 for j=1:4,z=reshape(sp3.position(ix(:,j),p,:),N,3);r=r+w(:,j).*z;v=v+dw(:,j).*z;a=a+ddw(:,j).*z;end
 center=rotate(R,r);plus=rotate(Rp,r+v+.5*a);minus=rotate(Rm,r-v+.5*a);center(~good,:)=NaN;
 out.ps(:,p,:)=center;out.vs(:,p,:)=(plus-minus)/2;out.acc(:,p,:)=plus-2*center+minus;
 c=(1-u).*sp3.clock(ix(:,2),p)+u.*sp3.clock(ix(:,3),p);c(~good)=NaN;out.clock(:,p)=c;
 out.clock_rate(:,p)=sp3.clock(ix(:,3),p)-sp3.clock(ix(:,2),p);
end
[out.sun,~]=raw_ephemerides(t,models);
end
function r=rotate(R,x)
r=reshape(pagemtimes(permute(R,[2 1 3]),reshape(x',3,1,[])),3,[])';
end

