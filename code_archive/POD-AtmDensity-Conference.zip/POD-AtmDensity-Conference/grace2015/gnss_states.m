function st=gnss_states(block,t)
% 6 x number-of-basis-columns x epochs; native MATLAB ODE dense output.
t=t(:)';st=zeros(6,block.ncol,numel(t));le=t<=block.pivot;
if any(le),st(:,:,le)=reshape(deval(block.left,t(le)),6,block.ncol,[]);end
if any(~le),st(:,:,~le)=reshape(deval(block.right,t(~le)),6,block.ncol,[]);end
end
