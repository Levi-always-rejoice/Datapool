function nav=raw_bootstrap(obs,cache,rot,receiver,ants,attitudeAge)
% Independent GPS code/carrier EKF: original J2 + empirical-acceleration bootstrap.
% No GNV/POD, accelerometer, saved ambiguities, or force arrays are read.
N=numel(obs.rx);NS=43;x=zeros(NS,1);P0=diag([ones(1,6)*1e4,ones(1,3)*1e-6,1e8,ones(1,33)*1e8]);P=P0;
if nargin<6,attitudeAge=zeros(N,1);end
track=-ones(33,1);wind=nan(33,1);previous=0;firsti=0;active=false;segment=0;
nav=struct('t',obs.rx,'r',nan(N,3),'v',nan(N,3),'clock',nan(N,1),'segment',zeros(N,1),'events',{{}});
have=~cellfun(@isempty,ants);alpha=1575.42^2/(1575.42^2-1227.60^2);beta=-1227.60^2/(1575.42^2-1227.60^2);
for i=1:N
 if attitudeAge(i)>5,continue,end
 try
  if ~active
   p=find(isfinite(obs.code(i,:))'&isfinite(cache.clock(i,:))'&obs.snr(i,:)'>10&have);
   if numel(p)<4,continue,end
   x(:)=0;
   for it=1:12
    [base,~,h]=raw_observation_model(i,x(1:3),p,rot(:,:,i),receiver,ants,cache);
    res=obs.code(i,p)'-base-x(10);delta=[h,ones(numel(p),1)]\res;x(1:3)=x(1:3)+delta(1:3);x(10)=x(10)+delta(4);
    if norm(delta)<1e-4,break,end
   end
   assert(norm(x(1:3))>6e6&&norm(x(1:3))<9e6,'Invalid SPP initialization');
   if firsti==0,first=x;firsti=i;continue,end
   dt=obs.rx(i)-obs.rx(firsti);x(4:6)=(x(1:3)-first(1:3))/dt+.5*accel(x(1:3),zeros(3,1))*dt;
   P=P0;wind(:)=NaN;active=true;segment=segment+1;
  elseif previous>0
   [x,P]=propagate(x,P,obs.rx(i)-obs.rx(previous));
  end
  p=find(isfinite(obs.phase(i,:))'&isfinite(cache.clock(i,:))'&have);
  if numel(p)<4,previous=i;continue,end
  [base,ph,h,el,ww]=raw_observation_model(i,x(1:3),p,rot(:,:,i),receiver,ants,cache,wind);
  keep=el>deg2rad(10);p=p(keep);base=base(keep);ph=ph(keep);h=h(keep,:);el=el(keep);ww=ww(keep);
  if numel(p)<4,previous=i;continue,end
  continuous=track(p)==obs.ids(i,p)';innovation=obs.phase(i,p)'-ph-x(10)-x(10+p);
  common=0;if sum(continuous)>=4,common=median(innovation(continuous));end
  rejected=continuous&abs(innovation-common)>1;track(p(rejected))=-1;x(10)=x(10)+common;
  H=[];res=[];vari=[];
  for j=1:numel(p)
   pr=p(j);ai=10+pr;
   if track(pr)~=obs.ids(i,pr)
    x(ai)=obs.phase(i,pr)-ph(j)-x(10);P(ai,:)=0;P(:,ai)=0;P(ai,ai)=1e4;track(pr)=obs.ids(i,pr);
   end
   row=zeros(1,NS);row(1:3)=h(j,:);row(10)=1;row(ai)=1;
   if ~rejected(j)
    H(end+1,:)=row;res(end+1,1)=obs.phase(i,pr)-ph(j)-x(10)-x(ai);vari(end+1,1)=(.005*hypot(alpha,beta)/max(sin(el(j)),.25))^2;
   end
   if isfinite(obs.code(i,pr))
    v=obs.code(i,pr)-base(j)-x(10);
    if abs(v)<10
     row(ai)=0;H(end+1,:)=row;res(end+1,1)=v;vari(end+1,1)=(4.5/max(sin(el(j)),.25))^2*max(1,abs(v)/3);
    end
   end
  end
  if isempty(H),previous=i;continue,end
  S=H*P*H'+diag(vari);gain=(S\(H*P))';change=gain*res;x=x+change;J=eye(NS)-gain*H;P=J*P*J'+(gain.*vari')*gain';P=(P+P')/2;
  assert(all(isfinite(x))&&abs(x(10)/299792458)<.5,'Invalid navigation update');
  post=obs.phase(i,p)'-ph-x(10)-x(10+p)-h*change(1:3);track(p(abs(post)>.5))=-1;
  wind(p)=ww;previous=i;nav.r(i,:)=x(1:3);nav.v(i,:)=x(4:6);nav.clock(i)=x(10)/299792458;nav.segment(i)=segment;
 catch e
  nav.events{end+1}=struct('t',obs.rx(i),'reason',e.message);active=false;previous=0;firsti=0;track(:)=-1;
 end
 if mod(i,1000)==0,fprintf('  raw orbit %d/%d, valid %d\n',i,N,sum(isfinite(nav.clock)));end
end
assert(sum(isfinite(nav.clock))>N*.8,'Too few usable bootstrap epochs; inspect events');
end
function a=accel(r,emp)
mu=3.986004418e14;rr=norm(r);z=r(3)/rr;j2=1.5*1.08262668e-3*mu*6378136.3^2/rr^5*r.*[5*z*z-1;5*z*z-1;5*z*z-3];a=-mu*r/rr^3+j2+emp;
end
function [x,P]=propagate(x,P,dt)
h=dt/max(1,ceil(dt/5));
for j=1:max(1,ceil(dt/5))
 y=x(1:6);fun=@(q)[q(4:6);accel(q(1:3),x(7:9))];k1=fun(y);k2=fun(y+h*k1/2);k3=fun(y+h*k2/2);k4=fun(y+h*k3);x(1:6)=y+h*(k1+2*k2+2*k3+k4)/6;
end
A=zeros(9);A(1:3,4:6)=eye(3);A(4:6,1:3)=gnss_gradient(x(1:3));A(4:6,7:9)=eye(3);D=A*dt;F=eye(43);F(1:9,1:9)=eye(9)+D+D^2/2+D^3/6;P=F*P*F';
Q=[dt^5/20 dt^4/8 dt^3/6;dt^4/8 dt^3/3 dt^2/2;dt^3/6 dt^2/2 dt]*(5e-6)^2;
for j=1:3,ii=[j j+3 j+6];P(ii,ii)=P(ii,ii)+Q;end
P(10,10)=P(10,10)+1e6;
end
