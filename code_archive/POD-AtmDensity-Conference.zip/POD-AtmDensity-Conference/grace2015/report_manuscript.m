function report=report_manuscript(out)
% Regenerated manuscript figures, matched-support statistics and discrepancy flags.
set(groot,'defaultLineLineWidth',1.6);
root=fileparts(mfilename('fullpath'));raw=fullfile(root,'raw');models=fullfile(root,'models');
a=load(fullfile(out,'A_all_density.mat'));b=load(fullfile(out,'B_all_density.mat'));
na=load(fullfile(out,'A_branches.mat'));nb=load(fullfile(out,'B_branches.mat'));
[t,ia,ib]=intersect(a.density.S.values(:,1),b.density.S.values(:,1));utc=(t-16)/3600;
orig=a.maskOriginal(ia)&b.maskOriginal(ib);fixed=a.maskFixed(ia)&b.maskFixed(ib);
windows={true(size(t)),utc>=3.25&utc<4.25,utc>=9+40/60&utc<10+25/60,utc>=20.5&utc<23};wn={'day','S1','S2','late'};
ra=interp1(a.d.t,a.d.r,t,'spline');rb=interp1(b.d.t,b.d.r,t,'spline');e=(rb-ra)./vecnorm(rb-ra,2,2);
ka=sum(e.*interp1(a.d.t,a.d.K.*a.d.drag,t,'spline'),2);kb=sum(e.*interp1(b.d.t,b.d.K.*b.d.drag,t,'spline'),2);
names={'S','F','R','O','M','P'};report=struct;
for j=1:numel(names)
 name=names{j};av=a.density.(name).values(ia,:);bv=b.density.(name).values(ib,:);
 if any(strcmp(name,{'M','P'})),mask=fixed;else,mask=orig;end
 report.(name).orbit_A_RMS_m=orbit_error(na.(name),a.d);report.(name).orbit_B_RMS_m=orbit_error(nb.(name),b.d);
 for k=1:numel(windows)
  use=mask&windows{k}&all(isfinite([av(:,2:4),bv(:,2:4)]),2);
  report.(name).(wn{k})=statistics(av,bv,ka,kb,use);
  % Same fixed-only support makes Table III/IV comparisons interpretable.
  use=fixed&windows{k}&all(isfinite([av(:,2:4),bv(:,2:4)]),2);
  report.(name).(['fixed_' wn{k}])=statistics(av,bv,ka,kb,use);
 end
end
% Raw KBR: one POD-defined constant per tracking segment, shared by all methods.
k=read_grace_ascii(fullfile(raw,'KBR1B_2015-03-15_X_02.asc'),1:16);k=k.values;k=k(k(:,16)==0,:);
kr=k(:,2)+k(:,6)+k(:,9);segments=cumsum([0;diff(k(:,1))>5.1|abs(diff(kr))>100]);
valid=ismember(k(:,1),na.R.values(:,1))&ismember(k(:,1),nb.R.values(:,1));k=k(valid,:);kr=kr(valid);segments=segments(valid);kt=k(:,1);
pa=raw_pod_reference('A',raw,models);pb=raw_pod_reference('B',raw,models);
pr=vecnorm(ppval(gnss_hermite(pa.t,pa.r,pa.v),kt')'-ppval(gnss_hermite(pb.t,pb.r,pb.v),kt')',2,2);
aligned=kr;for seg=unique(segments)',ii=segments==seg;aligned(ii)=kr(ii)+mean(pr(ii)-kr(ii));end
range=struct('t',kt,'POD',pr-aligned,'segments',segments);[yes,loc]=ismember(kt,t);
for j=1:numel(names)
 name=names{j};x=na.(name).values;y=nb.(name).values;
 rr=vecnorm(interp1(x(:,1),x(:,2:4),kt)-interp1(y(:,1),y(:,2:4),kt),2,2);range.(name)=rr-aligned;
 for z=1:2
  if z==1,mask=orig;prefix='original';else,mask=fixed;prefix='fixed';end
  use=false(size(kt));use(yes)=mask(loc(yes));
  % F/R range evaluation is on common navigation/KBR epochs, not the much
  % narrower set of centers possessing complete 20-minute density support.
  if z==1,use=isfinite(range.(name))&isfinite(range.POD);end
  report.(name).([prefix '_range_RMS_mm'])=1e3*rms(range.(name)(use));report.(name).([prefix '_range_epochs'])=nnz(use);
  report.(name).([prefix '_POD_range_RMS_mm'])=1e3*rms(range.POD(use));
 end
end
save(fullfile(out,'range_comparison.mat'),'range');writematrix([kt,range.F,range.R,range.P,range.POD],fullfile(out,'range_comparison.csv'));
ri=load(fullfile(out,'R_integer_validation.mat'));pi=load(fullfile(out,'P_integer_audit.mat'));
report.integer=struct('R_candidates',ri.integers.WL_candidates,'R_rank',ri.integers.independent_rank,'R_fixed',ri.integers.fixed_count,'P_relations',pi.audit.accepted_relations,'P_rank',pi.audit.independent_rank);
report.ACC_bias_A_mps2=a.bias;report.ACC_bias_B_mps2=b.bias;
% Directly usable equivalents of manuscript Tables II--IV.
rows=[];for name={'F','R'},s=report.(name{1}).day;rows(end+1,:)=[s.centers,s.A_RMS,s.A_r,s.B_RMS,s.B_r,s.difference_RMS,s.difference_r,s.projected_drag_RMS_mps2,report.(name{1}).original_range_RMS_mm];end %#ok<AGROW>
writetable(array2table(rows,'RowNames',{'F','R'},'VariableNames',{'Centers','A_RMS','A_r','B_RMS','B_r','Difference_RMS','Difference_r','ProjectedDrag_RMS','Range_RMS_mm'}),fullfile(out,'tableII_float_integer.csv'),'WriteRowNames',true);
rows=[];for name={'O','M','P'},s=report.(name{1}).fixed_late;rows(end+1,:)=[s.centers,s.difference_RMS,s.difference_r];end %#ok<AGROW>
writetable(array2table(rows,'RowNames',{'O','M','P'},'VariableNames',{'Centers','Difference_RMS','Difference_r'}),fullfile(out,'tableIII_offset_mask_control.csv'),'WriteRowNames',true);
rows=[];for name={'S1','S2','day'},s=report.P.(name{1});v=report.S.(['fixed_' name{1}]);rows(end+1,:)=[s.centers,s.A_RMS,s.B_RMS,s.difference_RMS,v.A_RMS,v.B_RMS,v.difference_RMS,s.POD_difference_RMS,s.zero_difference_RMS,s.difference_r,s.gain,s.residual_correlation,s.projected_drag_RMS_mps2];end %#ok<AGROW>
writetable(array2table(rows,'RowNames',{'S1','S2','day'},'VariableNames',{'Centers','P_A_RMS','P_B_RMS','P_diff_RMS','S_A_RMS','S_B_RMS','S_diff_RMS','POD_diff_RMS','Zero_diff_RMS','P_diff_r','P_gain','Residual_r','ProjectedDrag_RMS'}),fullfile(out,'tableIV_segment_cancellation.csv'),'WriteRowNames',true);
f=fopen(fullfile(out,'manuscript_metrics.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
% Explicit manuscript targets are validation data, never estimator inputs.
metric={};expected=[];actual=[];kind={};
add('S A density RMS',3.26e-13,report.S.day.A_RMS,'RMS');add('S B density RMS',3.76e-13,report.S.day.B_RMS,'RMS');
add('S A correlation',.890,report.S.day.A_r,'correlation');add('S B correlation',.854,report.S.day.B_r,'correlation');
add('S A orbit RMS',.0696,report.S.orbit_A_RMS_m,'RMS');add('S B orbit RMS',.0916,report.S.orbit_B_RMS_m,'RMS');
add('F range RMS mm',29.206,report.F.original_range_RMS_mm,'RMS');add('R range RMS mm',17.394,report.R.original_range_RMS_mm,'RMS');
add('F differential density RMS',22.88e-14,report.F.day.difference_RMS,'RMS');add('R differential density RMS',21.23e-14,report.R.day.difference_RMS,'RMS');
add('R density difference correlation',.162,report.R.day.difference_r,'correlation');
add('P fixed constraints',358,report.integer.P_rank,'count');add('R fixed constraints',188,report.integer.R_fixed,'count');
add('P supported centers',35916,report.P.day.centers,'count');add('P day density difference RMS',5.52e-14,report.P.day.difference_RMS,'RMS');
add('P S1 density difference RMS',1.76e-14,report.P.S1.difference_RMS,'RMS');add('P S2 density difference RMS',2.49e-14,report.P.S2.difference_RMS,'RMS');
add('P day density difference correlation',.497,report.P.day.difference_r,'correlation');add('P S1 correlation',.899,report.P.S1.difference_r,'correlation');add('P S2 correlation',.884,report.P.S2.difference_r,'correlation');
add('P fixed-support range RMS mm',1.940,report.P.fixed_range_RMS_mm,'RMS');
add('O matched late RMS',6.960e-14,report.O.fixed_late.difference_RMS,'RMS');add('M matched late RMS',5.091e-14,report.M.fixed_late.difference_RMS,'RMS');add('P matched late RMS',4.152e-14,report.P.fixed_late.difference_RMS,'RMS');
relative=abs(actual-expected)./abs(expected);substantial=relative>.15;
for j=1:numel(metric),if strcmp(kind{j},'correlation'),substantial(j)=abs(actual(j)-expected(j))>.05;elseif strcmp(kind{j},'count'),substantial(j)=relative(j)>.10;end,end
T=table(metric(:),expected(:),actual(:),relative(:),substantial(:),'VariableNames',{'Metric','Manuscript','NativeRawMATLAB','RelativeDifference','Investigate'});writetable(T,fullfile(out,'manuscript_comparison.csv'));
f=fopen(fullfile(out,'REPRODUCTION_REVIEW.md'),'w');fprintf(f,'# Native raw-input reproduction review\n\n%d of %d monitored quantities exceed diagnostic thresholds (15%% RMS, 0.05 correlation, 10%% counts). These are investigation triggers, not statistical equivalence tests.\n\n',nnz(substantial),numel(substantial));
fprintf(f,'| Metric | Paper | New raw MATLAB | Investigate |\n|---|---:|---:|---|\n');for j=1:numel(metric),fprintf(f,'| %s | %.7g | %.7g | %d |\n',metric{j},expected(j),actual(j),substantial(j));end
fprintf(f,'\nThe raw package regenerates radiation, unit-density aerodynamic forces, atmosphere temperature/winds and ACC calibration. The paper retained legacy force/effective-aerodynamic tables and a legacy ACC bias. Changes in these inputs must be assessed alongside observation support and integer decisions; numerical agreement alone does not establish equivalence.\n');fclose(f);
displayMask=false(size(kt));displayMask(yes)=fixed(loc(yes));range.P(~displayMask)=NaN;
gap=[false;diff(kt)>5.1|diff(segments)~=0];for name=[names,{'POD'}],range.(name{1})(gap)=NaN;end
make_figures(out,t,a,b,ia,ib,orig,fixed,range);
 function add(label,target,value,type),metric{end+1}=label;expected(end+1)=target;actual(end+1)=value;kind{end+1}=type;end
end
function x=orbit_error(nav,d)
p=ppval(gnss_hermite(d.pod_t,d.pod_r,d.pod_v),nav.values(:,1)')';x=rms(vecnorm(nav.values(:,2:4)-p,2,2));
end
function s=statistics(a,b,ka,kb,use)
a=a(use,:);b=b(use,:);ka=ka(use);kb=kb(use);
dg=b(:,2)-a(:,2);da=b(:,4)-a(:,4);dp=b(:,3)-a(:,3);ea=a(:,2)-a(:,4);eb=b(:,2)-b(:,4);
s=struct('centers',nnz(use),'A_RMS',rms(ea),'B_RMS',rms(eb),'A_r',cor(a(:,2),a(:,4)),'B_r',cor(b(:,2),b(:,4)),...
 'difference_RMS',rms(dg-da),'difference_r',cor(dg,da),'POD_difference_RMS',rms(dp-da),'zero_difference_RMS',rms(da),'residual_correlation',cor(ea,eb),...
 'projected_drag_RMS_mps2',rms(kb.*eb-ka.*ea),'gain',(da-mean(da))\(dg-mean(dg)));
end
function x=cor(a,b),if numel(a)<3,x=NaN;else,c=corrcoef(a,b);x=c(1,2);end,end
function make_figures(out,t,a,b,ia,ib,orig,fixed,range)
u=(t-16)/3600;set(groot,'defaultFigureVisible','off','defaultAxesColorOrder',[0 .45 .7;.85 .33 .1;.1 .1 .1]);
fig=figure('Position',[50 50 1300 700]);tiledlayout(2,1);
for j=1:2,if j==1,v=a.density.S.values(ia,:);sat='A';else,v=b.density.S.values(ib,:);sat='B';end
 nexttile;v(~orig,2:4)=NaN;plot(u,v(:,[2 3 4])*1e12);grid on;ylabel('Density (10^{-12} kg/m^3)');title(['GRACE ' sat ', single-satellite S']);legend('GNSS','POD control','ACC');xlim([0 24]);end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'figure1_single_satellite.png'),'Resolution',160);close(fig);
av=a.density.P.values(ia,:);bv=b.density.P.values(ib,:);diffs=bv(:,2:4)-av(:,2:4);diffs(~fixed,:)=NaN;
fig=figure('Position',[50 50 1300 650]);tiledlayout(2,1);limits=[3.25 4.25;9+40/60 10+25/60];
for j=1:2,nexttile;plot(u,diffs*1e12);xlim(limits(j,:));grid on;ylabel('\Delta density (10^{-12} kg/m^3)');legend('Integer-conditioned P','POD control','ACC');end
xlabel('UTC hour');exportgraphics(fig,fullfile(out,'figure2_differential_segments.png'),'Resolution',160);close(fig);
fig=figure('Position',[50 50 1300 650]);tiledlayout(2,1);err=[av(:,2)-av(:,4),bv(:,2)-bv(:,4)];err(~fixed,:)=NaN;
for j=1:2,nexttile;plot(u,err*1e12);xlim(limits(j,:));grid on;ylabel('Density error (10^{-12})');legend('A minus ACC','B minus ACC');end
xlabel('UTC hour');exportgraphics(fig,fullfile(out,'figure3_residual_cancellation.png'),'Resolution',160);close(fig);
fig=figure('Position',[50 50 1300 700]);tiledlayout(2,1);nexttile;plot(u,diffs*1e12);xlim([0 24]);ylim([-1 1]);grid on;ylabel('\Delta density (10^{-12} kg/m^3)');legend('P','POD','ACC');
nexttile;stairs(u,double(fixed));ylim([-.1 1.1]);xlim([0 24]);ylabel('Fixed-only supported');xlabel('UTC hour');grid on;exportgraphics(fig,fullfile(out,'figure4_full_day_coverage.png'),'Resolution',160);close(fig);
fig=figure('Position',[50 50 1300 750]);tiledlayout(2,1);x=(range.t-16)/3600;nexttile;plot(x,[range.F,range.R,range.POD]*1e3);legend('Float F','GNSS-only integer R','POD');ylabel('Range minus KBR (mm)');grid on;
nexttile;plot(x,[range.P,range.POD]*1e3);ylim([-20 20]);legend('POD-assisted integer P','POD');ylabel('Range minus KBR (mm)');xlabel('UTC hour');grid on;exportgraphics(fig,fullfile(out,'range_comparison.png'),'Resolution',160);close(fig);
end
