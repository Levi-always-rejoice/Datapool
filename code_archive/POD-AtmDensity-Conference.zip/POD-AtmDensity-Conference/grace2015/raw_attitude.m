function [R,age]=raw_attitude(sat,t,raw)
% Scalar-first SCA quaternion, active SRF->CRF, shortest-path SLERP.
persistent savedRoot tables
if isempty(savedRoot)||~strcmp(savedRoot,raw),savedRoot=raw;tables=struct;end
if ~isfield(tables,sat),z=read_grace_ascii(fullfile(raw,sprintf('SCA1B_2015-03-15_%s_02.asc',sat)),[1 4 5 6 7]);tables.(sat)=z.values;end
a=tables.(sat);t=t(:);assert(all(t>=a(1,1)&t<=a(end,1)),'SCA coverage missing');
ii=discretize(t,a(:,1));ii(t==a(end,1))=size(a,1)-1;
next=ii+1;exact=t==a(ii,1);next(exact)=ii(exact);age=abs(a(next,1)-t);
u=(t-a(ii,1))./(a(ii+1,1)-a(ii,1));q1=a(ii,2:5);q2=a(ii+1,2:5);q1=q1./vecnorm(q1,2,2);q2=q2./vecnorm(q2,2,2);
dotq=sum(q1.*q2,2);q2(dotq<0,:)=-q2(dotq<0,:);dotq=abs(dotq);ang=acos(min(dotq,1));q=(1-u).*q1+u.*q2;use=ang>1e-7;
q(use,:)=(sin((1-u(use)).*ang(use)).*q1(use,:)+sin(u(use).*ang(use)).*q2(use,:))./sin(ang(use));q=q./vecnorm(q,2,2);
R=zeros(3,3,numel(t));
for k=1:numel(t)
 w=q(k,1);x=q(k,2);y=q(k,3);z=q(k,4);R(:,:,k)=[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w);2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w);2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)];
end
end
