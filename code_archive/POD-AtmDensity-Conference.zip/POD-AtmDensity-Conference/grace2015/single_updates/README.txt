GRACE 2015-03-15: single-satellite GPS product control
==================================================
Wei identified the GPS real-time products as a major source of the 15-18 UTC
single-satellite discrepancy. This native MATLAB control tests that diagnosis.

RUN
  out = run_grace_single_updates;
The default rebuilds the existing raw-input 2015 route and runs this control.
To continue an already generated updated run:
  out = run_grace_single_updates(updated_run_folder);
To also run the earlier screening/smoothing controls:
  out = run_grace_single_updates(updated_run_folder, true);
run_all includes the default product control.

CONTROL
The original S branch is compared with the same estimator after replacing GPS
transmitter positions/clocks by ESA final products. Native GPS1B observations,
10-second sampling, tracking labels, phase mask, 20-minute dynamic blocks,
state continuity, force/geometry linearization, antenna model, original SSR
code-bias convention, and 20-minute moving density operator are held the same.
Associated GPS LOS and observation-model terms are recomputed. Receiver clocks
and float track offsets are re-estimated. No new screening, extra smoothing,
fitted scale, phase lag, demeaning or ACC tuning is added to this control.
The same code admission rule and weights act on product-corrected residuals;
any resulting admission changes are explicitly counted in the JSON.

Both spacecraft are solved separately. Spacecraft POD, KBR and accelerometers
do not constrain either navigation solution. The initial/reference spacecraft
orbit remains the original independent JAXA code/carrier geometry in this
controlled substitution; this is not a separately optimized final-PPP pipeline.
Absolute ambiguities in this S test are FLOAT tracking offsets, not claimed
integer-resolved PPP. Differential integer fixing is a separate experiment.

FINAL PRODUCTS
Bundled original ESA0MGNFIN 5-minute SP3 and 30-second CLK for March 14-16
provide bracketing. Native MATLAB uses a ten-node orbit polynomial and linear
bracketing clock interpolation, with no clock extrapolation/gap bridging.
JAXA uses the existing 1-Hz SP3 reader and local interpolation. All frozen
admitted carrier measurements must have final-product coverage or the run fails.
The ESA control is POSTPROCESSED, not evidence of real-time performance.

EVALUATION
Identical force corrections from the independent GNSS reference and identical
20-minute operators are applied to both recovered spacecraft orbits. Official
POD supplies the external orbit/density comparison. ACC uses the unchanged
original POD-calibrated daily constant; it is not recalibrated to the new result.
Scores use paired supported epochs, without residual clipping. No preprocessed
estimator arrays are distributed; MAT files are created only by running MATLAB.

OTHER CONTROLS
The optional held-out phase screen improves real-time 15-18 UTC density RMS
by about 17% (A) and 20% (B), but does not remove the discrepancy. Its GRACE A local
40/90-minute injection response retains over 99.6% relative to the density
operator alone. Additional acceleration continuity improves apparent RMS more,
but attenuates those signals by about 17%/14%; it is a smoothing control, not
an unqualified measurement correction. These controls remain separate from
the product substitution and do not use differential integer information.

NUMERICAL RESULTS
A h15_18: n=10800; density RMS RT/final/POD = 5.80076546e-13 / 1.84269071e-13 / 1.35374822e-13 kg/m3; correlation RT/final/POD = 0.556460 / 0.962134 / 0.978965.
A day: n=80796; density RMS RT/final/POD = 3.22248996e-13 / 1.67870966e-13 / 1.09611624e-13 kg/m3; correlation RT/final/POD = 0.890057 / 0.971487 / 0.988269.
A rest: n=69996; density RMS RT/final/POD = 2.60669636e-13 / 1.65195939e-13 / 1.05075485e-13 kg/m3; correlation RT/final/POD = 0.930720 / 0.972769 / 0.989447.
A: orbit position RMS RT/final = 0.068055936 / 0.034637733 m. Phase count 61623; changes in the unchanged code admission test: 0.
B h15_18: n=9448; density RMS RT/final/POD = 7.36985024e-13 / 2.38738911e-13 / 1.26585916e-13 kg/m3; correlation RT/final/POD = 0.335283 / 0.936938 / 0.980996.
B day: n=75284; density RMS RT/final/POD = 3.70040477e-13 / 1.73690594e-13 / 1.05244358e-13 kg/m3; correlation RT/final/POD = 0.855181 / 0.969362 / 0.989138.
B rest: n=65836; density RMS RT/final/POD = 2.80418481e-13 / 1.62229495e-13 / 1.01815281e-13 kg/m3; correlation RT/final/POD = 0.918959 / 0.973736 / 0.990090.
B: orbit position RMS RT/final = 0.090519067 / 0.039710888 m. Phase count 56640; changes in the unchanged code admission test: 0.
