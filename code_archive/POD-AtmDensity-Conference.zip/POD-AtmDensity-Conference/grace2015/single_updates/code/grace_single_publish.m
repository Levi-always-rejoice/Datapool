function report=grace_single_publish(core,updated,work,out,variant)
if ~isfolder(out),mkdir(out);end;addpath(core,fullfile(core,'updates','code'));
set(groot,'defaultFigureVisible','off');report=struct('date','2015-03-15','variant',variant,'density_window_seconds',1200,'native_phase_interval_seconds',10,'POD_in_navigation',false,'integer_fixed',false);data=cell(2,1);
fig=figure('Position',[30 30 1500 900]);tl=tiledlayout(2,2,'TileSpacing','compact');
for s=1:2
 sat=char(64+s);old=readmatrix(fullfile(work,[sat '_old_day_density.csv']));new=readmatrix(fullfile(work,[sat '_' variant '_day_density.csv']));assert(isequal(old(:,1),new(:,1)));assert(max(abs(old(:,4)-new(:,4)))<1e-20);support=logical(old(:,8));t=(old(:,1)-16)/3600;
 data{s}=[old(:,1),old(:,2),new(:,2:4),support];writematrix(data{s},fullfile(out,[sat '_density_comparison.csv']));
 for k=1:3
  m=support;if k==2,m=m&t>=15&t<18;elseif k==3,m=m&(t<15|t>=18);end
  reg={'day','h15_18','rest'};names={'original','updated','POD'};v=[old(:,2),new(:,2),new(:,3)];ref=new(:,4);
  for j=1:3,c=corrcoef(v(m,j),ref(m));report.(sat).(reg{k}).(names{j})=struct('n',nnz(m),'RMS',rms(v(m,j)-ref(m)),'correlation',c(1,2),'bias',mean(v(m,j)-ref(m)));end
 end
 for k=1:2
  nexttile;v=[old(:,2),new(:,2),new(:,3),new(:,4)];v(~support,:)=NaN;hold on;
  plot(t,v(:,1)*1e12,'--','Color',[.65 .65 .65],'LineWidth',1.2);plot(t,v(:,2)*1e12,'Color',[0 .4 .75],'LineWidth',1.9);plot(t,v(:,3)*1e12,'Color',[.2 .6 .2],'LineWidth',1.3);plot(t,v(:,4)*1e12,'k','LineWidth',1.5);grid on;
  if k==1,xlim([0 24]);title(['GRACE ' sat ': full day']);else,xlim([15 18]);title(sprintf('GRACE %s: 15–18 UTC, r %.3f → %.3f',sat,report.(sat).h15_18.original.correlation,report.(sat).h15_18.updated.correlation));end
  ylabel('\rho (10^{-12} kg/m^3)');xlabel('UTC hour');legend('Original','Updated independent GNSS','POD control','ACC reference','Location','best');
 end
end
title(tl,'GRACE 2015-03-15 · single-receiver code/carrier navigation · 20-minute density · no additional display filtering');exportgraphics(fig,fullfile(out,'single_satellite_density_update.png'),'Resolution',150);close(fig);
fig=figure('Position',[30 30 1500 680]);tiledlayout(2,1);
for s=1:2
 d=data{s};t=(d(:,1)-16)/3600;m=logical(d(:,6));v=d(:,2:4)-d(:,5);v(~m,:)=NaN;nexttile;plot(t,v*1e12,'LineWidth',1.7);grid on;xlim([15 18]);ylabel('\rho - \rho_{ACC} (10^{-12} kg/m^3)');title(['GRACE ' char(64+s)]);legend('Original','Updated independent GNSS','POD control');
end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'density_residuals_15_18.png'),'Resolution',150);close(fig);
fig=figure('Position',[30 30 1500 960]);tiledlayout(3,2);
for s=1:2
 sat=char(64+s);ref=load(fullfile(updated,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d');old=readmatrix(fullfile(work,[sat '_old_orbit.csv']));z=load(fullfile(work,[sat '_' variant '_nav.mat']),'L');n=z.L.values;P=gnss_hermite(ref.d.pod_t,ref.d.pod_r,ref.d.pod_v);p=ppval(P,n(:,1)')';v=interp1(ref.d.pod_t,ref.d.pod_v,n(:,1),'spline');er=p./vecnorm(p,2,2);en=cross(p,v,2);en=en./vecnorm(en,2,2);et=cross(en,er,2);dr=n(:,2:4)-p;[yes,ii]=ismember(old(:,1),n(:,1));assert(all(yes));dold=old(:,2:4);frames={er,et,en};orbit=[old(:,1),dold,dr(ii,:)];writematrix(orbit,fullfile(out,[sat '_orbit_comparison.csv']));
 report.(sat).orbit_original_RMS_m=rms(vecnorm(dold,2,2));report.(sat).orbit_updated_RMS_m=rms(vecnorm(dr(ii,:),2,2));
 for k=1:3,nexttile((k-1)*2+s);f=frames{k};plot((old(:,1)-16)/3600,[sum(dold.*f(ii,:),2),sum(dr(ii,:).*f(ii,:),2)]*100,'LineWidth',1.5);grid on;xlim([0 24]);names={'Radial','Along-track','Cross-track'};ylabel([names{k} ' error (cm)']);title(['GRACE ' sat]);if k==1,legend('Original','Updated');end;end
end
xlabel('UTC hour, 2015-03-15; official POD used for evaluation only');exportgraphics(fig,fullfile(out,'single_satellite_orbit_update.png'),'Resolution',150);close(fig);
report.reference_note='Same matched epochs, ACC bias, geometry and density operator for before/after. Each receiver estimated separately without spacecraft POD, KBR, ACC, or the second spacecraft observations. Float ambiguities persist per tracking label; this is not claimed as independently fixed absolute PPP. No extra density smoothing, fitted gain, lag or offset removal.';
report.extra_navigation_acceleration_continuity=strcmp(variant,'continuous_robust');
if report.extra_navigation_acceleration_continuity,report.smoothing_caution='Navigation acceleration continuity adds smoothing even though the density operator is unchanged. GRACE A local injection tests show 40/90-minute signal attenuation of approximately 17/14 percent relative to the density operator alone.';end
f=fopen(fullfile(out,'comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
