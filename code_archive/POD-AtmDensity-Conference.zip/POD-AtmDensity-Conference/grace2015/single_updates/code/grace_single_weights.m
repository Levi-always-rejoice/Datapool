function report=grace_single_weights(core,source,out)
maxNumCompThreads(2);addpath(core,fullfile(core,'updates','code'));if ~isfolder(out),mkdir(out);end
report=struct;
for sat='AB'
 z=load(fullfile(source,[sat '_float_model.mat']),'model');base=z.model;clear z;q=base.q;assert(~any(startsWith(fieldnames(q),'pod_')));
 assign=mod(floor(q.t/300)+(0:32),4);folds=cell(4,1);allres=[];allsigma=[];
 for fold=0:3
  file=fullfile(out,sprintf('%s_single_fold%d.mat',sat,fold));
  if isfile(file),load(file,'p');else
   fprintf('Single %s: withhold GPS five-minute segments fold %d\n',sat,fold);
   training=q;held=q.good&assign==fold;training.good(held)=false;
   [model,profile]=gnss_long_code_profile(base,training,1200,true(size(q.t)),true);
   p=gnss_heldout_prediction(model,q,held,profile.B,profile.Q,0,numel(q.B0));
   p.support=profile.count(p.label)>=6;p=rmfield(p,'ambiguity_gradient');save(file,'p','-v7.3');clear model profile;
  end
  folds{fold+1}=p;m=p.support&isfinite(p.residual)&isfinite(p.prediction_variance);
  allres=[allres;p.residual(m)];allsigma=[allsigma;sqrt(p.prediction_variance(m)+p.measurement_variance(m))]; %#ok<AGROW>
 end
 standardized=allres./allsigma;scale=max(.1,1.4826*median(abs(standardized-median(standardized))));weights=ones(size(q.good));
 for f=1:4
  p=folds{f};m=p.support&isfinite(p.residual)&isfinite(p.prediction_variance);
  sigma=max(.003,scale*sqrt(p.prediction_variance(m)+p.measurement_variance(m)));
  ix=sub2ind(size(q.good),p.epoch(m),p.prn(m)+1);weights(ix)=max(.001,min(1,(3*sigma./max(abs(p.residual(m)),1e-15)).^2));
 end
 report.(sat)=struct('formal_scale',scale,'phase_count',nnz(q.good),'downweighted',nnz(weights(q.good)<1),'strongly_downweighted',nnz(weights(q.good)<.1),'heldout_abs_mm',prctile(abs(allres)*1000,[50 90 99 100]));
 save(fullfile(out,[sat '_single_weights.mat']),'weights','report','-v7.3');
 for mode={'robust'}
  name=mode{1};file=fullfile(out,[sat '_' name '_nav.mat']);if isfile(file),continue;end
  training=q;training.phase_weight=weights;
  if strcmp(name,'elevation'),el=training.elev;el(~isfinite(el))=0;training.phase_weight=weights.*(max(sin(el),.08)./max(sin(el),.25)).^2;end
  fprintf('Single %s: refit frozen %s weights\n',sat,name);
  [model,~,stats]=gnss_long_code_profile(base,training,1200,true(size(q.t)),true);L=gnss_condition_navigation(model,[],[]);
  save(file,'L','stats','-v7.3');clear model;
 end
 disp(report.(sat));clear base;
end
report.policy='Each receiver processed separately. Hold out 5-minute GPS segments from code and carrier; use other signals and the same track outside the segment. No POD/KBR/ACC or second-receiver integer constraints. Maintain float tracking offsets across dynamic blocks. Same transferred 3-sigma weighting with 3-mm floor; no density smoothing or reference tuning.';
f=fopen(fullfile(out,'independent_phase_weighting.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
end
