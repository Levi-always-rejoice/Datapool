function report=grace_single_continuity(core,source,out)
% Optional smoother control; not the default phase-only correction.
addpath(core,fullfile(core,'updates','code'));report=struct;
for sat='AB'
 file=fullfile(out,[sat '_continuous_robust_nav.mat']);if isfile(file),continue;end
 z=load(fullfile(source,[sat '_float_model.mat']),'model');base=z.model;clear z;q=base.q;assert(~any(startsWith(fieldnames(q),'pod_')));
 w=load(fullfile(out,[sat '_single_weights.mat']),'weights');q.phase_weight=w.weights;nb=numel(base.blocks);C=[];
 for j=1:nb-1
  a=base.blocks{j};b=base.blocks{j+1};if abs(a.b-b.a)>1e-7,continue;end
  A=zeros(3,12*nb);ia=(j-1)*12;ib=j*12;A(:,ia+(7:9))=eye(3);A(:,ia+(10:12))=eye(3)*(a.b-a.pivot)/600;
  A(:,ib+(7:9))=-eye(3);A(:,ib+(10:12))=-eye(3)*(a.b-b.pivot)/600;C=[C;A]; %#ok<AGROW>
 end
 base.C=[base.C;C];base.d=[base.d;zeros(size(C,1),1)];[model,~,stats]=gnss_long_code_profile(base,q,1200,true(size(q.t)),true);L=gnss_condition_navigation(model,[],[]);
 report.(sat)=struct('rows',size(C,1),'maximum_acceleration_jump',max(abs(C*L.coefficients))*1e-7);save(file,'L','stats','-v7.3');clear base model;
end
report.caution='This constraint adds smoothing beyond the nominal density window. In the measured injection test, it attenuates 40/90-minute variations by approximately 17/14 percent relative to the density operator alone. Do not report its RMS improvement as measurement correction alone.';
f=fopen(fullfile(out,'continuity_method.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
end
