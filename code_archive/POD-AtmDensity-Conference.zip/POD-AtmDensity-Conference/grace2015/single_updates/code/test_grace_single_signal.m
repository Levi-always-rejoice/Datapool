function test_grace_single_signal(core,upd,out,variant)
assert(ismember(variant,{'robust','continuous_robust'}));maxNumCompThreads(2);addpath(core,fullfile(core,'updates','code'));
z=load(fullfile(upd,'code_history20_run','A_float_model.mat'),'model');base=z.model;clear z;w=load(fullfile(out,'A_single_weights.mat'),'weights');q=base.q;q.phase_weight=w.weights;
nb=numel(base.blocks);
C=[];for j=1:nb-1,a=base.blocks{j};b=base.blocks{j+1};if abs(a.b-b.a)>1e-7,continue;end;A=zeros(3,12*nb);ia=(j-1)*12;ib=j*12;A(:,ia+(7:9))=eye(3);A(:,ia+(10:12))=eye(3)*(a.b-a.pivot)/600;A(:,ib+(7:9))=-eye(3);A(:,ib+(10:12))=-eye(3)*(a.b-b.pivot)/600;C=[C;A];end %#ok<AGROW>
if contains(variant,'continuous'),base.C=[base.C;C];base.d=[base.d;zeros(size(C,1),1)];end
fprintf('Rebuild frozen weighted continuous response operator\n');[model,~,~]=gnss_long_code_profile(base,q,1200,true(size(q.t)),true);clear base;
L=gnss_condition_navigation(model,[],[]);check=load(fullfile(out,['A_' variant '_nav.mat']),'L');assert(max(abs(check.L.values(:,2:7)-L.values(:,2:7)),[],'all')<1e-5);
r=load(fullfile(upd,'independent_run','fresh_force_reference','A_all_density.mat'),'d');d=r.d;R=gnss_hermite(d.t,d.r,d.v);DK=spline(d.t,(d.K.*d.drag)');periods=[2400 5400];amp=1e-13;
sol=ode113(@rhs,[q.t(1) q.t(end)],zeros(12,1),odeset('RelTol',1e-10,'AbsTol',1e-12,'MaxStep',20));
X=reshape(deval(sol,q.t),6,2,[]);namb=numel(q.B0);rr=zeros(12*nb,2);bb=zeros(namb,2);
alpha=1575.42e6^2/(1575.42e6^2-1227.6e6^2);beta=1-alpha;
for j=1:nb
 block=model.blocks{j};st=gnss_states(block,q.t(block.ids));ix=(j-1)*12+(1:12);
 for k=1:numel(block.ids)
  e=block.ids(k);h=squeeze(q.h(e,:,:));H=h*st(1:3,2:13,k);dy=h*X(1:3,:,e);gg=q.good(e,:)';
  sn=max(sin(q.elev(e,:)'),.25);sn(~isfinite(sn))=.25;wp=double(gg)./(.005*hypot(alpha,beta)./sn).^2.*q.phase_weight(e,:)';
  cg=gg&isfinite(q.code(e,:)')&abs(q.code(e,:)')<30;rc=q.code(e,:)';rc(~isfinite(rc))=0;wc=double(cg)./(4.5./sn).^2./max(1,abs(rc)/3);W=wp+wc;den=max(sum(W),1e-30);yc=(W'*dy)/den;
  HH=H-block.mh(k,:);rr(ix,:)=rr(ix,:)+HH'*(W.*(dy-yc));
  ps=find(gg);lab=q.labels(e,ps)';for a=1:2,bb(:,a)=bb(:,a)+accumarray(lab,wp(ps).*(dy(ps,a)-yc(a)),[namb 1]);end
 end
end
bz=model.T'*rr;db=model.Q*(bb-model.Nzb'*(model.red\bz));cc=model.T*(model.red\(bz-model.Nzb*db));
branches=struct('baseline',L);tt=L.values(:,1);truth=reshape(deval(sol,tt),6,2,[]);
for a=1:2
 recovered=zeros(size(tt,1),6);for j=1:nb,ii=L.values(:,8)==j-1;st=gnss_states(model.blocks{j},tt(ii));c=cc((j-1)*12+(1:12),a);recovered(ii,:)=squeeze(sum(st(:,2:13,:).*reshape(c,1,12,1),2))';end
 ptag=sprintf('p%d',periods(a)/60);n=L;n.values(:,2:7)=n.values(:,2:7)+recovered;branches.(['recovered_' ptag])=n;n=L;n.values(:,2:7)=n.values(:,2:7)+squeeze(truth(:,a,:))';branches.(['truth_' ptag])=n;
end
clear model;fprintf('Density signal retention test\n');dens=gnss_density_sparse_window(d,branches,1200);report=struct;v=dens.baseline.values;t=v(:,1);use=t>=2*3600+16&t<22*3600+16;
for a=1:2
 ptag=sprintf('p%d',periods(a)/60);actual=dens.(['recovered_' ptag]).values(:,2)-v(:,2);expected=dens.(['truth_' ptag]).values(:,2)-v(:,2);
 H=[sin(2*pi*t/periods(a)),cos(2*pi*t/periods(a)),ones(size(t)),(t-mean(t))/86400];ca=H(use,:)\actual(use);ce=H(use,:)\expected(use);
 report.(ptag)=struct('period_min',periods(a)/60,'input_amplitude',amp,'true_orbit_density_amplitude',hypot(ce(1),ce(2)),'recovered_density_amplitude',hypot(ca(1),ca(2)),'gain_relative_to_density_operator',hypot(ca(1),ca(2))/hypot(ce(1),ce(2)),'phase_error_degrees',rad2deg(atan2(ca(2),ca(1))-atan2(ce(2),ce(1))),'response_error_RMS',rms(actual(use)-expected(use)));
 writematrix([t,expected,actual],fullfile(out,['injection_' variant '_' ptag '.csv']));disp(report.(ptag));
end
report.note='Synthetic density perturbations integrated through the variational orbital dynamics, projected into all real single-receiver GPS lines of sight, and recovered with the actual frozen code/carrier weights and float ambiguity estimation. Extra acceleration continuity is applied ONLY to the continuous_robust variant. No truth used by solve. Gains referenced to the SAME 20-minute density operator. Real orbit forces/geometry and data gaps retained; robust weights held fixed, so this tests local linear response, not nonlinear outlier detection.';
report.variant=variant;f=fopen(fullfile(out,['signal_retention_' variant '.json']),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
 function v=rhs(t,y)
  y=reshape(y,6,2);v=zeros(6,2);v(1:3,:)=y(4:6,:);G=gnss_gradient(ppval(R,t));v(4:6,:)=G*y(1:3,:)+ppval(DK,t)*(amp*sin(2*pi*t./periods));v=v(:);
 end
end
