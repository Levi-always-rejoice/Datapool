function reports=grace_single_density(core,baseline,updated,out)
% External references enter only here, after saving independent navigation.
addpath(core,fullfile(core,'updates','code'));reports=struct;
for sat='AB'
 z=load(fullfile(baseline,[sat '_branches.mat']),'S');nav=struct('old',z.S);
 for name={'robust','continuous_robust'},z=load(fullfile(out,[sat '_' name{1} '_nav.mat']),'L');nav.(name{1})=z.L;end
 names=fieldnames(nav);tt=nav.old.values(:,1);for k=2:numel(names),tt=intersect(tt,nav.(names{k}).values(:,1));end
 for k=1:numel(names),[~,ii]=ismember(tt,nav.(names{k}).values(:,1));nav.(names{k}).values=nav.(names{k}).values(ii,:);end
 r=load(fullfile(updated,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d');ref=load(fullfile(baseline,[sat '_all_density.mat']),'bias','density');
 dens=gnss_density_sparse_window(r.d,nav,1200);P=gnss_hermite(r.d.pod_t,r.d.pod_r,r.d.pod_v);old=nav.old.values;writematrix([old(:,1),old(:,2:4)-ppval(P,old(:,1)')'],fullfile(out,[sat '_old_orbit.csv']));
 for k=1:numel(names)
  name=names{k};v=dens.(name).values;v(:,4)=v(:,4)-ref.bias/1e-6*v(:,6);[ok,ii]=ismember(v(:,1),ref.density.S.values(:,1));support=false(size(ok));support(ok)=ref.density.S.supported(ii(ok));
  writematrix([v,support],fullfile(out,[sat '_' name '_day_density.csv']));reports.(sat).(name)=rmfield(dens.(name),'values');
 end
end
f=fopen(fullfile(out,'density_numerical_checks.json'),'w');fprintf(f,'%s',jsonencode(reports,PrettyPrint=true));fclose(f);
end
