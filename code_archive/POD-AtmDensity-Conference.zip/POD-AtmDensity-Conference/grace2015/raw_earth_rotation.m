function R=raw_earth_rotation(t,models)
% IAU 2006/2000A; original ESA EOP records. GPS seconds from 2015-03-15.
persistent lastRoot erp
if isempty(lastRoot)||~strcmp(lastRoot,models)
 files=dir(fullfile(models,'*ERP.gz'));a=[];
 for k=1:numel(files)
  folder=tempname;mkdir(folder);names=gunzip(fullfile(files(k).folder,files(k).name),folder);
  lines=splitlines(fileread(names{1}));rmdir(folder,'s');
  for j=1:numel(lines)
   v=sscanf(lines{j},'%f')';if numel(v)>=4&&v(1)>40000&&v(1)<80000,a(end+1,:)=v(1:4);end %#ok<AGROW>
  end
 end
 [~,ii]=unique(a(:,1),'stable');erp=sortrows(a(ii,:),1);lastRoot=models;
end
t=t(:);mjd=57096+(t-16)/86400;
assert(all(mjd>=erp(1,1)&mjd<=erp(end,1)),'EOP coverage missing');
e=interp1(erp(:,1),erp(:,2:4),mjd,'linear');xp=e(:,1:2)*1e-6*pi/(180*3600);dut=e(:,3)*1e-7;
utc=datetime(2015,3,15)+seconds(t-16);R=dcmeci2ecef('IAU-2000/2006',utc,35*ones(size(t)),dut,xp);
end

