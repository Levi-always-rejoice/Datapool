function out=read_raw_inputs(sat,root)
% Decode original measurements and construct uncorrected IF/MW/GF combinations.
% This is raw ingestion, not the antenna/frame/force preprocessing pipeline.
if nargin<2,root=fullfile(fileparts(mfilename('fullpath')),'raw');end
assert(ismember(sat,{'A','B'}),'Expected A or B');
out.gps=read_grace_gps1b(fullfile(root,sprintf('GPS1B_2015-03-15_%s_02.dat',sat)));
a=out.gps.values;v=a(:,4:end);f1=1575.42e6;f2=1227.60e6;
alpha=f1^2/(f1^2-f2^2);beta=-f2^2/(f1^2-f2^2);
out.t=a(:,1);out.prn=a(:,2);out.quality=a(:,3);
out.code_IF_m=alpha*v(:,2)+beta*v(:,3);
out.phase_IF_m=alpha*v(:,5)+beta*v(:,6);
out.MW_m=(f1*v(:,5)-f2*v(:,6))/(f1-f2)-(f1*v(:,2)+f2*v(:,3))/(f1+f2);
out.GF_m=v(:,5)-v(:,6);bad=bitand(uint8(out.quality),15)~=0;
out.phase_IF_m(bad)=NaN;out.MW_m(bad)=NaN;out.GF_m(bad)=NaN;
end
