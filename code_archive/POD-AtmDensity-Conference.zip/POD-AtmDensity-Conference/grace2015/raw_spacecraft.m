function model=raw_spacecraft(sat,models)
% Original GRACE macro-model XML, preserving optical parameters and mass history.
num=double(sat)-double('A')+1;text=fileread(fullfile(models,sprintf('grace%d_satelliteModel.xml',num)));
model=struct('mass',numtag(text,'mass'),'coefficientDrag',numtag(text,'coefficientDrag'));
blocks=regexp(text,'<surface>(.*?)</surface>','tokens');s=struct([]);
for k=1:numel(blocks)
 b=blocks{k}{1};s(k).type=numtag(b,'type');s(k).area=numtag(b,'area');
 normal=regexp(b,'<normal>(.*?)</normal>','tokens','once');s(k).normal=[numtag(normal{1},'x'),numtag(normal{1},'y'),numtag(normal{1},'z')];
 for field={'reflexionVisible','diffusionVisible','absorptionVisible','reflexionInfrared','diffusionInfrared','absorptionInfrared','hasThermalReemission'}
  s(k).(field{1})=numtag(b,field{1});
 end
 assert(s(k).hasThermalReemission==0,'Transient thermal model requires separate implementation');
end
model.surfaces=s;model.mass_history=[];mods=regexp(text,'<modul>(.*?)</modul>','tokens');
for k=1:numel(mods)
 b=mods{k}{1};assert(numtag(b,'type')==3,'Unsupported moving/thermal spacecraft module');ep=regexp(b,'<epoch>(.*?)</epoch>','tokens');
 for j=1:numel(ep),model.mass_history(end+1,:)=[numtag(ep{j}{1},'time'),numtag(ep{j}{1},'mass')];end
end
end
function v=numtag(s,key)
z=regexp(s,['<' key '>([^<]+)</' key '>'],'tokens','once');assert(~isempty(z),key);v=str2double(z{1});
end
