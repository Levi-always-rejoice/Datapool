function [receiver,ants]=raw_antennas(sat,models)
% Original GRACE XML and IGS ANTEX calibration files, selected for 2015-03-15.
num=double(sat)-double('A')+1;s=fileread(fullfile(models,sprintf('grace%d_satelliteInfo.xml',num)));
a=regexp(s,'<antenna>(.*?)</antenna>','tokens','once');cells=regexp(a{1},'<cell>(.*?)</cell>','tokens');chosen='';
for j=1:numel(cells)
 b=cells{j}{1};if value(b,'timeStart')<=57096&&57096<value(b,'timeEnd'),chosen=b;break,end
end
assert(~isempty(chosen),'No active receiver antenna');n=tag(chosen,'name');serial=tag(chosen,'serial');
z=tag(chosen,'position');receiver.arp=[value(z,'x');value(z,'y');value(z,'z')];
z=tag(chosen,'local2antennaFrame');frame=zeros(3);keys='xyz';for j=1:3,for k=1:3,frame(j,k)=value(z,keys([j k]));end,end
assert(isequal(frame,diag([1 1 -1])),'Unexpected receiver antenna frame');
s=fileread(fullfile(models,sprintf('grace%d_antennaDefinition.xml',num)));ant=regexp(s,'<antenna>(.*?)</antenna>','tokens');chosen='';
for j=1:numel(ant),if strcmp(tag(ant{j}{1},'name'),n)&&strcmp(tag(ant{j}{1},'serial'),serial),chosen=ant{j}{1};break,end,end
assert(~isempty(chosen));receiver.patterns=cell(1,2);
for k=1:2
 b=regexp(chosen,['<cell>\s*<type>L' num2str(k) '[^<]*</type>(.*?)</pattern>\s*</cell>'],'tokens','once');assert(~isempty(b));b=b{1};
 z=tag(b,'offset');offset=[value(z,'x');value(z,'y');value(z,'z')];nr=value(b,'rows');nc=value(b,'columns');
 cells=regexp(b,'<cell row="(\d+)" col="(\d+)">([^<]+)</cell>','tokens');v=str2double(string(vertcat(cells{:})));mat=zeros(nr,nc);mat(sub2ind([nr nc],v(:,1)+1,v(:,2)+1))=v(:,3);
 receiver.patterns{k}=struct('offset',offset,'pcv',mat,'dz',value(b,'dZenit'));
end
ants=cell(33,1);s=fileread(fullfile(models,'igs20_2239.atx'));blocks=strsplit(s,'START OF ANTENNA');
for j=2:numel(blocks)
 lines=splitlines(blocks{j});h=find(contains(lines,'TYPE / SERIAL NO'),1);if isempty(h),continue,end
 line=lines{h};prn=strtrim(line(21:23));if numel(prn)~=3||prn(1)~='G',continue,end
 pr=str2double(prn(2:3));if ~isfinite(pr)||pr<1||pr>32,continue,end
 first=-Inf;last=Inf;v=struct;freq='';
 for k=1:numel(lines)
  line=lines{k};
  if contains(line,'VALID FROM'),first=epoch(line);elseif contains(line,'VALID UNTIL'),last=epoch(line);end
  if contains(line,'ZEN1 / ZEN2 / DZEN'),v.zen=sscanf(line(1:30),'%f')';end
  if contains(line,'START OF FREQUENCY'),freq=strtrim(line(1:10));end
  if contains(line,'NORTH / EAST / UP'),v.([freq '_offset'])=sscanf(line(1:60),'%f')*.001;end
  if contains(line,'NOAZI'),v.([freq '_pcv'])=sscanf(strrep(line,'NOAZI',''),'%f')*.001;end
 end
 if first<=0&&last>=0&&isfield(v,'G01_offset')&&isfield(v,'G02_offset'),ants{pr+1}=v;end
end
end
function t=epoch(line)
v=sscanf(line(1:43),'%f');t=seconds(datetime(v(1),v(2),v(3),v(4),v(5),v(6))-datetime(2015,3,15));
end
function z=tag(s,key)
v=regexp(s,['<' key '>(.*?)</' key '>'],'tokens','once');assert(~isempty(v),key);z=strtrim(v{1});
end
function x=value(s,key),x=str2double(tag(s,key));end
