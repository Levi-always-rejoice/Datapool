function report=test_force_kernels
% Physical limiting cases and frame/linearity checks; no prepared observations.
s=struct('type',0,'normal',[1 0 0],'area',1.5,'reflexionVisible',0,...
 'diffusionVisible',0,'absorptionVisible',1,'reflexionInfrared',0,...
 'diffusionInfrared',0,'absorptionInfrared',1);
m=struct('surfaces',s,'coefficientDrag',2.2);rho=3e-12;v=7600;u=[-1 0 0];
f=groops_aerodynamic_force(m,u,v,rho,0);expected=.5*rho*s.area*v^2*2.2*u;
assert(norm(f-expected)<1e-18);assert(norm(groops_aerodynamic_force(m,-u,v,rho,0))==0);
hot=groops_aerodynamic_force(m,u,v,rho,800);assert(all(isfinite(hot))&&hot(1)<0&&norm(hot(2:3))<1e-18);
assert(norm(groops_aerodynamic_force(m,u,v,2*rho,800)-2*hot)<1e-18);
angle=.37;Q=[cos(angle) -sin(angle) 0;sin(angle) cos(angle) 0;0 0 1];
mm=m;mm.surfaces.normal=(Q*s.normal')';d=[-1 .4 .2];d=d/norm(d);
f=groops_aerodynamic_force(m,d,v,rho,800);fr=groops_aerodynamic_force(mm,(Q*d')',v,rho,800);
assert(norm(fr-(Q*f')')<1e-17);
p=4.5e-6;f=groops_radiation_force(m,u,p,0);assert(norm(f-s.area*p*u)<1e-18);
assert(norm(groops_radiation_force(m,-u,p,0))==0);
mm=m;mm.surfaces.reflexionVisible=1;mm.surfaces.absorptionVisible=0;
assert(norm(groops_radiation_force(mm,u,p,0)-2*s.area*p*u)<1e-18);
mm=m;mm.surfaces.diffusionVisible=1;mm.surfaces.absorptionVisible=0;
assert(norm(groops_radiation_force(mm,u,p,0)-(5/3)*s.area*p*u)<1e-18);
mm=m;mm.surfaces.type=1;assert(norm(groops_radiation_force(mm,d,p,p)-2*s.area*p*d)<1e-18);
mm=m;mm.surfaces.type=3;mm.surfaces.normal=[0 0 1];d=[.2 .1 -1];d=d/norm(d);
f=groops_radiation_force(mm,d,p,0);plain=mm;plain.surfaces.type=0;fp=groops_radiation_force(plain,d,p,0);
assert(all(isfinite(f))&&norm(f)<=norm(fp)*(1+1e-12));
report=struct('passed',true,'checks',{{'analytic drag and illumination limits','thermal drag density linearity',...
 'thermal drag rotation covariance','absorbing/reflecting/diffuse radiation limits','sphere radiation','GRACE bottom shadow bound'}},...
 'scope','force kernels only; no full-day validation or flux/thermosphere input validation');
f=fopen(fullfile(fileparts(mfilename('fullpath')),'FORCE_KERNEL_TEST.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report)
end
