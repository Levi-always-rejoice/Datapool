function pp=gnss_hermite(t,r,v)
% Cubic Hermite state interpolation; no interpolation of full gravity.
t=t(:);h=diff(t);delta=diff(r)./h;
c3=(v(1:end-1,:)+v(2:end,:)-2*delta)./h.^2;
c2=(3*delta-2*v(1:end-1,:)-v(2:end,:))./h;
c=cat(3,c3,c2,v(1:end-1,:),r(1:end-1,:));
pp=mkpp(t',reshape(permute(c,[2 1 3]),[],4),size(r,2));
end
