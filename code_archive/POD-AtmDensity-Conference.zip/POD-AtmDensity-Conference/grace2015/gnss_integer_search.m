function [integers,costs,complete,loops]=gnss_integer_search(L,D,a,limit)
% Two-best sphere enumeration. Incomplete searches must never be accepted.
if nargin<4,limit=200000;end
n=numel(a);a=a(:);S=zeros(n);dist=zeros(n,1);center=zeros(n,1);z=center;step=center;k=n;
center(k)=a(k);z(k)=floor(center(k)+.5);y=center(k)-z(k);step(k)=sgn(y);integers=zeros(n,0);costs=[];bound=Inf;complete=false;
for loops=1:limit
 nd=dist(k)+y*y/D(k);
 if nd<bound
  if k>1
   k=k-1;dist(k)=nd;S(k,1:k)=S(k+1,1:k)+(z(k+1)-center(k+1))*L(k+1,1:k);
   center(k)=a(k)+S(k,k);z(k)=floor(center(k)+.5);y=center(k)-z(k);step(k)=sgn(y);
  else
   costs=[costs,nd];integers=[integers,z];[costs,order]=sort(costs);order=order(1:min(2,numel(order)));costs=costs(1:numel(order));integers=integers(:,order);
   if numel(costs)==2,bound=costs(2);end
   z(1)=z(1)+step(1);y=center(1)-z(1);step(1)=-step(1)-sgn(step(1));
  end
 else
  if k==n,complete=true;return,end
  k=k+1;z(k)=z(k)+step(k);y=center(k)-z(k);step(k)=-step(k)-sgn(step(k));
 end
end
end
function s=sgn(x),if x>0,s=1;else,s=-1;end,end
