function fixed=gnss_resolve_temporal(q,model,splits)
assisted=nargin<3;
% POD-assisted temporal integer changes; same criteria as screened Python run.
% POD assists selection only. KBR is not used by this function.
c=299792458;f1=1575.42e6;f2=1227.6e6;lw=c/(f1-f2);a=f1^2/(f1^2-f2^2);b=-f2^2/(f1^2-f2^2);
if assisted
 P=[gnss_pod_offsets(q,-1),gnss_pod_offsets(q,0),gnss_pod_offsets(q,1)];
else
 P=[model.B0+model.db,splits{1}.B,splits{2}.B];covariances={model.Q,splits{1}.Q,splits{2}.Q};
end
t=q.t(:);lab=double(q.labels);nb=numel(model.B0);sel=zeros(0,8);candidates=0;
for p=2:33 % column1 is unused GPS PRN0
 good=q.good(:,p) & lab(:,p)>0;keys=unique(lab(good,p));tracks=cell(numel(keys),1);first=zeros(numel(keys),1);
 for j=1:numel(keys),tracks{j}=find(good & lab(:,p)==keys(j));first(j)=t(tracks{j}(1));end
 [~,order]=sort(first);keys=keys(order);tracks=tracks(order);
 for j=1:numel(keys)-1
  ia=tracks{j};ib=tracks{j+1};ka=keys(j);kb=keys(j+1);gap=t(ib(1))-t(ia(end));
  if gap<=0 || gap>120,continue;end
  candidates=candidates+1;before=t(ia(end));after=t(ib(1));ia=ia(t(ia)>=before-600);ib=ib(t(ib)<=after+600);ints=zeros(3,2);passed=true;
  for k=1:3
   aa=ia;cc=ib;if k>1,aa=aa(mod(aa-1,2)==k-2);cc=cc(mod(cc-1,2)==k-2);end
   ma=mean_se(t(aa),q.mw(aa,p)/lw);mb=mean_se(t(cc),q.mw(cc,p)/lw);
   if isempty(ma) || isempty(mb),passed=false;break;end
   w=mb(1)-ma(1);sw=hypot(ma(2),mb(2));dif=P(kb,k)-P(ka,k);
   sigma=.01;if ~assisted,C=covariances{k};sigma=max(.005,2*sqrt(max(0,C(kb,kb)+C(ka,ka)-2*C(ka,kb))));end
   [ii,cost]=gnss_ils2(dif,sigma,w,sw);ints(k,:)=ii;
   if cost(1)>9.21 || cost(2)-cost(1)<2*log(1000) || cost(2)/max(cost(1),1e-12)<3,passed=false;break;end
  end
  if ~passed || any(any(ints~=ints(1,:))),continue;end
  n1=ints(1,1);n2=n1-ints(1,2);target=a*c/f1*n1+b*c/f2*n2;
  sel(end+1,:)=[p,ka,kb,before,after,n1,n2,target]; %#ok<AGROW>
 end
end
H=zeros(size(sel,1),nb);target=sel(:,8);for j=1:size(sel,1),H(j,sel(j,2:3))=[-1,1];end
B=model.B0+model.db;Q=model.Q;
while ~isempty(H)
 S=H*Q*H';dv=target-H*B;invS=inv(S);conditional=(invS*dv).^2./diag(invS);cost=dv'*invS*dv;
 if max(conditional)<=9 && cost<=size(H,1)+3*sqrt(2*size(H,1)),break;end
 [~,k]=max(conditional);H(k,:)=[];target(k)=[];sel(k,:)=[];
end
if ~assisted,fixed=struct('H',H,'target',target,'selected',sel,'candidate_count',candidates);return;end
preliminary=size(H,1);keep=false(preliminary,1);gf=zeros(preliminary,5);
for j=1:preliminary
 p=sel(j,1);mid=mean(sel(j,4:5));intercept=zeros(2,1);rms=zeros(2,1);counts=zeros(2,1);
 for side=1:2
  ix=find(q.good(:,p) & lab(:,p)==sel(j,side+1) & abs(t-sel(j,side+3))<=180);
  y=q.gf(ix,p);valid=isfinite(y);ix=ix(valid);y=y(valid);counts(side)=numel(ix);X=[ones(numel(ix),1),t(ix)-mid];coef=X\y;intercept(side)=coef(1);rms(side)=std(y-X*coef,1);
 end
 residual=diff(intercept)-(c/f1*sel(j,6)-c/f2*sel(j,7));gf(j,:)=[residual,rms',counts'];
 keep(j)=min(counts)>=6 && abs(residual)<=.1 && max(rms)<=.1;
end
fixed=struct('H',H(keep,:),'target',target(keep),'selected',sel(keep,:),'candidate_count',candidates,'preliminary_count',preliminary,'GF_audit',gf,'POD_offsets',P);
fprintf('  integer candidates %d; preliminary %d; screened %d\n',candidates,preliminary,sum(keep));
end

function m=mean_se(t,y)
ok=isfinite(y);t=t(ok);y=y(ok);m=[];if numel(y)<3,return;end
bins=unique(floor(t/60));if numel(bins)<2,return;end
means=zeros(numel(bins),1);for j=1:numel(bins),means(j)=mean(y(floor(t/60)==bins(j)));end
m=[mean(y),max(.035,std(means)/sqrt(numel(means)))];
end

