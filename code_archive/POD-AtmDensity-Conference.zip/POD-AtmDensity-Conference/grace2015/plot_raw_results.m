function plot_raw_results(out)
% Plot this run's generated estimates; never loads old/prepared solver inputs.
root=fileparts(mfilename('fullpath'));list=dir(fullfile(out,'*_navigation.mat'));fig=figure('Visible','off','Position',[50 50 1450 440*numel(list)]);tl=tiledlayout(fig,numel(list),2,'TileSpacing','compact');
for k=1:numel(list)
 sat=list(k).name(1);z=load(fullfile(out,list(k).name));d=load(fullfile(out,[sat '_density.mat']));pod=raw_pod_reference(sat,fullfile(root,'raw'),fullfile(root,'models'));P=gnss_hermite(pod.t,pod.r,pod.v);v=z.nav.values;
 a=nexttile(tl);[tt,y]=withgaps(v(:,1),(v(:,2:4)-ppval(P,v(:,1)')')*100);plot(a,(tt-16)/3600,y);grid(a,'on');ylabel(a,'Orbit minus GNV (cm)');title(a,['GRACE-' sat ': native raw-data solution']);legend(a,{'X','Y','Z'});
 a=nexttile(tl);v=d.density.values(d.density.supported,:);[tt,y]=withgaps(v(:,1),v(:,2:4)*1e12);plot(a,(tt-16)/3600,y);grid(a,'on');ylabel(a,'Density (10^{-12} kg/m^3)');title(a,[sat ': 20-min window; ACC constant bias from GNV']);legend(a,{'GNSS','GNV control','ACC (GNV offset calibrated)'},'Location','best');
end
xlabel(tl,'UTC hour, 2015-03-15');title(tl,'Raw-to-density MATLAB run | 10-min dynamics | POD-assisted partial temporal integer fixing');exportgraphics(fig,fullfile(out,'raw_orbit_density.png'),'Resolution',140);close(fig);
end
function [t,y]=withgaps(t,y)
ix=find(diff(t)>1.1)+1;for k=numel(ix):-1:1,j=ix(k);t=[t(1:j-1);NaN;t(j:end)];y=[y(1:j-1,:);nan(1,size(y,2));y(j:end,:)];end
end
