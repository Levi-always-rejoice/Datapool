function out=run_manuscript()
% One-command raw-input native MATLAB reproduction of the 2015 manuscript.
% Requires MATLAB R2025a, Aerospace Toolbox and the bundled original inputs.
% Creates a new run folder; reads no generated/preprocessed observation arrays.
test_joint_integer;test_pair_candidates;test_force_kernels;
out=prepare_manuscript_raw;
fit_manuscript_navigation(out);
manuscript_density(out);
report_manuscript(out);
manuscript_temporal_auxiliary(out);
fprintf('Reproduction and discrepancy report: %s\n',out);
end
