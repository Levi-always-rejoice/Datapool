function [integers,costs,complete,loops]=gnss_joint_integer(a,Q,limit)
if nargin<3,limit=200000;end
[L,D,Z]=gnss_integer_reduce(Q);[z,costs,complete,loops]=gnss_integer_search(L,D,Z'*a(:),limit);integers=round(Z'\z);
end
