function test_density_batch(out)
% Independent single-RHS implementation vs multi-branch operator on fresh data.
x=load(fullfile(out,'A_float_model.mat'),'F','model');d=x.model.q;d.pod_t=d.t;d.pod_v=d.v;
d.acc_rho=ones(size(d.t))*2e-12;d.acc_bias_template_rho=ones(size(d.t))*1e-12;
nav=x.F.values;nav=nav(nav(:,1)<3600,:);branches=struct('one',struct('values',nav),'two',struct('values',nav));
single=gnss_density(d,nav);batch=gnss_density_many(d,branches);
err=max(abs(single.values-batch.one.values),[],'all');assert(err<1e-17);assert(isequal(batch.one.values,batch.two.values));
fprintf('Batch vs independent density operator discrepancy %.3g\n',err);
end
