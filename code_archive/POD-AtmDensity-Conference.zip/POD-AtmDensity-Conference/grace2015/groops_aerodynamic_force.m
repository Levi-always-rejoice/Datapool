function force=groops_aerodynamic_force(model,direction,speed,density,temperature)
% MATLAB port of GROOPS MiscAccelerationsAtmosphericDrag::force.
% GPL-3.0; original source and attribution in third_party/GROOPS.
% Direction: atmospheric velocity relative to spacecraft, SRF unit vector.
% Supply epoch-updated surfaces (including moving panels) and drag coefficient.
n=size(direction,1);speed=expand(speed,n);density=expand(density,n);temperature=expand(temperature,n);
assert(size(direction,2)==3&&all(isfinite(direction(:))));
assert(all(abs(vecnorm(direction,2,2)-1)<1e-10),'Direction must be unit length');
assert(all(speed>0&isfinite(speed))&&all(density>=0&isfinite(density))&&all(temperature>=0&isfinite(temperature)));
force=zeros(n,3);R=8.3144;M=15.5/1000;alpha=.9;Tw=273;
for k=1:numel(model.surfaces)
 surface=model.surfaces(k);normal=surface.normal(:)';assert(surface.area>=0);
 if ismember(surface.type,[0 3])
  assert(abs(norm(normal)-1)<1e-10);c=-direction*normal';hot=temperature>0;
  if any(hot)
   d=direction(hot,:);v=speed(hot);co=c(hot);
   ul=cross(d,cross(d,repmat(normal,sum(hot),1),2),2);
   s=v./sqrt(2*R*temperature(hot)/M);P=exp(-(co.*s).^2)./s;G=1./(2*s.^2);Z=1+erf(co.*s);
   x=sqrt((1+alpha*(3*R*Tw./v.^2-1))/6).*(co*sqrt(pi).*Z+P);
   force(hot,:)=force(hot,:)+(.5*density(hot)*surface.area.*v.^2).*...
     ((P/sqrt(pi)+co.*((1+G).*Z+x)).*d+(G.*Z+x).*ul);
  end
  use=~hot&c>0;if any(use)
  force(use,:)=force(use,:)+(.5*density(use)*surface.area.*c(use).*speed(use).^2*model.coefficientDrag).*direction(use,:);end
 elseif surface.type==1
  force=force+(.5*density*surface.area.*speed.^2*model.coefficientDrag).*direction;
 else,error('GROOPS atmospheric drag does not implement cylinder surfaces');end
end
end
function x=expand(x,n)
x=x(:);if isscalar(x),x=repmat(x,n,1);end;assert(numel(x)==n);
end

