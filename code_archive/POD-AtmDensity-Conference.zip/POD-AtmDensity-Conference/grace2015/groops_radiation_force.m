function [force,absorbed]=groops_radiation_force(model,direction,visible,infrared)
% MATLAB port of GROOPS MiscAccelerationsRadiationPressure::force.
% GPL-3.0; source in third_party/GROOPS. Pressures in N/m2, force in N.
% This is the surface kernel, not the solar/Earth flux or thermal integration.
% Direction is photon propagation direction in SRF. Surfaces must be updated.
n=size(direction,1);visible=expand(visible,n);infrared=expand(infrared,n);
assert(size(direction,2)==3&&all(isfinite(direction(:)))&&all(abs(vecnorm(direction,2,2)-1)<1e-10));
assert(all(isfinite(visible)&visible>=0&isfinite(infrared)&infrared>=0));
force=zeros(n,3);absorbed=zeros(n,numel(model.surfaces));
for k=1:numel(model.surfaces)
 s=model.surfaces(k);normal=s.normal(:)';co=-direction*normal';
 ref=s.reflexionVisible*visible+s.reflexionInfrared*infrared;
 dif=s.diffusionVisible*visible+s.diffusionInfrared*infrared;
 ab=s.absorptionVisible*visible+s.absorptionInfrared*infrared;
 if ismember(s.type,[0 3])
  use=co>=1e-10;fraction=ones(n,1);
  if s.type==3
   for j=find(use)'
    fraction(j)=shadow_fraction(direction(j,:),normal);
   end
  end
  w=s.area*co.*fraction.*use;
  force=force+w.*(ab+dif).*direction-w.*(2/3*dif+2*co.*ref).*normal;
  absorbed(:,k)=fraction.*co.*ab.*use;
 elseif s.type==2
  use=co>=1e-10;w=s.area*co.*use;
  force=force+w.*(ab+dif).*direction-w.*(pi/6*dif+4/3*co.*ref).*normal;
  absorbed(:,k)=co.*ab.*use;
 elseif s.type==1
  force=force+(1+4/9*s.diffusionVisible)*s.area*direction.*(visible+infrared);
 else,error('Unknown GROOPS surface type');end
end
end
function fraction=shadow_fraction(d,normal)
sin50=.766044443119;cos50=.642787609687;a=3122.5;b=1643.52084;s=73.10281*2;
alpha=deg2rad(50);c=sqrt(s^2+b^2-2*s*b*cos(pi-alpha));
if normal(3)>.999
 sx=s/a*sin50*abs(d(1)/d(3));sy=s/b*sin50*abs(d(2)/d(3))-s/b*cos50;
 if sx>1,sy=sy/sx;sx=1;end
 if sy>1,sx=sx/sy;sy=1;end
 fraction=1-max(sy,0)*(1-.5*sx);
else
 sy1=0;sy2=1;
 if abs(d(3))>1e-10
  lambda1=atan2(d(3),abs(d(2)));
  if lambda1<1e-10,gamma1=pi-alpha-abs(lambda1);sy1=-(sin(abs(lambda1))*b/sin(gamma1))/s;
  else,gamma1=alpha-lambda1;sy1=(sin(lambda1)*b/sin(gamma1))/s;end
  lambda2=atan2(-d(3),abs(-d(2)));epsilon=asin(sin50*s/c);
  if lambda2<=epsilon,gamma2=pi-(pi-epsilon-alpha)-(epsilon-lambda2);sy2=(c*sin(epsilon-lambda2)/sin(gamma2))/s;
  else,gamma2=pi-(epsilon+alpha)-(lambda2-epsilon);sy2=-(c*sin(lambda2-epsilon)/sin(gamma2))/s;end
 end
 dx=abs(d(1)/(normal(3)*d(3)+normal(2)*d(2)));h=b*sin50+s*.984807753012;
 sx1=b/a*sin50*dx;sx2=h/a*dx;
 if sx1>1,sy1=sy1/sx1;sx1=1;end
 if sy1>1,sx1=sx1/sy1;sy1=1;end
 if sy1<0,sx1=sx1-(sx2-sx1)/sy2*sy1;sy1=0;end
 if sx2>1,sy2=sy1+(sy2-sy1)*(1-sx1)/(sx2-sx1);sx2=1;end
 if sy2>1,sx2=sx1+(sx2-sx1)*(1-sy1)/(sy2-sy1);sy2=1;end
 fraction=1-max(sy1,0)*(1-.5*sx1)-max(sy2-sy1,0)*((1-sx1)-.5*(sx2-sx1));
end
end
function x=expand(x,n)
x=x(:);if isscalar(x),x=repmat(x,n,1);end;assert(numel(x)==n);
end
