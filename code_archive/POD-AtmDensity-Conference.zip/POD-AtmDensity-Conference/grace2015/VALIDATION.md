> Historical validation from the previous native release. The 2026-10-01 raw rerun and the local R/S1 partial-selection sensitivity are documented in `../RESULTS_AND_VALIDATION.txt` and `../GRACE_NUMERICAL_SENSITIVITY.txt`. The example plots/metrics in this combined release come from the new raw run.

# Validation of the native MATLAB manuscript package

Completed full-day GRACE A/B raw-input run for 2015-03-15 under MATLAB R2025a and Aerospace Toolbox. Runtime stages decoded bundled original products and generated their own navigation/force/ambiguity checkpoints. No old project or prepared arrays were estimator inputs. All S/F/R/O/M/P and auxiliary T0/T1/TP branches completed. Figures were inspected. The package is an approximate reproduction with the explicitly flagged S2 difference below.

| Quantity | Manuscript | Regenerated MATLAB |
|---|---:|---:|
| S orbit RMS A / B (cm) | 6.96 / 9.16 | 6.806 / 9.052 |
| S density RMS A / B (kg/m3) | 3.26e-13 / 3.76e-13 | 3.103e-13 / 3.723e-13 |
| F range RMS (mm) | 29.206 | 29.200 |
| R range RMS (mm) | 17.394 | 17.392 |
| P supported range RMS (mm) | 1.940 | 1.944 |
| R full-day differential density RMS (kg/m3) | 2.123e-13 | 2.114e-13 |
| P full-day differential density RMS (kg/m3) | 5.515e-14 | 5.748e-14 |
| P S1 RMS / correlation | 1.76e-14 / 0.899 | 1.755e-14 / 0.894 |
| P S2 RMS / correlation | 2.485e-14 / 0.884 | 2.984e-14 / 0.787 |

R: 609 candidates, rank333, 188 accepted constraints. P: 754 relations, rank358. P coverage exactly 35,916 centers and 7,154 KBR epochs. GNSS-only temporal repair accepts 0 A / 5 B links; POD-assisted temporal repair accepts 4 A / 11 B links (paper:4/10). Temporal B T0/T1 density RMS is 4.2811e-13 / 4.2692e-13, versus paper4.3392e-13 / 4.3274e-13.

## Tests and discrepancy investigation

- Two-best integer solver:30 exhaustive 2–4D tests, maximum cost error6.7e-16; incomplete search rejected.
- Synthetic dual-frequency signs, integer cycles and connected masks passed.
- Shared multi-branch density operator equals the independent single-branch operator in the tested segment.
- Raw preparation has the same observation support as the earlier implementation; geometry/clock-adjusted phase discrepancy is about0.04 mm RMS.
- The R constraint spaces and enforced integer relations are equivalent to the manuscript: combined rank188; cross-solution constraint residual below3e-14 m. The decorrelated coordinate representations need not be identical.
- Same-input orbit-solver comparison agrees at approximately1 micrometre daily RMS. The density solver reproduces legacy S2 RMS within0.2% on identical inputs.
- The first port incorrectly applied an obsolete preliminary acceptance gate; that error was found, corrected, and all affected outputs regenerated. It is not present in the release.
- S2 remains a material departure and is flagged. Controlled substitutions isolate its dominant source to the POD reference conversion used for assisted offsets. See `INVESTIGATION_S2.md`; no legacy correction was inserted into runtime.

Detailed current results and table/figure outputs are in `example_manuscript_results`. A new run regenerates them in a new directory. Example results are not estimator inputs. The validation oracle arrays used for port diagnostics are not included.
