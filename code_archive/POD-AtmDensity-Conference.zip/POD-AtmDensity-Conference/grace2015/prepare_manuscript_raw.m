function out=prepare_manuscript_raw(out)
% Fresh raw decoding and force reconstruction. Saved MAT files are run outputs.
root=fileparts(mfilename('fullpath'));raw=fullfile(root,'raw');models=fullfile(root,'models');
if nargin<1,out=fullfile(root,['manuscript_run_' datestr(now,'yyyymmdd_HHMMSS')]);end
assert(~exist(out,'dir'),'Choose a new output directory for a raw run');mkdir(out);
diary(fullfile(out,'preparation.log'));cleanup=onCleanup(@()diary('off'));
sp3=read_jaxa_sp3(fullfile(raw,'madoca18360.sp3.gz'));bias=read_jaxa_code_bias(fullfile(raw,'ssr18360.rtcm3'));
t=(0:10:86399)';tx=raw_transmitters(sp3,t,models);clear sp3;
for sat='AB'
 fprintf('RAW preparation %s\n',sat);obs=raw_observation_grid(sat,raw,bias);
 [rot,age]=raw_attitude(sat,t,raw);[receiver,ants]=raw_antennas(sat,models);
 bootstrap=raw_bootstrap(obs,tx,rot,receiver,ants,age);
 q=raw_navigation_design(sat,obs,tx,bootstrap,receiver,ants,raw,models);
 save(fullfile(out,[sat '_raw_design.mat']),'q','bootstrap','-v7.3');
 fprintf('Single-satellite S, 20-minute dynamics: %s\n',sat);
 smodel=gnss_navigation(q,1200,false);S=gnss_condition_navigation(smodel,[],[]);clear smodel;
 fprintf('Joint precursor F, 20-minute dynamics: %s\n',sat);
 model=gnss_navigation(q,1200,true);F=gnss_condition_navigation(model,[],[]);
 save(fullfile(out,[sat '_float_model.mat']),'model','S','F','-v7.3');clear model;
 for split=0:1
  fprintf('Interleaved validation %s split %d\n',sat,split);m=gnss_navigation(q,1200,true,split);
  B=m.B0+m.db;Q=m.Q;save(fullfile(out,sprintf('%s_split%d.mat',sat,split)),'B','Q');clear m;
 end
end
fprintf('Fresh preparation complete: %s\n',out);
end
