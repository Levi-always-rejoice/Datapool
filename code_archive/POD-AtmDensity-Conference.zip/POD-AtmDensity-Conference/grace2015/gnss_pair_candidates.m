function c=gnss_pair_candidates(a,b,assisted)
% Actual L1/L2 integer relations from MW and (assisted only) POD phase.
f1=1575.42e6;f2=1227.60e6;lw=299792458/(f1-f2);ln=299792458/(f1+f2);cf=f2/(f1+f2)*lw;
[t,ia,ib]=intersect(a.t,b.t);nc=numel(a.B0);nb=nc+numel(b.B0);
pa=a.phase(ia,:);pb=b.phase(ib,:);
if assisted
 pa=pa-sum(a.h(ia,:,:).*reshape(a.pod_r(ia,:)-a.r(ia,:),[],1,3),3);
 pb=pb-sum(b.h(ib,:,:).*reshape(b.pod_r(ib,:)-b.r(ib,:),[],1,3),3);
end
sd=pb-pa;mw=(b.mw(ib,:)-a.mw(ia,:))/lw;
good=a.good(ia,:)&b.good(ib,:)&isfinite(sd)&isfinite(mw);
la=a.labels(ia,:);lb=b.labels(ib,:);pieces=cell(numel(t),1);
for i=1:numel(t)
 ps=find(good(i,:));if numel(ps)<2,continue;end
 pr=nchoosek(ps,2);p=pr(:,1);r=pr(:,2);n=numel(p);
 pieces{i}=[p,r,la(i,p)',lb(i,p)',la(i,r)',lb(i,r)',repmat(i,n,1),(sd(i,p)-sd(i,r))',(mw(i,p)-mw(i,r))'];
end
% Preserve first-observed track-pair order. Pivoted QR / partial ILS subsets
% depend on this otherwise arbitrary ordering; match the reference algorithm.
records=vertcat(pieces{:});[keys,~,group]=unique(records(:,1:6),'rows','stable');[group,order]=sort(group);records=records(order,:);edges=[1;find(diff(group))+1;numel(group)+1];
accepted=struct('key',{},'rows',{},'WL',{},'NL',{},'target',{},'score',{});tested=0;
for g=1:numel(edges)-1
 rec=records(edges(g):edges(g+1)-1,:);if size(rec,1)<30,continue;end
 rows=rec(:,7);[bins,~,ii]=unique(floor(t(rows)/60));if numel(bins)<5,continue;end
 tested=tested+1;dd=rec(:,8);ww=rec(:,9);
 if assisted
  wm=accumarray(ii,ww,[],@median);pm=accumarray(ii,dd,[],@median);
  w=median(wm);wi=round(w);se=max(.025,1.4826*median(abs(wm-median(wm)))/sqrt(numel(wm)));
  p=median(pm);ni=round((p-cf*wi)/ln);target=ln*ni+cf*wi;spread=1.4826*median(abs(dd-median(dd)));
  h=ceil(numel(pm)/2);wh=floor(numel(wm)/2);
  pass=abs(w-wi)+3*se<.5 && abs(w-wi)<.2 && se<.12 && abs(p-target)<.02 && spread<.02 && abs(median(pm(1:h))-median(pm(h+1:end)))<.02 && abs(median(wm(1:wh))-median(wm(wh+1:end)))<.25;
  score=abs(p-target)+spread;
 else
  wm=accumarray(ii,ww,[],@mean);w=mean(ww);wi=round(w);se=max(.025,std(wm)/sqrt(numel(wm)));h=ceil(numel(wm)/2);
  pass=abs(w-wi)<.15 && abs(w-wi)+3*se<.5 && se<.12 && abs(mean(wm(1:h))-mean(wm(h+1:end)))<.25;
  ni=NaN;target=NaN;score=se;
 end
 if pass,accepted(end+1)=struct('key',keys(group(edges(g)),:),'rows',rows,'WL',wi,'NL',ni,'target',target,'score',score);end %#ok<AGROW>
end
cycleRejected=0;
if assisted && ~isempty(accepted)
 [~,order]=sort([accepted.score]);accepted=accepted(order);kk=vertcat(accepted.key);[nodes,~,idx]=unique([kk(:,3:4);kk(:,5:6)],'rows');parent=(1:size(nodes,1))';potential=zeros(numel(parent),2);retain=false(numel(accepted),1);
 for j=1:numel(accepted)
  [u,pu]=root(idx(j));[v,pv]=root(idx(j+numel(accepted)));want=[accepted(j).WL,accepted(j).NL];
  if u==v && any(pv-pu~=want),cycleRejected=cycleRejected+1;continue;end
  if u~=v,parent(v)=u;potential(v,:)=want+pu-pv;end
  retain(j)=true;
 end
 accepted=accepted(retain);
end
A=zeros(numel(accepted),nb);mask=false(numel(t),33);epochEdges=cell(numel(t),1);
for j=1:numel(accepted)
 k=accepted(j).key;A(j,[k(3),nc+k(4),k(5),nc+k(6)])=[-1,1,1,-1];
 if assisted
  rows=accepted(j).rows;rows=rows(abs(sd(rows,k(1))-sd(rows,k(2))-accepted(j).target)<.05);
  for e=rows',epochEdges{e}(end+1,:)=k(1:2);end
 end
end
if assisted
 for e=1:numel(t)
  ed=epochEdges{e};if isempty(ed),continue;end
  G=graph(ed(:,1),ed(:,2),[],33);bins=conncomp(G);counts=accumarray(bins',1);[count,which]=max(counts);
  if count>=4,mask(e,bins==which)=true;end
 end
end
if isempty(A),take=[];else,[~,R,piv]=qr(A','vector');rankA=sum(abs(diag(R))>1e-9);take=piv(1:rankA);end
c=struct('A',A,'WL',[accepted.WL]','NL',[accepted.NL]','target',[accepted.target]','independent',take,'mask',mask,'ia',ia,'ib',ib,'t',t,'tested',tested,'cycle_rejected',cycleRejected,'accepted',{accepted});
 function [r,p]=root(node)
  r=node;p=[0 0];while parent(r)~=r,p=p+potential(r,:);r=parent(r);end
 end
end
