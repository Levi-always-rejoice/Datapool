function result=gnss_validate_pair_integers(c,B,Q,splits)
% GNSS-only partial joint ILS and exact even/odd repeatability validation.
% No POD, KBR or ACC observations enter this function.
f1=1575.42e6;f2=1227.6e6;ln=299792458/(f1+f2);cf=f2/(f1+f2)*299792458/(f1-f2);
A=c.A(c.independent,:);w=c.WL(c.independent);a=(A*B-cf*w)/ln;C=A*Q*A'/ln^2;C=(C+C')/2;
[~,D,Z]=gnss_integer_reduce(C);rankA=numel(D);
% Reproduce the saved validated experiment's 192-dimensional starting search
% subspace. This is a search configuration, not an imposed accepted count.
% The obsolete precursor's ratio>=3 gate is NOT part of that experiment.
chosen=max(1,rankA-192+1);attempts=[];
while chosen<rankA && prod(erf(.5./sqrt(2*D(chosen:end))))<.99,chosen=chosen+1;end
H=Z'*A;offset=cf*(Z'*w);models=cell(3,1);models{1}=struct('a',(H*B-offset)/ln,'C',H*Q*H'/ln^2);
for s=1:2,models{s+1}=struct('a',(H*splits{s}.B-offset)/ln,'C',H*splits{s}.Q*H'/ln^2);end
keep=(chosen:rankA)';history=[];accepted=false;
while ~isempty(keep)
 m=numel(keep);aa=models{1}.a(keep);CC=models{1}.C(keep,keep);CC=(CC+CC')/2;
 [ints,costs,done,nodes]=gnss_joint_integer(aa,CC,300000);[~,drop]=max(diag(CC));reason=1;
 if done
  best=ints(:,1);dv=best-aa;inverse=CC\eye(m);conditional=(inverse*dv).^2./diag(inverse);gap=costs(2)-costs(1);
  if max(conditional)>9 || costs(1)>m+3*sqrt(2*m)
   [~,drop]=max(conditional);reason=2;
  elseif gap<2*log(1000)
   choices=find(ints(:,2)~=best);[~,j]=max(diag(CC(choices,choices)));drop=choices(j);reason=3;
  else
   bad=[];complete=true;
   for s=2:3
    CS=models{s}.C(keep,keep);[is,~,ok]=gnss_joint_integer(models{s}.a(keep),(CS+CS')/2,300000);
    if ~ok,complete=false;break;end
    bad=union(bad,find(is(:,1)~=best));
   end
   if complete && isempty(bad),accepted=true;break;end
   if isempty(bad),bad=(1:m)';end
   [~,j]=max(diag(CC(bad,bad)));drop=bad(j);reason=4;
  end
 end
 history(end+1,:)=[m,keep(drop),reason,done,nodes]; %#ok<AGROW>
 if mod(size(history,1),10)==1,fprintf('Validation %d dimensions, rejection reason %d\n',m,reason);end
 keep(drop)=[];
end
assert(accepted,'No repeatable GNSS integer subset');
HH=H(keep,:);target=ln*best+offset(keep);HQ=HH*Q;delta=target-HH*B;lambda=(HQ*HH')\delta;fixed=B+HQ'*lambda;
error=max(abs(HH*fixed-target));assert(error<5e-7,'Pair integer equality failed');
result=struct('H',HH,'target',target,'fixedB',fixed,'integers',best,'selected',keep,'WL_candidates',size(c.A,1),'independent_rank',rankA,'fixed_count',numel(keep),'max_error_m',error,'profile_cost',delta'*lambda,'attempts',attempts,'history',history);
end
