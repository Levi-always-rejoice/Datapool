function [L,D,Z]=gnss_integer_reduce(Q)
% Native MATLAB LDL integer decorrelation. See Teunissen (1995), Chang (2005).
% Algorithm follows the existing project gnss_joint_ils.py (RTKLIB formulation).
n=size(Q,1);A=Q;L=zeros(n);D=zeros(n,1);
for i=n:-1:1
 D(i)=A(i,i);assert(D(i)>0,'Nonpositive ambiguity covariance');
 L(i,1:i)=A(i,1:i)/D(i);A(1:i-1,1:i-1)=A(1:i-1,1:i-1)-D(i)*(L(i,1:i-1)'*L(i,1:i-1));
end
Z=eye(n);j=n-1;k=j;
while j>=1
 if j<=k
  for i=j+1:n
   mu=floor(L(i,j)+.5);
   if mu~=0,L(i:n,j)=L(i:n,j)-mu*L(i:n,i);Z(:,j)=Z(:,j)-mu*Z(:,i);end
  end
 end
 delta=D(j)+L(j+1,j)^2*D(j+1);
 if delta+1e-6<D(j+1)
  eta=D(j)/delta;lambda=D(j+1)*L(j+1,j)/delta;ell=L(j+1,j);a=L(j,1:j-1);b=L(j+1,1:j-1);
  D(j)=eta*D(j+1);D(j+1)=delta;L(j,1:j-1)=-ell*a+b;L(j+1,1:j-1)=eta*a+lambda*b;L(j+1,j)=lambda;
  L(j+2:n,[j j+1])=L(j+2:n,[j+1 j]);Z(:,[j j+1])=Z(:,[j+1 j]);k=j;j=n-1;
 else,j=j-1;end
end
left=Z'*Q*Z;right=L'*diag(D)*L;assert(all(abs(left-right)<=1e-8+1e-7*abs(right),'all'),'Integer covariance transform failed');
end
