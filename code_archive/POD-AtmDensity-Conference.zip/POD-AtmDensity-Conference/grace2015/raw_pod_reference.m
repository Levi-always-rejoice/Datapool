function pod=raw_pod_reference(sat,raw,models)
% Original GNV ECEF state -> CRF, including derivative of Earth rotation.
a=read_grace_gnv(fullfile(raw,sprintf('GNV1B_2015-03-15_%s_02.asc',sat)));R=raw_earth_rotation(a.t,models);Rp=raw_earth_rotation(a.t+.5,models);Rm=raw_earth_rotation(a.t-.5,models);
pod=struct('t',a.t,'r',rotate(R,a.r_ecef),'v',rotate(R,a.v_ecef)+rotate(Rp-Rm,a.r_ecef));
end
function x=rotate(R,x),x=reshape(pagemtimes(permute(R,[2 1 3]),reshape(x',3,1,[])),3,[])';end
