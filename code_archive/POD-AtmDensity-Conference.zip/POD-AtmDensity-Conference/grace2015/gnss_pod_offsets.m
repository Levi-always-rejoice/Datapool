function B=gnss_pod_offsets(q,split)
% POD-assisted robust phase offsets with free receiver clocks; no fixed clock.
B0=q.B0(:);lab=double(q.labels);nt=numel(q.t);nb=numel(B0);
good=q.good & lab>0 & reshape(q.used(max(lab(:),1)),size(lab));
if split>=0,good=good & (mod((0:nt-1)',2)==split);end
dr=q.pod_r-q.r;off=sum(q.h.*reshape(dr,nt,1,3),3);
y0=q.phase-off-reshape(B0(max(lab(:),1)),size(lab));[ep,prn]=find(good);idx=sub2ind(size(good),ep,prn);labels=lab(idx);y=y0(idx);w=max(sin(q.elev(idx)),.25).^2;
[db,clock]=solve_offsets(w);
for it=1:3,res=y-db(labels)-clock(ep);[db,clock]=solve_offsets(w.*min(1,.01./max(abs(res),1e-15)));end
B=B0+db;
 function [delta,clock]=solve_offsets(ww)
  den=max(accumarray(ep,ww,[nt 1]),1e-30);E=sparse(ep,labels,ww,nt,nb);counts=accumarray(labels,ww,[nb 1]);N=spdiags(counts,0,nb,nb)-E'*(E./den);
  ey=accumarray(ep,ww.*y,[nt 1]);r=accumarray(labels,ww.*y,[nb 1])-E'*(ey./den);ids=find(counts>1e-9);S=N(ids,ids);
  adjacency=spones(S);adjacency=adjacency-spdiags(diag(adjacency),0,numel(ids),numel(ids));groups=conncomp(graph(adjacency,'upper'));
  keep=true(numel(ids),1);for g=unique(groups),keep(find(groups==g,1))=false;end
  chosen=ids(keep);sc=sqrt(diag(N(chosen,chosen)));delta=zeros(nb,1);delta(chosen)=((N(chosen,chosen)./sc./sc')\(r(chosen)./sc))./sc;
  clock=accumarray(ep,ww.*(y-delta(labels)),[nt 1])./den;
 end
end
