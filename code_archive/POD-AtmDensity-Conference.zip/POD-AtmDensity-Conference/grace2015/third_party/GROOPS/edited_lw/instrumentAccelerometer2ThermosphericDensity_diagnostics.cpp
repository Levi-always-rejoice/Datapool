/***********************************************/
/**
* @file instrumentAccelerometer2ThermosphericDensity.cpp
*
* @brief Estimate neutral density from accelerometer data.
*
* @author Sandro Krauss
* @date 2020-06-22
*/
/***********************************************/

// Latex documentation
#define DOCSTRING docstring
static const char *docstring = R"(
This program estimates neutral mass densities along the satellite trajectory based on \file{accelerometer data}{instrument}.
In order to determine the neutral mass density the accelerometer input should only reflect the accelerations due to drag
(e.g. \configClass{miscAccelerations:atmosphericDrag}{miscAccelerationsType:atmosphericDrag}).
Thus, influences from solar and Earth radiation pressure must be reduced beforehand.

Optionally, \configFile{outputfileAerodynamicDiagnostics}{instrument} stores the intermediate quantities used in the
thermospheric-density retrieval. The 20 data columns are satellite velocity in SRF (3), co-rotation velocity in SRF (3),
wind velocity in SRF (3), atmosphere-relative-to-satellite velocity in SRF (3), relative speed (1), modeled acceleration
for unit density in SRF (3), effective (CA) in SRF-X (1), thermosphere-model temperature (1), thermosphere-model density (1),
and satellite mass (1).
)";

/***********************************************/

#include "programs/program.h"
#include "files/fileMatrix.h"
#include "files/fileSatelliteModel.h"
#include "classes/earthRotation/earthRotation.h"
#include "classes/parametrizationAcceleration/parametrizationAcceleration.h"
#include "classes/thermosphere/thermosphere.h"
#include "classes/miscAccelerations/miscAccelerationsAtmosphericDrag.h"
#include "classes/ephemerides/ephemerides.h"

/***** CLASS ***********************************/

/** @brief Estimate neutral density from accelerometer data.
* @ingroup programsGroup */
class InstrumentAccelerometer2ThermosphericDensity
{
public:
  void run(Config &config, Parallel::CommunicatorPtr comm);
};

GROOPS_REGISTER_PROGRAM(InstrumentAccelerometer2ThermosphericDensity, PARALLEL, "Estimate neutral density from accelerometer data", Instrument)

/***********************************************/

void InstrumentAccelerometer2ThermosphericDensity::run(Config &config, Parallel::CommunicatorPtr comm)
{
  try
  {
    FileName         fileNameOutDensity, fileNameOutDiagnostics;
    FileName         fileNameSatellite;
    FileName         fileNameOrbit, fileNameStarCamera, fileNameAccelerometer;
    EarthRotationPtr earthRotation;
    ThermospherePtr  thermosphere;
    Bool             useTemperature, useWind;
    EphemeridesPtr   ephemerides;

    readConfig(config, "outputfileDensity",                fileNameOutDensity,     Config::MUSTSET,  "",    "MISCVALUE (kg/m^3)");
    readConfig(config, "outputfileAerodynamicDiagnostics", fileNameOutDiagnostics, Config::OPTIONAL, "",    "MISCVALUES: 20 aerodynamic diagnostic quantities");
    readConfig(config, "satelliteModel",                   fileNameSatellite,      Config::OPTIONAL, "{groopsDataDir}/satelliteModel/", "satellite macro model");
    readConfig(config, "inputfileOrbit",                   fileNameOrbit,          Config::MUSTSET,  "",    "");
    readConfig(config, "inputfileStarCamera",              fileNameStarCamera,     Config::MUSTSET,  "",    "");
    readConfig(config, "inputfileAccelerometer",           fileNameAccelerometer,  Config::MUSTSET,  "",    "add non-gravitational forces in satellite reference frame");
    readConfig(config, "thermosphere",                     thermosphere,           Config::MUSTSET,  "",    "used to compute temperature and wind");
    readConfig(config, "considerTemperature",              useTemperature,         Config::DEFAULT,  "1",   "compute drag and lift, otherwise simple drag coefficient is used");
    readConfig(config, "considerWind",                     useWind,                Config::DEFAULT,  "1",   "");
    readConfig(config, "earthRotation",                    earthRotation,          Config::MUSTSET,  "",    "");
    readConfig(config, "ephemerides",                      ephemerides,            Config::OPTIONAL, "jpl", "");
    if(isCreateSchema(config)) return;

    // open and test instrument files
    // ------------------------------
    InstrumentFile orbitFile, starCameraFile, accelerometerFile;
    orbitFile.open(fileNameOrbit);
    starCameraFile.open(fileNameStarCamera);
    accelerometerFile.open(fileNameAccelerometer);
    InstrumentFile::checkArcCount({orbitFile, starCameraFile, accelerometerFile});

    SatelliteModelPtr satellite;
    if(!fileNameSatellite.empty())
      readFileSatelliteModel(fileNameSatellite, satellite);
    if(!satellite)
      throw(Exception("satelliteModel is required to compute aerodynamic force and diagnostics"));

    // Each internal epoch contains density followed by the 20 diagnostic values.
    // Returning them together ensures that all data are gathered correctly in parallel/MPI execution.
    logStatus<<"computing density and aerodynamic diagnostics"<<Log::endl;
    std::vector<Arc> arcListCombined(orbitFile.arcCount());
    Parallel::forEach(arcListCombined, [&](UInt arcNo)
    {
      OrbitArc        orbit        = orbitFile.readArc(arcNo);
      StarCameraArc   starCamera   = starCameraFile.readArc(arcNo);
      AccelerometerArc accelerometer = accelerometerFile.readArc(arcNo);
      Arc::checkSynchronized({orbit, starCamera, accelerometer});

      MiscValuesArc output;
      for(UInt k=0; k<orbit.size(); k++)
      {
        Rotary3d rotSat;
        if(starCamera.size())
          rotSat = starCamera.at(k).rotary;
        const Time     time     = orbit.at(k).time;
        const Rotary3d rotEarth = earthRotation->rotaryMatrix(time);
        const Vector3d omega    = earthRotation->rotaryAxis(time);

        Vector3d positionSun;
        if(ephemerides)
          positionSun = ephemerides->position(time, Ephemerides::SUN);
        satellite->changeState(time, orbit.at(k).position, orbit.at(k).velocity, positionSun, rotSat, rotEarth);

        Double   modelDensity, modelTemperature;
        Vector3d modelWindTrf;
        thermosphere->state(time, rotEarth.rotate(orbit.at(k).position), modelDensity, modelTemperature, modelWindTrf);

        // Quantities actually used by the aerodynamic-force computation.
        const Double   temperatureUsed = useTemperature ? modelTemperature : 0.;
        const Vector3d windTrfUsed      = useWind ? modelWindTrf : Vector3d();

        // All four velocity vectors below are expressed in SRF.
        const Vector3d velocitySatelliteSrf = rotSat.inverseRotate(orbit.at(k).velocity);
        const Vector3d velocityCorotationSrf = rotSat.inverseRotate(crossProduct(omega, orbit.at(k).position));
        const Vector3d velocityWindSrf = rotSat.inverseRotate(rotEarth.inverseRotate(windTrfUsed));
        const Vector3d velocityRelativeSrf = velocityCorotationSrf + velocityWindSrf - velocitySatelliteSrf;

        // force() requires a unit direction and the separate relative speed.
        Vector3d direction = velocityRelativeSrf;
        const Double relativeSpeed = direction.normalize();
        const Vector3d forceUnitDensity = MiscAccelerationsAtmosphericDrag::force(
                                            satellite, direction, relativeSpeed, 1., temperatureUsed);
        const Double satelliteMass = satellite->mass;
        const Vector3d accelerationUnitDensity = (1./satelliteMass) * forceUnitDensity;
        const Double density = accelerometer.at(k).acceleration.x() / accelerationUnitDensity.x();
        const Double effectiveCaX = 2.*forceUnitDensity.x()/(relativeSpeed*relativeSpeed);

        MiscValuesEpoch epoch(21);
        epoch.time = time;
        UInt i = 0;
        epoch.values(i++) = density;
        epoch.values(i++) = velocitySatelliteSrf.x();
        epoch.values(i++) = velocitySatelliteSrf.y();
        epoch.values(i++) = velocitySatelliteSrf.z();
        epoch.values(i++) = velocityCorotationSrf.x();
        epoch.values(i++) = velocityCorotationSrf.y();
        epoch.values(i++) = velocityCorotationSrf.z();
        epoch.values(i++) = velocityWindSrf.x();
        epoch.values(i++) = velocityWindSrf.y();
        epoch.values(i++) = velocityWindSrf.z();
        epoch.values(i++) = velocityRelativeSrf.x();
        epoch.values(i++) = velocityRelativeSrf.y();
        epoch.values(i++) = velocityRelativeSrf.z();
        epoch.values(i++) = relativeSpeed;
        epoch.values(i++) = accelerationUnitDensity.x();
        epoch.values(i++) = accelerationUnitDensity.y();
        epoch.values(i++) = accelerationUnitDensity.z();
        epoch.values(i++) = effectiveCaX;
        epoch.values(i++) = modelTemperature;
        epoch.values(i++) = modelDensity;
        epoch.values(i++) = satelliteMass;
        output.push_back(epoch);
      }
      return output;
    }, comm);

    if(Parallel::isMaster(comm))
    {
      std::vector<Arc> arcListDensity(arcListCombined.size());
      std::vector<Arc> arcListDiagnostics(arcListCombined.size());

      for(UInt arcNo=0; arcNo<arcListCombined.size(); arcNo++)
      {
        MiscValueArc  densityArc;
        MiscValuesArc diagnosticsArc;
        for(UInt k=0; k<arcListCombined.at(arcNo).size(); k++)
        {
          const Vector combined = arcListCombined.at(arcNo).at(k).data();

          MiscValueEpoch densityEpoch;
          densityEpoch.time  = arcListCombined.at(arcNo).at(k).time;
          densityEpoch.value = combined(0);
          densityArc.push_back(densityEpoch);

          MiscValuesEpoch diagnosticsEpoch(20);
          diagnosticsEpoch.time = densityEpoch.time;
          for(UInt i=0; i<20; i++)
            diagnosticsEpoch.values(i) = combined(i+1);
          diagnosticsArc.push_back(diagnosticsEpoch);
        }
        arcListDensity.at(arcNo)     = densityArc;
        arcListDiagnostics.at(arcNo) = diagnosticsArc;
      }

      logStatus<<"write density data to file <"<<fileNameOutDensity<<">"<<Log::endl;
      InstrumentFile::write(fileNameOutDensity, arcListDensity);

      if(!fileNameOutDiagnostics.empty())
      {
        logStatus<<"write aerodynamic diagnostics to file <"<<fileNameOutDiagnostics<<">"<<Log::endl;
        InstrumentFile::write(fileNameOutDiagnostics, arcListDiagnostics);
      }
    }
  }
  catch(std::exception &e)
  {
    GROOPS_RETHROW(e)
  }
}

/***********************************************/
