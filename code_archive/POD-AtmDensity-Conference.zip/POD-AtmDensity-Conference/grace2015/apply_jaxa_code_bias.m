function code=apply_jaxa_code_bias(obs,bias,latency)
% Apply GPS P1/P2 biases to row-form IF code, using past stream timestamps.
% Default reproduces the original five-second product availability delay.
if nargin<3,latency=5;end
assert(isscalar(latency)&&isfinite(latency)&&latency>=0,'Invalid latency');
f1=1575.42e6;f2=1227.60e6;alpha=f1^2/(f1^2-f2^2);beta=-f2^2/(f1^2-f2^2);
code=nan(size(obs.code_IF_m));
for p=1:32
 key=sprintf('m1059_p%d',p);if ~isfield(bias,key),continue,end
 z=bias.(key);ix=find(obs.prn==p);[times,order]=sort(obs.t(ix)-latency);j=0;
 for k=1:numel(times)
  while j<size(z,1)&&z(j+1,1)<=times(k),j=j+1;end
  if j>0,row=ix(order(k));code(row)=obs.code_IF_m(row)-alpha*z(j,6)-beta*z(j,7);end
 end
end
end
