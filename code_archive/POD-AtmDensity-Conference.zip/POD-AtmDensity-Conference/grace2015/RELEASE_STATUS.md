# Release status

Validated native MATLAB raw-input reproduction of the supplied 2015 manuscript, including S/F/R/O/M/P and auxiliary T0/T1/TP. Approximate agreement is demonstrated; S2 is explicitly flagged and investigated. Run `run_manuscript`. Read `VALIDATION.md` and `INVESTIGATION_S2.md` before interpreting the numerical reproduction. This supersedes the earlier single-satellite-only ZIP.
