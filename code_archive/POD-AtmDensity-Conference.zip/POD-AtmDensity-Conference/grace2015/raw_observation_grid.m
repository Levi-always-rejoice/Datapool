function obs=raw_observation_grid(sat,folder,bias)
% Original GPS1B -> IF observations, quality masks and continuity labels.
% No saved decoded arrays are read. Optional bias is freshly decoded by caller.
if nargin<2,folder=fullfile(fileparts(mfilename('fullpath')),'raw');end
if nargin<3,bias=read_jaxa_code_bias(fullfile(folder,'ssr18360.rtcm3'));end
rows=read_raw_inputs(sat,folder);a=rows.gps.values;v=a(:,4:end);
obs=struct('rx',(0:10:86390)','code',nan(8640,33),'phase',nan(8640,33),...
 'snr',nan(8640,33),'ids',-ones(8640,33),'mw',nan(8640,33),'gf',nan(8640,33));
code=apply_jaxa_code_bias(rows,bias,5);previous=nan(33,1);track=zeros(33,1);serial=0;
seen=false(8640,33);
for j=1:size(a,1)
 t=a(j,1);p=a(j,2)+1;i=round(t/10)+1;
 if i<1||i>8640||abs(t-(i-1)*10)>1e-4,continue,end
 assert(~seen(i,p),'Duplicate receiver/PRN/epoch');seen(i,p)=true;
 if isnan(previous(p))||t-previous(p)>10.1||bitand(uint8(a(j,3)),15)
  serial=serial+1;track(p)=serial;
 end
 assert(isnan(previous(p))||t>previous(p),'Non-increasing PRN epochs');
 previous(p)=t;obs.ids(i,p)=track(p);obs.code(i,p)=code(j);obs.phase(i,p)=rows.phase_IF_m(j);
 obs.snr(i,p)=min(v(j,[8 9]));obs.mw(i,p)=rows.MW_m(j);obs.gf(i,p)=rows.GF_m(j);
end
end
