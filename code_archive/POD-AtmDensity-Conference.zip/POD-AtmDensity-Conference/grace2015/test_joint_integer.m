function report=test_joint_integer
% Exhaustive small-dimension oracle independent of decorrelation/search code.
rng(241);worst=0;
for n=2:4
 for rep=1:10
  M=randn(n);Q=M*M'+.2*eye(n);a=.8*rand(n,1)-.4;
  [z,cost,complete]=gnss_joint_integer(a,Q);assert(complete&&numel(cost)==2);
  grids=cell(1,n);[grids{:}]=ndgrid(-3:3);allz=zeros(numel(grids{1}),n);
  for j=1:n,allz(:,j)=grids{j}(:);end
  delta=allz-a';expected=sort(sum((delta/Q).*delta,2));err=max(abs(cost(:)-expected(1:2)));worst=max(worst,err);
  assert(err<1e-8);assert(all(z==round(z),'all'));
 end
end
[~,~,complete]=gnss_joint_integer([.1;.2],eye(2),1);assert(~complete,'Search budget exhaustion must be rejected');
report=struct('passed',true,'exhaustive_cases',30,'maximum_cost_discrepancy',worst,'incomplete_search_rejected',true);disp(report);
end
