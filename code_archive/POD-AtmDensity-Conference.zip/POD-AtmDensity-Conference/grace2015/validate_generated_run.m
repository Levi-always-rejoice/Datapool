function report=validate_generated_run(out)
% Validate newly generated outputs, not an input to the retrieval.
root=fileparts(mfilename('fullpath'));files=dir(fullfile(out,'*_navigation.mat'));assert(~isempty(files));report=struct;
for k=1:numel(files)
 sat=files(k).name(1);n=load(fullfile(out,files(k).name));d=load(fullfile(out,[sat '_density.mat']));d=d.density;
 assert(d.injection_error<1e-17&&d.QR_difference<1e-17);
 assert(n.nav.continuity_error<1e-6&&n.nav.integer_error<1e-8);
 [~,age]=raw_attitude(sat,n.bootstrap.t,fullfile(root,'raw'));
 bad=age>5;assert(all(all(isnan(n.bootstrap.r(bad,:)))),'Navigation bridged missing attitude');
 report.(sat)=struct('injection_error_kg_m3',d.injection_error,'QR_difference_kg_m3',d.QR_difference, ...
  'attitude_gap_epochs_excluded',sum(bad),'supported_density_centers',sum(d.supported), ...
  'accepted_partial_integer_links',size(n.integers.H,1), ...
  'orbit_continuity_constraint_error',n.nav.continuity_error,'integer_constraint_error_m',n.nav.integer_error);
end
f=fopen(fullfile(out,'numerical_validation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report)
end
