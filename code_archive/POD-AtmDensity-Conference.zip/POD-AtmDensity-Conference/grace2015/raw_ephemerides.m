function [sun,moon]=raw_ephemerides(t,models)
% Original GROOPS JPL DE432 binary; times are already in GPS in this file.
% GPL-3.0 reader adaptation; no prepared Sun/Moon position array input.
f=fopen(fullfile(models,'ephemerides_JPL_DE432.dat'),'r','ieee-le');assert(f>=0);c=onCleanup(@()fclose(f));
assert(fread(f,1,'*char')=='B');ty=readstr;ver=readstr;fread(f,mod(1+numel(ty)+numel(ver),8),'*char');
assert(strcmp(ty,'ephemerides'));nb=readu;ni=readu;ratio=fread(f,1,'double');
meta=reshape(fread(f,nb*3,'uint64=>double'),3,[])';times=zeros(ni+1,1);
for k=1:ni+1,times(k)=fread(f,1,'int64=>double')+fread(f,1,'double');end
base=ftell(f);sizes=meta(:,1).*meta(:,2).*(meta(:,3)+1);offset=[0;cumsum(sizes)];stride=sum(sizes)*8;
mjd=57096+t(:)/86400;sun=zeros(numel(t),3);moon=sun;
interval=discretize(mjd,times);assert(all(isfinite(interval)),'Ephemeris date outside coverage');
for j=unique(interval)'
 ix=find(interval==j);data=cell(nb,1);fseek(f,base+(j-1)*stride,'bof');
 for k=1:nb,data{k}=reshape(fread(f,sizes(k),'double'),meta(k,2),meta(k,3)+1,meta(k,1));end
 emb=body(3);luna=body(10);sol=body(11);moon(ix,:)=luna;sun(ix,:)=sol-emb+luna/(1+ratio);
end
 function r=body(k)
  span=(times(j+1)-times(j))/meta(k,1);v=(mjd(ix)-times(j))/span;sub=floor(v)+1;u=2*(v-floor(v))-1;
  r=zeros(numel(ix),3);
  for ss=unique(sub)'
   use=find(sub==ss);T=ones(numel(use),meta(k,3)+1);if size(T,2)>1,T(:,2)=u(use);end
   for d=3:size(T,2),T(:,d)=2*u(use).*T(:,d-1)-T(:,d-2);end
   r(use,:)=T*data{k}(:,:,ss)';
  end
 end
 function v=readu,v=fread(f,1,'uint64=>double');end
 function s=readstr,n=readu;s=fread(f,n,'*char')';end
end
