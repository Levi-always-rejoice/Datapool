function out=read_grace_ascii(path,columns,day)
% Read selected ONE-BASED numeric columns from a JPL ASCII mission product.
% Non-numeric columns must not be selected. No calibration/frame change.
if nargin<3,day=datetime(2015,3,15);end
f=fopen(path,'r');assert(f>=0,'Cannot open mission file');c=onCleanup(@()fclose(f));
header={};found=false;
while ~feof(f)
 s=fgetl(f);header{end+1}=s; %#ok<AGROW>
 if contains(s,'END OF HEADER'),found=true;break,end
end
assert(found,'Missing mission header terminator');
% Read all tokens as strings because satellite identifiers are non-numeric.
lines=textscan(f,'%s','Delimiter','\n','Whitespace','');lines=lines{1};
a=nan(numel(lines),numel(columns));n=0;
for k=1:numel(lines)
 if isempty(strtrim(lines{k})),continue,end
 tokens=strsplit(strtrim(lines{k}));assert(numel(tokens)>=max(columns),'Truncated mission row');
 v=str2double(tokens(columns));assert(all(isfinite(v)),'Non-numeric selected mission field');
 n=n+1;a(n,:)=v;
end
a=a(1:n,:);ix=find(columns==1);if ~isempty(ix),a(:,ix)=a(:,ix)-seconds(day-datetime(2000,1,1,12,0,0));end
out=struct('values',a,'columns',columns,'header',{header},'time_system','GPS');
end
