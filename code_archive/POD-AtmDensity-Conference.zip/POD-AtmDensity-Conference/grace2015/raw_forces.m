function d=raw_forces(sat,t,r,v,rot,models)
% Recompute gravity, third bodies, elastic tides, relativity, radiation and
% full unit-density aerodynamic acceleration on the supplied GNSS orbit.
% Uses public model coefficients, never a saved force/density table.
t=t(:);N=numel(t);mu=3.986004418e14;c=299792458;Re=6378136.3;earth=raw_earth_rotation(t,models);[sun,moon]=raw_ephemerides(t,models);
ecef=reshape(pagemtimes(earth,reshape(r',3,1,[])),3,[])';g=zeros(N,3);
for lo=1:1000:N,ii=lo:min(lo+999,N);[gx,gy,gz]=gravitysphericalharmonic(ecef(ii,:),'EGM2008',120);g(ii,:)=[gx gy gz];end
g=reshape(pagemtimes(permute(earth,[2 1 3]),reshape(g',3,1,[])),3,[])';radius=vecnorm(r,2,2);u=r./radius;external=zeros(N,3);tides=external;
for k=1:2
 if k==1,b=sun;gm=1.32712440018e20;else,b=moon;gm=4.902800066e12;end
 dist=vecnorm(b,2,2);bn=b./dist;co=sum(u.*bn,2);external=external+gm*((b-r)./vecnorm(b-r,2,2).^3-b./dist.^3);
 for degree=2:3
  if degree==2,love=.3;pol=(3*co.^2-1)/2;der=3*co;else,love=.093;pol=(5*co.^3-3*co)/2;der=(15*co.^2-3)/2;end
  factor=love*gm*Re^(2*degree+1)./(dist.^(degree+1).*radius.^(degree+2));tides=tides+factor.*(der.*bn-((degree+1)*pol+co.*der).*u);
 end
end
rel=mu./(c^2*radius.^3).*((4*mu./radius-sum(v.^2,2)).*r+4*sum(r.*v,2).*v);
macro=raw_spacecraft(sat,models);mass=interp1(macro.mass_history(:,1),macro.mass_history(:,2),57096+t/86400,'linear');assert(all(isfinite(mass)));
[temp,wind]=raw_thermosphere(t,ecef,models);wind=reshape(pagemtimes(permute(earth,[2 1 3]),reshape(wind',3,1,[])),3,[])';
corot=reshape(pagemtimes(permute(earth,[2 1 3]),reshape(cross(repmat([0 0 7.292115e-5],N,1),ecef,2)',3,1,[])),3,[])';
flow=corot+wind-v;speed=vecnorm(flow,2,2);body=reshape(pagemtimes(permute(rot,[2 1 3]),reshape((flow./speed)',3,1,[])),3,[])';
a=groops_aerodynamic_force(macro,body,speed,1,temp)./mass;a=reshape(pagemtimes(rot,reshape(a',3,1,[])),3,[])';K=vecnorm(a,2,2);drag=a./K;
grid=raw_ceres(models,57096+t/86400);normals=grid.points./vecnorm(grid.points,2,2);rad=zeros(N,3);shadow=eclipse(r,sun);
for i=1:N
 B=rot(:,:,i)';E=earth(:,:,i);rs=(B*r(i,:)')';ss=(B*sun(i,:)')';flow=(rs-ss);distance=norm(flow);
 pressure=shadow(i)*1367/c*(149597870700/distance)^2;F=groops_radiation_force(macro,flow/distance,pressure,0);
 ds=ecef(i,:)-grid.points;dslen=vecnorm(ds,2,2);direction=ds./dslen;co=sum(direction.*normals,2);ix=find(co>0);
 factor=co(ix).*grid.areas(ix)./(pi*dslen(ix).^2);sunE=(E*sun(i,:)')';sdir=grid.points(ix,:)-sunE;sdist=vecnorm(sdir,2,2);inc=max(0,-sum(sdir./sdist.*normals(ix,:),2));
 visible=factor.*grid.albedo(ix).*inc*1367/c.*(149597870700./sdist).^2;infrared=factor.*grid.flux(ix)/c;
 bodydir=direction(ix,:)*E*rot(:,:,i);F=F+sum(groops_radiation_force(macro,bodydir,visible,infrared),1);rad(i,:)=(rot(:,:,i)*F')'/mass(i);
 if mod(i,1500)==0,fprintf('  raw forces %d/%d\n',i,N);end
end
d=struct('t',t,'r',r,'v',v,'rot',permute(rot,[3 1 2]),'known',g+external+tides+rel+rad,'rad',rad,'drag',drag,'K',K,'temperature',temp,'mass',mass);
d.gradient=zeros(N,3,3);for i=1:N,d.gradient(i,:,:)=gnss_gradient(r(i,:)');end
end
function f=eclipse(r,sun)
s=sun-r;rs=vecnorm(s,2,2);rr=vecnorm(r,2,2);a=asin(695700000./rs);b=asin(6378136.3./rr);ang=acos(max(-1,min(1,sum(s./rs.*(-r./rr),2))));f=ones(size(rr));f(ang<=b-a)=0;ix=ang>b-a&ang<a+b;
x=a(ix);y=b(ix);z=ang(ix);area=x.^2.*acos(max(-1,min(1,(z.^2+x.^2-y.^2)./(2*z.*x))))+y.^2.*acos(max(-1,min(1,(z.^2+y.^2-x.^2)./(2*z.*y))))-.5*sqrt(max(0,(-z+x+y).*(z+x-y).*(z-x+y).*(z+x+y)));f(ix)=1-area./(pi*x.^2);
end
