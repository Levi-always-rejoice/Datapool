function q=raw_navigation_design(sat,obs,tx,bootstrap,receiver,ants,raw,models)
% Rebuild observation residuals and force geometry from this run's raw-data orbit.
ix=find(all(isfinite(bootstrap.r),2));t=obs.rx(ix);r=bootstrap.r(ix,:);v=bootstrap.v(ix,:);rot=raw_attitude(sat,t,raw);
q=raw_forces(sat,t,r,v,rot,models);q.phase=nan(numel(t),33);q.code=q.phase;q.elev=q.phase;q.h=zeros(numel(t),33,3);wind=nan(33,1);
for j=1:numel(t)
 i=ix(j);ps=find(isfinite(obs.phase(i,:))'&isfinite(tx.clock(i,:))'&~cellfun(@isempty,ants));
 if isempty(ps),continue,end
 [base,phase,h,el,ww]=raw_observation_model(i,r(j,:),ps,rot(:,:,j),receiver,ants,tx,wind);
 q.phase(j,ps)=obs.phase(i,ps)-phase';q.code(j,ps)=obs.code(i,ps)-base';q.h(j,ps,:)=h;q.elev(j,ps)=el;wind(ps)=ww;
end
q.good=isfinite(q.phase)&q.elev>deg2rad(10);ids=obs.ids(ix,:);same=q.good(2:end,:)&q.good(1:end-1,:)&ids(2:end,:)==ids(1:end-1,:);dx=diff(q.phase);dd=dx;dd(~same)=NaN;common=median(dd,2,'omitnan');common(~isfinite(common))=0;
jump=[false(1,33);same&abs(dx-common)>.10];q.good(jump)=false;q.ids=ids*100000+cumsum(jump,1);
[ei,pi]=find(q.good);[~,~,inv]=unique([pi,q.ids(sub2ind(size(q.ids),ei,pi))],'rows');q.labels=zeros(size(q.good));q.labels(sub2ind(size(q.good),ei,pi))=inv;
q.B0=accumarray(inv,q.phase(sub2ind(size(q.phase),ei,pi)),[],@median);q.used=true(numel(q.B0),1);q.clock=zeros(numel(t),1);q.thr=[];
q.mw=obs.mw(ix,:);q.gf=obs.gf(ix,:);pod=raw_pod_reference(sat,raw,models);R=gnss_hermite(pod.t,pod.r,pod.v);q.pod_r=ppval(R,t')';
end
