function out=read_jaxa_sp3(path)
% JAXA daily GPS SP3 archive: native epochs, ECEF metres, clock seconds.
% No interpolation, extrapolation, frame rotation, APC or relativity change.
if endsWith(path,'.gz')
 folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s'));
 names=gunzip(path,folder);path=names{1};
end
f=fopen(path,'r');assert(f>=0,'Cannot open SP3');c=onCleanup(@()fclose(f));
% Fast vectorized fixed-width decoding after splitting the file into lines.
lines=textscan(f,'%s','Delimiter','\n','Whitespace','');lines=lines{1};clear c; % Close before parsing/temporary-directory cleanup
isepoch=startsWith(lines,'* ');ep=find(isepoch);assert(~isempty(ep),'No SP3 epochs');
ev=sscanf(strjoin(lines(ep),newline),' * %f %f %f %f %f %f',[6 Inf])';
assert(size(ev,1)==numel(ep),'Invalid SP3 epochs');
days=unique(ev(:,1:3),'rows');assert(size(days,1)<=2,'Reader expects one daily SP3 including optional next midnight');
t=seconds(datetime(ev(:,1),ev(:,2),ev(:,3),ev(:,4),ev(:,5),ev(:,6))-datetime(ev(1,1),ev(1,2),ev(1,3)));assert(all(diff(t)>0)&&max(t)<=86400,'Invalid daily SP3 epochs');
which=cumsum(isepoch);ix=find(startsWith(lines,'PG'));epoch=which(ix);assert(all(epoch>0),'Position before first epoch');
s=char(lines(ix));assert(size(s,2)>=60,'Truncated SP3 position');
prn=str2double(string(s(:,3:4)));v=zeros(numel(ix),4);
for k=1:4,v(:,k)=str2double(string(s(:,5+14*(k-1):18+14*(k-1))));end
valid=prn>=1&prn<=32&all(abs(v(:,1:3))<1e5,2)&abs(v(:,4))<999999&vecnorm(v(:,1:3),2,2)>10000;
r=nan(numel(t),33,3);clock=nan(numel(t),33);
ind=sub2ind(size(clock),epoch(valid),prn(valid)+1);
for k=1:3,z=r(:,:,k);z(ind)=v(valid,k)*1000;r(:,:,k)=z;end
clock(ind)=v(valid,4)*1e-6;
out=struct('t',t,'position',r,'clock',clock,'date',days,'frame','ECEF','time_system','GPS');
end


