# Investigated S2 discrepancy (09:40–10:25 UTC)

The raw-input release gives differential-density RMS **2.9841e-14 kg/m3**, correlation **0.7872**, compared with manuscript **2.4854e-14**, **0.88385**. This is flagged; it is not claimed numerically equivalent.

## Isolation tests

| Test | S2 RMS (kg/m3) | Correlation |
|---|---:|---:|
| Delivered raw-input method | 2.98407e-14 | 0.787185 |
| Change ACC bias only to legacy value | 3.37097e-14 | 0.786417 |
| Legacy aerodynamic basis, current bias | 2.94942e-14 | 0.790155 |
| Legacy force/aero/bias, regenerated orbit | 3.10205e-14 | 0.788555 |
| Native density operator, original orbit/force inputs | 2.48971e-14 | 0.883297 |
| Change only the POD position reference used for assisted offsets to the old GROOPS-converted reference | 2.15708e-14 | 0.911936 |

These are development-only controlled substitutions, not alternate default estimator outputs. Original prepared arrays were used solely to isolate causes and are not shipped or read by `run_manuscript`.

The native orbit solver on identical observations, masks and fixed offsets agrees with the original Python trajectory at 1.02/1.13 micrometres RMS (A/B), and 0.42/0.33 micrometres in S2. Thus this discrepancy is not explained by the MATLAB orbit or density solver port.

The raw GNV-to-inertial reference and the manuscript's preconverted GROOPS reference differ by 1.42 cm daily RMS and **2.315 cm in S2** for both spacecraft. The delivered POD-assisted navigation differs from the earlier trajectory by about 2.07 cm in S2. Changing only the reference used for estimating the assisted offsets restores strong S2 agreement, while leaving the raw force reconstruction, density calibration and fixed-integer mask unchanged. This isolates the **POD-assisted reference-conversion dependency** as the main source of the local discrepancy. It does not establish which conversion is more accurate.

The delivered conversion uses original GNV states and the supplied ESA ERP records with MATLAB IAU 2000/2006 rotation. The exact earlier GROOPS Earth-rotation configuration was unavailable; the low-level cause within that conversion remains unresolved. No empirical centimetre correction was fitted or inserted into the release.

The primary result remains the fully regenerated raw-input solution. GNSS-only F/R results do not use this POD reference to estimate their offsets. Their range RMS and the fixed constraint space match the manuscript closely. P retains the documented POD assistance, and its sensitivity must remain visible in interpretation of selected short segments.
