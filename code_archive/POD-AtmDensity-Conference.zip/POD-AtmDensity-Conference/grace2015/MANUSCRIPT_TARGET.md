# Reproduction target: IEEE Aerospace Conference 2027 manuscript

Authoritative supplied PDF: `ieee_aeroconf_2027.pdf`, **Assessing Relative GNSS Constraints for Thermospheric Density Retrieval**, Wei Li and Yang Wang. Experiment: **GRACE A/B, 2015-03-15**. This supersedes the older 2023 near-real-time manuscript as the package target.

This directory is under development. It is not yet a completed reproduction package. The existing raw MATLAB package contains only the auxiliary 10-minute single-satellite branch, with reconstructed physical inputs.

## Required native MATLAB branches

- **S:** independent temporal-continuity benchmark, 20-minute navigation blocks and 20-minute density fits. Figure 1.
- **F/R:** exact fully float precursor and GNSS-only intersatellite integer conditioning; same final-R force geometry and common observation-only support. Table II.
- **O/M/P:** POD-supported offset solution with original mask; same real offsets with the P mask; integer-conditioned offsets with that same mask. Table III.
- **P selected/full support:** S1 03:15–04:15 UTC; S2 09:40–10:25 UTC; all supported centers. Figures 2–4 and Table IV.
- **T0/T1:** auxiliary temporal integer-change tests using 10-minute dynamics; this does not replace S or F/R.

All estimates must be computed before evaluation. KBR segment datums, retained calibration, common timestamp masks, half-open intervals, and the 16-second GPS-to-UTC offset must follow the paper. One-second moving outputs are correlated and must not be counted as independent samples.

## Checks against reported values

- F/R: 609 screened wide-lane candidates, 333 independent DD coordinates, 188 accepted combinations; 16,833 matched KBR epochs and 73,636 common density centers.
- F/R KBR RMS: 29.206 / 17.394 mm; differential-density RMS 2.288e-13 / 2.123e-13 kg/m3, correlation 0.105 / 0.162.
- O/M/P: 3,567 common centers; differential-density RMS 6.960e-14 / 5.091e-14 / 4.152e-14 kg/m3.
- P: 754 audited DD relations, 358 independent constraints; 35,916 supported density centers and 7,154 matched KBR epochs.
- P S1/S2: 3,600 / 2,700 centers; density-difference RMS 1.76e-14 / 2.49e-14 kg/m3, correlation 0.899 / 0.884.
- P full support: density-difference RMS 5.5151173145e-14 kg/m3, correlation 0.4966094385; range RMS 1.9402738601 mm; projected drag RMS 12.2532428783 nm/s2.

These values are evaluation targets only. They must never enter parameter estimation, masks, ambiguity selection or calibration.

## Physical-input issue identified in the paper

Section 2.B explicitly retains earlier radiation tables, effective aerodynamic coefficients and same-date POD-assisted ACC bias calibration, with some quantities evaluated on POD geometry. Their generating configuration was unavailable in the supplied project. The newer raw-input MATLAB implementation reconstructs these terms with different documented settings. The user authorized approximate raw-input reproduction, with investigation of substantial differences. Legacy prepared tables are not runtime inputs. Numerical departures must be reported rather than overwritten with archived results.

## Source mapping found

Existing Python reference modules under `outputs/gnss_relative_phase_test` include `grace2015_independent_float.py`, `grace2015_relative_integer.py`, `grace2015_joint_ILS.py`, `grace2015_joint_ILS_validated.py`, `grace2015_same_method_POD_offsets.py`, `grace2015_POD_integer_audit.py`, `grace2015_resolve_POD_integer.py`, and the corresponding navigation/density/report modules. Native MATLAB ports are being developed; no Python runtime is permitted in the delivered package.
