function out=read_grace_gnv(path)
% Read original GNV1B position AND velocity (not position error columns).
% Retains Earth-fixed frame; transformation is a separate explicit step.
z=read_grace_ascii(path,[1 4 5 6 10 11 12 7 8 9 13 14 15]);a=z.values;
out=struct('t',a(:,1),'r_ecef',a(:,2:4),'v_ecef',a(:,5:7),...
 'position_error',a(:,8:10),'velocity_error',a(:,11:13),'header',{z.header});
f=fopen(path,'r');c=onCleanup(@()fclose(f));
while ~feof(f),s=fgetl(f);if contains(s,'END OF HEADER'),break,end,end
while ~feof(f)
 s=fgetl(f);if ~ischar(s),break,end;s=strtrim(s);if isempty(s),continue,end
 tokens=strsplit(s);assert(strcmp(tokens{3},'E'),'GNV frame must be E');
end
end

