function [base,phase,h,elev,wind]=raw_observation_model(i,r,p,rot,receiver,ants,cache,previous)
% GPS1B observation epochs are already GPS time; no receiver clock time shift.
c=299792458;mu=3.986004418e14;f1=1575.42e6;f2=1227.60e6;alpha=f1^2/(f1^2-f2^2);beta=-f2^2/(f1^2-f2^2);
rx=r(:)+rot*receiver.arp;p0=reshape(cache.ps(i,p,:),[],3);v0=reshape(cache.vs(i,p,:),[],3);a0=reshape(cache.acc(i,p,:),[],3);ps=p0;
for k=1:3,distance=vecnorm(rx'-ps,2,2);dt=.075-distance/c;ps=p0+dt.*v0+.5*dt.^2.*a0;end
vel=v0+dt.*a0;h=unit(rx'-ps);distance=vecnorm(rx'-ps,2,2);clock=cache.clock(i,p)'+cache.clock_rate(i,p)'.*dt;
rs=vecnorm(ps,2,2);rr=norm(rx);rel=-2*sum(ps.*vel,2)/c;sh=zeros(size(rs));if rr>1e6,sh=2*mu/c^2*log((rs+rr+distance)./(rs+rr-distance));end
arf=rot';arf(3,:)=-arf(3,:);los=-h*arf';elev=asin(max(-1,min(1,los(:,3))));
sun=cache.sun(i,:);z=-unit(ps);y=unit(cross(z,sun-ps,2));x=cross(y,z,2);antenna=zeros(numel(p),1);nadir=acosd(max(-1,min(1,sum(h.*z,2))));
for j=1:numel(p)
 at=ants{p(j)};off=alpha*at.G01_offset+beta*at.G02_offset;offset=x(j,:)*off(1)-y(j,:)*off(2)+z(j,:)*off(3);
 zg=(0:numel(at.G01_pcv)-1)'*at.zen(3)+at.zen(1);zz=max(zg(1),min(zg(end),nadir(j)));
 antenna(j)=interp1(zg,alpha*at.G01_pcv+beta*at.G02_pcv,zz,'linear')-h(j,:)*offset';
end
az=mod(atan2(los(:,2),los(:,1)),2*pi);zen=acosd(max(-1,min(1,los(:,3))));
for k=1:2
 pp=receiver.patterns{k};tab=pp.pcv;ia=az/(2*pi)*size(tab,1);iz=max(0,min(size(tab,2)-1,zen/pp.dz));a=floor(ia);b=floor(iz);da=ia-a;db=iz-b;a2=mod(a+1,size(tab,1));b2=min(b+1,size(tab,2)-1);
 pc=(1-da).*(1-db).*tab(sub2ind(size(tab),a+1,b+1))+da.*(1-db).*tab(sub2ind(size(tab),a2+1,b+1))+(1-da).*db.*tab(sub2ind(size(tab),a+1,b2+1))+da.*db.*tab(sub2ind(size(tab),a2+1,b2+1));
 if k==1,factor=alpha;else,factor=beta;end;antenna=antenna+factor*(pc-los*pp.offset);
end
tx=cross(cross(h,x,2),h,2)*arf';ty=cross(cross(h,-y,2),h,2)*arf';wind=atan2(tx(:,2)+ty(:,1),ty(:,2)-tx(:,1))-pi/2;
if nargin>=8,prev=previous(p);valid=isfinite(prev);wind(valid)=prev(valid)+mod(wind(valid)-prev(valid)+pi,2*pi)-pi;end
base=distance-c*clock-rel+sh+antenna;phase=base+wind/(2*pi)*(alpha*c/f1+beta*c/f2);
end
function u=unit(x),u=x./vecnorm(x,2,2);end

