function result=gnss_condition_navigation(model,H,target,fixedB)
% Re-estimate all state/float-offset parameters under exact integer changes.
db=model.db;Q=model.Q;
if nargin>=4,db=fixedB(:)-model.B0;end
if ~isempty(H),HQ=H*Q;db=db+HQ'*((HQ*H')\(target(:)-H*(model.B0+db)));end
B=model.B0+db;c=model.xp+model.T*(model.red\(model.bz-model.Nzb*db));values=[];clocks=[];
for j=1:numel(model.blocks)
 x=model.blocks{j};cc=c((j-1)*12+(1:12));tt=(ceil(x.a):ceil(x.b)-1)';st=gnss_states(x,tt);
 state=squeeze(st(:,1,:))+squeeze(sum(st(:,2:13,:).*reshape(cc,1,12,1),2));
 values=[values;tt,state',repmat(j-1,numel(tt),1)]; %#ok<AGROW>
 labs=max(double(model.q.labels(x.ids,:)),1);delta=reshape(db(labs(:)),size(labs));
 clk=x.my-x.mh*cc-sum(x.wp.*delta,2)./x.den;clocks=[clocks;reshape(model.q.t(x.ids),[],1),clk]; %#ok<AGROW>
end
eq=max(abs(model.C*c-model.d));assert(eq<1e-6,'Orbit continuity failed');
ie=0;if ~isempty(H),ie=max(abs(H*B-target(:)));assert(ie<1e-8,'Integer equality failed');end
result=struct('values',values,'ambiguities',B,'clock',clocks,'continuity_error',eq,'integer_error',ie,'coefficients',c);
end

