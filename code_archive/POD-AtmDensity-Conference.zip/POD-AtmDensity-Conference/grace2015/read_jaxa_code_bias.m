function out=read_jaxa_code_bias(path)
% GPS RTCM 1059 code biases used with JAXA SP3, NOT a full SSR orbit replay.
% Same stream chronology as original implementation. Only 1059 CRCs checked.
f=fopen(path,'rb');assert(f>=0,'Cannot open RTCM');c=onCleanup(@()fclose(f));b=fread(f,Inf,'*uint8');
i=1;latest=-Inf;rows=repmat({zeros(90000,7)},32,1);nr=zeros(32,1);count=0;udi=[1 2 5 10 15 30 60 120 240 300 600 900 1800 3600 7200 10800];
while i<=numel(b)
 assert(i+5<=numel(b)&&b(i)==211,'Invalid/truncated RTCM frame');
 sz=double(bitand(b(i+1),3))*256+double(b(i+2));last=i+sz+5;
 assert(last<=numel(b)&&sz>=2,'Truncated RTCM payload');
 typ=double(b(i+3))*16+double(bitshift(b(i+4),-4));
 if ismember(typ,[1057 1058 1059 1062])
  payload=b(i+3:last-3);assert(numel(payload)>=4,'Truncated SSR header');bit=32;t=double(bitand(payload(2),15))*65536+double(payload(3))*256+double(payload(4));if t>500000,t=t-604800;end
  if typ~=1059,latest=max(latest,t);
  else
   expected=double(b(last-2))*65536+double(b(last-1))*256+double(b(last));
   assert(crc24(b(i:last-3))==expected,'RTCM 1059 CRC mismatch');
   u=udi(take(4,false)+1);take(1,false);iod=take(4,false);provider=take(16,false);solution=take(4,false);ns=take(6,false);
   for k=1:ns
    prn=take(6,false);nb=take(5,false);bias=[0 0];
    for j=1:nb
     mode=take(5,false);v=take(14,true)*.01;
     if mode==2,bias(1)=v;elseif mode==11,bias(2)=v;end
    end
    assert(prn>=1&&prn<=32,'Invalid GPS PRN');
    nr(prn)=nr(prn)+1;rows{prn}(nr(prn),:)=[latest,u,iod,provider,solution,bias];
   end
   count=count+1;if mod(count,20000)==0,fprintf('Decoded %d code-bias messages\n',count);end
  end
 end
 i=last+1;
end
out=struct;
for prn=1:32
 a=rows{prn}(1:nr(prn),:);if isempty(a),continue,end
 a=sortrows(a,1);a=a([diff(a(:,1))~=0;true],:);out.(sprintf('m1059_p%d',prn))=a;
end
fprintf('Read %d CRC-verified GPS code-bias messages\n',count);
 function x=take(n,signed)
  assert(bit+n<=numel(payload)*8,'Truncated RTCM field');x=0;
  firstByte=floor(bit/8)+1;lastByte=ceil((bit+n)/8);
  for z=firstByte:lastByte,x=x*256+double(payload(z));end
  x=mod(floor(x/2^(lastByte*8-bit-n)),2^n);bit=bit+n;
  if signed&&x>=2^(n-1),x=x-2^n;end
 end
end
function c=crc24(bytes)
persistent table
if isempty(table)
 table=zeros(256,1,'uint32');
 for j=0:255
  v=bitshift(uint32(j),16);
  for k=1:8
   top=bitget(v,24);v=bitshift(v,1);if top,v=bitxor(v,uint32(hex2dec('1864CFB')));end
  end
  table(j+1)=bitand(v,uint32(16777215));
 end
end
c=uint32(0);
for j=1:numel(bytes)
 idx=bitxor(bitshift(c,-16),uint32(bytes(j)));
 c=bitxor(bitand(bitshift(c,8),uint32(16777215)),table(double(idx)+1));
end
c=double(c);
end


