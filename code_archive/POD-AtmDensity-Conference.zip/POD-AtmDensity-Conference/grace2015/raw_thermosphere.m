function [temperature,wind]=raw_thermosphere(t,ecef,models)
% Reconstructed setting: NRLMSISE-00 temperature and HWM14 wind.
% Model density is discarded; it is not an orbit prior or density target.
persistent root msis ap
if isempty(root)||~strcmp(root,models)
 msis=readtable_numeric(fullfile(models,'inputMSIS.txt'),10);ap=readtable_numeric(fullfile(models,'apActivity.txt'),2);root=models;
end
t=t(:);gps=57096+t/86400;utc=57096+(t-16)/86400;sec=mod(t-16,86400);doy=floor(utc)-57023+1;
idx=interp1(msis(:,1),(1:size(msis,1))',gps,'previous');prev=interp1(msis(:,1),(1:size(msis,1))',gps-1,'previous');
assert(all(isfinite(idx)&isfinite(prev)),'Missing raw solar/geomagnetic indices');x=msis(idx,:);f107=msis(prev,3);
lla=ecef2lla(ecef);flags=ones(1,23);flags(9)=-1;
[temperature,~]=atmosnrlmsise00(lla(:,3),lla(:,1),lla(:,2),2015*ones(size(t)),doy,sec,x(:,2),f107,x(:,4:10),flags,'Oxygen','Error');temperature=temperature(:,2);
aps=interp1(ap(:,1),ap(:,2),gps,'previous');assert(all(isfinite(aps)));w=atmoshwm(lla(:,1),lla(:,2),lla(:,3),'day',doy,'seconds',sec,'apindex',aps,'model','total','version','14','action','none');
lat=deg2rad(lla(:,1));lon=deg2rad(lla(:,2));north=[-sin(lat).*cos(lon),-sin(lat).*sin(lon),cos(lat)];east=[-sin(lon),cos(lon),zeros(size(lat))];wind=w(:,1).*north+w(:,2).*east;
end
function a=readtable_numeric(path,n)
lines=splitlines(fileread(path));a=zeros(numel(lines),n);count=0;
for j=1:numel(lines),v=sscanf(lines{j},'%f')';if numel(v)==n&&v(1)>40000&&v(1)<90000,count=count+1;a(count,:)=v;end,end
a=a(1:count,:);assert(~isempty(a));
end
