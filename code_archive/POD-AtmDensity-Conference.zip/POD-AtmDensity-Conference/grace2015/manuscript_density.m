function manuscript_density(out)
% One R-based force/window operator shared across all navigation branches.
root=fileparts(mfilename('fullpath'));raw=fullfile(root,'raw');models=fullfile(root,'models');
diary(fullfile(out,'density.log'));cleanup=onCleanup(@()diary('off'));
for sat='AB'
 branches=load(fullfile(out,[sat '_branches.mat']));z=branches.R.values;
 ii=unique([1:5:size(z,1),size(z,1),find(diff(z(:,1))>1)',find(diff(z(:,1))>1)'+1]);
 fprintf('Common R force geometry %s\n',sat);frot=raw_attitude(sat,z(ii,1),raw);
 d=raw_forces(sat,z(ii,1),z(ii,2:4),z(ii,5:7),frot,models);
 pod=raw_pod_reference(sat,raw,models);d.pod_t=pod.t;d.pod_r=pod.r;d.pod_v=pod.v;
 acc=read_grace_ascii(fullfile(raw,sprintf('ACC1B_2015-03-15_%s_02.asc',sat)),[1 3 4 5]);
 ax=interp1(acc.values(:,1),acc.values(:,2),d.t,'spline');
 rb=reshape(pagemtimes(permute(frot,[2 1 3]),reshape(d.rad',3,1,[])),3,[])';
 ab=reshape(pagemtimes(permute(frot,[2 1 3]),reshape((d.K.*d.drag)',3,1,[])),3,[])';
 d.acc_rho=(ax-rb(:,1))./ab(:,1);d.acc_bias_template_rho=1e-6./ab(:,1);
 original=branches.supportOriginal;fixed=branches.supportFixed;
 branches=rmfield(branches,{'supportOriginal','supportFixed'});
 fprintf('Shared 20-minute density operator, six branches %s\n',sat);density=gnss_density_many(d,branches);
 names=fieldnames(density);tt=density.S.values(:,1);maskOriginal=support_mask(tt,original);maskFixed=support_mask(tt,fixed);
 density.S.supported=maskOriginal;cal=calibrate_acc_reference(density.S);bias=cal.ACC_bias_mps2;
 for j=1:numel(names)
  name=names{j};v=density.(name).values;v(:,4)=v(:,4)-bias/1e-6*v(:,6);density.(name).values=v;
  density.(name).ACC_bias_mps2=bias;density.(name).supported=maskOriginal;
  if any(strcmp(name,{'M','P'})),density.(name).supported=maskFixed;end
  writematrix([v,density.(name).supported],fullfile(out,[sat '_' name '_density.csv']));
 end
 save(fullfile(out,[sat '_all_density.mat']),'density','d','maskOriginal','maskFixed','bias','-v7.3');
end
end
function mask=support_mask(t,support)
mask=false(size(t));
for j=1:numel(t)
 s=support(support>=t(j)-600&support<t(j)+600);
 mask(j)=numel(s)>=108&&max(diff([t(j)-600;s(:);t(j)+600]))<=30;
end
end
