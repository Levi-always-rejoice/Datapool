# Raw physical model reconstruction

## Reconstructed physical settings

The original run XML and external model directory were not available. The supplied C++ code and public model products were used to reconstruct an explicit configuration. Numerical identity to the old radiation and aerodynamic tables is not claimed.

- Public GRACE spacecraft surface/optical models and their dated mass histories.
- GROOPS aerodynamic surface law, including its fixed molecular mass/surface-temperature/accommodation constants. Full wind/lift force vector, rather than the inherited effective-CDA table.
- NRLMSISE-00 for temperature and HWM14 for wind, using original published solar/geomagnetic index files. The model density output is discarded. This differs from NRLMSIS2 and must not be described as thermosphere-model-independent gas-surface interaction.
- EGM2008 degree/order120, JPL DE432 Sun/Moon third-body attraction, nominal elastic degree2/3 tides, Schwarzschild relativity. No ocean/pole tides or secular gravity correction were added.
- Direct solar pressure with spherical apparent-disk eclipse and solar flux1367 W/m2; original CERES monthly albedo/longwave climatology integrated over visible Earth elements. The supplied macro models have thermal re-emission disabled.
- Thruster exclusion is not added to this GRACE2015 baseline. THR files are included, but no translation-impulse model is claimed.

These settings are scientifically material. Inspect the new validation report and plots; do not substitute the earlier prepared-input metrics for this run.

