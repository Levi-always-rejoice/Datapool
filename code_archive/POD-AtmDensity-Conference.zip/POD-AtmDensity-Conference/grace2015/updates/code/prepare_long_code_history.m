function prepare_long_code_history(source,out,windowSeconds)
% Reuse the same orbit basis and force reference; only code treatment changes.
if ~isfolder(out),mkdir(out);end
report=struct;
for sat='AB'
 fprintf('Screen and aggregate code, satellite %s, %d seconds\n',sat,windowSeconds);
 a=load(fullfile(source,[sat '_float_model.mat']),'model');base=a.model;clear a;
 [q,qc]=screen_code_history(base.q);[model,~,stats]=gnss_long_code_profile(base,q,windowSeconds,true(size(q.t)),true);
 F=gnss_condition_navigation(model,[],[]);save(fullfile(out,[sat '_float_model.mat']),'model','F','-v7.3');
 writematrix(stats.anchor_audit,fullfile(out,[sat '_code_anchor_audit.csv']));stats=rmfield(stats,'anchor_audit');report.(sat)=struct('screen',qc,'profile',stats);disp(report.(sat));
 for fold=0:1
  fprintf('Long-code likelihood validation %s fold %d\n',sat,fold);[~,z,~]=gnss_long_code_profile(base,q,windowSeconds,mod(floor(q.t/300),2)==fold,true);save(fullfile(out,sprintf('%s_fold%d.mat',sat,fold)),'z','-v7.3');
 end
 clear base model F;
end
report.note='Code screening uses code-minus-carrier and MW without reference values or rounding. Long offsets are counted once, with robust one-minute blocks and variance no smaller than the original formal average. Decorrelated carrier retains only the tiny code contribution needed for exact white-noise factorization. Past and future phase already span the full day. This is not a fixed-lag causal demonstration.';
f=fopen(fullfile(out,'code_history_preparation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
end
