function report=check_long_code_equivalence(root,out)
% Real-data regression of the transformation before screening/robustifying.
source=fullfile(root,'independent_run');a=load(fullfile(source,'A_float_model.mat'),'model','F');
[model,~,~]=gnss_long_code_profile(a.model,a.model.q,1200,true(size(a.model.q.t)),false);
n=gnss_condition_navigation(model,[],[]);assert(isequal(n.values(:,1),a.F.values(:,1)));
report=struct('max_position_difference_m',max(vecnorm(n.values(:,2:4)-a.F.values(:,2:4),2,2)),'RMS_position_difference_m',rms(vecnorm(n.values(:,2:4)-a.F.values(:,2:4),2,2)),'max_velocity_difference_mps',max(vecnorm(n.values(:,5:7)-a.F.values(:,5:7),2,2)),'max_ambiguity_difference_m',max(abs(n.ambiguities-a.F.ambiguities)),'covariance_relative_frobenius_difference',norm(model.Q-a.model.Q,'fro')/norm(a.model.Q,'fro'));
assert(report.max_position_difference_m<1e-4,'Code factorization changes unscreened orbit by >0.1 mm');
f=fopen(fullfile(out,'code_factorization_real_data_check.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
