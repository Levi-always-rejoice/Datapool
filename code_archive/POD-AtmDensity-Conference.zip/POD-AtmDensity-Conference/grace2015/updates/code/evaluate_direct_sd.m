function report=evaluate_direct_sd(root,out)
% All external references are read after navigation and GNSS-only support
% flags have been frozen. Refit comparison densities on the exact same orbit
% epoch grid as the direct solution, so changed support cannot mimic a gain.
assert(isfile(fullfile(out,'navigation_method.json'))&&isfile(fullfile(out,'support_policy.json')));
names={'previous_full','previous_common_view','direct','alternate_mean'};navs=cell(2,1);forces=cell(2,1);old=cell(2,1);report=struct('columns',{names});
for s=1:2
 sat=char(64+s);z=load(fullfile(out,'direct',[sat '_L.mat']),'L');navs{s}.direct=z.L;t=z.L.values(:,1);
 z=load(fullfile(out,'alternate_mean',[sat '_L.mat']),'L');navs{s}.alternate_mean=z.L;
 z=load(fullfile(root,'code_history20_run',[sat '_L_history2.mat']),'L');old{s}=z.L;
 [yes,ix]=ismember(t,z.L.values(:,1));assert(all(yes));z.L.values=z.L.values(ix,:);navs{s}.previous_full=z.L;
 z=load(fullfile(root,'assistance_factorial_run','common_view_independent',[sat '_L.mat']),'L');[yes,ix]=ismember(t,z.L.values(:,1));assert(all(yes));z.L.values=z.L.values(ix,:);navs{s}.previous_common_view=z.L;
 forces{s}=load(fullfile(root,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d','bias');P=gnss_hermite(forces{s}.d.pod_t,forces{s}.d.pod_r,forces{s}.d.pod_v);
 for v=1:4,x=navs{s}.(names{v}).values;report.orbit_RMS_m.(names{v}).(sat)=rms(vecnorm(x(:,2:4)-ppval(P,x(:,1)')',2,2));end
end
base=load(fullfile(root,'code_history20_run','comparison_history2.mat'));t=base.t;ranges=nan(numel(t),4);[ya,ia]=ismember(t,old{1}.values(:,1));[yb,ib]=ismember(t,old{2}.values(:,1));[yn,in]=ismember(t,navs{1}.direct.values(:,1));m=ya&yb&yn;
rb=vecnorm(old{2}.values(ib(m),2:4)-old{1}.values(ia(m),2:4),2,2);
for v=1:4,a=navs{1}.(names{v}).values;b=navs{2}.(names{v}).values;assert(isequal(a(:,1),b(:,1)));ranges(m,v)=base.rv(m,2)+vecnorm(b(in(m),2:4)-a(in(m),2:4),2,2)-rb;end
report.range_epochs=nnz(m);report.range_RMS_mm=rms(ranges(m,:))*1000;writejson(fullfile(out,'comparison.json'),report);save(fullfile(out,'range_comparison.mat'),'t','ranges','m','report');disp(report.range_RMS_mm);
dens=cell(2,1);
for s=1:2
 sat=char(64+s);fprintf('Direct-SD comparison density %s\n',sat);z=gnss_density_sparse_window(forces{s}.d,navs{s},1200);
 for v=1:4
  x=z.(names{v});vv=x.values;vv(:,4)=vv(:,4)-forces{s}.bias/1e-6*vv(:,6);dens{s}.(names{v})=vv;folder=fullfile(out,names{v});if ~isfolder(folder),mkdir(folder);end
  writematrix(vv,fullfile(folder,[sat '_density.csv']));report.checks.(sat).(names{v})=rmfield(x,'values');
 end
end
[tt,ia,ib]=intersect(dens{1}.direct(:,1),dens{2}.direct(:,1));g=nan(numel(tt),4);acc=dens{2}.direct(ib,4)-dens{1}.direct(ia,4);
for v=1:4,a=dens{1}.(names{v});b=dens{2}.(names{v});g(:,v)=b(ib,2)-a(ia,2);writematrix([tt,g(:,v),acc],fullfile(out,names{v},'differential_density.csv'));end
z=load(fullfile(root,'assisted_benchmark_reconciliation','comparison.mat'),'t','mask');legacy=false(size(tt));[~,i,j]=intersect(tt,z.t);legacy(i)=z.mask(j);
z=load(fullfile(out,'gnss_support.mat'),'v');support=false(size(tt));[~,i,j]=intersect(tt,z.v(:,1));support(i)=logical(z.v(j,2));
for v=1:4
 report.density.(names{v})=struct('all',score(g(:,v),acc),'legacy_matched',score(g(legacy,v),acc(legacy)),'GNSS_support',score(g(support,v),acc(support)), ...
  'last4_all',score(g(tt>=72016,v),acc(tt>=72016)));
end
report.reference_sensitivity=struct('range_difference_RMS_mm',rms(ranges(m,4)-ranges(m,3))*1000,'density_difference_RMS_all',rms(g(:,4)-g(:,3)), ...
 'density_difference_RMS_supported',rms(g(support,4)-g(support,3)));
report.note='Direct SD cases use common-view carrier differences only in the relative likelihood; all code and single-view phase are confined to precomputed GNSS mean-orbit geometry. Existing 297 independent DD constraints retained, remaining pair offsets float; no new integer resolution. Baseline comparison densities are recomputed on identical orbit support. Legacy mask shown only for continuity with previous reports; independent GNSS support scores and all-output scores also supplied. Formal uncertainty conditional on mean geometry. The alternate mean is a sensitivity check, not a calibrated uncertainty bound. Existing ACC comparison-bias calibration unchanged. Full-day batch, native 10-second GPS1B, JAXA GNSS products.';
writejson(fullfile(out,'comparison.json'),report);save(fullfile(out,'comparison.mat'),'t','ranges','m','tt','g','acc','support','legacy','names','report');plot_direct_sd(out);disp(report.density);
end
function s=score(g,a),m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
