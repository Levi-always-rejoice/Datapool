function results=gnss_density_sparse_window(d,branches,windowSeconds,centerBounds)
if nargin<4,centerBounds=[-inf inf];end
assert(ismember(windowSeconds,[600 1200]));
names=fieldnames(branches);nv=numel(names);nav=branches.(names{1}).values;
for j=2:nv,assert(isequal(nav(:,1),branches.(names{j}).values(:,1)),'Branch epochs differ');end
nrhs=nv+4;
% Native configurable integrated force fit. Keep basis scaling unchanged.
mu=3.986004418e14;t=nav(:,1);qt=d.t(:);half=windowSeconds/2;stop=floor(t(end))-half;
R=gnss_hermite(qt,d.r,d.v);POD=gnss_hermite(d.pod_t,d.pod_r,d.pod_v);
pert=spline(qt,(d.known+mu*d.r./vecnorm(d.r,2,2).^3)');
dk=d.drag.*d.K(:);DK=spline(qt,dk');ref=zeros(numel(qt),3,4);
ref(:,:,2)=dk.*d.acc_rho(:);ref(:,:,3)=dk*1e-12;ref(:,:,4)=dk.*d.acc_bias_template_rho(:);
REF=spline(qt,reshape(permute(ref,[2 3 1]),12,[]));
opts=odeset('RelTol',2e-13,'AbsTol',1e-11,'MaxStep',20);rows={};checks=[];
for begin=ceil(t(1))+half:600:stop
 centers=(begin:min(begin+599,stop))';pivot=mean(centers([1 end]));ids=find(t>=centers(1)-half-1 & t<=centers(end)+half+1);tt=t(ids);
 if centers(end)<centerBounds(1)||centers(1)>centerBounds(2),continue;end
 if numel(tt)<2 || ~(tt(1)<pivot && pivot<tt(end)),continue;end
 % Integrate each actually available continuous segment separately. Never
 % integrate through a missing orbit/force interval. All segments share the
 % density intercept/slope at the chunk pivot, but have separate six-state
 % nuisance parameters. Their ambiguities remain those in the fixed nav.
 first=[1;find(diff(tt)>1.1)+1];last=[first(2:end)-1;numel(tt)];st=zeros(6,13,numel(tt));
 for seg=1:numel(first)
  ix=first(seg):last(seg);localpivot=mean(tt(ix([1 end])));Y=zeros(6,13);Y(1:3,1)=ppval(R,localpivot);
  [~,piece]=histc(localpivot,R.breaks);piece=min(max(piece,1),R.pieces);
  c=R.coefs((piece-1)*3+(1:3),:);u=localpivot-R.breaks(piece);Y(4:6,1)=3*c(:,1)*u^2+2*c(:,2)*u+c(:,3);
  Y(1:3,2:4)=eye(3);Y(4:6,5:7)=eye(3)/600;
  if numel(ix)==1,st(:,:,ix)=Y;continue;end
  block=struct('pivot',localpivot,'ncol',13,'left',ode113(@rhs,[localpivot tt(ix(1))],Y(:),opts),'right',ode113(@rhs,[localpivot tt(ix(end))],Y(:),opts));
  st(:,:,ix)=gnss_states(block,tt(ix));
 end
 H=st(1:3,2:9,:);y=st(1:3,10:13,:);
 yy=zeros(3,nv,numel(tt));for branch=1:nv,nn=branches.(names{branch}).values;yy(:,branch,:)=reshape(nn(ids,2:4)'-squeeze(st(1:3,1,:)),3,1,[]);end
 y=cat(2,yy,y);
 y(:,nv+1,:)=reshape(ppval(POD,tt')-squeeze(st(1:3,1,:)),3,1,[]);
 NN=zeros(8,8,numel(tt)+1);bb=zeros(8,nrhs,numel(tt)+1);
 for k=1:numel(tt),NN(:,:,k+1)=NN(:,:,k)+H(:,:,k)'*H(:,:,k);bb(:,:,k+1)=bb(:,:,k)+H(:,:,k)'*y(:,:,k);end
 rr=zeros(numel(centers),nrhs+2);accepted=false(numel(centers),1);
 for k=1:numel(centers)
  L=find(tt>=centers(k)-half,1);U=find(tt>=centers(k)+half,1);if isempty(U),U=numel(tt)+1;end
  if isempty(L) || U-L<120,continue;end
  S=zeros(2);b=zeros(2,nrhs);usedSegments=[];
  for seg=1:numel(first)
   l=max(L,first(seg));v=min(U,last(seg)+1);if v-l<30,continue;end
   A=NN(:,:,v)-NN(:,:,l);B=bb(:,:,v)-bb(:,:,l);sc=sqrt(max(diag(A),1e-30));As=A./sc./sc';Bs=B./sc;
   if rcond(As(1:6,1:6))<1e-12,continue;end
   ss=As(7:8,7:8)-As(7:8,1:6)*(As(1:6,1:6)\As(1:6,7:8));
   bs=Bs(7:8,:)-As(7:8,1:6)*(As(1:6,1:6)\Bs(1:6,:));
   S=S+ss.*sc(7:8).*sc(7:8)';b=b+bs.*sc(7:8);usedSegments=[usedSegments;l v]; %#ok<AGROW>
  end
  scale=sqrt(max(diag(S),1e-30));Ss=(S./scale./scale');Ss=(Ss+Ss')/2;
  if isempty(usedSegments)||min(eig(Ss))<1e-8,continue;end
  cc=(Ss\(b./scale))./scale;
  u=(centers(k)-pivot)/600;rho=(cc(1,:)+u*cc(2,:))*1e-12;rr(k,:)=[centers(k),rho,U-L];accepted(k)=true;
  if mod(k-1,300)==0
   hh=[];yy=[];nseg=size(usedSegments,1);
   for seg=1:nseg
    ix=usedSegments(seg,1):usedSegments(seg,2)-1;ht=reshape(permute(H(:,:,ix),[1 3 2]),[],8);htfull=zeros(size(ht,1),6*nseg+2);htfull(:,6*(seg-1)+(1:6))=ht(:,1:6);htfull(:,end-1:end)=ht(:,7:8);hh=[hh;htfull];yy=[yy;reshape(permute(y(:,:,ix),[1 3 2]),[],nrhs)]; %#ok<AGROW>
   end
   ss=vecnorm(hh);qc=(hh./ss)\yy;qc=qc./ss';qr=(qc(end-1,:)+u*qc(end,:))*1e-12;checks(end+1)=max(abs(qr-rho)); %#ok<AGROW>
  end
 end
 rows{end+1}=rr(accepted,:); %#ok<AGROW>
 if mod(numel(rows),25)==0,fprintf('  density chunks %d\n',numel(rows));end
end
values=vertcat(rows{:});values=values(values(:,1)>=centerBounds(1)&values(:,1)<=centerBounds(2),:);injection=max(abs(values(:,nv+4)-1e-12));assert(injection<1e-17);assert(max(checks)<1e-17);
results=struct;for branch=1:nv,results.(names{branch})=struct('values',values(:,[1,branch+1,nv+2:nv+5,nv+6]),'injection_error',injection,'QR_difference',max(checks));end
 function z=rhs(time,z)
  x=reshape(z,6,13);v=zeros(6,13);r=ppval(R,time);g=gnss_gradient(r);v(1:3,:)=x(4:6,:);v(4:6,:)=g*x(1:3,:);
  v(4:6,1)=v(4:6,1)+ppval(pert,time)-mu*r/norm(r)^3-g*r;
  v(4:6,8:9)=v(4:6,8:9)+ppval(DK,time)*[1,(time-pivot)/600]*1e-12;
  v(4:6,10:13)=v(4:6,10:13)+reshape(ppval(REF,time),3,4);z=v(:);
 end
end
