function plot_final_range_comparison(baseline,navdir,densitydir)
label='Relative GNSS (ESA final)';if contains(navdir,'arc5_run'),label='Relative GNSS (JAXA real time)';end
k=load(fullfile(baseline,'range_comparison.mat'));t=k.range.t;
a=load(fullfile(navdir,'A_J.mat'));b=load(fullfile(navdir,'B_J.mat'));
[ya,ia]=ismember(t,a.J.values(:,1));[yb,ib]=ismember(t,b.J.values(:,1));assert(all(ya&yb));
gnss=vecnorm(b.J.values(ib,2:4)-a.J.values(ia,2:4),2,2);
a=load(fullfile(baseline,'A_all_density.mat'),'d');b=load(fullfile(baseline,'B_all_density.mat'),'d');
P=gnss_hermite(a.d.pod_t,a.d.pod_r,a.d.pod_v);Q=gnss_hermite(b.d.pod_t,b.d.pod_r,b.d.pod_v);
pod=vecnorm(ppval(Q,t')'-ppval(P,t')',2,2);kbr=pod-k.range.POD;
d=load(fullfile(densitydir,'comparison.mat'));[yes,ix]=ismember(t,d.series{1}.t);matched=false(size(t));matched(yes)=d.series{1}.mask(ix(yes));
e=[gnss-kbr,pod-kbr,gnss-pod]*1000;valid=all(isfinite(e),2);matched=matched&valid;
report=struct('all_common',stats(e,valid),'density20_support',stats(e,matched),'datum','One POD-defined constant per KBR tracking segment, inherited unchanged; no method-specific offset or trend removal.','filtering','No additional filtering; GNSS range is from the existing reduced-dynamic phase/code solution. KBR at native 5-second epochs.');
file=fopen(fullfile(densitydir,'range_comparison_details.json'),'w');fprintf(file,'%s',jsonencode(report,PrettyPrint=true));fclose(file);
writetable(array2table([t,gnss,pod,kbr,e,matched],'VariableNames',{'GPS_seconds','GNSS_range_m','POD_range_m','aligned_KBR_range_m','GNSS_minus_KBR_mm','POD_minus_KBR_mm','GNSS_minus_POD_mm','density20_supported'}),fullfile(densitydir,'range_comparison_details.csv'));
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 1100]);tiledlayout(3,1);u=(t-16)/3600;gap=[false;diff(t)>5.1|diff(k.range.segments)~=0];
nexttile;z=e(:,1:2);z(gap,:)=NaN;plot(u,z);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title('All common navigation/KBR epochs; no additional filtering');legend(label,'POD');
nexttile;z=e(:,1:2);z(~matched|gap,:)=NaN;plot(u,z);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title('Identical supported intervals used for 20-minute density');legend(label,'POD');
nexttile;z=e(:,3);z(~matched|gap)=NaN;plot(u,z,'Color',[.2 .2 .2]);grid on;xlim([0 24]);ylabel('GNSS - POD (mm)');title('Direct relative-range difference on the same supported intervals');xlabel('UTC hour, GRACE A/B, 2015-03-15');
exportgraphics(fig,fullfile(densitydir,'relative_range_vs_POD_KBR.png'),'Resolution',150);close(fig);disp(report);
end
function s=stats(e,m)
s=struct('epochs',nnz(m),'GNSS_KBR_RMS_mm',rms(e(m,1)),'POD_KBR_RMS_mm',rms(e(m,2)),'GNSS_POD_RMS_mm',rms(e(m,3)),'bias_mm',mean(e(m,:),1),'demeaned_RMS_mm',std(e(m,:),1,1),'max_absolute_mm',max(abs(e(m,:)),[],1));
end
