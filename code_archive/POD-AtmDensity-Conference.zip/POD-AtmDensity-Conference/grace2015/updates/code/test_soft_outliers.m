function test_soft_outliers(original,screened,out)
if ~isfolder(out),mkdir(out);end
copyfile(fullfile(original,'P_integer_audit.mat'),fullfile(out,'P_integer_audit.mat'));copyfile(fullfile(original,'history_mask.mat'),fullfile(out,'history_mask.mat'));
c=load(fullfile(original,'P_integer_audit.mat'));c=c.audit.candidate_detail;z=load(fullfile(screened,'outlier_audit.mat'),'flag');
for sat='AB'
 x=load(fullfile(screened,[sat '_raw_design.mat']),'q');q=x.q;if sat=='A',ix=c.ia;else,ix=c.ib;end
 w=q.phase_weight(ix,:);w(z.flag)=.05;q.phase_weight(ix,:)=w;save(fullfile(out,[sat '_raw_design.mat']),'q');
end
fit_connected_integer_only(out,out,@gnss_navigation_robust);
z=jsondecode(fileread(fullfile(out,'connected_integer_only.json')));assert(z.fixed_rank==354,'Original independent constraints were not restored');
end
