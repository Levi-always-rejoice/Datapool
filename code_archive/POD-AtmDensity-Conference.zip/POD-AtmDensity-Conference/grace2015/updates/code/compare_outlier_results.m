function compare_outlier_results(rtout,finout,navRT,navFinal,baseline)
r=load(fullfile(rtout,'comparison.mat'));f=load(fullfile(finout,'comparison.mat'));report=struct;
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 950]);tiledlayout(2,1);windows=[20 10];
for k=1:2
 a=r.series{k};b=f.series{k};assert(isequal(a.t,b.t));assert(max(abs(a.acc-b.acc))<1e-20);m=a.mask&b.mask;
 report.(['min' num2str(windows(k))])=struct('old_centers',nnz(a.mask),'new_centers',nnz(b.mask),'common_centers',nnz(m),'original',score(a.gnss,a.acc,m),'robust',score(b.gnss,b.acc,m),'robust_all',score(b.gnss,b.acc,b.mask));
 nexttile;bad=~m|[false;diff(a.t)>1.1];v=a.gnss;v(bad)=NaN;w=b.gnss;w(bad)=NaN;ref=a.acc;ref(bad)=NaN;u=(a.t-16)/3600;
 plot(u,v*1e12);hold on;plot(u,w*1e12);plot(u,ref*1e12,'k');grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('%d-minute density: identical comparison times',windows(k)));legend('Original JAXA solution','Outlier-screened and robust fit','ACC');
end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(finout,'outlier_density_comparison.png'),'Resolution',150);close(fig);
% Identical KBR datum and time support for relative range comparison.
z=load(fullfile(baseline,'range_comparison.mat'));kt=z.range.t;
da=load(fullfile(baseline,'A_all_density.mat'),'d');db=load(fullfile(baseline,'B_all_density.mat'),'d');
P=gnss_hermite(da.d.pod_t,da.d.pod_r,da.d.pod_v);Q=gnss_hermite(db.d.pod_t,db.d.pod_r,db.d.pod_v);aligned=vecnorm(ppval(Q,kt')'-ppval(P,kt')',2,2)-z.range.POD;
dirs={navRT,navFinal};names={'original','robust'};rangeValues=cell(2,1);
for k=1:2
 a=load(fullfile(dirs{k},'A_J.mat'));b=load(fullfile(dirs{k},'B_J.mat'));
 rr=vecnorm(interp1(a.J.values(:,1),a.J.values(:,2:4),kt)-interp1(b.J.values(:,1),b.J.values(:,2:4),kt),2,2)-aligned;
 [yes,ix]=ismember(kt,r.series{1}.t);m=false(size(kt));m(yes)=r.series{1}.mask(ix(yes))&f.series{1}.mask(ix(yes));report.range.(names{k})=struct('centers',nnz(m),'RMS_mm',rms(rr(m))*1000,'all_finite_RMS_mm',rms(rr(isfinite(rr)))*1000);rangeValues{k}=rr;
 report.orbit.(names{k})=struct('A_RMS_m',rms(vecnorm(a.J.values(:,2:4)-ppval(P,a.J.values(:,1)')',2,2)),'B_RMS_m',rms(vecnorm(b.J.values(:,2:4)-ppval(Q,b.J.values(:,1)')',2,2)));
end
fig=figure('Position',[20 20 1400 750]);tiledlayout(2,1);u=(kt-16)/3600;gap=[false;diff(kt)>5.1|diff(z.range.segments)~=0];
for j=1:2,nexttile;hold on;for k=1:2,v=rangeValues{k};if j==2,v(~m)=NaN;end;v(gap)=NaN;plot(u,v*1000);end;v=z.range.POD;if j==2,v(~m)=NaN;end;v(gap)=NaN;plot(u,v*1000,'k');grid on;xlim([0 24]);ylabel('Range - KBR (mm)');legend('Original','Outlier-screened and robust fit','POD');if j==1,title('All common navigation/KBR epochs');else,title('Common supported density intervals');end;end
xlabel('UTC hour');exportgraphics(fig,fullfile(finout,'outlier_range_comparison.png'),'Resolution',150);close(fig);
file=fopen(fullfile(finout,'outlier_comparison.json'),'w');fprintf(file,'%s',jsonencode(report,PrettyPrint=true));fclose(file);disp(report);
end
function s=score(x,y,m)
c=corrcoef(x(m),y(m));s=struct('RMS',rms(x(m)-y(m)),'r',c(1,2));
end
