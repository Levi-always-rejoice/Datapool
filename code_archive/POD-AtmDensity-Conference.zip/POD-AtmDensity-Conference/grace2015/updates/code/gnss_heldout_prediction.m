function p=gnss_heldout_prediction(model,original,holdout,fixedB,Qfixed,offset,totalLabels)
% Predict excluded phase from remaining GPS tracks at that epoch and from
% the same track outside its withheld five-minute segment. No POD is read.
% Integer history is conditioned on, not revalidated by this cross-fit.
db=fixedB-model.B0;R=model.red;D=-(R\model.Nzb);
c=model.xp+model.T*(R\(model.bz-model.Nzb*db));
nb=numel(db);[ei,pi]=find(holdout);nr=numel(ei);index=zeros(size(holdout));index(holdout)=1:nr;
p=struct('epoch',ei,'prn',pi-1,'time',original.t(ei),'label',double(original.labels(holdout)), ...
 'residual',nan(nr,1),'prediction_variance',nan(nr,1),'measurement_variance',nan(nr,1), ...
 'state_clock_variance',nan(nr,1),'ambiguity_gradient',zeros(nr,totalLabels),'training_sats',zeros(nr,1));
aa=1575.42e6^2/(1575.42e6^2-1227.6e6^2);bb=1-aa;
Qlocal=Qfixed(offset+(1:nb),offset+(1:nb));
for j=1:numel(model.blocks)
 block=model.blocks{j};ids=block.ids;sel=find(any(holdout(ids,:),2));if isempty(sel),continue;end
 st=gnss_states(block,original.t(ids(sel)));ix=(j-1)*12+(1:12);cc=c(ix);
 rows=[];ar=[];dr=[];vr=[];
 for kk=1:numel(sel)
  k=sel(kk);e=ids(k);gps=find(holdout(e,:));id=index(e,gps)';lab=double(original.labels(e,gps))';
  train=find(model.q.good(e,:));p.training_sats(id)=numel(train);
  if numel(train)<2,continue;end
  h=squeeze(original.h(e,gps,:));if numel(gps)==1,h=reshape(h,1,3);end
  hh=h*st(1:3,2:13,kk);off=h*(st(1:3,1,kk)-original.r(e,:)');
  w=zeros(1,nb);lt=double(model.q.labels(e,train));w(lt)=block.wp(k,train)/block.den(k);
  clock=block.my(k)-block.mh(k,:)*cc-w*db;
  prediction=off+hh*cc+clock+fixedB(lab);
  p.residual(id)=original.phase(e,gps)'-prediction;
  a=(hh-block.mh(k,:))*model.T(ix,:);
  d=a*D-w;d(sub2ind(size(d),(1:numel(lab))',lab))=d(sub2ind(size(d),(1:numel(lab))',lab))+1;
  rows=[rows;id];ar=[ar;a];dr=[dr;d];vr=[vr;repmat(1/block.den(k),numel(lab),1)]; %#ok<AGROW>
  sn=max(sin(original.elev(e,gps)'),.25);p.measurement_variance(id)=(.005*hypot(aa,bb)./sn).^2;
 end
 if isempty(rows),continue;end
 v=sum((ar/R).*ar,2)+vr;p.state_clock_variance(rows)=v;
 p.prediction_variance(rows)=max(0,v+sum((dr*Qlocal).*dr,2));
 p.ambiguity_gradient(rows,offset+(1:nb))=dr;
end
end
