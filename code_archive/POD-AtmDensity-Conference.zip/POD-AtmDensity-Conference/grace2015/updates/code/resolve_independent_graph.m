function result=resolve_independent_graph(out,inflation,suffix,seedFile)
if nargin<2,inflation=4;end;if nargin<3,suffix='';end
if nargin<4,seedFile='';end
% Partial natural-DD integer fixing from code/carrier/MW only.
% Engineering validation gates are not a calibrated failure probability.
a=load(fullfile(out,'A_float_model.mat'),'model');b=load(fullfile(out,'B_float_model.mat'),'model');qa=a.model.q;qb=b.model.q;assert(~isfield(qa,'pod_r')&&~isfield(qb,'pod_r'));
c=gnss_pair_candidates(qa,qb,false);nc=numel(qa.B0);B=[a.model.B0+a.model.db;b.model.B0+b.model.db];Q=blkdiag(a.model.Q,b.model.Q);profiles={struct('B',B,'Q',Q,'count',inf(size(B)))};
for fold=0:1,x=load(fullfile(out,sprintf('A_fold%d.mat',fold)));y=load(fullfile(out,sprintf('B_fold%d.mat',fold)));profiles{end+1}=struct('B',[x.z.B;y.z.B],'Q',blkdiag(x.z.Q,y.z.Q),'count',[x.z.count;y.z.count]);end
ln=299792458/(1575.42e6+1227.6e6);lw=299792458/(1575.42e6-1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*lw;
keys=vertcat(c.accepted.key);[nodes,~,nodeix]=unique([keys(:,3:4);keys(:,5:6)],'rows');ne=numel(c.WL);parent=(1:size(nodes,1))';potential=zeros(size(nodes,1),2);accepted=false(ne,1);integer=nan(ne,1);audit=nan(ne,12);history=[];
mw=(qb.mw(c.ib,:)-qa.mw(c.ia,:))/lw;wideOK=true(ne,1);
for j=1:ne
 rows=c.accepted(j).rows;v=mw(rows,keys(j,1))-mw(rows,keys(j,2));
 for fold=0:1
  use=mod(floor(c.t(rows)/300),2)==fold;[~,~,bins]=unique(floor(c.t(rows(use))/60));
  if nnz(use)<12||numel(unique(bins))<2,wideOK(j)=false;continue;end
  wm=accumarray(bins,v(use),[],@median);w=median(wm);se=max(.025,1.4826*median(abs(wm-w))/sqrt(numel(wm)));
  wideOK(j)=wideOK(j)&&abs(w-c.WL(j))<.2&&abs(w-c.WL(j))+3*se<.5&&se<.12;
 end
end
seedH=zeros(0,numel(B));seedTarget=zeros(0,1);
if ~isempty(seedFile),z=load(seedFile);seedH=z.result.H;seedTarget=z.result.target;end
H=seedH;target=seedTarget;audit_rounds={};
for iteration=1:3
 means=zeros(ne,3);sigmas=means;supported=wideOK;
 for p=1:3
  z=profiles{p};pp=z.B;QQ=z.Q;
  if ~isempty(H),HQ=H*QQ;S=HQ*H';assert(rcond(S)>1e-14);pp=pp+HQ'*(S\(target-H*pp));QQ=QQ-HQ'*(S\HQ);QQ=(QQ+QQ')/2;end
  means(:,p)=(c.A*pp-cf*c.WL)/ln;vari=sum((c.A*QQ).*c.A,2)/ln^2;sigmas(:,p)=sqrt(max(0,inflation*vari));
  supported=supported&~any(abs(c.A(:,z.count<6))>0,2);
 end
 % Add a marginal floor and a separated-block disagreement term, rather than
 % allowing formal covariance collapse to justify arbitrarily certain fixes.
 sigma=max([sigmas,.05*ones(ne,1),abs(means(:,2)-means(:,3))/sqrt(2)],[],2);
 ints=round(means(:,1));distance=max(abs(means-ints),[],2);gap=(1-2*distance)./sigma.^2;
 pass=supported&~accepted&all(round(means)==ints,2)&distance<.2&distance+3*sigma<.5&gap>2*log(1000);
 audit(:,1:8)=[wideOK,supported,means,sigma,distance,gap];choose=find(pass);[~,ord]=sort(sigma(choose));choose=choose(ord);before=nnz(accepted);
 audit_rounds{iteration}=audit(:,1:8);
 for j=choose'
  if ~isempty(H)
   coef=H'\c.A(j,:)';if norm(H'*coef-c.A(j,:)')<1e-8&&abs(coef'*target-(ln*ints(j)+cf*c.WL(j)))>1e-7,audit(j,12)=2;continue;end
  end
  [u,pu]=root(nodeix(j));[v,pv]=root(nodeix(j+ne));want=[c.WL(j),ints(j)];
  if u==v&&any(pv-pu~=want),audit(j,12)=1;continue;end
  if u~=v,parent(v)=u;potential(v,:)=want+pu-pv;end
  accepted(j)=true;integer(j)=ints(j);audit(j,9:11)=[iteration,ints(j),1];
 end
 A=[seedH;c.A(accepted,:)];tt=[seedTarget;ln*integer(accepted)+cf*c.WL(accepted)];
 if isempty(A),history=[history;iteration 0 0];break;end
 [~,R,piv]=qr(A','vector');rankA=sum(abs(diag(R))>1e-9);H=A(piv(1:rankA),:);target=tt(piv(1:rankA));
 % Also check dependencies induced by reuse of individual receiver labels.
 consistent=lsqminnorm(H,target);assert(max(abs(A*consistent-tt))<1e-7,'Inconsistent integer relation graph');
 history=[history;iteration nnz(accepted) rankA];fprintf('Independent graph round %d: %d relations, rank %d\n',iteration,nnz(accepted),rankA);
 if nnz(accepted)==before,break;end
end
fixed=B;error=0;if ~isempty(H),HQ=H*Q;fixed=B+HQ'*((HQ*H')\(target-H*B));error=max(abs(H*fixed-target));assert(error<5e-7);end
% Build a reference-free connected phase mask. It contains only simultaneous
% signals linked by resolved integer relations in the same track histories.
mask=false(size(c.mask));kk=keys(accepted,:);
if ~isempty(kk)
 [nd,~,ix]=unique([kk(:,3:4);kk(:,5:6)],'rows');nedge=size(kk,1);component=conncomp(graph(ix(1:nedge),ix(nedge+1:end),[],size(nd,1)));
 for e=1:numel(c.t)
  ps=find(qa.good(c.ia(e),:)&qb.good(c.ib(e),:));pairs=[qa.labels(c.ia(e),ps)',qb.labels(c.ib(e),ps)'];[yes,id]=ismember(pairs,nd,'rows');ps=ps(yes);id=id(yes);if isempty(id),continue;end
  groups=component(id);u=unique(groups);counts=arrayfun(@(g)nnz(groups==g),u);[count,k]=max(counts);if count>=2,mask(e,ps(groups==u(k)))=true;end
 end
end
result=struct('H',H,'target',target,'fixedB',fixed,'accepted_rows',find(accepted),'integer_N1',integer(accepted),'integer_WL',c.WL(accepted),'keys',keys(accepted,:),'fixed_rank',size(H,1),'constraint_error_m',error,'history',history,'mask',mask,'c',c,'wideOK',wideOK,'audit_rounds',{audit_rounds});
save(fullfile(out,['independent_graph' suffix '.mat']),'result','-v7.3');writematrix([keys,audit],fullfile(out,['candidate_graph_audit' suffix '.csv']));
N=gnss_condition_navigation(a.model,[],[],fixed(1:nc));save(fullfile(out,['A_N' suffix '.mat']),'N','-v7.3');N=gnss_condition_navigation(b.model,[],[],fixed(nc+1:end));save(fullfile(out,['B_N' suffix '.mat']),'N','-v7.3');
summary=struct('initial_WL_candidates',ne,'wide_block_validated',nnz(wideOK),'fixed_relations',nnz(accepted),'fixed_rank',size(H,1),'seed_fixed_rank',size(seedH,1),'covariance_multiplier',inflation,'constraint_error_m',error,'fixed_connected_epochs',nnz(sum(mask,2)>=2),'paired_selected_observations',nnz(mask),'history',history,'method','GNSS-only DD edges; disjoint 300-second block validation; 0.05-cycle floor; three-sigma integer separation; integer graph closure; up to three conditional rounds. Optional seeds are saved GNSS-only joint fixes. No POD/KBR/ACC inputs.');
f=fopen(fullfile(out,['independent_graph' suffix '.json']),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
 function [r,p]=root(node)
  r=node;p=[0 0];while parent(r)~=r,p=p+potential(r,:);r=parent(r);end
 end
end
