function report=direct_sd_support(out)
% GNSS-only output-support diagnostic, not a phase mask or a fit change.
% Reuse the previous explicit coverage/geometry thresholds, without loading
% its POD-derived phase mask or any KBR/ACC benchmark.
z=load(fullfile(out,'sd_inputs.mat'),'q');q=z.q;info=zeros(numel(q.t),9);has=false(size(q.t));
for e=1:numel(q.t)
 if ~any(q.t(e)>=q.blocks(:,1)&q.t(e)<q.blocks(:,2)),continue;end
 ps=find(q.good(e,:));if numel(ps)<2,continue;end
 ha=squeeze(q.qa.h(q.ia(e),ps,:));hb=squeeze(q.qb.h(q.ib(e),ps,:));h=(ha+hb)/2;
 sa=max(sin(q.qa.elev(q.ia(e),ps)'),.25);sb=max(sin(q.qb.elev(q.ib(e),ps)'),.25);w=2./(1./sa.^2+1./sb.^2);
 h=h-sum(w.*h,1)/sum(w);I=h'*(w.*h);info(e,:)=I(:)';has(e)=true;
end
t=q.t(has);I=info(has,:);cum=[zeros(1,9);cumsum(I,1)];centers=(ceil(q.blocks(1,1))+600:floor(q.blocks(end,2))-600-1)';v=zeros(numel(centers),6);lo=1;hi=1;
for k=1:numel(centers)
 c=centers(k);while lo<=numel(t)&&t(lo)<c-600,lo=lo+1;end
 while hi<=numel(t)&&t(hi)<c+600,hi=hi+1;end
 ids=lo:hi-1;count=numel(ids);maxgap=max(diff([c-600;t(ids);c+600]));J=reshape(cum(hi,:)-cum(lo,:),3,3);e=eig((J+J')/2);condition=max(e)/max(min(e),1e-30);
 pass=count>=108&&maxgap<=120&&min(e)>1e-3&&condition<1000;
 v(k,:)=[c,pass,count,maxgap,min(e),condition];
end
report=struct('window_s',1200,'minimum_native_epochs',108,'maximum_gap_s',120,'minimum_geometry_eigenvalue',1e-3,'maximum_geometry_condition',1000,'available_centers',numel(centers),'accepted_centers',nnz(v(:,2)), ...
 'note','Flag only; all fitted densities remain saved. Two or more simultaneous common-view carriers form a native epoch. Clock-projected geometry uses normalized harmonic elevation weights. Thresholds inherited from earlier coverage diagnostic, applied to GNSS common-view data without POD/ACC/KBR. This flags support, not a calibrated density-error probability.');
save(fullfile(out,'gnss_support.mat'),'v','report');writematrix(v,fullfile(out,'gnss_support.csv'));f=fopen(fullfile(out,'support_policy.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
