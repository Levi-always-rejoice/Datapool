function result=gnss_condition_kinematic(model,H,target,fixedB,ambiguityCovariance)
% Back-substitute epoch states; no time smoothing or gap interpolation.
db=model.db;Q=model.Q;
if nargin>=4&&~isempty(fixedB),db=fixedB(:)-model.B0;end
if ~isempty(H),HQ=H*Q;C=HQ*H';db=db+HQ'*(C\(target-H*(model.B0+db)));Q=Q-HQ'*(C\HQ);end
if nargin>=5,Q=ambiguityCovariance;end
B=model.B0+db;ids=find(model.eligible);values=nan(numel(ids),8);clocks=zeros(numel(ids),2);covariance=zeros(4,4,numel(ids));rmsphase=zeros(numel(ids),1);
segment=cumsum([1;diff(model.q.t(ids))>15]);
for k=1:numel(ids)
 i=ids(k);e=model.epochs{i};x=e.x0-e.D*db(e.labels);
 values(k,:)=[model.q.t(i),model.q.r(i,:)+x(1:3)',nan(1,3),segment(k)];clocks(k,:)=[model.q.t(i),x(4)];
 covariance(:,:,k)=e.P+e.D*Q(e.labels,e.labels)*e.D';
 residual=e.yphase-e.G*x-db(e.labels);rmsphase(k)=sqrt(mean(residual.^2));
end
ie=0;if ~isempty(H),ie=max(abs(H*B-target));assert(ie<1e-8);end
result=struct('values',values,'clock',clocks,'ambiguities',B,'integer_error',ie,'epoch_index',ids,'state_covariance',covariance,'phase_RMS_m',rmsphase,'geometry',model.geometry(ids),'signal_count',model.signal_count(ids),'note','Native observed epochs; free position/clock, no velocity estimate or propagated gap states.');
end
