function report=evaluate_reduced_dynamic_integer_assistance(root,out)
% Controlled 20-min reduced-dynamic comparison: only integer information
% differs. Same GNSS data/weights, geometry, force reference, no POD mask.
source=fullfile(root,'independent_run');navs=cell(2,1);refs=cell(2,1);report=struct;
for sat='AB'
 k=double(sat)-64;r=load(fullfile(source,[sat '_L_search3m.mat']),'L');u=load(fullfile(out,[sat '_U.mat']),'n');p=load(fullfile(out,[sat '_P.mat']),'n');
 assert(isequal(r.L.values(:,1),u.n.values(:,1))&&isequal(u.n.values(:,1),p.n.values(:,1)));
 stateDifference=max(abs(u.n.values(:,2:7)-p.n.values(:,2:7)),[],'all');assert(stateDifference<1e-7,'Union should reproduce the same assisted constraint space');report.(['assisted_only_vs_union_' sat '_max_state_difference'])=stateDifference;
 navs{k}=struct('R',r.L,'U',u.n);refs{k}=load(fullfile(source,'fresh_force_reference',[sat '_all_density.mat']),'d','bias');d=refs{k}.d;P=gnss_hermite(d.pod_t,d.pod_r,d.pod_v);
 for tag={'R','U'},n=navs{k}.(tag{1});v=n.values;report.(tag{1}).(['orbit_' sat '_RMS_m'])=rms(vecnorm(v(:,2:4)-ppval(P,v(:,1)')',2,2));end
end
z=load(fullfile(source,'search_budget_comparison.mat'),'t','rv');t=z.t;rv=z.rv(:,4);new=nan(size(t));
a=navs{1}.R.values;b=navs{2}.R.values;[ya,ia]=ismember(t,a(:,1));[yb,ib]=ismember(t,b(:,1));m=ya&yb;original=vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2);
a=navs{1}.U.values;b=navs{2}.U.values;new(m)=rv(m)+vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-original;rv=[rv,new];m=all(isfinite(rv),2);
report.range_common_epochs=nnz(m);report.R.range_RMS_mm=rms(rv(m,1))*1000;report.U.range_RMS_mm=rms(rv(m,2))*1000;
save(fullfile(out,'range_comparison.mat'),'t','rv','report');writejson(fullfile(out,'evaluation.json'),report);disp(report);
for sat='AB'
 k=double(sat)-64;fprintf('20-min density comparison, %s\n',sat);res=gnss_density_sparse_window(refs{k}.d,navs{k},1200);
 for tag={'R','U'}
  v=res.(tag{1}).values;v(:,4)=v(:,4)-refs{k}.bias/1e-6*v(:,6);writematrix(v,fullfile(out,[sat '_' tag{1} '_density.csv']));report.checks.(sat).(tag{1})=rmfield(res.(tag{1}),'values');
  if strcmp(tag{1},'R')
   old=readmatrix(fullfile(source,[sat '_L_search3m_density.csv']));assert(isequal(old(:,1),v(:,1)));err=max(abs(v(:,2)-old(:,2)));assert(err<1e-19);report.(['unchanged_independent_density_' sat '_max_difference'])=err;
  end
 end
end
z=load(fullfile(root,'bridge_force_density_run','comparison.mat'));base=z.series{1};series=cell(2,1);tags={'R','U'};
for k=1:2
 a=readmatrix(fullfile(out,['A_' tags{k} '_density.csv']));b=readmatrix(fullfile(out,['B_' tags{k} '_density.csv']));[tt,ia,ib]=intersect(a(:,1),b(:,1));g=b(ib,2)-a(ia,2);acc=b(ib,4)-a(ia,4);series{k}=[tt,g,acc];
 [~,i,j]=intersect(tt,base.t);mask=base.mask(j);report.(tags{k}).density_matched=score(g(i(mask)),acc(i(mask)));report.(tags{k}).density_all=score(g,acc);
 writematrix(series{k},fullfile(out,[tags{k} '_differential_density.csv']));
 report.(tags{k}).density_13_15=score(g(tt>=46816&tt<=54016),acc(tt>=46816&tt<=54016));
 report.(tags{k}).density_last4=score(g(tt>=72016),acc(tt>=72016));
end
report.note='Both solutions use the SAME full-day continuous reduced-dynamic estimator with 20-minute linear-acceleration blocks. R has 240 independently fixed combinations; U adds POD-assisted integer information only. No POD positions or POD-based phase/epoch mask enter U. Identical physical-force geometry, density operator, KBR datum and evaluation support. All 240 accepted independent fixes agree with POD-assisted L1/L2. ACC retains the prior POD-calibrated constant reference bias. This isolates incomplete integer fixing; the historical fully assisted processing also differed in phase selection.';
writejson(fullfile(out,'evaluation.json'),report);save(fullfile(out,'comparison.mat'),'t','rv','series','report');
plot_reduced_dynamic_integer_assistance(root,out);
end
function s=score(g,a)
m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));
end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
