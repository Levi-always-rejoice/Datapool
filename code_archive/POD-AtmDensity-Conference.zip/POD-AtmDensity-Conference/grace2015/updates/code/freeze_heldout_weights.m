function report=freeze_heldout_weights(root,out)
% Freeze two GNSS-only weighting variants BEFORE external evaluation.
% Formal phase variance is conservative for this data. Calibrate one robust
% scale for each of A, B and B-A from all their held-out standardized errors;
% no per-track demeaning, reference score, or assisted selection mask.
source=fullfile(root,'code_history20_run');raw=cell(2,1);weights=cell(2,2);
for s=1:2
 z=load(fullfile(source,[char(64+s) '_float_model.mat']),'model');raw{s}=z.model.q;
 for j=1:2,weights{s,j}=ones(size(raw{s}.good));end
end
folds=cell(4,1);vals=cell(3,1);sigs=cell(3,1);valid=cell(3,1);names={'A','Bp','D'};
for f=0:3
 z=load(fullfile(out,sprintf('heldout_fold%d.mat',f)));folds{f+1}=z;
 for j=1:3,p=z.(names{j});vals{j}=[vals{j};p.residual];sigs{j}=[sigs{j};sqrt(p.prediction_variance+p.measurement_variance)];valid{j}=[valid{j};p.support&isfinite(p.residual)&isfinite(p.prediction_variance)];end %#ok<AGROW>
end
scale=zeros(3,1);report=struct;
for j=1:3
 m=logical(valid{j});r=vals{j}(m)./sigs{j}(m);scale(j)=max(.1,1.4826*median(abs(r-median(r))));
 report.(names{j})=struct('predictions',nnz(m),'total',numel(m),'formal_scale',scale(j), ...
  'abs_residual_percentiles_mm',1000*prctile(abs(vals{j}(m)),[50 90 95 99 100]), ...
  'formal_sigma_percentiles_mm',1000*prctile(sigs{j}(m),[50 90 95 99 100]));
end
for f=1:4
 z=folds{f};
 for s=1:2
  p=z.(names{s});w=robustWeight(p,scale(s));ii=sub2ind(size(raw{s}.good),p.epoch,p.prn+1);weights{s,2}(ii)=min(weights{s,2}(ii),w);
 end
 p=z.D;w=robustWeight(p,scale(3));
 for s=1:2
  a=z.(names{s});if s==1,ix=p.A_index;else,ix=p.B_index;end
  ii=sub2ind(size(raw{s}.good),a.epoch(ix),a.prn(ix)+1);
  for j=1:2,weights{s,j}(ii)=min(weights{s,j}(ii),w);end
 end
end
report.variant_names={'DD_only','combined'};
report.policy=struct('block_s',300,'folds',4,'standardized_cutoff',3,'sigma_floor_m',.003,'formal_scale_floor',.1,'minimum_weight',.001, ...
 'rule','Weight=min(1,(3*sigma/abs(heldout residual))^2), bounded below by 0.001. Sigma=max(3 mm, robust global scale * formal held-out sigma). Unsupported predictions keep unit weight. DD weights applied symmetrically to both receivers. Combined also includes separate receiver innovations. No phase correction, ambiguity reset, integer change, or observation deletion.', ...
 'conditional_validation','Integer seed uses full-day observations; validation is conditional on that retained seed. Scaled formal errors supply robust weighting, not calibrated fault probabilities.', ...
 'frozen_at',char(datetime('now','Format','yyyy-MM-dd HH:mm:ss')));
for j=1:2
 for s=1:2
  v=weights{s,j}(raw{s}.good);report.(report.variant_names{j}).(char(64+s))=struct('observations',numel(v),'downweighted',nnz(v<1),'weight_below_01',nnz(v<.1),'min_weight',min(v),'effective_weight_sum',sum(v));
 end
end
save(fullfile(out,'frozen_weights.mat'),'weights','report','scale');writejson(fullfile(out,'frozen_weights.json'),report);
set(groot,'defaultFigureVisible','off');fig=figure('Position',[30 30 1500 1000]);tiledlayout(3,1);
for j=1:3
 nexttile;hold on;
 for f=1:4,p=folds{f}.(names{j});m=p.support&isfinite(p.residual);scatter((p.time(m)-16)/3600,p.residual(m)*1000,3,p.prn(m),'filled');end
 ylim([-60 60]);xlim([0 24]);grid on;ylabel('Held-out phase (mm)');title(sprintf('%s: withheld 5-minute GPS segments; color = GPS PRN',names{j}));
end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'heldout_phase_residuals.png'),'Resolution',150);close(fig);disp(report);
end
function w=robustWeight(p,scale)
w=ones(size(p.residual));m=p.support&isfinite(p.residual)&isfinite(p.prediction_variance);
sigma=max(.003,scale*sqrt(p.prediction_variance(m)+p.measurement_variance(m)));
w(m)=max(.001,min(1,(3*sigma./max(abs(p.residual(m)),1e-15)).^2));
end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
