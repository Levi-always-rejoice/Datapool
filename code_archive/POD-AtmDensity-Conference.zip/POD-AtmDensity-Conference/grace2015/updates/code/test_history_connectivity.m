function test_history_connectivity(baseline,out)
% Carry validated DD integers through the whole unchanged track-pair history.
% POD remains an assisted screening reference, not a newly fitted ambiguity.
if ~isfolder(out),mkdir(out);end
z=load(fullfile(baseline,'P_integer_audit.mat'));c=z.audit.candidate_detail;
aa=load(fullfile(baseline,'A_raw_design.mat'),'q');bb=load(fullfile(baseline,'B_raw_design.mat'),'q');a=aa.q;b=bb.q;
kk=vertcat(c.accepted.key);[nodes,~,ix]=unique([kk(:,3:4);kk(:,5:6)],'rows');ne=size(kk,1);
G=graph(ix(1:ne),ix(ne+1:end),[],size(nodes,1));component=conncomp(G);
E=sparse((1:ne)',ix(1:ne),1,ne,size(nodes,1))-sparse((1:ne)',ix(ne+1:end),1,ne,size(nodes,1));
potential=lsqminnorm(full(E),c.target);assert(max(abs(E*potential-c.target))<1e-8);
pa=a.phase(c.ia,:)-sum(a.h(c.ia,:,:).*reshape(a.pod_r(c.ia,:)-a.r(c.ia,:),[],1,3),3);
pb=b.phase(c.ib,:)-sum(b.h(c.ib,:,:).*reshape(b.pod_r(c.ib,:)-b.r(c.ib,:),[],1,3),3);
sd=pb-pa;mask=false(size(c.mask));available=zeros(size(c.t));
for e=1:numel(c.t)
 ps=find(a.good(c.ia(e),:)&b.good(c.ib(e),:));
 pairs=[a.labels(c.ia(e),ps)',b.labels(c.ib(e),ps)'];[yes,id]=ismember(pairs,nodes,'rows');ps=ps(yes);id=id(yes);if isempty(id),continue;end
 groups=unique(component(id));best=[];
 for g=groups(:)'
  take=find(component(id)==g);v=sd(e,ps(take))'-potential(id(take));
  take=take(abs(v-median(v))<.025);
  if numel(take)>numel(best),best=take;end
 end
 available(e)=numel(best);if numel(best)>=4,mask(e,ps(best))=true;end
end
summary=struct('old_four_signal_epochs',nnz(sum(c.mask,2)>=4),'new_four_signal_epochs',nnz(sum(mask,2)>=4),'old_phase_count',nnz(c.mask),'new_phase_count',nnz(mask));
disp(summary);save(fullfile(out,'history_mask.mat'),'mask','available','summary');
audit=z.audit;audit.candidate_detail.mask=mask;save(fullfile(out,'P_integer_audit.mat'),'audit');
% Reuse the exact tested integer-only estimator, with new mask only.
for sat='AB',copyfile(fullfile(baseline,[sat '_raw_design.mat']),fullfile(out,[sat '_raw_design.mat']));end
fit_connected_integer_only(out,out);
for sat='AB'
 x=load(fullfile(baseline,[sat '_all_density.mat']));n=load(fullfile(out,[sat '_J.mat']));density=gnss_density_many(x.d,n);v=density.J.values;v(:,4)=v(:,4)-x.bias/1e-6*v(:,6);
 supported=false(size(v,1),1);support=c.t(sum(mask,2)>=4);
 for j=1:numel(supported),s=support(support>=v(j,1)-600&support<v(j,1)+600);supported(j)=numel(s)>=108&&max(diff([v(j,1)-600;s(:);v(j,1)+600]))<=30;end
 writematrix([v,supported],fullfile(out,[sat '_history_density.csv']));
end
end
