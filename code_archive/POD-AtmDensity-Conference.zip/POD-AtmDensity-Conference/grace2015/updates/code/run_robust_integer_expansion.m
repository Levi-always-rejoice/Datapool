function run_robust_integer_expansion(package,root)
% Independent estimation first, then withheld benchmark evaluation.
% Starts from existing raw-derived GNSS-only float profiles and 240 fixes.
% Does not modify the manuscript-validation package or original ZIP.
maxNumCompThreads(2);addpath(package,root);
source=fullfile(root,'independent_run');out=fullfile(root,'coverage_expansion_run');
prepare_robust_wide_lanes(source,out,true);
seed=fullfile(source,'independent_joint_search3m.mat');lastChanged='';
for iteration=1:5
 if iteration==1,tag='_coverage';else,tag=sprintf('_round%d',iteration);end
 result=resolve_incremental_joint(source,out,fullfile(out,'robust_wide_lanes.mat'),seed,tag);
 seed=fullfile(out,['independent_joint' tag '.mat']);
 if result.added_rank==0,break;end
 lastChanged=tag;
end
% Selection is by convergence, never by POD/KBR/ACC scores.
if ~isempty(lastChanged),evaluate_integer_expansion(package,root,out,lastChanged,true);end
end
