function report=reconcile_assisted_benchmarks(root,out)
% Identify the original attached figure and retain it as a distinct benchmark.
% Re-evaluate its SAVED navigation through the current density operator/force
% reference to distinguish navigation changes from density postprocessing.
if ~isfolder(out),mkdir(out);end
historic=fullfile(root,'bridge_force_density_run');navdir=fullfile(root,'bridge_force_run');current=fullfile(root,'reduced_dynamic_pod_integer_run');independent=fullfile(root,'code_history20_run');source=fullfile(root,'independent_run');
z=load(fullfile(historic,'comparison.mat'));old=z.series{1};u=readmatrix(fullfile(current,'U_differential_density.csv'));tag=strtrim(fileread(fullfile(independent,'selected_tag.txt')));now=readmatrix(fullfile(independent,[tag '_differential_density.csv']));
[t,io,iu]=intersect(old.t,u(:,1));[t,k,in]=intersect(t,now(:,1));io=io(k);iu=iu(k);mask=old.mask(io)&isfinite(old.gnss(io))&isfinite(u(iu,2))&isfinite(now(in,2));
g=[old.gnss(io),u(iu,2),now(in,2)];acc=[old.acc(io),u(iu,3),now(in,3)];report=struct;
names={'original_POD_screened354','POD_integer_only358','independent297'};
for j=1:3,report.(names{j})=score(g(mask,j),acc(mask,j));report.(names{j}).same_original_ACC=score(g(mask,j),acc(mask,1));end
report.ACC_difference_RMS_vs_original=rms(acc(mask,:)-acc(mask,1));report.common_density_centers=nnz(mask);
z=load(fullfile(navdir,'P_integer_audit.mat'),'audit');c=z.audit.candidate_detail;
for sat='AB'
 z=load(fullfile(navdir,[sat '_raw_design.mat']),'q');qo=z.q;z=load(fullfile(source,[sat '_raw_design.mat']),'q');qi=z.q;
 m=false(size(qo.good));if sat=='A',ix=c.ia;else,ix=c.ib;end;m(ix,:)=c.mask;mo=qo.good&m;
 [~,a,b]=intersect(qo.t,qi.t);report.phase_support.(sat)=struct('old_selected_observations',nnz(mo),'independent_observations',nnz(qi.good),'old_selected_common_epochs',nnz(mo(a,:)),'independent_common_epochs',nnz(qi.good(b,:)),'same_selected_phase_max_difference_m',finiteMax(abs(qo.phase(a,:)-qi.phase(b,:)),mo(a,:)&qi.good(b,:)),'common_geometry_position_RMS_m',rms(vecnorm(qo.r(a,:)-qi.r(b,:),2,2)));
end
r=load(fullfile(historic,'range_comparison.mat'),'t','rv');s=load(fullfile(current,'range_comparison.mat'),'t','rv');n=load(fullfile(independent,['comparison' tag '.mat']),'t','rv');[tr,ir,is]=intersect(r.t,s.t);[tr,k,inn]=intersect(tr,n.t);ir=ir(k);is=is(k);ranges=[r.rv(ir,2),s.rv(is,2),n.rv(inn,2)];rm=all(isfinite(ranges),2);report.common_range_epochs=nnz(rm);report.range_RMS_mm=rms(ranges(rm,:))*1000;
report.columns=names;report.note='Original figure is bridge_force_density_run/connected_density.png. Original benchmark includes POD-informed phase selection and connected fixed tracks; the recent integer-only control retains the broader independent phase set. These are distinct processing branches. Matched timestamps do not make their observation likelihoods identical.';
save(fullfile(out,'comparison.mat'),'t','g','acc','mask','tr','ranges','report');writejson(fullfile(out,'comparison.json'),report);disp(report);
% No orbit estimation is rerun: change only the density operator/reference.
den=cell(2,1);
for sat='AB'
 j=double(sat)-64;z=load(fullfile(navdir,[sat '_J.mat']),'J');ref=load(fullfile(source,'fresh_force_reference',[sat '_all_density.mat']),'d','bias');
 fprintf('Original saved navigation, current density operator: %s\n',sat);d=gnss_density_sparse_window(ref.d,struct('J',z.J),1200);v=d.J.values;v(:,4)=v(:,4)-ref.bias/1e-6*v(:,6);den{j}=v;report.density_checks.(sat)=rmfield(d.J,'values');writematrix(v,fullfile(out,[sat '_original_nav_current_density.csv']));
end
[tt,a,b]=intersect(den{1}(:,1),den{2}(:,1));reprocessed=[tt,den{2}(b,2)-den{1}(a,2),den{2}(b,4)-den{1}(a,4)];[~,i,j]=intersect(t,tt);matched=mask(i);delta=reprocessed(j,2)-g(i,1);
report.original_navigation_current_density=score(reprocessed(j(matched),2),reprocessed(j(matched),3));report.original_density_processing_change=struct('centers',nnz(matched),'RMS_kg_m3',rms(delta(matched)),'maximum_absolute_kg_m3',max(abs(delta(matched))));
writejson(fullfile(out,'comparison.json'),report);save(fullfile(out,'comparison.mat'),'t','g','acc','mask','tr','ranges','reprocessed','report');writematrix(reprocessed,fullfile(out,'original_nav_current_density.csv'));
plot_assisted_benchmark_reconciliation(out);disp(report);
end
function m=finiteMax(v,use),v=v(use&isfinite(v));if isempty(v),m=NaN;else,m=max(v);end,end
function s=score(g,a),m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
