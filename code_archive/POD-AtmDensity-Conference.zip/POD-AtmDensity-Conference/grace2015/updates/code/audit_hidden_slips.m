function audit_hidden_slips(baseline,out)
% Independent of POD/KBR/ACC; tests surviving tracks for slips that a 0.1m
% IF jump threshold can miss. Density errors are not used to select candidates.
summary=struct;
for sat='AB'
 x=load(fullfile(baseline,[sat '_raw_design.mat']),'q');q=x.q;z=load(fullfile(baseline,[sat '_branches.mat']),'R');nav=z.R;
 pos=interp1(nav.values(:,1),nav.values(:,2:4),q.t,'linear',NaN);clock=interp1(nav.clock(:,1),nav.clock(:,2),q.t,'linear',NaN);
 phase=q.phase-sum(q.h.*reshape(pos-q.r,[],1,3),3)-clock;
 fitted=ismember(q.t,nav.clock(:,1))&ismember(q.t,nav.values(:,1));good=q.good&fitted;events=zeros(0,10);confirmed=zeros(0,10);validation=zeros(0,16);tracks=0;
 for p=2:33
  labels=unique(q.labels(good(:,p),p));
  for label=labels'
   ix=find(good(:,p)&q.labels(:,p)==label);if numel(ix)<12,continue;end
   tracks=tracks+1;e=detect_dual_frequency_steps(q.t(ix),q.gf(ix,p),phase(ix,p));ee=[repmat([p-1,label],size(e,1),1),e];events=[events;ee]; %#ok<AGROW>
   [ok,details]=validate_slip_steps(q.t(ix),q.gf(ix,p),q.mw(ix,p),e);
   confirmed=[confirmed;ee(ok,:)];validation=[validation;ee,details,double(ok)]; %#ok<AGROW>
  end
 end
 summary.(sat)=struct('tracks_tested',tracks,'candidate_count',size(events,1),'confirmed_count',size(confirmed,1));
 writematrix(events,fullfile(out,[sat '_hidden_slip_candidates.csv']));
 writematrix(confirmed,fullfile(out,[sat '_hidden_slips_confirmed.csv']));
 writematrix(validation,fullfile(out,[sat '_hidden_slip_validation.csv']));
end
% A slip can have a small IF jump and a large geometry-free jump.
rng(923);t=(0:10:990)';u=t/1000;gf=.2*u+.1*u.^2+.0002*randn(size(t));ph=.001*randn(size(t));
c=299792458;f1=1575.42e6;f2=1227.6e6;al=f1^2/(f1^2-f2^2);be=1-al;n1=3;n2=4;
gf(t>=500)=gf(t>=500)+c/f1*n1-c/f2*n2;ph(t>=500)=ph(t>=500)+al*c/f1*n1+be*c/f2*n2;
e=detect_dual_frequency_steps(t,gf,ph);assert(any(e(:,1)==500&e(:,2)==n1&e(:,3)==n2),'Injected sub-0.1m IF slip missed');
mw=.01*randn(size(t));mw(t>=500)=mw(t>=500)+c/(f1-f2)*(n1-n2);
ok=validate_slip_steps(t,gf,mw,e);assert(any(ok),'Injected slip rejected by confirmation');
mw0=.001*randn(size(t));ok0=validate_slip_steps(t,gf,mw0,e);assert(~any(ok0),'Unconfirmed GF/IF step accepted without MW evidence');
summary.injection=struct('IF_jump_m',al*c/f1*n1+be*c/f2*n2,'N1',n1,'N2',n2,'detected',true);
f=fopen(fullfile(out,'hidden_slip_audit.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
end
