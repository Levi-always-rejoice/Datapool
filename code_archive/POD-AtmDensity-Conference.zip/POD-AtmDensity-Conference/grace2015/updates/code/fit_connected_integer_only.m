function fit_connected_integer_only(baseline,out,navigationFunction)
if nargin<3,navigationFunction=@gnss_navigation;end
% Keep a connected integer-resolved GPS component, but estimate the common
% real offsets, receiver clocks and orbit states from GNSS. No held POD floats.
z=load(fullfile(baseline,'P_integer_audit.mat'));c=z.audit.candidate_detail;models=cell(2,1);count=cell(2,1);
for sat='AB'
 j=double(sat)-64;x=load(fullfile(baseline,[sat '_raw_design.mat']),'q');q=x.q;mask=false(size(q.good));if sat=='A',ix=c.ia;else,ix=c.ib;end;mask(ix,:)=c.mask;q.good=q.good&mask;
 labels=q.labels(q.good);count{j}=accumarray(labels,1,[numel(q.B0),1]);fprintf('Connected integer-only refit %s\n',sat);models{j}=navigationFunction(q,1200,true);
end
counts=vertcat(count{:});active=~any(abs(c.A(:,counts==0))>0,2);A=c.A(active,:);target=c.target(active);
[~,R,piv]=qr(A','vector');rankA=sum(abs(diag(R))>1e-9);take=piv(1:rankA);H=A(take,:);target=target(take);
B=[models{1}.B0+models{1}.db;models{2}.B0+models{2}.db];Q=blkdiag(models{1}.Q,models{2}.Q);HQ=H*Q;S=HQ*H';sc=sqrt(diag(S));SS=S./sc./sc';
assert(min(eig((SS+SS')/2))>1e-12,'Unobservable fixed relation: do not silently force it');
dv=target-H*B;lambda=((SS\(dv./sc))./sc);fixed=B+HQ'*lambda;err=max(abs(H*fixed-target));assert(err<5e-7);
n=numel(models{1}.B0);J=gnss_condition_navigation(models{1},[],[],fixed(1:n));save(fullfile(out,'A_J.mat'),'J','-v7.3');
J=gnss_condition_navigation(models{2},[],[],fixed(n+1:end));save(fullfile(out,'B_J.mat'),'J','-v7.3');
summary=struct('fixed_rank',rankA,'active_relations',nnz(active),'profile_cost',dv'*lambda,'max_integer_error_m',err,'method','Same assisted integer-connected phase mask; only integer relations held; all remaining offsets and clocks estimated from GNSS');
f=fopen(fullfile(out,'connected_integer_only.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
