function [B,report]=condition_supported_history(a,b,seed,count)
% An ambiguity absent from the selected carrier data is unobserved, not
% perfectly known. Eliminate those nuisance parameters from the constraint
% equations before conditioning the observed profile. Afterwards choose
% their values to satisfy the full known integer history; these values have
% zero leverage on the orbit. No float ambiguity is held to a POD value.
unsupported=count==0;H=seed.H;target=seed.target;effective=seed;
if any(unsupported)
 Z=null(H(:,unsupported)');effective.H=Z'*H;effective.target=Z'*target;
end
[B,~,r]=gnss_fixed_profile(a,b,effective);
if any(unsupported)
 B(unsupported)=B(unsupported)+lsqminnorm(H(:,unsupported),target-H*B);
end
report=r;report.nominal_fixed_rank=size(H,1);report.unsupported_labels=nnz(unsupported);
report.active_constraint_rank=size(effective.H,1);report.full_constraint_error_m=max(abs(H*B-target));
assert(report.full_constraint_error_m<1e-7,'Unable to reconstruct full integer history');
end
