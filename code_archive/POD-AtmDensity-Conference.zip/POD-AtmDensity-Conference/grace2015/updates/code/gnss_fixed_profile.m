function [fixedB,Qfixed,report]=gnss_fixed_profile(a,b,seed,count)
% Condition a pair of GNSS-only profiles on an already validated DD history.
% If a deleted-data profile has no observations for a label, only constrain
% the seed subspace that does not involve that unsupported label.
n=numel(a.B0);B=[a.B0+a.db;b.B0+b.db];Q=blkdiag(a.Q,b.Q);
H=seed.H;target=seed.target;
if nargin>3 && any(count<6)
 Z=null(H(:,count<6)');H=Z'*H;target=Z'*target;
end
HQ=H*Q;S=HQ*H';sc=sqrt(max(diag(S),1e-30));S=S./sc./sc';
[R,p]=chol((S+S')/2);assert(p==0,'Fixed history is unobservable in training data');
gain=(R\(R'\(HQ./sc)))./sc;
fixedB=B+gain'*(target-H*B);Qfixed=Q-HQ'*gain;Qfixed=(Qfixed+Qfixed')/2;
report=struct('conditioned_rank',size(H,1),'retained_seed_rank',size(seed.H,1), ...
 'constraint_error_m',max(abs(H*fixedB-target)),'nA',n);
assert(report.constraint_error_m<1e-7);
end
