function plot_assistance_factorial(out)
z=load(fullfile(out,'comparison.mat'));set(groot,'defaultFigureVisible','off');
cols=[.55 .55 .55;0 .45 .74;.85 .33 .10];fig=figure('Position',[20 20 1600 1200]);tiledlayout(3,2,'TileSpacing','compact');
labels={'No POD observation mask','POD carrier mask; retain code','POD carrier and code mask'};
for row=1:3
 j=2*row-1;nexttile;v=z.ranges(:,[j j+1])*1000;v([false;diff(z.t)>1.5*median(diff(z.t))],:)=NaN;
 plot((z.t-16)/3600,v(:,1),'Color',cols(1,:));hold on;plot((z.t-16)/3600,v(:,2),'Color',cols(2,:));
 grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title(labels{row});legend('Independent integers','Add POD integer constraints','Location','northoutside');
 nexttile;v=z.g(:,[j j+1])*1e12;v(~z.mask,:)=NaN;
 plot((z.tt-16)/3600,v(:,1),'Color',cols(1,:));hold on;plot((z.tt-16)/3600,v(:,2),'Color',cols(2,:));
 a=z.acc*1e12;a(~z.mask)=NaN;plot((z.tt-16)/3600,a,'k','LineWidth',1.1);grid on;xlim([0 24]);ylim([-1 1]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title('20-minute density: identical accepted comparison times');legend('Independent integers','Add POD integer constraints','ACC','Location','northoutside');
end
nexttile(5);xlabel('UTC hour, GRACE A/B, 2015-03-15');nexttile(6);xlabel('UTC hour, GRACE A/B, 2015-03-15');
exportgraphics(fig,fullfile(out,'controlled_assistance_comparison.png'),'Resolution',150);close(fig);
% A separate full-scale density plot preserves all excursions and availability.
fig=figure('Position',[30 30 1550 1050]);tiledlayout(3,1,'TileSpacing','compact');
for row=1:3
 nexttile;v=z.g(:,[2*row-1,2*row])*1e12;v([false;diff(z.tt)>1.1],:)=NaN;
 plot((z.tt-16)/3600,v(:,1),'Color',cols(1,:));hold on;plot((z.tt-16)/3600,v(:,2),'Color',cols(2,:));plot((z.tt-16)/3600,z.acc*1e12,'k');grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title([labels{row} ': all fitted centers']);legend('Independent integers','Add POD integer constraints','ACC','Location','northoutside');
end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'all_density_centers.png'),'Resolution',150);close(fig);
end
