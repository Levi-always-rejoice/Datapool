function compare_arc_support(root)
names={'history_run','arc10_run','arc5_run'};labels={'Four signals per epoch, 10 degrees','Arc support, 10 degrees','Arc support, 5 degrees'};
z=cell(3,1);for k=1:3,z{k}=load(fullfile(root,names{k},'comparison.mat'));end
t=z{1}.t;common=true(size(t));for k=1:3,assert(isequal(t,z{k}.t));common=common&z{k}.m;end
rows=zeros(3,7);details=struct;
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 900]);tiledlayout(3,1);
for k=1:3
 x=z{k};m=x.m;c=corrcoef(x.new(m),x.acc(m));cc=corrcoef(x.new(common),x.acc(common));
 rows(k,:)=[nnz(m),100*nnz(m)/86400,rms(x.new(m)-x.acc(m)),c(1,2),nnz(common),rms(x.new(common)-x.acc(common)),cc(1,2)];
 q=load(fullfile(root,names{k},'history_mask.mat'));counts=sum(q.mask,2);s=struct('two_signal_epochs',nnz(counts==2),'three_signal_epochs',nnz(counts==3),'four_plus_epochs',nnz(counts>=4));
 audit=load(fullfile(root,names{k},'P_integer_audit.mat'));a=load(fullfile(root,names{k},'A_raw_design.mat'),'q');b=load(fullfile(root,names{k},'B_raw_design.mat'),'q');
 s.retained_below10_A=nnz(q.mask&a.q.elev(audit.audit.candidate_detail.ia,:)<deg2rad(10));s.retained_below10_B=nnz(q.mask&b.q.elev(audit.audit.candidate_detail.ib,:)<deg2rad(10));details.(names{k})=s;
 nexttile;v=x.new;breaks=[false;diff(t)>1.1];v(~m|breaks)=NaN;r=x.acc;r(~m|breaks)=NaN;plot((t-16)/3600,v*1e12);hold on;plot((t-16)/3600,r*1e12,'k');title(labels{k});ylabel('\Delta\rho (10^{-12} kg/m^3)');ylim([-.8 .8]);xlim([0 24]);grid on;legend('GNSS','ACC');
end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(root,'arc_support_comparison.png'),'Resolution',150);close(fig);
T=array2table(rows,'RowNames',names,'VariableNames',{'Centers','PercentDay','RMS_all','r_all','CommonCenters','RMS_common','r_common'});writetable(T,fullfile(root,'arc_support_comparison.csv'),'WriteRowNames',true);disp(T);
f=fopen(fullfile(root,'arc_support_diagnostics.json'),'w');fprintf(f,'%s',jsonencode(details,PrettyPrint=true));fclose(f);
end
