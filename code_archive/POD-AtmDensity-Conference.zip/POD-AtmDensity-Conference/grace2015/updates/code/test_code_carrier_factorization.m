function test_code_carrier_factorization
% Nontrivial independent normal-equation identity: variable geometry, phase
% variance and clock parameters, with repeated ambiguity observations.
rng(817);ne=40;np=7;nb=np;nx=6+ne;N=zeros(nx+nb);r=zeros(nx+nb,1);NN=N;rr=r;anchorW=zeros(nb,1);anchorY=anchorW;
for e=1:ne
 for p=1:np
  h=zeros(1,nx);h(1:6)=randn(1,6);h(6+e)=1;a=zeros(1,nb);a(p)=1;vp=(.01+.01*rand)^2;vc=(2+5*rand)^2;wp=1/vp;wc=1/vc;
  ph=randn;code=randn;hp=[h,a];hc=[h,zeros(1,nb)];N=N+wp*(hp'*hp)+wc*(hc'*hc);r=r+wp*hp'*ph+wc*hc'*code;
  W=wp+wc;mix=(wp*ph+wc*code)/W;hh=[h,wp/W*a];NN=NN+W*(hh'*hh);rr=rr+W*hh'*mix;
  wd=wp*wc/W;anchorW(p)=anchorW(p)+wd;anchorY(p)=anchorY(p)+wd*(ph-code);
 end
end
NN(nx+(1:nb),nx+(1:nb))=NN(nx+(1:nb),nx+(1:nb))+diag(anchorW);rr(nx+(1:nb))=rr(nx+(1:nb))+anchorY;
assert(norm(NN-N,'fro')/norm(N,'fro')<1e-13&&norm(rr-r)/norm(r)<1e-13);
fprintf('PASS: code/carrier factorization and once-only anchor aggregation reproduce the original normal equations.\n');
end
