function prepare_independent_density_reference(package,out)
% Complete physical force tables on the independent float GNSS geometry.
% POD and ACC enter comparison columns/calibration only, never force geometry.
raw=fullfile(grace_update_input_root(package),'raw');models=fullfile(grace_update_input_root(package),'models');dest=fullfile(out,'fresh_force_reference');if ~isfolder(dest),mkdir(dest);end
for sat='AB'
 z=load(fullfile(out,[sat '_float_model.mat']),'F');v=z.F.values;ii=unique([1:5:size(v,1),size(v,1),find(diff(v(:,1))>1)',find(diff(v(:,1))>1)'+1]);
 [rot,age]=raw_attitude(sat,v(ii,1),raw);assert(all(age<=5),'Missing attitude inside evaluated GNSS trajectory');
 fprintf('Fresh independent GNSS force geometry %s\n',sat);d=raw_forces(sat,v(ii,1),v(ii,2:4),v(ii,5:7),rot,models);
 pod=raw_pod_reference(sat,raw,models);d.pod_t=pod.t;d.pod_r=pod.r;d.pod_v=pod.v;
 z=load(fullfile(grace_update_baseline(package),[sat '_all_density.mat']),'bias');bias=z.bias;
 acc=read_grace_ascii(fullfile(raw,sprintf('ACC1B_2015-03-15_%s_02.asc',sat)),[1 3 4 5]);ax=interp1(acc.values(:,1),acc.values(:,2),d.t,'spline');
 rb=reshape(pagemtimes(permute(rot,[2 1 3]),reshape(d.rad',3,1,[])),3,[])';ab=reshape(pagemtimes(permute(rot,[2 1 3]),reshape((d.K.*d.drag)',3,1,[])),3,[])';d.acc_rho=(ax-rb(:,1))./ab(:,1);d.acc_bias_template_rho=1e-6./ab(:,1);
 source='Independent GNSS float F trajectory; freshly evaluated five-second forces; no POD positions used as force geometry. ACC retains previous POD-calibrated body-X constant bias for comparison only.';
 save(fullfile(dest,[sat '_all_density.mat']),'d','bias','source','-v7.3');
end
end
