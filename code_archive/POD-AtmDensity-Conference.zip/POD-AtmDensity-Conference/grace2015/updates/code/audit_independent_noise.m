function audit_independent_noise(out)
% Diagnostics only: neither scales estimator weights nor reads references.
report=struct;alpha=1575.42e6^2/(1575.42e6^2-1227.60e6^2);beta=1-alpha;
for sat='AB'
 z=load(fullfile(out,[sat '_raw_design.mat']));q=z.q;z=load(fullfile(out,[sat '_float_model.mat']),'F');n=z.F;
 [yes,ir]=ismember(q.t,n.values(:,1));[yc,ic]=ismember(q.t,n.clock(:,1));ii=find(yes&yc);r=nan(size(q.phase));lab=max(q.labels(ii,:),1);B=reshape(n.ambiguities(lab(:)),size(lab));
 r(ii,:)=q.phase(ii,:)-sum(q.h(ii,:,:).*reshape(n.values(ir(ii),2:4)-q.r(ii,:),[],1,3),3)-n.clock(ic(ii),2)-B;r(~q.good)=NaN;
 normr=r.*max(sin(q.elev),.25)/(.005*hypot(alpha,beta));white=[];block=[];lagx=[];lagy=[];
 for p=2:33
  valid=isfinite(normr(:,p));same=valid(2:end)&valid(1:end-1)&diff(q.t)==10&q.labels(2:end,p)==q.labels(1:end-1,p);second=same(2:end)&same(1:end-1);d2=diff(normr(:,p),2);white=[white;d2(second)/sqrt(6)]; %#ok<AGROW>
  lagx=[lagx;normr(find(same),p)];lagy=[lagy;normr(find(same)+1,p)]; %#ok<AGROW>
  ix=find(valid);[~,~,g]=unique([q.labels(ix,p),floor(q.t(ix)/300)],'rows');cnt=accumarray(g,1);val=accumarray(g,normr(ix,p),[],@mean);block=[block;val(cnt>=18)]; %#ok<AGROW>
 end
 c=corrcoef(lagx,lagy);report.(sat)=struct('normalized_high_frequency_MAD_sigma',1.4826*median(abs(white-median(white))),'normalized_300s_mean_MAD_sigma',1.4826*median(abs(block-median(block))),'adjacent_phase_residual_correlation',c(1,2),'native_10s_samples',nnz(isfinite(normr)));
end
report.note='Postfit high-frequency noise is smaller than total correlated error and cannot alone calibrate ambiguity covariance. Neither nominal nor x4 covariance is a demonstrated integer failure-rate bound.';
f=fopen(fullfile(out,'noise_diagnostics.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
