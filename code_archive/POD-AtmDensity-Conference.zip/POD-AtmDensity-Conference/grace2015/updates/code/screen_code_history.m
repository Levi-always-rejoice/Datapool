function [q,report]=screen_code_history(q)
% GNSS-only code QC. Carrier observations and ambiguity labels are retained.
% Code-minus-carrier cancels common geometry/clock; MW adds a dual-code check.
% No rounding or reference integer is used by either screen.
lw=299792458/(1575.42e6-1227.6e6);rejectCode=false(size(q.code));rejectMW=rejectCode;
for p=2:33
 labels=unique(q.labels(q.good(:,p),p));
 for label=labels'
  ix=find(q.good(:,p)&q.labels(:,p)==label);t=q.t(ix);
  for mode=1:2
   if mode==1,y=q.code(ix,p)-q.phase(ix,p);floorSigma=.5;else,y=q.mw(ix,p)/lw;floorSigma=.10;end
   med=movmedian(y,300,'omitnan','SamplePoints',t);dev=y-med;
   sigma=max(floorSigma,1.4826*median(abs(dev-median(dev,'omitnan')),'omitnan'));
   bad=isfinite(dev)&abs(dev)>4.5*sigma;
   if mode==1,rejectCode(ix(bad),p)=true;else,rejectMW(ix(bad),p)=true;end
  end
 end
end
% Either code combination being anomalous excludes that code sample from
% both navigation anchors and MW estimation, never from carrier navigation.
reject=rejectCode|rejectMW;before=q.good;count=nnz(isfinite(q.code)&q.good);
q.code(reject)=NaN;q.mw(reject)=NaN;q.code_screen_rejected=reject;
assert(isequal(q.good,before));
report=struct('available_code_samples',count,'IF_code_outliers',nnz(rejectCode),'MW_code_outliers',nnz(rejectMW),'union_rejected',nnz(reject),'phase_observations_retained',nnz(q.good),'window_s',300,'sigma_multiplier',4.5,'no_reference_or_integer_rounding',true);
end
