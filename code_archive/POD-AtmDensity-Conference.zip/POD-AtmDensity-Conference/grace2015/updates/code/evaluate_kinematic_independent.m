function report=evaluate_kinematic_independent(package,root,source,out)
% References are evaluation only and are loaded after saving all solutions.
tags={'F','L','K'};navs=cell(2,1);refs=cell(2,1);report=struct;
for sat='AB'
 j=double(sat)-64;x=load(fullfile(out,[sat '_float_model.mat']),'F');y=load(fullfile(out,[sat '_L_kinematic.mat']),'L');z=load(fullfile(out,[sat '_K.mat']),'K');navs{j}=struct('F',x.F,'L',y.L,'K',z.K);
 refs{j}=load(fullfile(source,'fresh_force_reference',[sat '_all_density.mat']),'d','bias');P=gnss_hermite(refs{j}.d.pod_t,refs{j}.d.pod_r,refs{j}.d.pod_v);
 for name=tags,n=navs{j}.(name{1});v=n.values;e=vecnorm(v(:,2:4)-ppval(P,v(:,1)')',2,2);report.(name{1}).(['orbit_' sat])=struct('epochs',numel(e),'RMS_m',rms(e),'error_norm_percentiles_m',prctile(e,[50 95 99 100]));end
end
j=load(fullfile(out,'independent_joint_kinematic.mat'),'result');z=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');ref=z.audit.candidate_detail;
co=(j.result.H'\ref.A')';inside=max(abs(co*j.result.H-ref.A),[],2)<1e-8;error=co*j.result.target-ref.target;
report.kinematic_integer_check=struct('fixed_rank',j.result.fixed_rank,'assisted_relations_in_space',nnz(inside),'agree',nnz(inside&abs(error)<1e-6),'disagree',nnz(inside&abs(error)>=1e-6));
old=load(fullfile(source,'search_budget_comparison.mat'),'t','rv');t=old.t;rr=nan(numel(t),3);
a=load(fullfile(source,'A_float_model.mat'),'F');b=load(fullfile(source,'B_float_model.mat'),'F');[ya,ia]=ismember(t,a.F.values(:,1));[yb,ib]=ismember(t,b.F.values(:,1));m=ya&yb;datum=nan(size(t));datum(m)=vecnorm(b.F.values(ib(m),2:4)-a.F.values(ia(m),2:4),2,2)-old.rv(m,1);
for k=1:3
 a=navs{1}.(tags{k}).values;b=navs{2}.(tags{k}).values;[ya,ia]=ismember(t,a(:,1));[yb,ib]=ismember(t,b(:,1));m=ya&yb&isfinite(datum);
 rr(m,k)=vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-datum(m);
end
rv=[old.rv(:,4),rr,old.rv(:,5)];m=all(isfinite(rv),2);report.range_common_epochs=nnz(m);report.range_RMS_mm=rms(rv(m,:))*1000;report.range_abs_percentiles_mm=prctile(abs(rv(m,:))*1000,[50 95 99 100]);report.range_columns={'reduced_dynamic240','kinematic_float','kinematic_own135','kinematic_inherited240','assisted'};
report.native_paired_position_epochs=nnz(isfinite(rr(:,1)));save(fullfile(out,'range_comparison.mat'),'t','rv','report');
f=fopen(fullfile(out,'evaluation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
for sat='AB'
 k=double(sat)-64;d=gnss_density_kinematic_window(refs{k}.d,navs{k},1200);
 for name=tags,v=d.(name{1}).values;v(:,4)=v(:,4)-refs{k}.bias/1e-6*v(:,6);writematrix(v,fullfile(out,[sat '_' name{1} '_density.csv']));report.checks.(sat).(name{1})=rmfield(d.(name{1}),'values');end
end
comparison=load(fullfile(root,'bridge_force_density_run','comparison.mat'));reference=comparison.series{1};dd=cell(3,1);
for k=1:3
 a=readmatrix(fullfile(out,['A_' tags{k} '_density.csv']));b=readmatrix(fullfile(out,['B_' tags{k} '_density.csv']));[tt,ia,ib]=intersect(a(:,1),b(:,1));g=b(ib,2)-a(ia,2);acc=b(ib,4)-a(ia,4);dd{k}=[tt,g,acc];
 report.(tags{k}).density_all=score(g,acc);[~,i,j]=intersect(tt,reference.t);m=reference.mask(j);report.(tags{k}).density_previous_support=score(g(i(m)),acc(i(m)));
 writematrix(dd{k},fullfile(out,[tags{k} '_differential_density.csv']));
end
% A cadence-matched density control: use the OLD reduced-dynamic240 orbit
% only at the exact kinematic observation epochs, never interpolate samples.
control=cell(2,1);
for sat='AB'
 k=double(sat)-64;z=load(fullfile(source,[sat '_L_search3m.mat']),'L');[yes,ix]=ismember(navs{k}.F.values(:,1),z.L.values(:,1));n=struct('values',z.L.values(ix(yes),:));d=gnss_density_kinematic_window(refs{k}.d,struct('R',n),1200);v=d.R.values;v(:,4)=v(:,4)-refs{k}.bias/1e-6*v(:,6);control{k}=v;report.checks.(sat).control=rmfield(d.R,'values');
 writematrix(v,fullfile(out,[sat '_R_density.csv']));
end
[rt,ia,ib]=intersect(control{1}(:,1),control{2}(:,1));rg=control{2}(ib,2)-control{1}(ia,2);ra=control{2}(ib,4)-control{1}(ia,4);writematrix([rt,rg,ra],fullfile(out,'R_differential_density.csv'));
common=rt;for k=1:3,common=intersect(common,dd{k}(:,1));end
[~,i,j]=intersect(common,reference.t);common=common(i(reference.mask(j)));[~,ix]=ismember(common,rt);report.density_matched.control=score(rg(ix),ra(ix));
for k=1:3,[~,ix]=ismember(common,dd{k}(:,1));report.density_matched.(tags{k})=score(dd{k}(ix,2),dd{k}(ix,3));end
report.note='All integer/orbit decisions exclude POD/KBR/ACC. Kinematic_own135 uses only the new force-free kinematic likelihood; inherited240 carries the prior GNSS-only reduced-dynamic integer relations. JAXA real-time transmitters, full-day batch, native 10-s positions. No 1-s position interpolation. Density uses 20-min windows and common prior GNSS force geometry, with the same existing calibrated ACC reference. Matched density control samples the old dynamic solution at identical available kinematic epochs.';
f=fopen(fullfile(out,'evaluation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);save(fullfile(out,'comparison.mat'),'t','rv','dd','rt','rg','ra','report','common');
plot_kinematic_comparison(out);disp(report);
end
function s=score(g,a)
m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));
end
