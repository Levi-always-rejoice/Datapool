function report=run_heldout_phase_navigation(root,out)
% Frozen weights, unchanged integer values/labels, unchanged orbit model.
% Does not load any POD/KBR/ACC benchmark or assisted mask.
source=fullfile(root,'code_history20_run');z=load(fullfile(source,'independent_joint_history2.mat'),'result');seed=z.result;
z=load(fullfile(out,'frozen_weights.mat'),'weights','report');weights=z.weights;policy=z.report;clear z;
bases=cell(2,1);for s=1:2,z=load(fullfile(source,[char(64+s) '_float_model.mat']),'model');bases{s}=z.model;end
report=struct;
for v=1:2
 name=policy.variant_names{v};folder=fullfile(out,name);if ~isfolder(folder),mkdir(folder);end
 models=cell(2,1);
 for s=1:2
  fprintf('Weighted GNSS navigation %s receiver %s\n',name,char(64+s));q=bases{s}.q;assert(~any(startsWith(fieldnames(q),'pod_')));q.phase_weight=weights{s,v};
  [models{s},~,stats]=gnss_long_code_profile(bases{s},q,1200,true(size(q.t)),true);report.(name).(char(64+s))=rmfield(stats,'anchor_audit');
 end
 [B,~,info]=gnss_fixed_profile(models{1},models{2},seed);
 result=seed;result.fixedB=B;result.seedFile=fullfile(source,'independent_joint_history2.mat');result.added_rank=0;result.seed_rank=seed.fixed_rank;result.constraint_error_m=max(abs(seed.H*B-seed.target));
 save(fullfile(folder,'independent_joint_qc.mat'),'result','-v7.3');report.(name).constraints=info;
 n=numel(models{1}.B0);
 for s=1:2
  if s==1,bb=B(1:n);else,bb=B(n+1:end);end
  L=gnss_condition_navigation(models{s},[],[],bb);save(fullfile(folder,[char(64+s) '_L_qc.mat']),'L','-v7.3');
  report.(name).(char(64+s)).continuity_error_m=L.continuity_error;
 end
 clear models;
end
report.note='Both weighted solutions and all screening decisions saved before external evaluation. Same 297 relative integer constraints and underlying observation labels, with retained float common/absolute offsets; not fully integer-fixed absolute orbits. No new ambiguity search. No POD, KBR or ACC input to the screening/refit.';
f=fopen(fullfile(out,'navigation_method.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
