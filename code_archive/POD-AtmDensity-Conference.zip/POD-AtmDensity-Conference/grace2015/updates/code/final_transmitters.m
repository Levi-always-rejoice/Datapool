function out=final_transmitters(folder,t,models)
% ESA final: ten-node polynomial orbit interpolation; linear 30-s clocks.
% Adjacent days provide bracketing. No clock extrapolation or gap bridging.
T=[];P=[];CT=[];CP=[];CV=[];
for doy=73:75
 lines=readgz(fullfile(folder,sprintf('ESA0MGNFIN_2015%03d0000_01D_05M_ORB.SP3.gz',doy)));
 ep=find(startsWith(lines,'* '));ev=sscanf(strjoin(lines(ep),newline),' * %f %f %f %f %f %f',[6 Inf])';
 tt=seconds(datetime(ev(:,1),ev(:,2),ev(:,3),ev(:,4),ev(:,5),ev(:,6))-datetime(2015,3,15));
 which=cumsum(startsWith(lines,'* '));ix=find(startsWith(lines,'PG'));s=char(lines(ix));prn=str2double(string(s(:,3:4)));pos=nan(numel(tt),33,3);
 for k=1:3,z=str2double(string(s(:,5+14*(k-1):18+14*(k-1))));z(abs(z)>=999999|z==0)=NaN;v=pos(:,:,k);v(sub2ind(size(v),which(ix),prn+1))=z*1000;pos(:,:,k)=v;end
 T=[T;tt];P=cat(1,P,pos); %#ok<AGROW>
 lines=readgz(fullfile(folder,sprintf('ESA0MGNFIN_2015%03d0000_01D_30S_CLK.CLK.gz',doy)));lines=lines(startsWith(lines,'AS G'));
 v=sscanf(strjoin(lines,newline),' AS G%d %f %f %f %f %f %f %f %f',[9 Inf])';assert(size(v,1)==numel(lines));
 ct=seconds(datetime(v(:,2),v(:,3),v(:,4),v(:,5),v(:,6),v(:,7))-datetime(2015,3,15));CT=[CT;ct];CP=[CP;v(:,1)+1];CV=[CV;v(:,9)]; %#ok<AGROW>
end
[T,ix]=unique(T,'last');P=P(ix,:,:);t=t(:)-.075;N=numel(t);
R=raw_earth_rotation(t,models);Rp=raw_earth_rotation(t+1,models);Rm=raw_earth_rotation(t-1,models);
out=struct('ps',nan(N,33,3),'vs',nan(N,33,3),'acc',nan(N,33,3),'clock',nan(N,33),'clock_rate',nan(N,33));
for p=2:33
 r=nan(N,3);v=r;a=r;
 for i=1:N
  k=find(T<=t(i),1,'last');if isempty(k),continue;end
  ids=k-4:k+5;if ids(1)<1||ids(end)>numel(T)||any(abs(diff(T(ids))-300)>1e-6),continue;end
  y=reshape(P(ids,p,:),10,3);if any(~isfinite(y),'all'),continue;end
  u=(T(ids)-t(i))/300;V=u.^(0:9);coef=V\y;r(i,:)=coef(1,:);v(i,:)=coef(2,:)/300;a(i,:)=2*coef(3,:)/300^2;
 end
 center=rotate(R,r);plus=rotate(Rp,r+v+.5*a);minus=rotate(Rm,r-v+.5*a);
 out.ps(:,p,:)=center;out.vs(:,p,:)=(plus-minus)/2;out.acc(:,p,:)=plus-2*center+minus;
 take=CP==p;[ct,ix]=unique(CT(take));cv=CV(take);cv=cv(ix);if numel(ct)<2,continue;end
 for i=1:N
  k=find(ct<=t(i),1,'last');if isempty(k)||k==numel(ct)||ct(k+1)-ct(k)>30.1,continue;end
  rate=(cv(k+1)-cv(k))/(ct(k+1)-ct(k));out.clock(i,p)=cv(k)+(t(i)-ct(k))*rate;out.clock_rate(i,p)=rate;
 end
end
[out.sun,~]=raw_ephemerides(t,models);
end
function lines=readgz(path)
folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s'));names=gunzip(path,folder);lines=cellstr(splitlines(fileread(names{1})));
end
function r=rotate(R,x)
r=reshape(pagemtimes(permute(R,[2 1 3]),reshape(x',3,1,[])),3,[])';
end
