function result=validate_blocked_integers(baseline,out,inflation,adaptive)
% Conservative revalidation of the baseline GNSS-only constraint subspace.
% Does not read POD/KBR/ACC information. No fix count is imposed.
% Covariance x4 is a declared sensitivity test, NOT a calibrated failure rate.
if nargin<3,inflation=4;end;if nargin<4,adaptive=false;end
z=load(fullfile(baseline,'R_integer_validation.mat'));old=z.integers;
a=load(fullfile(baseline,'A_float_model.mat'),'model');b=load(fullfile(baseline,'B_float_model.mat'),'model');
B=[a.model.B0+a.model.db;b.model.B0+b.model.db];Q=blkdiag(a.model.Q,b.model.Q);n=numel(a.model.B0);
H=old.H;ln=299792458/(1575.42e6+1227.6e6);offset=old.target-ln*old.integers;
initial=true(size(H,1),1);tag=sprintf('C%d',inflation);
if adaptive
 c=gnss_pair_candidates(a.model.q,b.model.q,false);A=c.A(c.independent,:);wide=c.WL(c.independent);
 [~,D,Z]=gnss_integer_reduce(inflation*(A*Q*A')/ln^2);H=Z'*A;cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);offset=cf*Z'*wide;
 first=1;while first<numel(D)&&prod(erf(.5./sqrt(2*D(first:end))))<.999,first=first+1;end
 initial=false(size(H,1),1);initial(first:end)=true;tag='G';
end
profiles={struct('B',B,'Q',Q,'count',inf(size(B)))};
for seconds=[120 300]
 for fold=0:1
  aa=load(fullfile(out,sprintf('A_block%d_fold%d.mat',seconds,fold)));bb=load(fullfile(out,sprintf('B_block%d_fold%d.mat',seconds,fold)));
  profiles{end+1}=struct('B',[aa.z.B;bb.z.B],'Q',blkdiag(aa.z.Q,bb.z.Q),'count',[aa.z.count;bb.z.count]); %#ok<AGROW>
 end
end
models=cell(size(profiles));supported=initial;
for j=1:numel(profiles)
 z=profiles{j};models{j}=struct('a',(H*z.B-offset)/ln,'C',inflation*(H*z.Q*H')/ln^2);
 supported=supported&~any(abs(H(:,z.count<6))>1e-10,2);
end
keep=find(supported);history={};accepted=false;
while ~isempty(keep)
 m=numel(keep);baseInt=[];bad=false(m,1);scores=zeros(m,1);reason='';costRows=[];
 for j=1:numel(models)
  aa=models{j}.a(keep);CC=models{j}.C(keep,keep);CC=(CC+CC')/2;
  [ints,cost,done,nodes]=gnss_joint_integer(aa,CC,300000);
  if ~done || numel(cost)<2
   [~,drop]=max(diag(CC));bad(drop)=true;reason='incomplete blocked search';break;
  end
  best=ints(:,1);delta=best-aa;invC=CC\eye(m);conditional=(invC*delta).^2./diag(invC);scores=max(scores,conditional);
  costRows(end+1,:)=[j,cost(1),cost(2),nodes]; %#ok<AGROW>
  if j==1,baseInt=best;end
  mismatch=best~=baseInt;bad=bad|mismatch;
  if any(mismatch),reason='separated-block integer disagreement';end
  if max(conditional)>9 || cost(1)>m+3*sqrt(2*m)
   [~,drop]=max(conditional);bad(drop)=true;reason='blocked conditional likelihood';
  end
  if cost(2)-cost(1)<2*log(1000)
   candidate=find(ints(:,2)~=best);[~,k]=max(diag(CC(candidate,candidate)));bad(candidate(k))=true;reason='blocked alternative not separated';
  end
 end
 if ~any(bad),accepted=true;break;end
 choices=find(bad);[~,k]=max(scores(choices)+1e-12*diag(models{1}.C(keep(choices),keep(choices))));drop=choices(k);
 history{end+1}=struct('dimensions',m,'drop_row',keep(drop),'reason',reason,'costs',costRows); %#ok<AGROW>
 if mod(numel(history),10)==1,fprintf('Blocked validation: %d retained, %s\n',m,reason);end
 keep(drop)=[];
end
HH=H(keep,:);target=zeros(0,1);fixed=B;maxError=0;
if accepted
 target=offset(keep)+ln*baseInt;HQ=HH*Q;fixed=B+HQ'*((HQ*HH')\(target-HH*B));maxError=max(abs(HH*fixed-target));assert(maxError<5e-7);
end
changed=NaN;if ~adaptive,changed=nnz(baseInt~=old.integers(keep));end
result=struct('H',HH,'target',target,'fixedB',fixed,'fixed_count',numel(keep),'integer_vector',baseInt,'retained_original_rows',keep,'initial_supported_rows',nnz(supported),'covariance_inflation',inflation,'maximum_error_m',maxError,'history',{history},'integer_changed_vs_baseline',changed,'adaptive',adaptive);
save(fullfile(out,[tag '_validation.mat']),'result');
summary=rmfield(result,{'H','target','fixedB','history'});f=fopen(fullfile(out,[tag '_validation.json']),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
C=gnss_condition_navigation(a.model,[],[],fixed(1:n));save(fullfile(out,['A_' tag '.mat']),'C','-v7.3');
C=gnss_condition_navigation(b.model,[],[],fixed(n+1:end));save(fullfile(out,['B_' tag '.mat']),'C','-v7.3');
end
