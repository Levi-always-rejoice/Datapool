function events=detect_dual_frequency_steps(t,gf,ifres)
% Detect abrupt same-track L1/L2 changes against a smooth local ionosphere.
% Outputs candidates only: no automatic correction or declaration of truth.
t=t(:);gf=gf(:);ifres=ifres(:);events=zeros(0,8);half=6;
c=299792458;f1=1575.42e6;f2=1227.6e6;alpha=f1^2/(f1^2-f2^2);beta=1-alpha;
[n1,n2]=ndgrid(-10:10);N=[n1(:),n2(:)];N(all(N==0,2),:)=[];
pred=[c/f1*N(:,1)-c/f2*N(:,2),alpha*c/f1*N(:,1)+beta*c/f2*N(:,2)];
for j=half:numel(t)-half
 ix=(j-half+1:j+half)';if any(diff(t(ix))>10.1)||any(~isfinite([gf(ix);ifres(ix)])),continue;end
 u=(t(ix)-mean(t([j j+1])))/60;X=[ones(numel(ix),1),u,u.^2,double(ix>j)];
 cc=X\[gf(ix),ifres(ix)];res=[gf(ix),ifres(ix)]-X*cc;Q=(X'*X)\eye(4);
 sigma=max(.002,1.4826*median(abs(res-median(res,1)),1));se=sqrt(Q(4,4))*sigma;
 step=cc(4,:);if abs(step(1))<.03||abs(step(1))<6*se(1),continue;end
 se=max(se,[.005 .005]);cost=sum(((pred-step)./se).^2,2);[cost,order]=sort(cost);
 if cost(1)>9.21||cost(2)-cost(1)<2*log(1000),continue;end
 events(end+1,:)=[t(j+1),N(order(1),:),step,se,cost(1)]; %#ok<AGROW>
end
% Adjacent tests share data. Keep the best evidence within each 60-second group.
if ~isempty(events)
 [~,order]=sort(events(:,8));keep=false(size(events,1),1);chosen=[];
 for j=order',if isempty(chosen)||all(abs(events(j,1)-events(chosen,1))>60),keep(j)=true;chosen(end+1)=j;end,end %#ok<AGROW>
 events=sortrows(events(keep,:),1);
end
end
