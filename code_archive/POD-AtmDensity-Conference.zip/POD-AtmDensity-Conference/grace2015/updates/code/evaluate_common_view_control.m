function report=evaluate_common_view_control(root,out)
% Evaluate the additional common-view ablation without rerunning the six
% completed factorial density fits. Preserve identical reference support.
method=jsondecode(fileread(fullfile(out,'common_view_method.json')));names={'common_view_independent','common_view_addedPOD'};
base=load(fullfile(root,'code_history20_run','comparison_history2.mat'));ref=load(fullfile(root,'assisted_benchmark_reconciliation','comparison.mat'));
navs=cell(2,1);old=cell(2,1);forces=cell(2,1);report=struct('columns',{names},'method',method);
for s=1:2
 sat=char(64+s);old{s}=load(fullfile(root,'code_history20_run',[sat '_L_history2.mat']),'L');forces{s}=load(fullfile(root,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d','bias');P=gnss_hermite(forces{s}.d.pod_t,forces{s}.d.pod_r,forces{s}.d.pod_v);
 for v=1:2
  z=load(fullfile(out,names{v},[sat '_L.mat']),'L');navs{s}.(names{v})=z.L;x=z.L.values;assert(isequal(x(:,1),old{s}.L.values(:,1)));
  report.orbit_RMS_m.(names{v}).(sat)=rms(vecnorm(x(:,2:4)-ppval(P,x(:,1)')',2,2));
 end
end
t=base.t;ranges=nan(numel(t),2);[ya,ia]=ismember(t,old{1}.L.values(:,1));[yb,ib]=ismember(t,old{2}.L.values(:,1));m=ya&yb;rb=vecnorm(old{2}.L.values(ib(m),2:4)-old{1}.L.values(ia(m),2:4),2,2);
for v=1:2,a=navs{1}.(names{v}).values;b=navs{2}.(names{v}).values;ranges(m,v)=base.rv(m,2)+vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-rb;end
rm=all(isfinite(ranges),2);report.range_common_epochs=nnz(rm);report.range_RMS_mm=rms(ranges(rm,:))*1000;writejson(fullfile(out,'common_view_comparison.json'),report);disp(report.range_RMS_mm);
dens=cell(2,1);
for s=1:2
 sat=char(64+s);fprintf('Common-view 20-minute density, receiver %s\n',sat);d=gnss_density_sparse_window(forces{s}.d,navs{s},1200);
 for v=1:2,z=d.(names{v});vv=z.values;vv(:,4)=vv(:,4)-forces{s}.bias/1e-6*vv(:,6);dens{s}.(names{v})=vv;writematrix(vv,fullfile(out,names{v},[sat '_density.csv']));report.density_checks.(sat).(names{v})=rmfield(z,'values');end
end
[tt,ia,ib]=intersect(dens{1}.common_view_independent(:,1),dens{2}.common_view_independent(:,1));acc=dens{2}.common_view_independent(ib,4)-dens{1}.common_view_independent(ia,4);g=nan(numel(tt),2);
for v=1:2,a=dens{1}.(names{v});b=dens{2}.(names{v});g(:,v)=b(ib,2)-a(ia,2);writematrix([tt,g(:,v),acc],fullfile(out,names{v},'differential_density.csv'));end
mask=false(size(tt));[~,i,j]=intersect(tt,ref.t);mask(i)=ref.mask(j);mask=mask&all(isfinite(g),2)&isfinite(acc);report.density_common_centers=nnz(mask);
for v=1:2,report.density.(names{v})=score(g(mask,v),acc(mask));report.density.(names{v}).all=score(g(:,v),acc);report.density.(names{v}).last4=score(g(tt>=72016,v),acc(tt>=72016));end
writejson(fullfile(out,'common_view_comparison.json'),report);save(fullfile(out,'common_view_comparison.mat'),'t','ranges','rm','tt','g','acc','mask','names','report');disp(report.density);
end
function s=score(g,a),m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
