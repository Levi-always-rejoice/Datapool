function plot_heldout_phase(out)
z=load(fullfile(out,'comparison.mat'));set(groot,'defaultFigureVisible','off');
colors=[.45 .45 .45;0 .45 .74;.85 .33 .10;.47 .67 .19];labels={'Independent 297, before','GNSS DD screening','GNSS combined screening','POD-screened benchmark'};
fig=figure('Position',[20 20 1550 1160]);tiledlayout(3,1,'TileSpacing','compact');
nexttile;hold on;v=z.ranges*1000;v([false;diff(z.t)>1.5*median(diff(z.t))],:)=NaN;
for j=1:4,plot((z.t-16)/3600,v(:,j),'Color',colors(j,:));end
xlim([0 24]);grid on;ylabel('Range - KBR (mm)');legend(labels,'Location','northoutside','Orientation','horizontal');title('GNSS-only screening trials retain the same 297 independent integer constraints');
nexttile;hold on;v=z.g*1e12;v([false;diff(z.tt)>1.1],:)=NaN;
for j=1:3,plot((z.tt-16)/3600,v(:,j),'Color',colors(j,:));end
plot((z.tt-16)/3600,z.acc*1e12,'k','LineWidth',1);xlim([0 24]);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');legend([labels(1:3),{'ACC'}],'Location','northoutside','Orientation','horizontal');title('20-minute density retrieval: full-day scale, including excursions');
nexttile;hold on;
v(~z.mask,4)=NaN;
for j=1:4,plot((z.tt-16)/3600,v(:,j),'Color',colors(j,:));end
plot((z.tt-16)/3600,z.acc*1e12,'k','LineWidth',1.2);xlim([20 24]);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, GRACE A/B, 2015-03-15');title('Last four hours: all independent output; assisted benchmark on its original valid support');
exportgraphics(fig,fullfile(out,'phase_screening_comparison.png'),'Resolution',150);close(fig);
end
