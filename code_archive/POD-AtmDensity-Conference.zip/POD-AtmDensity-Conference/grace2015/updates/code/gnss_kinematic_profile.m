function model=gnss_kinematic_profile(q,epochMask)
% Free XYZ and receiver clock at each observed epoch, global track offsets.
% No dynamics, position continuity, 20-min blocks, POD or force observations.
if nargin<2,epochMask=true(size(q.t));end
keep={'t','r','phase','code','h','elev','good','labels','B0','used'};
assert(all(isfield(q,keep)));q=rmfield(q,setdiff(fieldnames(q),keep));
nb=numel(q.B0);nt=numel(q.t);N=zeros(nb);b=zeros(nb,1);count=zeros(nb,1);
epochs=cell(nt,1);eligible=false(nt,1);geometry=nan(nt,1);counts=zeros(nt,1);
alpha=1575.42e6^2/(1575.42e6^2-1227.60e6^2);beta=1-alpha;
for i=find(epochMask(:))'
 ps=find(q.good(i,:)&q.labels(i,:)>0&isfinite(q.phase(i,:)));
 ps=ps(q.used(q.labels(i,ps)));counts(i)=numel(ps);if numel(ps)<4,continue,end
 labs=double(q.labels(i,ps))';assert(numel(unique(labs))==numel(labs));
 h=reshape(q.h(i,ps,:),[],3);G=[h,ones(numel(ps),1)];
 sn=max(sin(q.elev(i,ps)'),.25);wp=(sn/(.005*hypot(alpha,beta))).^2;
 code=q.code(i,ps)';cg=isfinite(code)&abs(code)<30;code(~cg)=0;
 wc=double(cg).*(sn/4.5).^2./max(1,abs(code)/3);W=wp+wc;
 WG=sqrt(W).*G;sv=svd(WG);geometry(i)=sv(1)/sv(end);
 if sv(end)<sv(1)*1e-10,continue,end
 % QR eliminates epoch position/clock without subtracting large normal terms.
 A=[sqrt(wp).*G;sqrt(wc).*G];y=[sqrt(wp).*(q.phase(i,ps)'-q.B0(labs));sqrt(wc).*code];
 E=[diag(sqrt(wp));zeros(numel(ps))];[U,R]=qr(A,0);
 V=E-U*(U'*E);v=y-U*(U'*y);N(labs,labs)=N(labs,labs)+V'*V;b(labs)=b(labs)+V'*v;
 x0=R\(U'*y);D=R\(U'*E);P=R\(R'\eye(4));
 epochs{i}=struct('labels',labs,'x0',x0,'D',D,'P',P,'G',G,'wp',wp,'wc',wc,'yphase',q.phase(i,ps)'-q.B0(labs),'ycode',code);
 count(labs)=count(labs)+1;eligible(i)=true;
end
% A newly acquired carrier seen only with four signals and no usable code
% can have EXACTLY ZERO independent ambiguity information. QR roundoff must
% not be rescaled into a unit diagonal and then inverted as a measurement.
diagonal=diag(N);floorInfo=max(1e-10,100*eps(max(diagonal)));
unobservable=count>0&diagonal<floorInfo;
if any(unobservable)
 q.used(unobservable)=false;model=gnss_kinematic_profile(q,epochMask);model.removed_unobservable_labels=unique([find(unobservable);model.removed_unobservable_labels]);return;
end
used=count>0;ss=sqrt(diag(N(used,used)));S=N(used,used)./ss./ss';S=(S+S')/2;
ev=eig(S);assert(min(ev)>max(ev)*1e-12,'Unobservable coupled ambiguity modes require an explicit datum');
[R,flag]=chol(S);assert(flag==0,'Unobservable kinematic ambiguity directions; do not turn null modes into zero variance');
Q=zeros(nb);Q(used,used)=(R\(R'\eye(nnz(used))))./ss./ss';Q=(Q+Q')/2;db=Q*b;
model=struct('kind','kinematic','q',q,'B0',q.B0(:),'Q',Q,'db',db,'count',count,'epochs',{epochs},'eligible',eligible,'geometry',geometry,'signal_count',counts,'normal',N,'rhs',b,'removed_unobservable_labels',zeros(0,1));
end
