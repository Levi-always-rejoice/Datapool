function run_kinematic_independent(source,out)
% New all-day kinematic estimator using only GNSS observation designs.
if ~isfolder(out),mkdir(out);end
report=struct;
for sat='AB'
 z=load(fullfile(source,[sat '_raw_design.mat']),'q');q=z.q;
 fprintf('Kinematic profile %s, full day\n',sat);model=gnss_kinematic_profile(q);F=gnss_condition_kinematic(model,[],[]);
 save(fullfile(out,[sat '_float_model.mat']),'model','F','-v7.3');
 report.(sat)=struct('native_epochs',numel(q.t),'solved_epochs',nnz(model.eligible),'under_four_signals',nnz(model.signal_count<4),'rank_deficient_with_four_or_more',nnz(model.signal_count>=4&~model.eligible),'ambiguities_with_data',nnz(model.count),'position_clock_design_condition_percentiles',prctile(model.geometry(model.eligible),[50 95 99 100]));
 report.(sat).removed_unobservable_labels=model.removed_unobservable_labels;
 for fold=0:1
  m=gnss_kinematic_profile(q,mod(floor(q.t/300),2)==fold);z=struct('B',m.B0+m.db,'Q',m.Q,'count',m.count);save(fullfile(out,sprintf('%s_fold%d.mat',sat,fold)),'z','-v7.3');
 end
 clear model m q;
end
% Reuse only the previously GNSS-validated MW candidates, no narrow-lane fixes.
z=load(fullfile(source,'independent_graph1.mat'),'result');result=struct('c',z.result.c,'wideOK',z.result.wideOK);save(fullfile(out,'independent_graph1.mat'),'result','-v7.3');
resolve_independent_joint(out,1,'_kinematic',struct('searchLimit',3000000,'candidateSuffix','1'));
% Controlled second branch: SAME previous independent integers, free states.
a=load(fullfile(out,'A_float_model.mat'),'model');b=load(fullfile(out,'B_float_model.mat'),'model');s=load(fullfile(source,'independent_joint_search3m.mat'),'result');
H=s.result.H;target=s.result.target;Q=blkdiag(a.model.Q,b.model.Q);B=[a.model.B0+a.model.db;b.model.B0+b.model.db];nc=numel(a.model.B0);
assert(all([a.model.count;b.model.count]>0|all(H==0,1)'),'Inherited fixed direction contains an unobserved ambiguity');
HQ=H*Q;C=HQ*H';fixedB=B+HQ'*(C\(target-H*B));Qc=Q-HQ'*(C\HQ);err=max(abs(H*fixedB-target));assert(err<1e-8);
K=gnss_condition_kinematic(a.model,[],[],fixedB(1:nc),Qc(1:nc,1:nc));save(fullfile(out,'A_K.mat'),'K','-v7.3');
K=gnss_condition_kinematic(b.model,[],[],fixedB(nc+1:end),Qc(nc+1:end,nc+1:end));save(fullfile(out,'B_K.mat'),'K','-v7.3');
report.inherited=struct('fixed_rank',size(H,1),'constraint_error_m',err,'provenance','Independent reduced-dynamic ambiguity search; only integer relations inherited, no orbit states or force constraints.');
report.note='JAXA real-time GNSS products, 2015-03-15 native 10-s phase/code. No 20-min kinematic navigation blocks and no ambiguity reset on signal-set changes. Pure kinematic ambiguity search and inherited-integer control are distinct branches. Full-day batch, not causal real-time demonstration.';
save(fullfile(out,'inherited_constraints.mat'),'H','target','fixedB','Qc','report','-v7.3');
f=fopen(fullfile(out,'preparation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
