function prepare_independent_integers(package,out)
% GNSS-only estimation inputs. Reference fields are removed before use.
% No assisted integer files, reference masks, KBR, or ACC are read.
if ~isfolder(out),mkdir(out);end
baseline=grace_update_baseline(package);raw=fullfile(grace_update_input_root(package),'raw');models=fullfile(grace_update_input_root(package),'models');summary=struct;
for sat='AB'
 if isfile(fullfile(out,sprintf('%s_fold1.mat',sat)))
  z=load(fullfile(out,[sat '_raw_design.mat']),'q');n=load(fullfile(out,[sat '_float_model.mat']),'F');summary.(sat)=struct('phase_observations',nnz(z.q.good),'new_force_epochs',nnz(all(isnan(z.q.phase),2)),'state_continuity_error',n.F.continuity_error,'no_POD_fields',~any(startsWith(fieldnames(z.q),'pod_')));fprintf('Reuse completed independent profiles %s\n',sat);continue;
 end
 z=load(fullfile(baseline,[sat '_raw_design.mat']),'q');q=z.q;
 fields=fieldnames(q);q=rmfield(q,fields(startsWith(fields,'pod_')));assert(~isfield(q,'pod_r'));
 % Admit existing raw tracks down to five degrees without assisted screening.
 for p=2:33
  labels=unique(q.labels(q.good(:,p),p));
  for label=labels'
   rows=q.labels(:,p)==label&q.good(:,p);ids=unique(q.ids(rows,p));assert(numel(ids)==1);
   use=q.ids(:,p)==ids&q.labels(:,p)==0&isfinite(q.phase(:,p))&q.elev(:,p)>deg2rad(5)&q.elev(:,p)<=deg2rad(10);
   q.labels(use,p)=label;q.good(use,p)=true;
  end
 end
 % Declare propagation policy before any reference comparison. Orbit continuity
 % does NOT imply phase continuity: reacquired labels remain independent.
 gaps=find(diff(q.t)>10.1&diff(q.t)<=900);added=[];
 rejected=[];
 for g=gaps'
  tt=(q.t(g)+10:10:q.t(g+1)-10)';[~,age]=raw_attitude(sat,tt,raw);
  if all(age<=5),added=[added;tt];else,rejected=[rejected;q.t(g) q.t(g+1) max(age)];end %#ok<AGROW>
 end
 writematrix(rejected,fullfile(out,[sat '_unpropagated_attitude_gaps.csv']));
 oldT=q.t;
 if ~isempty(added)
  [rot,age]=raw_attitude(sat,added,raw);assert(all(age<=5),'Missing attitude: cannot safely propagate this test');
  R=gnss_hermite(q.t,q.r,q.v);r=ppval(R,added')';v=zeros(size(r));
  for j=1:numel(added),piece=find(R.breaks<=added(j),1,'last');piece=min(piece,R.pieces);cc=R.coefs((piece-1)*3+(1:3),:);u=added(j)-R.breaks(piece);v(j,:)=(3*cc(:,1)*u^2+2*cc(:,2)*u+cc(:,3))';end
  fresh=raw_forces(sat,added,r,v,rot,models);newT=unique([q.t;added]);[~,oi]=ismember(q.t,newT);[~,ni]=ismember(added,newT);fields=fieldnames(q);
  for j=1:numel(fields)
   name=fields{j};value=q.(name);if (~isnumeric(value)&&~islogical(value))||size(value,1)~=numel(oldT),continue;end
   sz=size(value);sz(1)=numel(newT);if islogical(value),a=false(sz);else,a=nan(sz);end;a(oi,:,:)=value;
   if isfield(fresh,name),a(ni,:,:)=fresh.(name);elseif any(strcmp(name,{'labels','h','clock'})),a(ni,:,:)=0;elseif strcmp(name,'ids'),a(ni,:,:)=-1;end
   q.(name)=a;
  end
  q.t=newT;
 end
 save(fullfile(out,[sat '_raw_design.mat']),'q','-v7.3');
 fprintf('Independent continuous float navigation %s\n',sat);model=gnss_navigation_bridge(q,1200,true);F=gnss_condition_navigation(model,[],[]);
 save(fullfile(out,[sat '_float_model.mat']),'model','F','-v7.3');summary.(sat)=struct('phase_observations',nnz(q.good),'new_force_epochs',numel(added),'state_continuity_error',F.continuity_error,'no_POD_fields',~any(startsWith(fieldnames(q),'pod_')));
 % Validate on disjoint five-minute blocks, not adjacent even/odd epochs.
 for fold=0:1
  fprintf('Independent blocked profile %s fold %d\n',sat,fold);z=gnss_reprofile(model,mod(floor(q.t/300),2)==fold);save(fullfile(out,sprintf('%s_fold%d.mat',sat,fold)),'z','-v7.3');
 end
 clear model;
end
summary.policy=struct('maximum_propagated_gap_s',900,'navigation_block_s',1200,'elevation_degrees',5,'validation_block_s',300,'reference_use','No POD/GNV, KBR or ACC values, targets or masks enter preparation or validation. Original raw-design checkpoints are reused after dropping POD fields.');
f=fopen(fullfile(out,'preparation.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
