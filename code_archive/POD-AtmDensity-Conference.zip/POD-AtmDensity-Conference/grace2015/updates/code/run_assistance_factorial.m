function report=run_assistance_factorial(package,root,out)
% Controlled diagnostic: independent versus added POD integer information,
% crossed with no mask / original POD carrier mask / same carrier+code mask.
% Every branch uses the same cached GNSS reference/force basis, block times,
% exact continuity constraints, receiver clocks and code processing policy.
if ~isfolder(out),mkdir(out);end
source=fullfile(root,'code_history20_run');z=load(fullfile(source,'independent_joint_history2.mat'),'result');ind=z.result;
z=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');cp=z.audit.candidate_detail;
z=load(fullfile(root,'bridge_force_run','P_integer_audit.mat'),'audit');cm=z.audit.candidate_detail;
ln=299792458/(1575.42e6+1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);
Wi=round((ind.target-ln*ind.integer_vector)/cf);Hp=cp.A(cp.independent,:);Np=cp.NL(cp.independent);Wp=cp.WL(cp.independent);
% Nested augmented constraints: keep all 297 independent fixes and add only
% new POD-supported directions (63). This avoids removing the two independent
% directions outside the POD benchmark when switching integer information.
[U,~]=qr(ind.H',0);select=[];
for j=1:size(Hp,1)
 v=Hp(j,:)'-U*(U'*Hp(j,:)');v=v-U*(U'*v);if norm(v)<1e-8,continue;end
 U=[U,v/norm(v)];select(end+1)=j; %#ok<AGROW>
end
aug=ind;aug.H=[ind.H;Hp(select,:)];aug.integer_vector=[ind.integer_vector;Np(select)];W=[Wi;Wp(select)];aug.target=ln*aug.integer_vector+cf*W;aug.fixed_rank=size(aug.H,1);
co=(aug.H'\Hp')';assert(max(abs(co*aug.H-Hp),[],'all')<1e-7);assert(max(abs(co*aug.integer_vector-Np))<1e-6&&max(abs(co*W-Wp))<1e-6,'Integer histories conflict');
assert(aug.fixed_rank==360&&numel(select)==63);seeds={ind,aug};integerNames={'independent','addedPOD'};
report=struct('independent_rank',ind.fixed_rank,'augmented_rank',aug.fixed_rank,'POD_directions_added',numel(select));
bases=cell(2,1);masks=cell(2,1);
for s=1:2
 sat=char(64+s);z=load(fullfile(source,[sat '_float_model.mat']),'model');bases{s}=z.model;q=z.model.q;assert(~any(startsWith(fieldnames(q),'pod_')));
 [yes,ix]=ismember(cm.t,q.t);assert(all(yes));mask=false(size(q.good));mask(ix,:)=cm.mask;masks{s}=mask&q.good;
 old=load(fullfile(root,'bridge_force_run',[sat '_raw_design.mat']),'q');[yes,oi]=ismember(cm.t,old.q.t);assert(all(yes));
 sel=cm.mask&old.q.good(oi,:);assert(isequal(sel,masks{s}(ix,:)),'Old mask support does not match current observations');
 phaseDiff=q.phase(ix,:)-old.q.phase(oi,:);labelDiff=double(q.labels(ix,:))-double(old.q.labels(oi,:));
 assert(max(abs(phaseDiff(sel)))==0&&max(abs(labelDiff(sel)))==0,'Ambiguity/phase mapping changed');
 report.input.(sat)=struct('phase_full',nnz(q.good),'phase_masked',nnz(masks{s}),'native_epochs',numel(q.t),'navigation_blocks',numel(z.model.blocks),'phase_and_label_mapping_exact',true);
end
save(fullfile(out,'frozen_factors.mat'),'seeds','masks','integerNames','report','-v7.3');
selectionNames={'full','phase_only','phase_and_code'};
for m=1:3
 selection=selectionNames{m};models=cell(2,1);counts=cell(2,1);
 for s=1:2
  sat=char(64+s);base=bases{s};q=base.q;
  if m==1
   models{s}=base;counts{s}=accumarray(double(q.labels(q.good)),1,[numel(base.B0),1]);
   cc=q.good&isfinite(q.code)&abs(q.code)<30;stats=struct('phase_observations',nnz(q.good),'code_total_observations',nnz(cc),'code_only_observations',0);
  else
   if m==2,q.phase_good=masks{s};else,q.good=q.good&masks{s};end
   fprintf('Profile %s / receiver %s\n',selection,sat);
   [models{s},p,stats]=gnss_long_code_profile(base,q,1200,true(size(q.t)),true);counts{s}=p.count;stats=rmfield(stats,'anchor_audit');
  end
  rawCode=base.q.good&isfinite(base.q.code)&abs(base.q.code)<30;
  if m==2,assert(stats.code_total_observations==nnz(rawCode)&&stats.code_only_observations==nnz(rawCode&~masks{s}));end
  if m>1,assert(stats.phase_observations==nnz(masks{s}));end
  report.selection.(selection).(sat)=stats;
 end
 for k=1:2
  name=[selection '_' integerNames{k}];folder=fullfile(out,name);if ~isfolder(folder),mkdir(folder);end
  fprintf('Condition %s\n',name);seed=seeds{k};[B,r]=condition_supported_history(models{1},models{2},seed,vertcat(counts{:}));
  report.branches.(name)=r;n=numel(models{1}.B0);result=seed;result.fixedB=B;
  save(fullfile(folder,'constraints.mat'),'result','r','-v7.3');
  for s=1:2
   if s==1,bb=B(1:n);else,bb=B(n+1:end);end
   L=gnss_condition_navigation(models{s},[],[],bb);sat=char(64+s);save(fullfile(folder,[sat '_L.mat']),'L','-v7.3');
   z=load(fullfile(source,[sat '_L_history2.mat']),'L');assert(isequal(z.L.values(:,1),L.values(:,1)),'Changed navigation coverage');
   report.branches.(name).(['continuity_' sat])=L.continuity_error;
   if m==1&&k==1,report.baseline_regression.(sat)=max(abs(z.L.values(:,2:7)-L.values(:,2:7)),[],'all');assert(report.baseline_regression.(sat)<1e-7);end
  end
 end
 clear models;
end
report.note='Diagnostic assisted branches, not independent solutions. The augmented integer set retains all 297 independent combinations and adds 63 POD-supported directions, totaling 360. Original POD phase mask is frozen and identical for both integer cases; it includes fixed-track connectivity and POD phase consistency information. Phase-only mask preserves original code availability; phase-and-code reproduces the original coupled observation selection. No POD coordinates used as orbit constraints or held float offsets. Same cached GNSS force/orbit basis and 20-minute dynamics throughout. Unobserved phase offsets are marginalized from effective constraints, not treated as known zero-variance offsets. Exact native 10-second GPS1B and JAXA products unchanged.';
writejson(fullfile(out,'navigation_factors.json'),report);disp(report);
end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
