function test_robust_outliers(source,out)
% POD-assisted prefit exclusion, trimmed integer revalidation, then Huber fit.
% Thresholds fixed before KBR/ACC evaluation; never change retained integers.
if ~isfolder(out),mkdir(out);end
z=load(fullfile(source,'P_integer_audit.mat'));audit=z.audit;c=audit.candidate_detail;
za=load(fullfile(source,'A_raw_design.mat'),'q');zb=load(fullfile(source,'B_raw_design.mat'),'q');a=za.q;b=zb.q;
na=load(fullfile(source,'A_J.mat'));nb=load(fullfile(source,'B_J.mat'));
ia=c.ia;ib=c.ib;pa=a.phase(ia,:)-sum(a.h(ia,:,:).*reshape(a.pod_r(ia,:)-a.r(ia,:),[],1,3),3);pb=b.phase(ib,:)-sum(b.h(ib,:,:).*reshape(b.pod_r(ib,:)-b.r(ib,:),[],1,3),3);
la=max(a.labels(ia,:),1);lb=max(b.labels(ib,:),1);offset=reshape(nb.J.ambiguities(lb(:)),size(lb))-reshape(na.J.ambiguities(la(:)),size(la));sd=pb-pa;err=sd-offset;err(~c.mask)=NaN;
prefit=nan(size(err));flag=false(size(c.mask));threshold=nan(size(err));
for p=2:33
 others=setdiff(2:33,p);enough=sum(isfinite(err(:,others)),2)>=3;center=median(err(:,others),2,'omitnan');prefit(:,p)=err(:,p)-center;
 pairs=[a.labels(ia,p),b.labels(ib,p)];[~,~,group]=unique(pairs,'rows');
 for g=unique(group(c.mask(:,p)))'
  ii=group==g&c.mask(:,p)&enough;v=prefit(ii,p);if numel(v)<10,continue;end
  sigma=max(.003,1.4826*median(abs(v-median(v))));cut=max(.015,4.5*sigma);threshold(ii,p)=cut;flag(ii,p)=abs(v)>cut;
 end
end
clean=c.mask&~flag;
% Revalidate existing candidate integers with outliers removed BEFORE bins.
f1=1575.42e6;f2=1227.6e6;lw=299792458/(f1-f2);ln=299792458/(f1+f2);cf=f2/(f1+f2)*lw;
mw=(b.mw(ib,:)-a.mw(ia,:))/lw;keep=false(numel(c.accepted),1);trimCount=0;
for j=1:numel(c.accepted)
 v=c.accepted(j);p=v.key(1);r=v.key(2);rows=v.rows;rows=rows(~flag(rows,p)&~flag(rows,r));dd=sd(rows,p)-sd(rows,r);ww=mw(rows,p)-mw(rows,r);
 sm=max(.025,1.4826*median(abs(ww-median(ww))));sp=max(.003,1.4826*median(abs(dd-median(dd))));ok=abs(ww-median(ww))<=4.5*sm&abs(dd-median(dd))<=max(.015,4.5*sp);trimCount=trimCount+nnz(~ok);rows=rows(ok);dd=dd(ok);ww=ww(ok);
 if numel(rows)<30,continue;end
 [bins,~,ii]=unique(floor(c.t(rows)/60));if numel(bins)<5,continue;end
 wm=accumarray(ii,ww,[],@median);pm=accumarray(ii,dd,[],@median);w=median(wm);se=max(.025,1.4826*median(abs(wm-median(wm)))/sqrt(numel(wm)));p0=median(pm);spread=1.4826*median(abs(dd-median(dd)));h=ceil(numel(pm)/2);wh=floor(numel(wm)/2);
 keep(j)=round(w)==v.WL&&round((p0-cf*v.WL)/ln)==v.NL&&abs(w-v.WL)+3*se<.5&&abs(w-v.WL)<.2&&se<.12&&abs(p0-v.target)<.02&&spread<.02&&abs(median(pm(1:h))-median(pm(h+1:end)))<.02&&abs(median(wm(1:wh))-median(wm(wh+1:end)))<.25;
end
oldc=c;c.A=c.A(keep,:);c.WL=c.WL(keep);c.NL=c.NL(keep);c.target=c.target(keep);c.accepted=c.accepted(keep);[~,R,piv]=qr(c.A','vector');c.independent=piv(1:sum(abs(diag(R))>1e-9));
% Only retain observations connected by the surviving fixed relations.
kk=vertcat(c.accepted.key);[nodes,~,ids]=unique([kk(:,3:4);kk(:,5:6)],'rows');ne=size(kk,1);G=graph(ids(1:ne),ids(ne+1:end),[],size(nodes,1));comp=conncomp(G);mask=false(size(clean));
for e=1:numel(c.t)
 ps=find(clean(e,:));pairs=[a.labels(ia(e),ps)',b.labels(ib(e),ps)'];[yes,id]=ismember(pairs,nodes,'rows');ps=ps(yes);id=id(yes);if isempty(id),continue;end
 groups=unique(comp(id));best=[];for g=groups(:)',take=find(comp(id)==g);if numel(take)>numel(best),best=take;end,end
 if numel(best)>=2,mask(e,ps(best))=true;end
end
c.mask=mask;audit.candidate_detail=c;save(fullfile(out,'P_integer_audit.mat'),'audit');save(fullfile(out,'history_mask.mat'),'mask');
q=a;save(fullfile(out,'A_raw_design.mat'),'q');q=b;save(fullfile(out,'B_raw_design.mat'),'q');
summary=struct('original_observations',nnz(oldc.mask),'prefit_flagged',nnz(flag),'retained_observations',nnz(mask),'original_relations',numel(keep),'revalidated_relations',nnz(keep),'candidate_samples_trimmed',trimCount,'retained_integers_unchanged',true);
save(fullfile(out,'outlier_audit.mat'),'flag','prefit','threshold','keep','summary');
fprintf('PREFIT SCREEN\n');disp(summary);fit_connected_integer_only(out,out);
% One declared Huber reweighting pass, preserving integer targets and mask.
for sat='AB'
 x=load(fullfile(out,[sat '_raw_design.mat']),'q');q=x.q;n=load(fullfile(out,[sat '_J.mat']));copyfile(fullfile(out,[sat '_J.mat']),fullfile(out,[sat '_screened_J.mat']));
 [yr,ir]=ismember(q.t,n.J.values(:,1));[yc,ic]=ismember(q.t,n.J.clock(:,1));valid=yr&yc;ix=find(valid);labs=max(q.labels(ix,:),1);B=reshape(n.J.ambiguities(labs(:)),size(labs));res=nan(size(q.phase));res(ix,:)=q.phase(ix,:)-sum(q.h(ix,:,:).*reshape(n.J.values(ir(ix),2:4)-q.r(ix,:),[],1,3),3)-n.J.clock(ic(ix),2)-B;
 selected=false(size(q.good));if sat=='A',selected(ia,:)=mask;else,selected(ib,:)=mask;end
 q.phase_weight=ones(size(q.good));for p=2:33
  for label=unique(q.labels(selected(:,p),p))'
   ix=find(selected(:,p)&q.labels(:,p)==label&isfinite(res(:,p)));if numel(ix)<10,continue;end
   v=res(ix,p);sigma=max(.003,1.4826*median(abs(v-median(v))));q.phase_weight(ix,p)=max(.05,min(1,2.5*sigma./max(abs(v),eps)));
  end
 end
 summary.(sat)=struct('downweighted',nnz(q.phase_weight(selected)<1),'minimum_weight',min(q.phase_weight(selected)));save(fullfile(out,[sat '_raw_design.mat']),'q');
end
fit_connected_integer_only(out,out,@gnss_navigation_robust);
f=fopen(fullfile(out,'outlier_summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
