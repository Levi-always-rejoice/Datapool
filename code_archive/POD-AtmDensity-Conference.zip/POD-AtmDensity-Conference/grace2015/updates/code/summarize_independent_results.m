function summarize_independent_results(root,out)
z=load(fullfile(out,'range_evaluation.mat'));p=load(fullfile(root,'bridge_force_density_run','range_comparison.mat'));[t,ia,ib]=intersect(z.t,p.t);g=z.ranges(ia,[1 5 7])*1000;assisted=p.rv(ib,2)*1000;valid=all(isfinite([g assisted]),2);names={'Float','Joint220','Extended223'};summary=struct;
for j=1:3,summary.(names{j}).range_RMS_mm=rms(g(valid,j));end;summary.Assisted.range_RMS_mm=rms(assisted(valid));summary.range_common_epochs=nnz(valid);
old=load(fullfile(root,'bridge_force_density_run','comparison.mat'));old=old.series{1};tags={'F','L1','N2'};dd=cell(3,1);
for j=1:3
 v=readmatrix(fullfile(out,[tags{j} '_differential_density.csv']));dd{j}=v;[~,i,k]=intersect(v(:,1),old.t);m=old.mask(k);gg=v(i(m),2);acc=v(i(m),3);summary.(names{j}).density_matched=score(gg,acc);
 summary.(names{j}).density_13_15=score(v(v(:,1)>=46816&v(:,1)<=54016,2),v(v(:,1)>=46816&v(:,1)<=54016,3));
 summary.(names{j}).density_last4=score(v(v(:,1)>=72016,2),v(v(:,1)>=72016,3));
end
summary.note='Matched density uses valid time centers from the prior assisted solution only as an evaluation mask; all independent variants use freshly computed forces on independent float GNSS geometry and the same ACC comparison operator. No assisted density is fitted or used to fix integers. Full-day statistics remain in evaluation.json.';
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1450 1050]);tiledlayout(3,1);
nexttile;plot((t-16)/3600,[g(:,1),g(:,3),assisted]);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title('Unfiltered range comparison, common KBR datum');legend('Independent float','Independent 223 integer combinations','POD-assisted benchmark');
for j=1:2
 nexttile;v=dd{3};[tt,i,k]=intersect(v(:,1),old.t);m=old.mask(k);vals=v(i,2:3)*1e12;vals(~m|[false;diff(tt)>1.1],:)=NaN;plot((tt-16)/3600,vals);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('Independent integers','ACC');
 if j==1,xlim([0 24]);title('20-minute density, matched previously valid time support');else,xlim([13 15]);title('Same density comparison, 13–15 UTC');end
end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(out,'independent_summary.png'),'Resolution',150);close(fig);
f=fopen(fullfile(out,'matched_summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
end
function s=score(g,a)
c=corrcoef(g,a);s=struct('centers',numel(g),'RMS',rms(g-a),'r',c(1,2));
end
