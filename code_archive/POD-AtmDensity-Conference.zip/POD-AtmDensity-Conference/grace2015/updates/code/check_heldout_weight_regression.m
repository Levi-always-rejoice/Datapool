function report=check_heldout_weight_regression(root,out)
% Adding optional phase weights must reproduce the saved unweighted float
% and fixed navigation when every weight equals one.
source=fullfile(root,'code_history20_run');a=load(fullfile(source,'A_float_model.mat'),'model');q=a.model.q;q.phase_weight=ones(size(q.good));
[m,~]=gnss_long_code_profile(a.model,q,1200,true(size(q.t)),true);
report=struct('max_float_ambiguity_difference_m',max(abs(m.db-a.model.db)), ...
 'float_covariance_relative_difference',norm(m.Q-a.model.Q,'fro')/norm(a.model.Q,'fro'));
z=load(fullfile(source,'independent_joint_history2.mat'),'result');n=numel(m.B0);L=gnss_condition_navigation(m,[],[],z.result.fixedB(1:n));old=load(fullfile(source,'A_L_history2.mat'),'L');
assert(isequal(L.values(:,1),old.L.values(:,1)));report.max_position_difference_m=max(abs(L.values(:,2:4)-old.L.values(:,2:4)),[],'all');
assert(report.max_float_ambiguity_difference_m<1e-7&&report.float_covariance_relative_difference<1e-8&&report.max_position_difference_m<1e-7);
report.synthetic_prediction=test_heldout_covariance;
f=fopen(fullfile(out,'numerical_checks.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
