function result=gnss_reprofile(base,epochMask)
% Refit the exact original linearized model on selected epochs. No new ODEs.
% Keeps all original track labels; unobserved labels are explicitly marked.
q=base.q;nt=numel(q.t);assert(numel(epochMask)==nt);lab=double(q.labels);nb=numel(base.B0);
good=q.good & epochMask(:) & lab>0;
alpha=1575.42e6^2/(1575.42e6^2-1227.6e6^2);beta=1-alpha;
phase=q.phase-reshape(base.B0(max(lab(:),1)),size(lab));nblocks=numel(base.blocks);
N=zeros(12*nblocks);rhs=zeros(12*nblocks,1);Nx=zeros(12*nblocks,nb);Nbb=zeros(nb);bb=zeros(nb,1);count=zeros(nb,1);
for j=1:nblocks
 block=base.blocks{j};ids=block.ids;st=gnss_states(block,q.t(ids));Nj=zeros(12);rj=zeros(12,1);cross=zeros(12,nb);
 for k=1:numel(ids)
  e=ids(k);if ~epochMask(e),continue;end
  h=squeeze(q.h(e,:,:));H=h*st(1:3,2:13,k);off=h*(st(1:3,1,k)-q.r(e,:)');
  ph=phase(e,:)'-off;code=q.code(e,:)'-off;ph(~isfinite(ph))=0;code(~isfinite(code))=0;
  elev=q.elev(e,:)';elev(~isfinite(elev))=0;sn=max(sin(elev),.25);gg=good(e,:)';
  wp=double(gg)./(.005*hypot(alpha,beta)./sn).^2;
  cg=gg&isfinite(q.code(e,:)')&abs(q.code(e,:)')<30;rc=q.code(e,:)';rc(~isfinite(rc))=0;
  wc=double(cg)./(4.5./sn).^2./max(1,abs(rc)/3);W=wp+wc;den=max(sum(W),1e-30);
  hm=(W'*H)/den;ym=sum(wp.*ph+wc.*code)/den;HH=H-hm;
  Nj=Nj+HH'*(W.*HH);rj=rj+HH'*(wp.*(ph-ym)+wc.*(code-ym));
  ps=find(gg);labels=lab(e,ps)';wt=wp(ps);E=accumarray(labels,wt,[nb 1]);
  Nbb=Nbb+diag(E)-(E*E')/den;bb=bb+accumarray(labels,wt.*ph(ps),[nb 1])-E*ym;
  cross(:,labels)=cross(:,labels)+(wt.*HH(ps,:))';count=count+accumarray(labels,1,[nb 1]);
 end
 ix=(j-1)*12+(1:12);N(ix,ix)=Nj;rhs(ix)=rj;Nx(ix,:)=cross;
end
C=base.C;d=base.d;sc=sqrt(max(diag(N),1e-20));Ns=N./sc./sc';Cs=C./sc';row=vecnorm(Cs,2,2);Cs=Cs./row;ds=d./row;
xp=lsqminnorm(Cs,ds);Z=null(Cs);red=Z'*Ns*Z;xp=xp./sc;T=Z./sc;
bz=T'*(rhs-N*xp);Nzb=T'*Nx;schur=Nbb-Nzb'*(red\Nzb);brhs=bb-Nx'*xp-Nzb'*(red\bz);
used=diag(schur)>1e-10;ss=sqrt(diag(schur));ss=ss(used);S=schur(used,used)./ss./ss';
[U,D]=eig((S+S')/2,'vector');keep=D>max(max(D)*1e-12,1e-14);Q=zeros(nb);
Q(used,used)=((U(:,keep)./D(keep)')*U(:,keep)')./ss./ss';B=base.B0+Q*brhs;
result=struct('B',B,'Q',Q,'count',count,'epochs',nnz(epochMask),'normal_min_eigenvalue',min(D));
end
