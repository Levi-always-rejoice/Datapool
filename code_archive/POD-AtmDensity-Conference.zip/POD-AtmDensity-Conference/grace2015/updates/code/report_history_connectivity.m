function report_history_connectivity(baseline,previous,out)
a=readmatrix(fullfile(out,'A_history_density.csv'));b=readmatrix(fullfile(out,'B_history_density.csv'));
[t,ia,ib]=intersect(a(:,1),b(:,1));a=a(ia,:);b=b(ib,:);m=a(:,8)>0&b(:,8)>0;u=(t-16)/3600;u([false;diff(t)>1.1])=NaN;
oldA=load(fullfile(previous,'A_experiment_density.mat'));oldB=load(fullfile(previous,'B_experiment_density.mat'));
baseA=load(fullfile(baseline,'A_all_density.mat'),'maskFixed');baseB=load(fullfile(baseline,'B_all_density.mat'),'maskFixed');
[yes,loc]=ismember(t,oldA.density.J.values(:,1));assert(all(yes));[yesB,locB]=ismember(t,oldB.density.J.values(:,1));assert(all(yesB));om=baseA.maskFixed(loc)&baseB.maskFixed(locB);
old=oldB.density.J.values(locB,2)-oldA.density.J.values(loc,2);new=b(:,2)-a(:,2);acc=b(:,4)-a(:,4);
s=struct('old_centers',nnz(om),'new_centers',nnz(m),'added_centers',nnz(m&~om),'lost_centers',nnz(om&~m));
s.old_on_common=score(old,acc,m&om);s.new_on_common=score(new,acc,m&om);s.new_on_added=score(new,acc,m&~om);s.new_on_all=score(new,acc,m);
save(fullfile(out,'comparison.mat'),'t','old','new','acc','m','om','s');f=fopen(fullfile(out,'comparison.json'),'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);disp(s);
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 850]);tiledlayout(3,1);
nexttile;v=old;v(~om)=NaN;r=acc;r(~om)=NaN;plot(u,v*1e12);hold on;plot(u,r*1e12,'k');title('Previous connected-mask solution');ylabel('\Delta\rho (10^{-12} kg/m^3)');ylim([-.8 .8]);xlim([0 24]);grid on;legend('GNSS','ACC');
nexttile;v=new;v(~m)=NaN;r=acc;r(~m)=NaN;plot(u,v*1e12);hold on;plot(u,r*1e12,'k');label='Carry fixed integer relations through unchanged track histories';if contains(out,'arc10_run'),label='Arc-level support, 10-degree elevation cutoff';elseif contains(out,'arc5_run'),label='Arc-level support, 5-degree elevation cutoff';end;title(label);ylabel('\Delta\rho (10^{-12} kg/m^3)');ylim([-.8 .8]);xlim([0 24]);grid on;legend('GNSS','ACC');
nexttile;stairs(u,double(om));hold on;stairs(u,double(m)+1.2);ylim([-.2 2.4]);yticks([.5 1.7]);yticklabels({'Previous support','History support'});xlim([0 24]);grid on;xlabel('UTC hour, 2015-03-15');title('Support masks: gaps remain excluded, not interpolated');
exportgraphics(fig,fullfile(out,'density_gap_comparison.png'),'Resolution',150);close(fig);
end
function s=score(x,y,m)
if nnz(m)<2,s=struct('count',nnz(m),'RMS',NaN,'r',NaN);return;end
c=corrcoef(x(m),y(m));s=struct('count',nnz(m),'RMS',rms(x(m)-y(m)),'r',c(1,2));
end
