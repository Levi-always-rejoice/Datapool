function report=evaluate_integer_expansion(package,root,out,suffix,doDensity,options)
% Withheld reference audit, called only AFTER navigation has been saved.
if nargin<5,doDensity=true;end
if nargin<6,options=struct;end
source=fullfile(root,'independent_run');base=fullfile(root,'reduced_dynamic_pod_integer_run');
z=load(fullfile(out,['independent_joint' suffix '.mat']),'result');s=z.result;ln=299792458/(1575.42e6+1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);
N=s.integer_vector;W=round((s.target-ln*N)/cf);assert(max(abs(s.target-ln*N-cf*W))<1e-8);
z=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');p=z.audit.candidate_detail;H=p.A(p.independent,:);NP=p.NL(p.independent);WP=p.WL(p.independent);
report=struct('fixed_rank',s.fixed_rank,'L1',space(s.H,N,H,NP),'L2',space(s.H,N-W,H,NP-WP),'WL',space(s.H,W,H,WP));
if isfield(options,'plotTitle'),report.plot_title=options.plotTitle;end
old=load(fullfile(source,'independent_joint_search3m.mat'),'result');report.old_seed=space(old.result.H,old.result.target,s.H,s.target);
co=(s.H'\p.A')';fixed=max(abs(co*s.H-p.A),[],2)<1e-8;d1=co*N-p.NL;d2=co*(N-W)-(p.NL-p.WL);
report.natural_relations_fixed=nnz(fixed);report.natural_relations_wrong_L1_or_L2=nnz(fixed&(abs(d1)>1e-6|abs(d2)>1e-6));
writejson(fullfile(out,['evaluation' suffix '.json']),report);disp(report);
navs=cell(2,1);refs=cell(2,1);
for sat='AB'
 k=double(sat)-64;z=load(fullfile(out,[sat '_L' suffix '.mat']),'L');navs{k}=z.L;refs{k}=load(fullfile(source,'fresh_force_reference',[sat '_all_density.mat']),'d','bias');v=z.L.values;P=gnss_hermite(refs{k}.d.pod_t,refs{k}.d.pod_r,refs{k}.d.pod_v);report.(['orbit_' sat '_RMS_m'])=rms(vecnorm(v(:,2:4)-ppval(P,v(:,1)')',2,2));
end
z=load(fullfile(base,'range_comparison.mat'),'t','rv');t=z.t;rv=z.rv;oldnav=cell(2,1);
for sat='AB',z=load(fullfile(source,[sat '_L_search3m.mat']),'L');oldnav{double(sat)-64}=z.L;end
a=navs{1}.values;b=navs{2}.values;oa=oldnav{1}.values;ob=oldnav{2}.values;
assert(isequal(a(:,1),oa(:,1))&&isequal(b(:,1),ob(:,1)));[ya,ia]=ismember(t,a(:,1));[yb,ib]=ismember(t,b(:,1));m=ya&yb;nr=nan(size(t));
nr(m)=rv(m,1)+vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-vecnorm(ob(ib(m),2:4)-oa(ia(m),2:4),2,2);
rv=[rv(:,1),nr,rv(:,2)];m=all(isfinite(rv),2);report.range_common_epochs=nnz(m);report.range_RMS_mm=rms(rv(m,:))*1000;report.columns={'original240','expanded','POD_integers_only358'};
save(fullfile(out,['comparison' suffix '.mat']),'t','rv','report');writejson(fullfile(out,['evaluation' suffix '.json']),report);
if ~doDensity,return;end
dens=cell(2,1);
for sat='AB'
 k=double(sat)-64;fprintf('Density for expanded solution %s\n',sat);z=gnss_density_sparse_window(refs{k}.d,struct('L',navs{k}),1200);v=z.L.values;v(:,4)=v(:,4)-refs{k}.bias/1e-6*v(:,6);dens{k}=v;
 report.checks.(sat)=rmfield(z.L,'values');writematrix(v,fullfile(out,[sat suffix '_density.csv']));
end
[tt,ia,ib]=intersect(dens{1}(:,1),dens{2}(:,1));g=dens{2}(ib,2)-dens{1}(ia,2);acc=dens{2}(ib,4)-dens{1}(ia,4);
z=load(fullfile(root,'bridge_force_density_run','comparison.mat'));ref=z.series{1};[~,i,j]=intersect(tt,ref.t);mask=ref.mask(j);report.density_matched=score(g(i(mask)),acc(i(mask)));report.density_all=score(g,acc);
report.density_last4=score(g(tt>=72016),acc(tt>=72016));report.density_13_15=score(g(tt>=46816&tt<=54016),acc(tt>=46816&tt<=54016));
writematrix([tt,g,acc],fullfile(out,[suffix '_differential_density.csv']));
report.note='GNSS-only integer decisions saved before reference audit. Original observations, weights, 20-minute reduced-dynamic blocks, fresh independent force geometry, 20-minute density operator and KBR datum unchanged. No POD-assisted selection mask. ACC retains prior POD-calibrated constant comparison bias. Formal likelihood and split-data gates do not calibrate false-fix probability; full-day batch.';
if isfield(options,'note'),report.note=options.note;end
writejson(fullfile(out,['evaluation' suffix '.json']),report);save(fullfile(out,['comparison' suffix '.mat']),'t','rv','tt','g','acc','report');
plot_integer_expansion(root,out,suffix);disp(report);
end
function r=space(A,a,B,b)
[ua,ra]=qr(A',0);[ub,rb]=qr(B',0);[U,S,~]=svd(ua'*ub,'econ');same=diag(S)>1-1e-10;H=U(:,same)'*ua';ca=(ra\(ua'*H'))';cb=(rb\(ub'*H'))';dd=ca*a-cb*b;
r=struct('rank',size(A,1),'reference_rank',size(B,1),'intersection_rank',nnz(same),'max_disagreement',max(abs(dd)),'only_new_rank',size(A,1)-nnz(same),'reference_missing_rank',size(B,1)-nnz(same));
end
function s=score(g,a)
m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));
end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
