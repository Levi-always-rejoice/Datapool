function fill_connected_force_gaps(package,oldnav,bridge,navout,forceout)
if ~isfolder(navout),mkdir(navout);end;if ~isfolder(forceout),mkdir(forceout);end
models=fullfile(grace_update_input_root(package),'models');raw=fullfile(grace_update_input_root(package),'raw');base=grace_update_baseline(package);
z=jsondecode(fileread(fullfile(bridge,'bridge_summary.json')));approved=z.connected_intervals_GPS;
z=load(fullfile(oldnav,'P_integer_audit.mat'));audit=z.audit;c=audit.candidate_detail;qa=cell(2,1);summary=struct;
for sat='AB'
 j=double(sat)-64;z=load(fullfile(oldnav,[sat '_raw_design.mat']),'q');q=z.q;oldT=q.t;newT=filltimes(oldT,approved,10);added=setdiff(newT,oldT);
 [r,v]=reference(q.t,q.r,q.v,added);[rot,age]=raw_attitude(sat,added,raw);assert(all(age<=5),'Missing attitude in proposed force gap');fresh=raw_forces(sat,added,r,v,rot,models);
 q=merge(q,fresh,oldT,added,newT);q.bridge_intervals=approved;qa{j}=q;
 z=load(fullfile(base,[sat '_all_density.mat']),'d','bias');d=z.d;bias=z.bias;oldT=d.t;newT=filltimes(oldT,approved,5);addedD=setdiff(newT,oldT);
 [r,v]=reference(d.t,d.r,d.v,addedD);[rot,age]=raw_attitude(sat,addedD,raw);assert(all(age<=5));fresh=raw_forces(sat,addedD,r,v,rot,models);
 acc=read_grace_ascii(fullfile(raw,sprintf('ACC1B_2015-03-15_%s_02.asc',sat)),[1 3 4 5]);ax=interp1(acc.values(:,1),acc.values(:,2),addedD,'spline');
 rb=reshape(pagemtimes(permute(rot,[2 1 3]),reshape(fresh.rad',3,1,[])),3,[])';ab=reshape(pagemtimes(permute(rot,[2 1 3]),reshape((fresh.K.*fresh.drag)',3,1,[])),3,[])';fresh.acc_rho=(ax-rb(:,1))./ab(:,1);fresh.acc_bias_template_rho=1e-6./ab(:,1);
 d=merge(d,fresh,oldT,addedD,newT);save(fullfile(forceout,[sat '_all_density.mat']),'d','bias','-v7.3');summary.(sat)=struct('navigation_force_epochs_added',numel(added),'density_force_epochs_added',numel(addedD));
end
[yes,c.ia]=ismember(c.t,qa{1}.t);assert(all(yes));[yes,c.ib]=ismember(c.t,qa{2}.t);assert(all(yes));audit.candidate_detail=c;save(fullfile(navout,'P_integer_audit.mat'),'audit');copyfile(fullfile(oldnav,'history_mask.mat'),fullfile(navout,'history_mask.mat'));
for sat='AB',q=qa{double(sat)-64};save(fullfile(navout,[sat '_raw_design.mat']),'q');end
fit_connected_integer_only(navout,navout,@gnss_navigation_bridge);
f=fopen(fullfile(navout,'force_gap_summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
function new=filltimes(t,approved,step)
new=t;for j=1:size(approved,1),inside=(ceil(approved(j,1)/step)*step:step:approved(j,2))';new=[new;inside];end;new=unique(new);
end
function [r,v]=reference(t,r0,v0,added)
R=gnss_hermite(t,r0,v0);r=ppval(R,added')';v=zeros(size(r));for k=1:numel(added),piece=find(R.breaks<=added(k),1,'last');piece=min(piece,R.pieces);cc=R.coefs((piece-1)*3+(1:3),:);u=added(k)-R.breaks(piece);v(k,:)=(3*cc(:,1)*u^2+2*cc(:,2)*u+cc(:,3))';end
end
function dest=merge(old,fresh,oldT,added,newT)
dest=old;[~,oi]=ismember(oldT,newT);[~,ni]=ismember(added,newT);fields=fieldnames(old);
for j=1:numel(fields)
 name=fields{j};v=old.(name);if ~isnumeric(v)&&~islogical(v),continue;end
 if size(v,1)~=numel(oldT)||startsWith(name,'pod_'),continue;end
 sz=size(v);sz(1)=numel(newT);if islogical(v),out=false(sz);else,out=nan(sz);end
 out(oi,:,:)=v;if isfield(fresh,name),out(ni,:,:)=fresh.(name);elseif any(strcmp(name,{'labels','h','clock'})),out(ni,:,:)=0;elseif strcmp(name,'ids'),out(ni,:,:)=-1;end
 dest.(name)=out;
end
dest.t=newT;
if isfield(old,'pod_r')&&size(old.pod_r,1)==numel(oldT)&&~isfield(old,'pod_t'),dest.pod_r=interp1(oldT,old.pod_r,newT,'spline');end
end
