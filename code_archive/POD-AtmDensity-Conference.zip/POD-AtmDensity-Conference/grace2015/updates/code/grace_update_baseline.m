function root=grace_update_baseline(workspace)
marker=fullfile(workspace,'baseline_path.txt');
if isfile(marker),root=strtrim(fileread(marker));else,root=fullfile(workspace,'manuscript_validation_run');end
assert(isfile(fullfile(root,'A_raw_design.mat')),'Generate the raw-input baseline first.');
end
