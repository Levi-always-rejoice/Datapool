function [model,profile,report]=gnss_long_code_profile(base,q,windowSeconds,epochMask,robust)
% Split code/carrier into an exactly decorrelated carrier-like channel and
% code-minus-carrier offset channel. Aggregate each offset once per tracking
% label and 20/60-min bin; do not replicate smoothed code at every epoch.
% With robust=false the normal equations reproduce the unaggregated input
% likelihood (aggregation is an exact sufficient statistic for constant B).
if nargin<5,robust=true;end
nt=numel(q.t);nb=numel(base.B0);assert(numel(epochMask)==nt);lab=double(q.labels);good=q.good&epochMask(:)&lab>0;
% Optional carrier-only selection leaves the underlying code availability
% unchanged. A code-only row contributes once to the mixed channel and has
% no ambiguity coefficient or phase-minus-code offset anchor.
phaseGood=good;if isfield(q,'phase_good'),phaseGood=phaseGood&q.phase_good;end
alpha=1575.42e6^2/(1575.42e6^2-1227.6e6^2);beta=1-alpha;
phase=q.phase-reshape(base.B0(max(lab(:),1)),size(lab));nblocks=numel(base.blocks);blocks=base.blocks;
N=zeros(12*nblocks);rhs=zeros(12*nblocks,1);Nx=zeros(12*nblocks,nb);Nbb=zeros(nb);bb=zeros(nb,1);count=zeros(nb,1);anchors=cell(nblocks,1);maxCodeFraction=0;codeTotal=0;codeOnly=0;
for j=1:nblocks
 block=blocks{j};ids=block.ids;st=gnss_states(block,q.t(ids));Nj=zeros(12);rj=zeros(12,1);cross=zeros(12,nb);rows=cell(numel(ids),1);
 mh=zeros(numel(ids),12);my=zeros(numel(ids),1);wpall=zeros(numel(ids),33);denall=ones(numel(ids),1);
 for k=1:numel(ids)
  e=ids(k);if ~epochMask(e),continue;end
  h=squeeze(q.h(e,:,:));H=h*st(1:3,2:13,k);off=h*(st(1:3,1,k)-q.r(e,:)');
  ph=phase(e,:)'-off;code=q.code(e,:)'-off;ph(~isfinite(ph))=0;code(~isfinite(code))=0;
  el=q.elev(e,:)';el(~isfinite(el))=0;sn=max(sin(el),.25);gg=phaseGood(e,:)';wp=double(gg)./(.005*hypot(alpha,beta)./sn).^2;
  if isfield(q,'phase_weight'),wp=wp.*q.phase_weight(e,:)';assert(all(q.phase_weight(e,:)>0),'Use positive variance weights; exclude observations through q.good');end
  cg=good(e,:)'&isfinite(q.code(e,:)')&abs(q.code(e,:)')<30;rc=q.code(e,:)';rc(~isfinite(rc))=0;wc=double(cg)./(4.5./sn).^2./max(1,abs(rc)/3);codeTotal=codeTotal+nnz(cg);codeOnly=codeOnly+nnz(cg&~gg);
  W=wp+wc;den=max(sum(W),1e-30);mix=zeros(33,1);on=W>0;mix(on)=(wp(on).*ph(on)+wc(on).*code(on))./W(on);
  hm=(W'*H)/den;ym=sum(W.*mix)/den;HH=H-hm;
  Nj=Nj+HH'*(W.*HH);rj=rj+HH'*(W.*(mix-ym));
  ps=find(gg);labels=lab(e,ps)';wt=wp(ps);E=accumarray(labels,wt,[nb 1]);
  Nbb=Nbb+diag(accumarray(labels,wt.^2./W(ps),[nb 1]))-(E*E')/den;
  bb=bb+accumarray(labels,wt.*mix(ps),[nb 1])-E*ym;cross(:,labels)=cross(:,labels)+(wt.*HH(ps,:))';count=count+accumarray(labels,1,[nb 1]);
  cp=find(cg&gg);wd=wp(cp).*wc(cp)./W(cp);rows{k}=[lab(e,cp)',repmat(q.t(e),numel(cp),1),ph(cp)-code(cp),wd];
  if ~isempty(cp),maxCodeFraction=max(maxCodeFraction,max(wc(cp)./W(cp)));end
  mh(k,:)=hm;my(k)=ym;wpall(k,:)=wp';denall(k)=den;
 end
 ix=(j-1)*12+(1:12);N(ix,ix)=Nj;rhs(ix)=rj;Nx(ix,:)=cross;anchors{j}=vertcat(rows{:});
 block.N=Nj;block.rhs=rj;block.cross=cross;block.mh=mh;block.my=my;block.wp=wpall;block.den=denall;blocks{j}=block;
end
obs=vertcat(anchors{:});[groups,~,gi]=unique([obs(:,1),floor(obs(:,2)/windowSeconds)],'rows');anchorAudit=nan(size(groups,1),8);
for k=1:size(groups,1)
 v=obs(gi==k,:);label=groups(k,1);rawPrecision=sum(v(:,4));meanValue=sum(v(:,3).*v(:,4))/rawPrecision;variance=1/rawPrecision;
 [~,~,minute]=unique(floor(v(:,2)/60));nw=accumarray(minute,v(:,4));means=accumarray(minute,v(:,3).*v(:,4))./nw;
 if robust&&numel(nw)>=3
  center=median(means);scale=max(1.4826*median(abs(means-center)),median(1./sqrt(nw)));
  for it=1:5,w=nw.*min(1,2.5*scale./max(abs(means-center),1e-12));center=sum(w.*means)/sum(w);end
  meanValue=center;neff=sum(w)^2/sum(w.^2);variance=max([variance,sum(w.^2./nw)/sum(w)^2,(1.4826*median(abs(means-center)))^2/neff]);
 end
 precision=1/variance;Nbb(label,label)=Nbb(label,label)+precision;bb(label)=bb(label)+precision*meanValue;
 anchorAudit(k,:)=[label,groups(k,2),size(v,1),numel(nw),meanValue,sqrt(variance),sqrt(1/rawPrecision),max(v(:,2))-min(v(:,2))];
end
C=base.C;d=base.d;sc=sqrt(max(diag(N),1e-20));Ns=N./sc./sc';Cs=C./sc';row=vecnorm(Cs,2,2);Cs=Cs./row;ds=d./row;
xp=lsqminnorm(Cs,ds);Z=null(Cs);red=Z'*Ns*Z;xp=xp./sc;T=Z./sc;bz=T'*(rhs-N*xp);Nzb=T'*Nx;
schur=Nbb-Nzb'*(red\Nzb);brhs=bb-Nx'*xp-Nzb'*(red\bz);used=diag(schur)>1e-10;ss=sqrt(diag(schur));ss=ss(used);S=schur(used,used)./ss./ss';
[U,D]=eig((S+S')/2,'vector');keep=D>max(max(D)*1e-12,1e-14);Q=zeros(nb);Q(used,used)=((U(:,keep)./D(keep)')*U(:,keep)')./ss./ss';db=Q*brhs;
model=struct('blocks',{blocks},'B0',base.B0,'Q',Q,'db',db,'xp',xp,'T',T,'red',red,'bz',bz,'Nzb',Nzb,'C',C,'d',d,'q',q);
profile=struct('B',base.B0+db,'Q',Q,'count',count,'epochs',nnz(epochMask),'normal_min_eigenvalue',min(D));
report=struct('window_s',windowSeconds,'robust',robust,'code_samples',size(obs,1),'code_total_observations',codeTotal,'code_only_observations',codeOnly,'offset_anchors',size(groups,1),'anchor_samples_percentiles',prctile(anchorAudit(:,3),[0 25 50 75 100]),'anchor_sigma_percentiles_m',prctile(anchorAudit(:,6),[0 25 50 75 100]),'max_code_fraction_in_decorrelated_carrier',maxCodeFraction,'anchor_audit',anchorAudit,'phase_observations',sum(count));
end
