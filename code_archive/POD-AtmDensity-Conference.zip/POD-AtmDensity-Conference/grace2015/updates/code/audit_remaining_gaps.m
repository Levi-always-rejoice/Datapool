function audit_remaining_gaps(package,navdir,densitydir,out)
if ~isfolder(out),mkdir(out);end
base=grace_update_baseline(package);raw=fullfile(grace_update_input_root(package),'raw');models=fullfile(grace_update_input_root(package),'models');
z=load(fullfile(navdir,'P_integer_audit.mat'));c=z.audit.candidate_detail;
kk=vertcat(c.accepted.key);[nodes,~,id]=unique([kk(:,3:4);kk(:,5:6)],'rows');ne=size(kk,1);G=graph(id(1:ne),id(ne+1:end),[],size(nodes,1));comp=conncomp(G);
qs=cell(2,1);navs=qs;boots=qs;obs=qs;
for sat='AB'
 k=double(sat)-64;z=load(fullfile(navdir,[sat '_raw_design.mat']),'q');qs{k}=z.q;z=load(fullfile(navdir,[sat '_J.mat']));navs{k}=z.J;
 z=load(fullfile(base,[sat '_raw_design.mat']),'bootstrap');boots{k}=z.bootstrap;
 obs{k}=raw_tracks(sat,raw);fprintf('Loaded raw observations %s\n',sat);
end
allT=(0:86399)';navmask=ismember(allT,navs{1}.values(:,1))&ismember(allT,navs{2}.values(:,1));
% Actual missing state intervals, separate from density-window dilation.
ng=intervals(~navmask);ng=ng(ng(:,1)>max(navs{1}.values(1,1),navs{2}.values(1,1))&ng(:,2)<min(navs{1}.values(end,1),navs{2}.values(end,1)),:);
navrows=[];details={};
for j=1:size(ng,1)
 lo=ng(j,1);hi=ng(j,2);before=find(c.t<lo&sum(c.mask,2)>=2,1,'last');after=find(c.t>hi&sum(c.mask,2)>=2,1);if isempty(before)||isempty(after),continue;end
 [leftNodes,leftGPS]=at(before);[rightNodes,rightGPS]=at(after);same=intersect(leftNodes,rightNodes);bridge=intersect(comp(leftNodes),comp(rightNodes));
 values=[lo,hi,hi-lo+1,numel(same),numel(bridge),numel(intersect(leftGPS,rightGPS))];
 d=struct('start_GPS_seconds',lo,'end_GPS_seconds',hi,'left_selected_epoch_GPS',c.t(before),'right_selected_epoch_GPS',c.t(after),'same_track_pair_GPS',nodesGPS(same,before),'graph_components_shared',numel(bridge));
 for k=1:2
  q=qs{k};l=find(q.t<lo,1,'last');r=find(q.t>hi,1);p=find(q.labels(l,:)>0&q.labels(r,:)>0);sameLab=sum(q.labels(l,p)==q.labels(r,p));
  o=obs{k};in=o.rx>=lo&o.rx<=hi;counts=sum(isfinite(o.phase(in,:)),2);minCount=NaN;if ~isempty(counts),minCount=min(counts);end
  rawSame=0;if ~isempty(l)&&~isempty(r),[~,ol]=min(abs(o.rx-q.t(l)));[~,orr]=min(abs(o.rx-q.t(r)));rawSame=nnz(o.ids(ol,:)>0&o.ids(ol,:)==o.ids(orr,:));end
  pipelineSplit=find(floor(q.ids(l,:)/100000)==floor(q.ids(r,:)/100000)&q.ids(l,:)~=q.ids(r,:)&q.labels(l,:)>0&q.labels(r,:)>0)-1;
  values=[values,sameLab,rawSame,minCount];d.(char(64+k))=struct('same_model_labels',sameLab,'same_raw_track_ids',rawSame,'pipeline_split_same_raw_track_GPS',pipelineSplit,'minimum_raw_phase_count_during_gap',minCount,'bootstrap_event_times',cellfun(@(v)v.t,boots{k}.events)); %#ok<AGROW>
 end
 navrows=[navrows;values];details{end+1}=d; %#ok<AGROW>
end
T=array2table(navrows,'VariableNames',{'start_GPS','end_GPS','duration_s','same_fixed_track_pairs','shared_integer_graph_components','same_GPS_both_sides','A_same_labels','A_same_raw_ids','A_min_raw_phase_count','B_same_labels','B_same_raw_ids','B_min_raw_phase_count'});writetable(T,fullfile(out,'navigation_gaps.csv'));
d=load(fullfile(densitydir,'comparison.mat'));summary=struct('navigation_internal_gaps',height(T),'navigation_missing_seconds',sum(T.duration_s),'gaps_with_same_fixed_track_pairs',nnz(T.same_fixed_track_pairs>0),'gaps_with_graph_bridge',nnz(T.shared_integer_graph_components>0),'navigation_gaps',{details});
for k=1:2
 s=d.series{k};valid=false(size(allT));valid(s.t+1)=s.mask;hasResult=false(size(allT));hasResult(s.t+1)=true;half=[600 300];h=half(k);
 eligible=allT>=max(navs{1}.values(1,1),navs{2}.values(1,1))+h&allT<=min(navs{1}.values(end,1),navs{2}.values(end,1))-h;
 missing=~valid&eligible;dg=intervals(missing);rows=[];
 for j=1:size(dg,1)
  lo=dg(j,1);hi=dg(j,2);ii=lo+1:hi+1;unavailable=nnz(~hasResult(ii));masked=nnz(hasResult(ii)&~valid(ii));before=find(c.t<lo,1,'last');after=find(c.t>hi,1);shared=0;graphBridge=0;
  if ~isempty(before)&&~isempty(after),ln=at(before);rn=at(after);shared=numel(intersect(ln,rn));graphBridge=numel(intersect(comp(ln),comp(rn)));end
  rows=[rows;lo,hi,hi-lo+1,unavailable,masked,shared,graphBridge]; %#ok<AGROW>
 end
 tab=array2table(rows,'VariableNames',{'start_GPS','end_GPS','duration_s','no_density_result_seconds','support_mask_seconds','same_track_pairs_at_gap_edges','shared_graph_components_at_gap_edges'});tag=sprintf('min%d',2*h/60);writetable(tab,fullfile(out,[tag '_density_gaps.csv']));
 summary.(tag)=struct('valid_centers',nnz(valid),'day_edge_excluded',nnz(~eligible),'internal_no_density_result',nnz(eligible&~hasResult),'internal_support_rejected',nnz(eligible&hasResult&~valid),'internal_gap_count',height(tab));
end
f=fopen(fullfile(out,'summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(T);disp(summary.min20);disp(summary.min10);
 function [ids,ps]=at(e)
  ps=find(c.mask(e,:));pairs=[qs{1}.labels(c.ia(e),ps)',qs{2}.labels(c.ib(e),ps)'];[yes,ids]=ismember(pairs,nodes,'rows');ids=ids(yes);ps=ps(yes);
 end
 function ps=nodesGPS(ids,e)
  [allids,allps]=at(e);ps=allps(ismember(allids,ids));ps=ps-1;
 end
end
function out=intervals(mask)
edge=diff([false;mask(:);false]);out=[find(edge==1)-1,find(edge==-1)-2];
end
function obs=raw_tracks(sat,raw)
rows=read_raw_inputs(sat,raw);a=rows.gps.values;obs=struct('rx',(0:10:86390)','phase',nan(8640,33),'ids',-ones(8640,33));previous=nan(33,1);track=zeros(33,1);serial=0;
for j=1:size(a,1)
 t=a(j,1);p=a(j,2)+1;i=round(t/10)+1;if i<1||i>8640||abs(t-(i-1)*10)>1e-4,continue;end
 if isnan(previous(p))||t-previous(p)>10.1||bitand(uint8(a(j,3)),15),serial=serial+1;track(p)=serial;end
 previous(p)=t;obs.ids(i,p)=track(p);obs.phase(i,p)=rows.phase_IF_m(j);
end
end
