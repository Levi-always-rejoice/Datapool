function plot_ten_minute_full(out)
x=load(fullfile(out,'comparison.mat'));set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 850]);tiledlayout(2,1);limit=0;
for k=1:2,s=x.series{k};limit=max(limit,max(abs([s.gnss(s.mask);s.acc(s.mask)]))*1e12);end
limit=ceil(limit*10)/10;windows=[20 10];
for k=1:2
 s=x.series{k};bad=~s.mask|[false;diff(s.t)>1.1];v=s.gnss;v(bad)=NaN;r=s.acc;r(bad)=NaN;
 nexttile;plot((s.t-16)/3600,v*1e12);hold on;plot((s.t-16)/3600,r*1e12,'k');grid on;xlim([0 24]);ylim([-limit limit]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('%d-minute density window; all supported extrema shown',windows(k)));legend('GNSS','ACC');
end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(out,'density_10_vs_20_full.png'),'Resolution',150);close(fig);
end
