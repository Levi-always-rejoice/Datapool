function report=test_direct_sd_inputs(out)
z=load(fullfile(out,'sd_inputs.mat'),'q');q=z.q;o=direct_sd_observations(q);
% Change EVERY code value, plus all single-view phase values, while holding
% the separately supplied reference geometry and integer history fixed.
qa=q;keepA=false(size(q.qa.phase));keepB=false(size(q.qb.phase));keepA(q.ia,:)=q.good;keepB(q.ib,:)=q.good;
qa.qa.phase(~keepA)=1e9;qa.qb.phase(~keepB)=-1e9;qa.qa.code(:)=1e10;qa.qb.code(:)=-1e10;
v=direct_sd_observations(qa);assert(isequaln(o,v),'Unmatched/code data leaked into SD measurements');
% Exact mean/baseline transformation, including receiver clock difference.
rng(129);ha=randn(12,3);hb=randn(12,3);dm=randn(3,1);db=randn(3,1);clock=3.4;
sd=hb*(dm+db/2)-ha*(dm-db/2)+clock;pred=(hb-ha)*dm+(hb+ha)*db/2+clock;
transform=max(abs(sd-pred));assert(transform<1e-12);
% Relative gravity includes both Gmean*delta_baseline and Gdifference*delta_mean.
mu=3.986004418e14;ra=[6870e3;0;0];rb=[6868e3;180e3;20e3];dm=[.05;-.04;.03];db=[-.02;.01;.03];
gravity=@(r)-mu*r/norm(r)^3;exact=gravity(rb+dm+db/2)-gravity(ra+dm-db/2)-(gravity(rb)-gravity(ra));
linear=(gnss_gradient(rb)-gnss_gradient(ra))*dm+(gnss_gradient(rb)+gnss_gradient(ra))*db/2;
gravityError=norm(exact-linear);assert(gravityError<1e-12);
S=full(q.S);rowrank=rank(S);assert(rowrank==size(S,1),'Pair ambiguities require extra shared-label consistency constraints');
report=struct('unmatched_and_code_invariance',true,'mean_baseline_identity_error_m',transform,'relative_gravity_linearization_error_m_s2',gravityError,'pair_incidence_rank',rowrank,'pair_count',size(S,1));
f=fopen(fullfile(out,'measurement_checks.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
