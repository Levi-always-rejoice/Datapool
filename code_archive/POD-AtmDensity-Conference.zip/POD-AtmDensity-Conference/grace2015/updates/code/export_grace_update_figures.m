function report=export_grace_update_figures(source,dest)
% Export existing completed experiments as figures/examples, never inputs.
if ~isfolder(dest),mkdir(dest);end
c=load(fullfile(source,'assistance_factorial_run','common_view_comparison.mat'));
d=load(fullfile(source,'direct_sd_run','comparison.mat'));
writematrix([c.tt,c.g,c.acc,double(c.mask)],fullfile(dest,'common_view_density.csv'));
writematrix([d.tt,d.g(:,3),d.acc,double(d.support)],fullfile(dest,'direct_density.csv'));
[t,i,j]=intersect(c.t,d.t);writematrix([t,c.ranges(i,:),d.ranges(j,3)],fullfile(dest,'range_residuals.csv'));
report=plot_grace_update_comparison(dest);
assert(abs(report.common_view_independent.last4.RMS-3.58630153764771e-14)<1e-25);
assert(abs(report.common_view_POD_assisted.last4.RMS-3.372292382469041e-14)<1e-25);
assert(abs(report.common_view_independent.last4.r-.7360882198839214)<1e-10);
assert(abs(report.common_view_POD_assisted.last4.r-.7460515127975009)<1e-10);
end
