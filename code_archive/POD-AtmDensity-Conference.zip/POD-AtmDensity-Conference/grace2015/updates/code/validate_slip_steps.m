function [accepted,details]=validate_slip_steps(t,gf,mw,events)
% Conservative confirmation, not a calibrated false-fix probability.
% Require independent MW evidence and agreement of short/long GF step fits.
accepted=false(size(events,1),1);details=nan(size(events,1),5);
lw=299792458/(1575.42e6-1227.6e6);
for k=1:size(events,1)
 j=find(t==events(k,1),1)-1;
 if isempty(j)||j<12||j+12>numel(t),continue;end
 [sm,em]=step(t,mw,j,12,.15);
 [sg,eg]=step(t,gf,j,3,.002);
 expected=lw*(events(k,2)-events(k,3));
 details(k,:)=[sm,em,expected,sg,eg];
 accepted(k)=isfinite(sm)&&abs(sm)>3*em&&abs(sm-expected)<3*em ...
  &&abs(sg-events(k,4))<max(.03,3*hypot(eg,events(k,6)));
end
end
function [s,e]=step(t,y,j,h,floorSE)
 ix=(j-h+1:j+h)';s=NaN;e=NaN;
 if any(diff(t(ix))>10.1)||any(~isfinite(y(ix))),return;end
 u=(t(ix)-mean(t([j j+1])))/60;X=[ones(size(u)),u,u.^2,double(ix>j)];
 b=X\y(ix);r=y(ix)-X*b;Q=(X'*X)\eye(4);
 s=b(4);e=max(floorSE,sqrt(Q(4,4))*sqrt(sum(r.^2)/(numel(ix)-4)));
end
