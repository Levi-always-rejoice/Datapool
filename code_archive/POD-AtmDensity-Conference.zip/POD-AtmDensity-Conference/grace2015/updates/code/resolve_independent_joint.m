function result=resolve_independent_joint(out,inflation,suffix,options)
if nargin<2,inflation=4;end;if nargin<3,suffix='';end
if nargin<4,options=struct;end
if ~isfield(options,'searchLimit'),options.searchLimit=300000;end
if ~isfield(options,'candidateSuffix'),options.candidateSuffix=suffix;end
if ~isfield(options,'outputDir'),options.outputDir=out;end
if ~isfield(options,'candidateFile'),options.candidateFile=fullfile(out,['independent_graph' options.candidateSuffix '.mat']);end
if ~isfolder(options.outputDir),mkdir(options.outputDir);end
assert(isscalar(options.searchLimit)&&options.searchLimit>=1&&options.searchLimit==round(options.searchLimit));
% Adaptive partial joint ILS on the newly continuous GNSS-only float model.
% No hard-coded fixed count and no reference-assisted seed constraints.
z=load(options.candidateFile);c=z.result.c;ok=z.result.wideOK;
a=load(fullfile(out,'A_float_model.mat'),'model');b=load(fullfile(out,'B_float_model.mat'),'model');assert(~isfield(a.model.q,'pod_r')&&~isfield(b.model.q,'pod_r'));
B=[a.model.B0+a.model.db;b.model.B0+b.model.db];Q=blkdiag(a.model.Q,b.model.Q);nc=numel(a.model.B0);profiles={struct('B',B,'Q',Q,'count',inf(size(B)))};
for fold=0:1,x=load(fullfile(out,sprintf('A_fold%d.mat',fold)));y=load(fullfile(out,sprintf('B_fold%d.mat',fold)));profiles{end+1}=struct('B',[x.z.B;y.z.B],'Q',blkdiag(x.z.Q,y.z.Q),'count',[x.z.count;y.z.count]);end
A=c.A(ok,:);wide=c.WL(ok);[~,R,piv]=qr(A','vector');rk=sum(abs(diag(R))>1e-9);A=A(piv(1:rk),:);wide=wide(piv(1:rk));ln=299792458/(1575.42e6+1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);
C=inflation*(A*Q*A')/ln^2;C=(C+C')/2;[~,D,Z]=gnss_integer_reduce(C);H=Z'*A;offset=cf*(Z'*wide);first=1;while first<rk&&prod(erf(.5./sqrt(2*D(first:end))))<.999,first=first+1;end
supported=false(rk,1);supported(first:end)=true;models=cell(3,1);
for j=1:3,z=profiles{j};models{j}=struct('a',(H*z.B-offset)/ln,'C',inflation*(H*z.Q*H')/ln^2);supported=supported&~any(abs(H(:,z.count<6))>1e-10,2);end
keep=find(supported);history=[];best=[];
while ~isempty(keep)
 m=numel(keep);bad=false(m,1);score=zeros(m,1);base=[];why=0;
 for j=1:3
  CC=models{j}.C(keep,keep);CC=(CC+CC')/2;aa=models{j}.a(keep);[ints,cost,done,nodes]=gnss_joint_integer(aa,CC,options.searchLimit);
  if ~done||numel(cost)<2,[~,drop]=max(diag(CC));bad(drop)=true;why=1;break;end
  if j==1,base=ints(:,1);end
  mismatch=ints(:,1)~=base;bad=bad|mismatch;if any(mismatch),why=2;end
  invC=CC\eye(m);delta=base-aa;conditional=(invC*delta).^2./diag(invC);score=max(score,conditional);
  if max(conditional)>9||cost(1)>m+3*sqrt(2*m),[~,drop]=max(conditional);bad(drop)=true;why=3;end
  if cost(2)-cost(1)<2*log(1000),choices=find(ints(:,2)~=ints(:,1));[~,jj]=max(diag(CC(choices,choices)));bad(choices(jj))=true;why=4;end
 end
 if ~any(bad),best=base;break;end
 choices=find(bad);[~,j]=max(score(choices)+1e-12*diag(models{1}.C(keep(choices),keep(choices))));drop=choices(j);history=[history;m keep(drop) why nodes];keep(drop)=[]; %#ok<AGROW>
 if mod(size(history,1),10)==1,fprintf('Independent joint validation: %d directions, reason %d\n',m,why);end
end
HH=H(keep,:);target=offset(keep)+ln*best;fixed=B;error=0;if ~isempty(HH),HQ=HH*Q;fixed=B+HQ'*((HQ*HH')\(target-HH*B));error=max(abs(HH*fixed-target));assert(error<5e-7);end
result=struct('H',HH,'target',target,'fixedB',fixed,'integer_vector',best,'selected',keep,'fixed_rank',numel(keep),'initial_supported',nnz(supported),'constraint_error_m',error,'history',history);
result.covariance_multiplier=inflation;result.search_limit=options.searchLimit;result.candidate_suffix=options.candidateSuffix;save(fullfile(options.outputDir,['independent_joint' suffix '.mat']),'result','-v7.3');
if isfield(a.model,'kind')&&strcmp(a.model.kind,'kinematic')
 Qc=Q;if ~isempty(HH),Qc=Q-HQ'*((HQ*HH')\HQ);end
 L=gnss_condition_kinematic(a.model,[],[],fixed(1:nc),Qc(1:nc,1:nc));save(fullfile(options.outputDir,['A_L' suffix '.mat']),'L','-v7.3');
 L=gnss_condition_kinematic(b.model,[],[],fixed(nc+1:end),Qc(nc+1:end,nc+1:end));save(fullfile(options.outputDir,['B_L' suffix '.mat']),'L','-v7.3');
else
 L=gnss_condition_navigation(a.model,[],[],fixed(1:nc));save(fullfile(options.outputDir,['A_L' suffix '.mat']),'L','-v7.3');L=gnss_condition_navigation(b.model,[],[],fixed(nc+1:end));save(fullfile(options.outputDir,['B_L' suffix '.mat']),'L','-v7.3');
end
f=fopen(fullfile(options.outputDir,['independent_joint' suffix '.json']),'w');fprintf(f,'%s',jsonencode(rmfield(result,{'H','target','fixedB','integer_vector','history','selected'}),PrettyPrint=true));fclose(f);disp(result.fixed_rank);
end
