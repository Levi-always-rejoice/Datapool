function report=evaluate_grace_updated(root)
% References enter here, after navigation is saved. Evaluate the updated
% independent/common-view assisted paths with the same density operator.
dest=fullfile(root,'updated_comparison');if ~isfolder(dest),mkdir(dest);end
folders={fullfile(root,'assistance_factorial_run','common_view_independent'),...
 fullfile(root,'assistance_factorial_run','common_view_addedPOD'),fullfile(root,'direct_sd_run','direct')};
names={'common_independent','common_assisted','direct_independent'};navs=cell(2,1);refs=navs;dens=navs;
report=struct;
for s=1:2
 sat=char(64+s);refs{s}=load(fullfile(root,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d','bias');
 for k=1:3,z=load(fullfile(folders{k},[sat '_L.mat']),'L');navs{s}.(names{k})=z.L;end
 % Ensure all compared force fits use identical navigation epoch support.
 tt=navs{s}.direct_independent.values(:,1);
 for k=1:3,z=navs{s}.(names{k});[yes,i]=ismember(tt,z.values(:,1));assert(all(yes));z.values=z.values(i,:);navs{s}.(names{k})=z;end
 fprintf('Updated comparison density %s\n',sat);dn=gnss_density_sparse_window(refs{s}.d,navs{s},1200);
 for k=1:3
  z=dn.(names{k});v=z.values;v(:,4)=v(:,4)-refs{s}.bias/1e-6*v(:,6);dens{s}.(names{k})=v;
  report.checks.(sat).(names{k})=rmfield(z,'values');writematrix(v,fullfile(dest,[sat '_' names{k} '_density.csv']));
 end
end
[t,ia,ib]=intersect(dens{1}.direct_independent(:,1),dens{2}.direct_independent(:,1));g=nan(numel(t),3);
for k=1:3,a=dens{1}.(names{k});b=dens{2}.(names{k});g(:,k)=b(ib,2)-a(ia,2);end
acc=dens{2}.direct_independent(ib,4)-dens{1}.direct_independent(ia,4);
su=readmatrix(fullfile(root,'direct_sd_run','gnss_support.csv'));[yes,i]=ismember(t,su(:,1));assert(all(yes));support=logical(su(i,2));
writematrix([t,g(:,1:2),acc,support],fullfile(dest,'common_view_density.csv'));
writematrix([t,g(:,3),acc,support],fullfile(dest,'direct_density.csv'));
% Preserve the original raw-baseline KBR datum, identically for all branches.
base=grace_update_baseline(root);z=load(fullfile(base,'range_comparison.mat'),'range');
inputs=grace_update_input_root(root);r=read_grace_ascii(fullfile(inputs,'raw','KBR1B_2015-03-15_X_02.asc'),1:16);r=r.values;r=r(r(:,16)==0,:);kt=r(:,1);kr=r(:,2)+r(:,6)+r(:,9);
P=gnss_hermite(refs{1}.d.pod_t,refs{1}.d.pod_r,refs{1}.d.pod_v);Q=gnss_hermite(refs{2}.d.pod_t,refs{2}.d.pod_r,refs{2}.d.pod_v);
pr=vecnorm(ppval(Q,kt')'-ppval(P,kt')',2,2);segments=cumsum([0;diff(kt)>5.1|abs(diff(kr))>100]);
[yes,i]=ismember(kt,z.range.t);datum=nan(size(kt));
for sg=unique(segments)',use=segments==sg&yes;if any(use),datum(segments==sg)=mean(pr(use)-z.range.POD(i(use))-kr(use),'omitnan');end;end
rr=nan(numel(kt),3);
for k=1:3
 a=navs{1}.(names{k}).values;b=navs{2}.(names{k}).values;[ya,ia]=ismember(kt,a(:,1));[yb,ib]=ismember(kt,b(:,1));m=ya&yb&isfinite(datum);
 rr(m,k)=vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-kr(m)-datum(m);
end
writematrix([kt,rr],fullfile(dest,'range_residuals.csv'));m=all(isfinite(rr),2);report.range_RMS_mm=sqrt(mean(rr(m,:).^2))*1000;
report.density=plot_grace_update_comparison(dest);report.reference_note='KBR datum inherited from baseline official-POD evaluation, identical for all navigation branches. ACC comparison retains baseline constant body-X bias. Neither reference enters independent estimation.';
f=fopen(fullfile(dest,'comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
end
