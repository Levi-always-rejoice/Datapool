function plot_assisted_benchmark_reconciliation(out)
z=load(fullfile(out,'comparison.mat'));t=z.t;g=z.g;acc=z.acc;mask=z.mask;tr=z.tr;ranges=z.ranges;
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1450 1060]);tiledlayout(3,1);
v=ranges*1000;v([false;diff(tr)>1.5*median(diff(tr))],:)=NaN;
nexttile;plot((tr-16)/3600,v);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title('Distinct benchmarks: original POD-screened solution versus integer-only POD control');legend('Original POD-screened 354','POD integers only 358','Current independent 297');
v=[g,acc(:,1)]*1e12;v(~mask|[false;diff(t)>1.1],:)=NaN;
nexttile;plot((t-16)/3600,v(:,1:3));hold on;plot((t-16)/3600,v(:,4),'k','LineWidth',1.1);grid on;xlim([0 24]);ylim([-1 1]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title('20-minute density, same evaluation centers and vertical scale');legend('Original POD-screened 354','POD integers only 358','Current independent 297','ACC');
[~,i,j]=intersect(t,z.reprocessed(:,1));v=[g(i,1),z.reprocessed(j,2),acc(i,1)]*1e12;v(~mask(i)|[false;diff(t(i))>1.1],:)=NaN;
nexttile;plot((t(i)-16)/3600,v(:,1:2));hold on;plot((t(i)-16)/3600,v(:,3),'k','LineWidth',1.1);grid on;xlim([0 24]);ylim([-.2 .3]);ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, GRACE A/B, 2015-03-15');title('Original saved orbit: old versus current density processing');legend('Original figure result','Same orbit, current density processing','ACC');
exportgraphics(fig,fullfile(out,'assisted_benchmark_reconciliation.png'),'Resolution',150);close(fig);
end
