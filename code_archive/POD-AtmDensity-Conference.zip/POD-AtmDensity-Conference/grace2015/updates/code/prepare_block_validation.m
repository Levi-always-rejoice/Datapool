function prepare_block_validation(baseline,out)
% Block sizes fixed before inspecting KBR/ACC results. No reference data used.
mkdir(out);diary(fullfile(out,'block_validation.log'));cleanup=onCleanup(@()diary('off'));
for sat='AB'
 x=load(fullfile(baseline,[sat '_float_model.mat']),'model');base=x.model;clear x;
 % Verify reprofile against the existing full-data normal equations.
 z=gnss_reprofile(base,true(size(base.q.t)));B=base.B0+base.db;
 delta=z.B-B;delta=delta-median(delta);assert(max(abs(delta))<1e-5,'Reprofile changed full-data offsets');
 assert(norm(z.Q-base.Q,'fro')/norm(base.Q,'fro')<1e-5,'Reprofile changed covariance');
 for seconds=[120 300]
  for fold=0:1
   mask=mod(floor(base.q.t/seconds),2)==fold;
   fprintf('%s: %d-second blocks, fold %d\n',sat,seconds,fold);z=gnss_reprofile(base,mask);
   save(fullfile(out,sprintf('%s_block%d_fold%d.mat',sat,seconds,fold)),'z');
  end
 end
end
fprintf('Blocked validation profiles complete\n');
end
