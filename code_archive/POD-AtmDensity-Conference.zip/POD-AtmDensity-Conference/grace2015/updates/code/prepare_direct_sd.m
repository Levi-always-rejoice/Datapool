function report=prepare_direct_sd(root,out)
% Compact inputs for a genuinely single-differenced carrier orbit fit.
% No POD/KBR/ACC data or reference mask is loaded. Absolute GNSS navigation
% supplies ONLY a prescribed mean orbit, not a baseline or ambiguity prior.
if ~isfolder(out),mkdir(out);end
source=fullfile(root,'code_history20_run');bases=cell(2,1);nav=cell(2,1);alt=cell(2,1);
for s=1:2
 sat=char(64+s);z=load(fullfile(source,[sat '_float_model.mat']),'model');bases{s}=z.model;
 z=load(fullfile(source,[sat '_L_history2.mat']),'L');nav{s}=z.L.values;
 z=load(fullfile(root,'assistance_factorial_run','common_view_independent',[sat '_L.mat']),'L');alt{s}=z.L.values;
 assert(~any(startsWith(fieldnames(bases{s}.q),'pod_')));
end
qa=bases{1}.q;qb=bases{2}.q;[t,ia,ib]=intersect(qa.t,qb.t);good=qa.good(ia,:)&qb.good(ib,:);
[e,p]=find(good);pairs=[double(qa.labels(sub2ind(size(qa.labels),ia(e),p))),double(qb.labels(sub2ind(size(qb.labels),ib(e),p)))];
[nodes,~,ni]=unique(pairs,'rows');node=zeros(size(good));node(good)=ni;S=sparse([(1:size(nodes,1))';(1:size(nodes,1))'],[nodes(:,1);numel(qa.B0)+nodes(:,2)],[-ones(size(nodes,1),1);ones(size(nodes,1),1)],size(nodes,1),numel(qa.B0)+numel(qb.B0));
z=load(fullfile(source,'independent_joint_history2.mat'),'result');seed=z.result;H=(full(S)'\seed.H')';
assert(max(abs(H*S-seed.H),[],'all')<1e-8,'Seed not representable by common-view ambiguities');
sd=qb.phase(ib,:)-qa.phase(ia,:);B0=accumarray(ni,sd(good),[size(nodes,1),1],@median);
[tm,ma,mb]=intersect(nav{1}(:,1),nav{2}(:,1));mean0=[tm,(nav{1}(ma,2:7)+nav{2}(mb,2:7))/2];
assert(isequal(nav{1}(:,1),alt{1}(:,1))&&isequal(nav{2}(:,1),alt{2}(:,1)));mean1=[tm,(alt{1}(ma,2:7)+alt{2}(mb,2:7))/2];
intervals=cell(2,1);
for s=1:2,bs=bases{s}.blocks;intervals{s}=cell2mat(cellfun(@(b)[b.a b.b],bs,'UniformOutput',false)');end
edges=unique([intervals{1}(:);intervals{2}(:)]);blocks=[];
for j=1:numel(edges)-1
 a=edges(j);b=edges(j+1);mid=(a+b)/2;
 if b-a>=120&&any(intervals{1}(:,1)<=mid&intervals{1}(:,2)>=mid)&&any(intervals{2}(:,1)<=mid&intervals{2}(:,2)>=mid),blocks=[blocks;a b];end %#ok<AGROW>
end
q=struct('t',t,'ia',ia,'ib',ib,'good',good,'node',node,'nodes',nodes,'S',S,'B0',B0,'H',H,'target',seed.target,'seed',seed,'qa',qa,'qb',qb,'mean0',mean0,'mean1',mean1,'blocks',blocks);
report=struct('common_phase_observations',nnz(good),'native_epochs',numel(t),'pair_offsets',size(nodes,1),'inherited_integer_rank',size(H,1),'orbit_blocks',size(blocks,1), ...
 'mean_reference_difference_RMS_m',rms(vecnorm(mean1(:,2:4)-mean0(:,2:4),2,2)), ...
 'note','Only SD carrier enters the relative fit. No code, undifferenced carrier, saved baseline, saved float ambiguity, POD, KBR, or ACC is used as a relative measurement/prior. Two existing GNSS-only mean orbits provide reference geometry and a reference-sensitivity check. The 297 independently validated DD constraints are inherited, not newly fixed.');
save(fullfile(out,'sd_inputs.mat'),'q','report','-v7.3');writejson(fullfile(out,'input_method.json'),report);disp(report);
end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
