function model=gnss_navigation_code_supported(q,blockSeconds,subtractRadiation,split)
if nargin<2,blockSeconds=1200;end
if nargin<3,subtractRadiation=false;end
if nargin<4,split=-1;end
% Code/carrier normal equations; configurable dynamic blocks and epoch split.
% Orbit, epoch clock, and float track offsets are all estimated.
mu=3.986004418e14;f1=1575.42e6;f2=1227.60e6;
alpha=f1^2/(f1^2-f2^2);beta=-f2^2/(f1^2-f2^2);
t=q.t(:);B0=q.B0(:);nb=numel(B0);lab=double(q.labels);
good=q.good & lab>0 & reshape(q.used(max(lab(:),1)),size(lab));
if split>=0,good=good & mod(round(t/10),2)==split;end
phase=q.phase-reshape(B0(max(lab(:),1)),size(lab));
known=q.known;if subtractRadiation,known=known-q.rad;end
R=gnss_hermite(t,q.r,q.v);pert=spline(t,(known+mu*q.r./vecnorm(q.r,2,2).^3)');
lo=max(18,ceil(t(1)));hi=min(86399,floor(t(end)));gi=find(diff(t)>30);
if isfield(q,'bridge_intervals')
 retain=true(size(gi));for j=1:numel(gi),g=gi(j);approved=q.bridge_intervals;retain(j)=~any(t(g)+1>=approved(:,1)&t(g+1)<=approved(:,2)+1);end;gi=gi(retain);
end
gaps=[t(gi)+1,t(gi+1)];ge=gaps(:);knots=(618:blockSeconds:hi-1)';
if ~isempty(ge),knots=knots(min(abs(knots-ge'),[],2)>300);end
edges=unique([lo;knots;ge;hi]);blocks={};Nbb=zeros(nb);bb=zeros(nb,1);
opts=odeset('RelTol',2e-13,'AbsTol',1e-11,'MaxStep',20);
for j=1:numel(edges)-1
 a=edges(j);b=edges(j+1);pivot=(a+b)/2;
 if any(gaps(:,1)<=pivot & pivot<=gaps(:,2)) || b-a<120,continue;end
 Y=zeros(6,13);Y(1:3,1)=ppval(R,pivot);
 % Derivative of the Hermite polynomial at midpoint.
 [~,piece]=histc(pivot,R.breaks);piece=min(max(piece,1),R.pieces);
 c=R.coefs((piece-1)*3+(1:3),:);u=pivot-R.breaks(piece);
 Y(4:6,1)=3*c(:,1)*u^2+2*c(:,2)*u+c(:,3);
 Y(1:3,2:4)=eye(3);Y(4:6,5:7)=eye(3)/600;
 block=struct('a',a,'b',b,'pivot',pivot,'ncol',13);
 block.left=ode113(@rhs,[pivot a],Y(:),opts);block.right=ode113(@rhs,[pivot b],Y(:),opts);
 if b<hi,ids=find(t>=a & t<b);else,ids=find(t>=a & t<=b);end
 st=gnss_states(block,t(ids));N=zeros(12);r=zeros(12,1);cross=zeros(12,nb);
 mh=zeros(numel(ids),12);my=zeros(numel(ids),1);wpall=zeros(numel(ids),33);denall=zeros(numel(ids),1);
 for k=1:numel(ids)
  e=ids(k);h=squeeze(q.h(e,:,:));H=h*st(1:3,2:13,k);off=h*(st(1:3,1,k)-q.r(e,:)');
  ph=phase(e,:)'-off;code=q.code(e,:)'-off;ph(~isfinite(ph))=0;code(~isfinite(code))=0;
  elev=q.elev(e,:)';elev(~isfinite(elev))=0;sn=max(sin(elev),.25);gg=good(e,:)';
  wp=double(gg)./(.005*hypot(alpha,beta)./sn).^2;
  if isfield(q,'phase_weight'),wp=wp.*q.phase_weight(e,:)';end
  cg=gg;if isfield(q,'code_good'),cg=q.code_good(e,:)';end
  cg=cg & isfinite(q.code(e,:)') & abs(q.code(e,:)')<30;
  rawcode=q.code(e,:)';rawcode(~isfinite(rawcode))=0;
  wc=double(cg)./(4.5./sn).^2./max(1,abs(rawcode)/3);W=wp+wc;den=max(sum(W),1e-30);
  hm=(W'*H)/den;ym=sum(wp.*ph+wc.*code)/den;HH=H-hm;
  N=N+HH'*(W.*HH);r=r+HH'*(wp.*(ph-ym)+wc.*(code-ym));
  ps=find(gg);labs=lab(e,ps)';wt=wp(ps);E=accumarray(labs,wt,[nb 1]);
  Nbb=Nbb+diag(E)-(E*E')/den;
  bb=bb+accumarray(labs,wt.*ph(ps),[nb 1])-E*ym;
  cross(:,labs)=cross(:,labs)+(wt.*HH(ps,:))';
  mh(k,:)=hm;my(k)=ym;wpall(k,:)=wp';denall(k)=den;
 end
 block.N=N;block.rhs=r;block.cross=cross;block.ids=ids;
 block.mh=mh;block.my=my;block.wp=wpall;block.den=denall;
 blocks{end+1}=block; %#ok<AGROW>
 if mod(numel(blocks),25)==0,fprintf('  orbit blocks %d\n',numel(blocks));end
end
nblocks=numel(blocks);N=zeros(12*nblocks);r=zeros(12*nblocks,1);Nx=zeros(12*nblocks,nb);C=[];d=[];
for j=1:nblocks
 ix=(j-1)*12+(1:12);x=blocks{j};N(ix,ix)=x.N;r(ix)=x.rhs;Nx(ix,:)=x.cross;
 if j<nblocks && abs(x.b-blocks{j+1}.a)<1e-7
  s=gnss_states(x,x.b);v=gnss_states(blocks{j+1},x.b);A=zeros(6,12*nblocks);
  A(:,ix)=s(:,2:13);A(:,ix+12)=-v(:,2:13);C=[C;A];d=[d;v(:,1)-s(:,1)]; %#ok<AGROW>
 end
end
sc=sqrt(max(diag(N),1e-20));Ns=N./sc./sc';Cs=C./sc';row=vecnorm(Cs,2,2);Cs=Cs./row;ds=d./row;
xp=lsqminnorm(Cs,ds);Z=null(Cs);red=Z'*Ns*Z;xp=xp./sc;T=Z./sc;
bz=T'*(r-N*xp);Nzb=T'*Nx;schur=Nbb-Nzb'*(red\Nzb);brhs=bb-Nx'*xp-Nzb'*(red\bz);
used=diag(schur)>1e-10;ss=sqrt(diag(schur));ss=ss(used);S=schur(used,used)./ss./ss';
[U,D]=eig((S+S')/2,'vector');keep=D>max(max(D)*1e-12,1e-14);Q=zeros(nb);
Q(used,used)=((U(:,keep)./D(keep)')*U(:,keep)')./ss./ss';
model=struct('blocks',{blocks},'B0',B0,'Q',Q,'db',Q*brhs,'xp',xp,'T',T,'red',red,'bz',bz,'Nzb',Nzb,'C',C,'d',d,'q',q);
 function z=rhs(time,z)
  x=reshape(z,6,13);v=zeros(6,13);r0=ppval(R,time);G=gnss_gradient(r0);
  known=ppval(pert,time)-mu*r0/norm(r0)^3;v(1:3,:)=x(4:6,:);v(4:6,:)=G*x(1:3,:);
  v(4:6,1)=v(4:6,1)+known-G*r0;v(4:6,8:10)=v(4:6,8:10)+eye(3)*1e-7;
  v(4:6,11:13)=v(4:6,11:13)+eye(3)*(time-pivot)/600*1e-7;z=v(:);
 end
end
