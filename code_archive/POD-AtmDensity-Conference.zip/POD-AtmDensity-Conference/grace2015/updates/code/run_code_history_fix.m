function run_code_history_fix(package,root,out)
% Preserve the independent 287-combination history, screen/expand MW using
% only GNSS, then perform conditional search in the new code likelihood.
seedFolder=fullfile(root,'coverage_expansion_run');seed=fullfile(seedFolder,'independent_joint_round4.mat');
prepare_robust_wide_lanes(out,out,true,fullfile(seedFolder,'robust_wide_lanes.mat'));
for iteration=1:4
 tag=sprintf('_history%d',iteration);r=resolve_incremental_joint(out,out,fullfile(out,'robust_wide_lanes.mat'),seed,tag);seed=fullfile(out,['independent_joint' tag '.mat']);
 if r.added_rank==0,break;end
end
options=struct('plotTitle','Screened long-interval code anchors; full-day phase; same 20-minute dynamics', 'note','Code treatment changes: GNSS-only outlier exclusion, robust long-interval code-minus-carrier anchors counted once, and exact decorrelated carrier channel with negligible instantaneous code fraction. Previous 287 independent integers retained, with conditional expansion. Native phase observations, 20-minute dynamics, independent force reference, density operator and KBR datum unchanged. No POD/KBR/ACC values in screening, code anchors, or fixing. References read only afterward. ACC keeps prior POD-calibrated constant comparison bias. Full-day batch, not causal fixed-lag processing.');
f=fopen(fullfile(out,'selected_tag.txt'),'w');fprintf(f,'%s',tag);fclose(f);
evaluate_integer_expansion(package,root,out,tag,true,options);
end
