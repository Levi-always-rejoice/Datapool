function plot_direct_sd(out)
z=load(fullfile(out,'comparison.mat'));set(groot,'defaultFigureVisible','off');colors=[.6 .6 .6;0 .45 .74;.85 .33 .10];labels={'Previous coupled common view','Direct SD carrier','Direct SD, alternate GNSS mean'};sel=[2 3 4];
fig=figure('Position',[20 20 1550 1180]);tiledlayout(3,1,'TileSpacing','compact');
nexttile;hold on;v=z.ranges(:,sel)*1000;v([false;diff(z.t)>1.5*median(diff(z.t))],:)=NaN;
for j=1:3,plot((z.t-16)/3600,v(:,j),'Color',colors(j,:));end
grid on;xlim([0 24]);ylabel('Range - KBR (mm)');legend(labels,'Location','northoutside','Orientation','horizontal');title('Common-view carrier differences estimate baseline and clock difference directly');
nexttile;hold on;v=z.g(:,sel)*1e12;v(~z.support,:)=NaN;
for j=1:3,plot((z.tt-16)/3600,v(:,j),'Color',colors(j,:));end
a=z.acc*1e12;a(~z.support)=NaN;plot((z.tt-16)/3600,a,'k','LineWidth',1.1);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title('20-minute density: GNSS-only coverage and geometry flags');legend([labels,{'ACC'}],'Location','northoutside','Orientation','horizontal');
nexttile;hold on;v=z.g(:,sel)*1e12;
for j=1:3,plot((z.tt-16)/3600,v(:,j),'Color',colors(j,:));end
plot((z.tt-16)/3600,z.acc*1e12,'k','LineWidth',1.2);grid on;xlim([20 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, GRACE A/B, 2015-03-15');title('Last four hours: all available fitted centers');
exportgraphics(fig,fullfile(out,'direct_sd_comparison.png'),'Resolution',150);close(fig);
fig=figure('Position',[30 30 1550 650]);hold on;
for j=1:3,plot((z.tt-16)/3600,z.g(:,sel(j))*1e12,'Color',colors(j,:));end
plot((z.tt-16)/3600,z.acc*1e12,'k');grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, 2015-03-15');title('All outputs, including intervals failing the independent support flags');legend([labels,{'ACC'}],'Location','northoutside','Orientation','horizontal');exportgraphics(fig,fullfile(out,'direct_sd_all_outputs.png'),'Resolution',150);close(fig);
end
