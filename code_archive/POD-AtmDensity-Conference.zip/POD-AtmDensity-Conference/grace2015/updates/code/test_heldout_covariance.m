function report=test_heldout_covariance
% Compare the profiled orbit/clock/ambiguity prediction variance against a
% direct constrained full least-squares inverse, including interreceiver
% covariance from exact DD history. Test data do not enter the training fit.
rng(917);nc=3;nb=5;ne=7;nf=nc+nb+ne;Ncell=cell(2,1);rhs=cell(2,1);parts=cell(2,1);
for s=1:2
 X=[];y=[];w=[];hh=cell(ne,1);ww=cell(ne,1);lab=cell(ne,1);
 for e=1:ne
  gps=setdiff(1:nb,mod(e+s,nb)+1);h=randn(numel(gps),nc);wt=.5+rand(numel(gps),1);x=zeros(numel(gps),nf);x(:,1:nc)=h;
  x(sub2ind(size(x),(1:numel(gps))',nc+gps'))=1;x(:,nc+nb+e)=1;
  X=[X;x];y=[y;randn(numel(gps),1)];w=[w;wt];hh{e}=h;ww{e}=wt;lab{e}=gps; %#ok<AGROW>
 end
 prior=diag([ones(1,nc),.3*ones(1,nb),zeros(1,ne)]);N=X'*(w.*X)+prior;r=X'*(w.*y);
 C=N(1:nc+nb,nc+nb+(1:ne));V=N(nc+nb+(1:ne),nc+nb+(1:ne));S=N(1:nc+nb,1:nc+nb)-C*(V\C');rr=r(1:nc+nb)-C*(V\r(nc+nb+(1:ne)));
 R=S(1:nc,1:nc);NX=S(1:nc,nc+(1:nb));Q=inv(S(nc+(1:nb),nc+(1:nb))-NX'*(R\NX));db=Q*(rr(nc+(1:nb))-NX'*(R\rr(1:nc)));
 parts{s}=struct('B0',zeros(nb,1),'Q',Q,'db',db,'R',R,'NX',NX,'bz',rr(1:nc),'hh',{hh},'ww',{ww},'lab',{lab},'V',V,'C',C,'rclock',r(nc+nb+(1:ne)));
 Ncell{s}=N;rhs{s}=r;
end
seed=struct('H',[-1 1 0 0 0 1 -1 0 0 0;0 0 -1 1 0 0 0 1 -1 0], 'target',[.4;-.2]);
[B,Q]=gnss_fixed_profile(parts{1},parts{2},seed);
N=blkdiag(Ncell{:});r=vertcat(rhs{:});P=inv(N);fullH=zeros(2,2*nf);fullH(:,nc+(1:nb))=seed.H(:,1:nb);fullH(:,nf+nc+(1:nb))=seed.H(:,nb+(1:nb));
K=P*fullH'/(fullH*P*fullH');x=P*r+K*(seed.target-fullH*(P*r));P=P-K*fullH*P;
maxMean=0;maxVariance=0;
for e=1:ne
 pred=zeros(2,1);v=zeros(2,1);g=zeros(2,2*nb);f=zeros(2,2*nf);
 for s=1:2
  p=parts{s};h=randn(1,nc);gps=mod(e+s,nb)+1;wt=p.ww{e};hm=wt'*p.hh{e}/sum(wt);wm=zeros(1,nb);wm(p.lab{e})=wt/sum(wt);
  bs=B((s-1)*nb+(1:nb));c=p.R\(p.bz-p.NX*bs);clock=p.rclock(e)/p.V(e,e)-hm*c-wm*bs;
  pred(s)=h*c+bs(gps)+clock;a=h-hm;d=-a*(p.R\p.NX)-wm;d(gps)=d(gps)+1;
  g(s,(s-1)*nb+(1:nb))=d;v(s)=a*(p.R\a')+1/sum(wt);
  f(s,(s-1)*nf+(1:nc))=h;f(s,(s-1)*nf+nc+gps)=1;f(s,(s-1)*nf+nc+nb+e)=1;
 end
 maxMean=max(maxMean,max(abs(pred-f*x)));pv=diag(v)+g*Q*g';maxVariance=max(maxVariance,max(abs(pv-f*P*f'),[],'all'));
 dg=g(2,:)-g(1,:);ff=f(2,:)-f(1,:);maxVariance=max(maxVariance,abs(sum(v)+dg*Q*dg'-ff*P*ff'));
end
assert(maxMean<1e-10&&maxVariance<1e-10);report=struct('max_mean_error',maxMean,'max_variance_error',maxVariance);disp(report);
end
