function report=evaluate_heldout_phase(package,root,out)
% External benchmarks are first opened only after both GNSS refits exist.
assert(isfile(fullfile(out,'navigation_method.json')),'Complete and freeze GNSS estimation first');
variants={'DD_only','combined'};navs=cell(2,1);scores=cell(2,1);
for v=1:2
 folder=fullfile(out,variants{v});scores{v}=evaluate_integer_expansion(package,root,folder,'_qc',false);
 for s=1:2,z=load(fullfile(folder,[char(64+s) '_L_qc.mat']),'L');navs{s}.(variants{v})=z.L;end
end
dens=cell(2,1);checks=struct;
for s=1:2
 sat=char(64+s);ref=load(fullfile(root,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d','bias');
 fprintf('20-minute density comparison, receiver %s\n',sat);r=gnss_density_sparse_window(ref.d,navs{s},1200);
 for v=1:2
  z=r.(variants{v});vv=z.values;vv(:,4)=vv(:,4)-ref.bias/1e-6*vv(:,6);dens{s}.(variants{v})=vv;checks.(sat).(variants{v})=rmfield(z,'values');
  writematrix(vv,fullfile(out,variants{v},[sat '_qc_density.csv']));
 end
end
base=load(fullfile(root,'code_history20_run','comparison_history2.mat'));
assisted=load(fullfile(root,'assisted_benchmark_reconciliation','comparison.mat'));
[tt,ia,ib]=intersect(dens{1}.DD_only(:,1),dens{2}.DD_only(:,1));[tt,k,in]=intersect(tt,base.tt);ia=ia(k);ib=ib(k);
g=[base.g(in),nan(numel(tt),3)];acc=base.acc(in);
for v=1:2,a=dens{1}.(variants{v});b=dens{2}.(variants{v});g(:,v+1)=b(ib,2)-a(ia,2);writematrix([tt,g(:,v+1),acc],fullfile(out,variants{v},'_qc_differential_density.csv'));end
[~,i,j]=intersect(tt,assisted.reprocessed(:,1));g(i,4)=assisted.reprocessed(j,2);
mask=false(size(tt));[~,i,j]=intersect(tt,assisted.t);mask(i)=assisted.mask(j);mask=mask&all(isfinite(g),2)&isfinite(acc);
t=base.t;ranges=[base.rv(:,2),nan(numel(t),3)];
for v=1:2,z=load(fullfile(out,variants{v},'comparison_qc.mat'),'t','rv');assert(isequal(t,z.t));ranges(:,v+1)=z.rv(:,2);end
[~,i,j]=intersect(t,assisted.tr);ranges(i,4)=assisted.ranges(j,1);rm=all(isfinite(ranges),2);
names={'independent297','DD_only','combined','original_POD_screened354'};
report=struct('columns',{names},'density_common_centers',nnz(mask),'range_common_epochs',nnz(rm),'range_RMS_mm',rms(ranges(rm,:))*1000,'density_checks',checks);
for v=1:4
 report.(names{v})=score(g(mask,v),acc(mask));report.(names{v}).all_centers=score(g(:,v),acc);report.(names{v}).last4=score(g(tt>=72016,v),acc(tt>=72016));
 report.(names{v}).hours13to15=score(g(tt>=46816&tt<=54016,v),acc(tt>=46816&tt<=54016));
end
report.integer_and_orbit_audits=struct('DD_only',scores{1},'combined',scores{2});
report.note='Both independent variants use exactly the same 297 validated relative integer constraints and identical raw phase labels, code treatment, JAXA transmitter products, GNSS force geometry and 20-minute orbit/density basis. Only frozen GNSS-only carrier weights change (and their consistent code/carrier noise factorization). No new fixes, phase corrections or ambiguity resets. The original assisted 354 result uses POD screening and different fixed-track selection and is a separate reference. Native 10-second GPS1B; 1-second fitted output. Full-day batch with past/future phase, not causal onboard processing. The ACC comparison retains its pre-existing POD-calibrated constant bias.';
writejson(fullfile(out,'comparison.json'),report);save(fullfile(out,'comparison.mat'),'tt','g','acc','mask','t','ranges','rm','report');
plot_heldout_phase(out);disp(report);
end
function s=score(g,a),m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
