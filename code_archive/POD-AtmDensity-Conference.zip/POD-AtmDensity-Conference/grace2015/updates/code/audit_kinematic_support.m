function report=audit_kinematic_support(out)
% GNSS-only propagated relative-range uncertainty; KBR scores are subsequent.
a=load(fullfile(out,'A_float_model.mat'),'model');b=load(fullfile(out,'B_float_model.mat'),'model');aa=load(fullfile(out,'A_K.mat'),'K');bb=load(fullfile(out,'B_K.mat'),'K');s=load(fullfile(out,'inherited_constraints.mat'),'Qc');
[t,ia,ib]=intersect(aa.K.values(:,1),bb.K.values(:,1));nc=numel(a.model.B0);sigma=zeros(size(t));changed=false(size(t));sets=zeros(numel(t),66);cross=s.Qc(1:nc,nc+1:end);
for k=1:numel(t)
 ea=a.model.epochs{aa.K.epoch_index(ia(k))};eb=b.model.epochs{bb.K.epoch_index(ib(k))};r=bb.K.values(ib(k),2:4)-aa.K.values(ia(k),2:4);u=r'/norm(r);
 Pab=ea.D(1:3,:)*cross(ea.labels,eb.labels)*eb.D(1:3,:)';P=aa.K.state_covariance(1:3,1:3,ia(k))+bb.K.state_covariance(1:3,1:3,ib(k))-Pab-Pab';sigma(k)=sqrt(max(0,u'*P*u));
 eaidx=aa.K.epoch_index(ia(k));ebidx=bb.K.epoch_index(ib(k));sets(k,:)=[a.model.q.labels(eaidx,:).*a.model.q.good(eaidx,:),b.model.q.labels(ebidx,:).*b.model.q.good(ebidx,:)];
end
changed(2:end)=any(diff(sets)~=0,2);continuous=[false;diff(t)==10];
% Declared 10-cm formal range-sigma integrity flag, not an observed-error gate.
quality=sigma<=.1;report=struct('paired_epochs',numel(t),'sigma_limit_m',.1,'retained_epochs',nnz(quality),'formal_range_sigma_percentiles_m',prctile(sigma,[50 95 99 100]));
save(fullfile(out,'gnss_quality.mat'),'t','sigma','quality','changed','continuous','report');
% Evaluation begins here. Reference data cannot modify the saved quality flag.
z=load(fullfile(out,'range_comparison.mat'),'t','rv');[~,i,j]=intersect(t,z.t);m=all(isfinite(z.rv(j,:)),2);ii=i(m);jj=j(m);r=z.rv(jj,:);ok=quality(ii);
report.range_common=struct('all_epochs',numel(ii),'quality_epochs',nnz(ok),'RMS_all_mm',rms(r)*1000,'RMS_quality_mm',rms(r(ok,:))*1000,'median_abs_all_mm',median(abs(r))*1000);
v=nan(size(t));v(ii)=z.rv(jj,4);delta=[NaN;diff(v)];stable=continuous&~changed&isfinite(delta);change=continuous&changed&isfinite(delta);
report.range_change=struct('stable_set_epochs',nnz(stable),'changed_set_epochs',nnz(change),'stable_median_abs_step_mm',median(abs(delta(stable)))*1000,'changed_median_abs_step_mm',median(abs(delta(change)))*1000,'stable_p99_abs_step_mm',prctile(abs(delta(stable))*1000,99),'changed_p99_abs_step_mm',prctile(abs(delta(change))*1000,99));
[~,order]=sort(abs(v),'descend','MissingPlacement','last');ix=order(1:min(12,numel(order)));writematrix([t(ix),(t(ix)-16)/3600,v(ix),sigma(ix),quality(ix),changed(ix)],fullfile(out,'largest_range_excursions.csv'));
report.note='Quality derives only from GNSS covariance, including between-receiver covariance from fixed integer constraints. It is a diagnostic integrity flag, not a calibrated precision guarantee. No KBR-derived outlier mask. Unknown/common ambiguity directions remain float.';
f=fopen(fullfile(out,'support_audit.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
