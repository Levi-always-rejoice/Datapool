function audit_absolute_fix_status(folder,previous)
z=load(fullfile(folder,'P_integer_audit.mat'));c=z.audit.candidate_detail;counts=cell(2,1);B=cell(2,1);
for sat='AB'
 k=double(sat)-64;x=load(fullfile(folder,[sat '_raw_design.mat']),'q');q=x.q;mask=false(size(q.good));if sat=='A',ix=c.ia;else,ix=c.ib;end;mask(ix,:)=c.mask;
 labels=q.labels(q.good&mask);counts{k}=accumarray(labels,1,[numel(q.B0),1]);n=load(fullfile(folder,[sat '_J.mat']));B{k}=n.J.ambiguities;
end
counts=vertcat(counts{:});B=vertcat(B{:});active=~any(abs(c.A(:,counts==0))>0,2);H=c.A(active,:);target=c.target(active);used=counts>0;
WL=c.WL(active);NL=c.NL(active);f1=1575.42e6;f2=1227.6e6;ln=299792458/(f1+f2);cf=f2/(f1+f2)*299792458/(f1-f2);
assert(all(WL==round(WL))&&all(NL==round(NL)));assert(max(abs(target-(ln*NL+cf*WL)))<1e-12);err=max(abs(H*B-target));assert(err<1e-8);
r=rank(H(:,used));old=load(fullfile(previous,'P_integer_audit.mat'));assert(isequal(c.target,old.audit.candidate_detail.target)&&isequal(c.A,old.audit.candidate_detail.A));
summary=struct('active_offset_unknowns',nnz(used),'active_A_offsets',nnz(counts(1:numel(B)/2)>0),'independent_fixed_DD_relations',r,'remaining_offset_dimensions',nnz(used)-r,'active_DD_relations',nnz(active),'all_WL_NL_targets_integer',true,'max_saved_solution_constraint_error_m',err,'same_targets_as_realtime',true,'classification','Absolute orbits conditioned on partial between-receiver integer constraints; common and unresolved offsets remain float. Not two independently fully integer-fixed absolute solutions.');
% Receiver vectors generally have different label counts; use saved counts.
aa=load(fullfile(folder,'A_raw_design.mat'),'q');summary.active_A_offsets=nnz(counts(1:numel(aa.q.B0))>0);summary.active_B_offsets=nnz(counts(numel(aa.q.B0)+1:end)>0);
f=fopen(fullfile(folder,'absolute_integer_status.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
end
