function report=prepare_grace_common_history(package,root,out)
% Reproduce the final 2015 common-view control. Retain independently resolved
% integers and add POD-supported directions only to the named assisted branch.
if ~isfolder(out),mkdir(out);end
z=load(fullfile(root,'code_history20_run','independent_joint_history2.mat'),'result');ind=z.result;
z=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');cp=z.audit.candidate_detail;
ln=299792458/(1575.42e6+1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);
Wi=round((ind.target-ln*ind.integer_vector)/cf);Hp=cp.A(cp.independent,:);Np=cp.NL(cp.independent);Wp=cp.WL(cp.independent);
[U,~]=qr(ind.H',0);select=[];
for j=1:size(Hp,1)
 v=Hp(j,:)'-U*(U'*Hp(j,:)');v=v-U*(U'*v);if norm(v)<1e-8,continue;end
 U=[U,v/norm(v)];select(end+1)=j; %#ok<AGROW>
end
aug=ind;aug.H=[ind.H;Hp(select,:)];aug.integer_vector=[ind.integer_vector;Np(select)];W=[Wi;Wp(select)];aug.target=ln*aug.integer_vector+cf*W;aug.fixed_rank=size(aug.H,1);
co=(aug.H'\Hp')';assert(max(abs(co*aug.H-Hp),[],'all')<1e-7);
assert(max(abs(co*aug.integer_vector-Np))<1e-6&&max(abs(co*W-Wp))<1e-6,'Independent and assisted integer histories conflict; do not overwrite independent fixes.');
seeds={ind,aug};report=struct('independent_rank',ind.fixed_rank,'augmented_rank',aug.fixed_rank,'POD_directions_added',numel(select));
save(fullfile(out,'frozen_factors.mat'),'seeds','report','-v7.3');
end
