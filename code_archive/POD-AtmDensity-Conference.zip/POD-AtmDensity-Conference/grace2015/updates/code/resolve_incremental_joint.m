function result=resolve_incremental_joint(source,out,candidateFile,seedFile,suffix)
% Keep independently validated L1/L2 seed relations exactly; search only the
% remaining WL-supported integer subspace, using the same three likelihoods.
% No POD/KBR/ACC inputs. Seed and folds are not statistically independent.
z=load(seedFile,'result');seed=z.result;z=load(candidateFile,'result');c=z.result.c;A=c.A(z.result.wideOK,:);wide=c.WL(z.result.wideOK);
a=load(fullfile(source,'A_float_model.mat'),'model');b=load(fullfile(source,'B_float_model.mat'),'model');nc=numel(a.model.B0);
assert(~isfield(a.model.q,'pod_r')&&~isfield(b.model.q,'pod_r'));
B=[a.model.B0+a.model.db;b.model.B0+b.model.db];Q=blkdiag(a.model.Q,b.model.Q);profiles={struct('B',B,'Q',Q,'count',inf(size(B)))};
for fold=0:1,x=load(fullfile(source,sprintf('A_fold%d.mat',fold)));y=load(fullfile(source,sprintf('B_fold%d.mat',fold)));profiles{end+1}=struct('B',[x.z.B;y.z.B],'Q',blkdiag(x.z.Q,y.z.Q),'count',[x.z.count;y.z.count]);end
ln=299792458/(1575.42e6+1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);
Wseed=round((seed.target-ln*seed.integer_vector)/cf);
% Verify candidate wide lanes against existing fixed relations before search.
[~,r,p]=qr(A','vector');rk=sum(abs(diag(r))>1e-9);AA=A(p(1:rk),:);ww=wide(p(1:rk));co=(AA'\seed.H')';
assert(max(abs(co*AA-seed.H),[],'all')<1e-7&&max(abs(co*ww-Wseed))<1e-6,'Seed/candidate WL inconsistency'); %#ok<ASGLU>
[U,~]=qr(seed.H',0);select=[];
for j=1:size(AA,1)
 v=AA(j,:)'-U*(U'*AA(j,:)');v=v-U*(U'*v);if norm(v)<1e-8,continue;end
 U=[U,v/norm(v)];select(end+1)=j; %#ok<AGROW>
end
A=AA(select,:);wide=ww(select);models=cell(3,1);
for j=1:3
 z=profiles{j};HQ=seed.H*z.Q;S=HQ*seed.H';sc=sqrt(diag(S));SS=S./sc./sc';
 delta=seed.target-seed.H*z.B;z.B=z.B+HQ'*((SS\(delta./sc))./sc);z.Q=z.Q-HQ'*((SS\(HQ./sc))./sc);z.Q=(z.Q+z.Q')/2;profiles{j}=z;
end
C=A*profiles{1}.Q*A'/ln^2;C=(C+C')/2;[~,D,Z]=gnss_integer_reduce(C);H=Z'*A;offset=cf*(Z'*wide);rk=size(H,1);
first=1;while first<rk&&prod(erf(.5./sqrt(2*D(first:end))))<.999,first=first+1;end
supported=false(rk,1);supported(first:end)=true;
for j=1:3,z=profiles{j};models{j}=struct('a',(H*z.B-offset)/ln,'C',(H*z.Q*H')/ln^2);supported=supported&~any(abs(H(:,z.count<6))>1e-10,2);end
keep=find(supported);history=[];best=[];limit=3000000;
while ~isempty(keep)
 m=numel(keep);bad=false(m,1);score=zeros(m,1);base=[];why=0;
 for j=1:3
  CC=models{j}.C(keep,keep);CC=(CC+CC')/2;aa=models{j}.a(keep);[ints,cost,done,nodes]=gnss_joint_integer(aa,CC,limit);
  if ~done||numel(cost)<2,[~,drop]=max(diag(CC));bad(drop)=true;why=1;break;end
  if j==1,base=ints(:,1);end
  mismatch=ints(:,1)~=base;bad=bad|mismatch;if any(mismatch),why=2;end
  invC=CC\eye(m);delta=base-aa;conditional=(invC*delta).^2./diag(invC);score=max(score,conditional);
  if max(conditional)>9||cost(1)>m+3*sqrt(2*m),[~,drop]=max(conditional);bad(drop)=true;why=3;end
  if cost(2)-cost(1)<2*log(1000),choices=find(ints(:,2)~=ints(:,1));[~,jj]=max(diag(CC(choices,choices)));bad(choices(jj))=true;why=4;end
 end
 if ~any(bad),best=base;break;end
 choices=find(bad);[~,j]=max(score(choices)+1e-12*diag(models{1}.C(keep(choices),keep(choices))));drop=choices(j);history=[history;m keep(drop) why nodes];keep(drop)=[]; %#ok<AGROW>
 if mod(size(history,1),10)==1,fprintf('Conditional expansion: %d new directions, reason %d\n',m,why);end
end
HH=[seed.H;H(keep,:)];N1=[seed.integer_vector;best];target=[seed.target;offset(keep)+ln*best];HQ=HH*Q;S=HQ*HH';sc=sqrt(diag(S));SS=S./sc./sc';fixedB=B+HQ'*((SS\((target-HH*B)./sc))./sc);
err=max(abs(HH*fixedB-target));assert(err<1e-7);assert(max(abs(seed.H*fixedB-seed.target))<1e-7);
result=struct('H',HH,'target',target,'fixedB',fixedB,'integer_vector',N1,'fixed_rank',size(HH,1),'seed_rank',seed.fixed_rank,'added_rank',numel(keep),'initial_supported',nnz(supported),'remaining_WL_supported_rank',rk,'constraint_error_m',err,'history',history,'candidateFile',candidateFile,'seedFile',seedFile);
save(fullfile(out,['independent_joint' suffix '.mat']),'result','-v7.3');
L=gnss_condition_navigation(a.model,[],[],fixedB(1:nc));save(fullfile(out,['A_L' suffix '.mat']),'L','-v7.3');L=gnss_condition_navigation(b.model,[],[],fixedB(nc+1:end));save(fullfile(out,['B_L' suffix '.mat']),'L','-v7.3');
f=fopen(fullfile(out,['independent_joint' suffix '.json']),'w');fprintf(f,'%s',jsonencode(rmfield(result,{'H','target','fixedB','integer_vector','history'}),PrettyPrint=true));fclose(f);disp(result.fixed_rank);
end
