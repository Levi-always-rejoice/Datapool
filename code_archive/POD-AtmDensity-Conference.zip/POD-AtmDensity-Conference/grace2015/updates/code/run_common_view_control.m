function report=run_common_view_control(root,out)
% Split the old composite assisted phase mask into its elementary GNSS-only
% common-view support and additional POD/fixed-component selection. All code
% remains. No minimum continuous GPS coverage, track graph, POD phase gate,
% per-arc ambiguity reset, or new integer decision is introduced here.
source=fullfile(root,'code_history20_run');z=load(fullfile(out,'frozen_factors.mat'),'seeds');seeds=z.seeds;
i=load(fullfile(source,'independent_joint_history2.mat'),'result');assert(isequal(seeds{1}.H,i.result.H)&&isequal(seeds{1}.target,i.result.target));seeds{1}=i.result;
bases=cell(2,1);for s=1:2,z=load(fullfile(source,[char(64+s) '_float_model.mat']),'model');bases{s}=z.model;end
[t,ia,ib]=intersect(bases{1}.q.t,bases{2}.q.t);common=bases{1}.q.good(ia,:)&bases{2}.q.good(ib,:);masks=cell(2,1);masks{1}=false(size(bases{1}.q.good));masks{2}=false(size(bases{2}.q.good));masks{1}(ia,:)=common;masks{2}(ib,:)=common;
models=cell(2,1);counts=cell(2,1);report=struct('common_native_epochs',numel(t),'common_phase_per_receiver',nnz(common));
for s=1:2
 q=bases{s}.q;assert(~any(startsWith(fieldnames(q),'pod_')));q.phase_good=masks{s};sat=char(64+s);fprintf('GNSS common-view-only carrier profile %s\n',sat);
 [models{s},p,r]=gnss_long_code_profile(bases{s},q,1200,true(size(q.t)),true);counts{s}=p.count;report.(sat)=rmfield(r,'anchor_audit');
 assert(r.phase_observations==nnz(common)&&r.code_total_observations==nnz(q.good&isfinite(q.code)&abs(q.code)<30));
end
tags={'common_view_independent','common_view_addedPOD'};
for k=1:2
 folder=fullfile(out,tags{k});if ~isfolder(folder),mkdir(folder);end
 [B,r]=condition_supported_history(models{1},models{2},seeds{k},vertcat(counts{:}));report.(tags{k})=r;result=seeds{k};result.fixedB=B;save(fullfile(folder,'constraints.mat'),'result','r','-v7.3');n=numel(models{1}.B0);
 for s=1:2
  if s==1,bb=B(1:n);else,bb=B(n+1:end);end
  L=gnss_condition_navigation(models{s},[],[],bb);save(fullfile(folder,[char(64+s) '_L.mat']),'L','-v7.3');
 end
end
report.note='Common-view mask constructed only from simultaneous GNSS q.good flags, retaining all available code. The independent branch uses the original independent 297 integer history only; it uses no POD mask, integer additions, coordinates, or residuals. The paired addedPOD branch is an explicitly assisted control. This is simultaneous common view, not continuous 20-minute common-view tracking. All original tracking labels are retained.';
save(fullfile(out,'common_view_mask.mat'),'masks','report');f=fopen(fullfile(out,'common_view_method.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
