function report=summarize_assistance_factorial(root,out)
% Consolidate factorial and common-view tests on exactly the same support.
f=load(fullfile(out,'comparison.mat'));c=load(fullfile(out,'common_view_comparison.mat'));assert(isequal(f.tt,c.tt)&&isequal(f.t,c.t)&&isequal(f.mask,c.mask));
names={'full_independent','full_addedPOD','common_view_independent','common_view_addedPOD','phase_only_independent','phase_only_addedPOD','phase_and_code_independent','phase_and_code_addedPOD'};
g=[f.g(:,1:2),c.g,f.g(:,3:6)];ranges=[f.ranges(:,1:2),c.ranges,f.ranges(:,3:6)];tt=f.tt;t=f.t;acc=f.acc;mask=f.mask;rm=f.rm&c.rm;
report=struct('columns',{names},'range_epochs',nnz(rm),'density_centers',nnz(mask),'range_RMS_mm',rms(ranges(rm,:))*1000);
for j=1:8
 report.density.(names{j})=score(g(mask,j),acc(mask));report.density.(names{j}).all=score(g(:,j),acc);report.density.(names{j}).last4=score(g(tt>=72016,j),acc(tt>=72016));
end
report.common_view_density_RMS_reduction_percent=100*(1-report.density.common_view_independent.RMS/report.density.full_independent.RMS);
report.common_view_range_RMS_reduction_percent=100*(1-report.range_RMS_mm(3)/report.range_RMS_mm(1));
report.integer_only_density_RMS_reduction_percent=100*(1-report.density.full_addedPOD.RMS/report.density.full_independent.RMS);
report.POD_carrier_mask_density_RMS_reduction_percent=100*(1-report.density.phase_only_independent.RMS/report.density.full_independent.RMS);
% Count exactly which parts of the assisted selection can be made from
% simultaneous GNSS coverage alone. This is a post-fit attribution audit.
z=load(fullfile(out,'frozen_factors.mat'),'masks');p=z.masks;z=load(fullfile(out,'common_view_mask.mat'),'masks');cv=z.masks;
for s=1:2,assert(~any(p{s}&~cv{s},'all'));report.support.(char(64+s))=struct('common_view_observations',nnz(cv{s}),'POD_mask_observations',nnz(p{s}),'additional_POD_mask_removals',nnz(cv{s}&~p{s}));end
report.note='Same 20-minute orbit basis, geometry, transmitter products, integer seed, code policy and density fit. Common-view independent is the only new independent branch; all other added-integer or POD-mask branches are diagnostics. Its mask requires only simultaneous observation, not continuous coverage through a window. ACC retains the existing benchmark bias calibration. Matched density scores use the earlier valid output support; all-output scores are also provided. No mask or threshold was tuned to KBR or ACC.';
save(fullfile(out,'summary.mat'),'report','g','ranges','tt','t','acc','mask','rm','names');writejson(fullfile(out,'summary.json'),report);
rowNames=string(names(:));range_rms_mm=report.range_RMS_mm(:);density_rms=zeros(8,1);correlation=density_rms;all_rms=density_rms;
for j=1:8,s=report.density.(names{j});density_rms(j)=s.RMS;correlation(j)=s.r;all_rms(j)=s.all.RMS;end
writetable(table(rowNames,range_rms_mm,density_rms,correlation,all_rms),fullfile(out,'matched_results.csv'));
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1550 1160]);tiledlayout(3,1,'TileSpacing','compact');
cols=[.55 .55 .55;0 .45 .74;.85 .33 .10];sel=[1 3 6];labels={'Previous independent','GNSS common-view only','POD mask + added POD integers'};
nexttile;hold on;v=ranges(:,sel)*1000;v([false;diff(t)>1.5*median(diff(t))],:)=NaN;
for j=1:3,plot((t-16)/3600,v(:,j),'Color',cols(j,:));end
grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title('Controlled comparison: independent common-view selection and assisted reference');legend(labels,'Location','northoutside','Orientation','horizontal');
nexttile;hold on;v=g(:,sel)*1e12;v(~mask,:)=NaN;a=acc*1e12;a(~mask)=NaN;
for j=1:3,plot((tt-16)/3600,v(:,j),'Color',cols(j,:));end
plot((tt-16)/3600,a,'k','LineWidth',1.1);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title('20-minute differential density: identical valid comparison times');legend([labels,{'ACC'}],'Location','northoutside','Orientation','horizontal');
nexttile;hold on;
for j=1:3,plot((tt-16)/3600,v(:,j),'Color',cols(j,:));end
plot((tt-16)/3600,a,'k','LineWidth',1.2);grid on;xlim([20 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title('Last four hours, unchanged solutions and comparison support');xlabel('UTC hour, GRACE A/B, 2015-03-15');
exportgraphics(fig,fullfile(out,'independent_common_view_comparison.png'),'Resolution',150);close(fig);
fig=figure('Position',[30 30 1500 650]);v=g(:,[1 3])*1e12;v([false;diff(tt)>1.1],:)=NaN;plot((tt-16)/3600,v(:,1),'Color',cols(1,:));hold on;plot((tt-16)/3600,v(:,2),'Color',cols(2,:));plot((tt-16)/3600,acc*1e12,'k');xlim([0 24]);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, 2015-03-15');title('All fitted centers: previous independent versus GNSS-only common view');legend('Previous independent','GNSS common-view only','ACC','Location','northoutside','Orientation','horizontal');exportgraphics(fig,fullfile(out,'independent_all_density_centers.png'),'Resolution',150);close(fig);
disp(report);
end
function s=score(g,a),m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
