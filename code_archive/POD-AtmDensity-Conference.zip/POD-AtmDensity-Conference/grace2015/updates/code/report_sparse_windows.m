function report_sparse_windows(previous,out)
% Compare changed availability treatment without changing navigation/integers.
a=load(fullfile(previous,'comparison.mat'));b=load(fullfile(out,'comparison.mat'));windows=[20 10];report=struct;
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1500 1000]);tiledlayout(3,1);
for k=1:2
 x=a.series{k};y=b.series{k};[~,ia,ib]=intersect(x.t,y.t);common=x.mask(ia)&y.mask(ib);added=y.mask&~ismember(y.t,x.t(x.mask));
 report.(sprintf('min%d',windows(k)))=struct('previous_centers',nnz(x.mask),'new_centers',nnz(y.mask),'added_centers',nnz(added),'lost_centers',nnz(x.mask&~ismember(x.t,y.t(y.mask))),'previous_common',score(x.gnss(ia),x.acc(ia),common),'new_common',score(y.gnss(ib),y.acc(ib),common),'new_added',score(y.gnss,y.acc,added),'new_all',score(y.gnss,y.acc,y.mask));
 eligible=(min([x.t;y.t]):max([x.t;y.t]))';missing=~ismember(eligible,y.t(y.mask));edges=diff([false;missing;false]);lo=eligible(find(edges==1));hi=eligible(find(edges==-1)-1);gaps=[lo,hi,hi-lo+1,(lo-16)/3600,(hi-16)/3600];
 writematrix(gaps,fullfile(out,sprintf('min%d_remaining_gaps.csv',windows(k))));
 report.(sprintf('min%d',windows(k))).internal_missing_centers=nnz(missing);
 report.(sprintf('min%d',windows(k))).maximum_absolute_density=max(abs(y.gnss(y.mask)));
 report.(sprintf('min%d',windows(k))).maximum_absolute_ACC_difference=max(abs(y.gnss(y.mask)-y.acc(y.mask)));
 report.(sprintf('min%d',windows(k))).common_maximum_GNSS_change=max(abs(x.gnss(ia(common))-y.gnss(ib(common))));
 report.(sprintf('min%d',windows(k))).common_maximum_ACC_change=max(abs(x.acc(ia(common))-y.acc(ib(common))));
 aa=readmatrix(fullfile(out,sprintf('A_%dmin.csv',windows(k))));bb=readmatrix(fullfile(out,sprintf('B_%dmin.csv',windows(k))));[~,ja]=ismember(y.t,aa(:,1));[~,jb]=ismember(y.t,bb(:,1));
 native=[y.t,(y.t-16)/3600,y.gnss,y.acc,y.mask,added,aa(ja,7),bb(jb,7)];writematrix(native,fullfile(out,sprintf('min%d_availability.csv',windows(k))));
 densityAxes(k)=nexttile;v=x.gnss;v(~x.mask|[false;diff(x.t)>1.1])=NaN;plot((x.t-16)/3600,v*1e12);hold on;
 v=y.gnss;v(~y.mask|[false;diff(y.t)>1.1])=NaN;r=y.acc;r(~y.mask|[false;diff(y.t)>1.1])=NaN;
 plot((y.t-16)/3600,v*1e12);plot((y.t-16)/3600,r*1e12,'k');grid on;xlim([0 24]);ylim([-1 1]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('%d-minute moving window: missing epochs allowed, fixed ambiguities unchanged',windows(k)));legend('Previous complete-window requirement','Available-epoch fit','ACC');
end
nexttile;hold on;t=(0:86399)';for k=1:2,x=a.series{k};y=b.series{k};plot((t-16)/3600,ismember(t,x.t(x.mask))+3*(k-1));plot((t-16)/3600,ismember(t,y.t(y.mask))+3*(k-1)+1.2);end;grid on;xlim([0 24]);xlabel('UTC hour, GRACE A/B, 2015-03-15');title('Coverage: full window span retained, missing epochs omitted');legend('20 min previous','20 min available-epoch','10 min previous','10 min available-epoch');
exportgraphics(fig,fullfile(out,'sparse_window_comparison.png'),'Resolution',150);
for k=1:2,ylim(densityAxes(k),'auto');end
exportgraphics(fig,fullfile(out,'sparse_window_full_scale.png'),'Resolution',150);close(fig);
f=fopen(fullfile(out,'sparse_comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
function s=score(x,y,m)
if nnz(m)<2,s=struct('centers',nnz(m),'RMS',NaN,'r',NaN);return;end
c=corrcoef(x(m),y(m));s=struct('centers',nnz(m),'RMS',rms(x(m)-y(m)),'r',c(1,2));
end
