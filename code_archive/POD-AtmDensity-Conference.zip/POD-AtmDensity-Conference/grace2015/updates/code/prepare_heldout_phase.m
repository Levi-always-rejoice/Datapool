function report=prepare_heldout_phase(root,out)
% Four deterministic folds, each excluding five-minute segments of GPS
% tracks from BOTH receivers. The phase and code of that segment are absent
% from the prediction fit. Previously validated independent integers stay
% available as history. No POD, KBR, ACC or assisted mask is read here.
if ~isfolder(out),mkdir(out);end
source=fullfile(root,'code_history20_run');z=load(fullfile(source,'independent_joint_history2.mat'),'result');seed=z.result;
z=load(fullfile(source,'A_float_model.mat'),'model');baseA=z.model;clear z;
z=load(fullfile(source,'B_float_model.mat'),'model');baseB=z.model;clear z;
assert(~any(startsWith(fieldnames(baseA.q),'pod_'))&&~any(startsWith(fieldnames(baseB.q),'pod_')));
qa=baseA.q;qb=baseB.q;na=numel(baseA.B0);nt=na+numel(baseB.B0);
assignA=mod(floor(qa.t/300)+(0:32),4);assignB=mod(floor(qb.t/300)+(0:32),4);
stats=cell(4,1);
for fold=0:3
 name=fullfile(out,sprintf('heldout_fold%d.mat',fold));if isfile(name),fprintf('Reuse saved fold %d\n',fold);continue;end
 fprintf('Fit held-out GPS segments, fold %d, A\n',fold);
 q=qa;ha=q.good&assignA==fold;q.good(ha)=false;
 [a,pa]=gnss_long_code_profile(baseA,q,1200,true(size(q.t)),true);
 fprintf('Fit held-out GPS segments, fold %d, B\n',fold);
 q=qb;hb=q.good&assignB==fold;q.good(hb)=false;
 [b,pb]=gnss_long_code_profile(baseB,q,1200,true(size(q.t)),true);
 [B,Q,info]=gnss_fixed_profile(a,b,seed,[pa.count;pb.count]);
 fprintf('Predict held-out phase, fold %d\n',fold);
 A=gnss_heldout_prediction(a,qa,ha,B(1:na),Q,0,nt);
 Bp=gnss_heldout_prediction(b,qb,hb,B(na+1:end),Q,na,nt);
 A.support=pa.count(A.label)>=6;Bp.support=pb.count(Bp.label)>=6;
 [key,ia,ib]=intersect([A.time,A.prn],[Bp.time,Bp.prn],'rows');
 D=struct('time',key(:,1),'prn',key(:,2),'A_index',ia,'B_index',ib, ...
  'residual',Bp.residual(ib)-A.residual(ia),'support',A.support(ia)&Bp.support(ib), ...
  'prediction_variance',nan(numel(ia),1),'measurement_variance',A.measurement_variance(ia)+Bp.measurement_variance(ib));
 for k=1:256:numel(ia)
  ii=k:min(k+255,numel(ia));g=Bp.ambiguity_gradient(ib(ii),:)-A.ambiguity_gradient(ia(ii),:);
  D.prediction_variance(ii)=max(0,A.state_clock_variance(ia(ii))+Bp.state_clock_variance(ib(ii))+sum((g*Q).*g,2));
 end
 A=rmfield(A,'ambiguity_gradient');Bp=rmfield(Bp,'ambiguity_gradient');
 stats{fold+1}=info;save(name,'A','Bp','D','info','-v7.3');clear a b Q B A Bp D;
 fprintf('Completed phase prediction fold %d\n',fold);
end
report=struct('folds',{stats},'seed_fixed_rank',seed.fixed_rank,'segment_seconds',300,'fold_count',4, ...
 'note','GNSS-only deleted-segment predictions conditioned on pre-existing 297-combination integer history. Seed integers used full-day data, so this is conditional cross-validation, not fully independent validation of the seed. The test segment code and phase are both withheld from its navigation prediction. Training requires at least two remaining GPS signals for epoch clock and six samples for the ambiguity label. No reference products are read.');
f=fopen(fullfile(out,'prediction_method.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
end
