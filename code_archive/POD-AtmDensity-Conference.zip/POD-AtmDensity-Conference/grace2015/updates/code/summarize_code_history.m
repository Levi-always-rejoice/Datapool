function report=summarize_code_history(root)
out=fullfile(root,'code_history_slip_audit');base=fullfile(root,'coverage_expansion_run');old=load(fullfile(base,'comparison_round4.mat'));folders={fullfile(root,'code_history20_run'),fullfile(root,'code_history60_run')};sets=cell(2,1);integers=cell(2,1);
report=struct('previous287',old.report);minutes=[20 60];
for k=1:2
 tag=strtrim(fileread(fullfile(folders{k},'selected_tag.txt')));sets{k}=load(fullfile(folders{k},['comparison' tag '.mat']));z=load(fullfile(folders{k},['independent_joint' tag '.mat']),'result');integers{k}=z.result;
 report.(sprintf('code%dmin',minutes(k)))=sets{k}.report;
end
assert(isequal(old.t,sets{1}.t)&&isequal(sets{1}.t,sets{2}.t)&&isequal(old.tt,sets{1}.tt)&&isequal(sets{1}.tt,sets{2}.tt));
co=(integers{1}.H'\integers{2}.H')';report.code20_vs_60_constraint_span_error=max(abs(co*integers{1}.H-integers{2}.H),[],'all');report.code20_vs_60_integer_target_error_m=max(abs(co*integers{1}.target-integers{2}.target));
report.code20_vs_60_max_range_difference_m=max(abs(sets{1}.rv(:,2)-sets{2}.rv(:,2)));report.code20_vs_60_max_density_difference=max(abs(sets{1}.g-sets{2}.g));
report.note='Previous solution is the independent 287-combination result. Code histories retain it and expand independently. Outlier screening and aggregation are GNSS-only; cycle-slip diagnostics use POD only after estimation. Both histories already use full-day phase, so longer aggregation does not provide additional observations. All comparisons use identical timestamps and force/density operators.';
f=fopen(fullfile(out,'code_history_summary.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1450 920]);tiledlayout(2,1);
t=old.t;v=[old.rv(:,2),sets{1}.rv(:,2),sets{2}.rv(:,2)]*1000;v([false;diff(t)>1.5*median(diff(t))],:)=NaN;
nexttile;plot((t-16)/3600,v(:,1:2));hold on;plot((t-16)/3600,v(:,3),'--');xlim([0 24]);grid on;ylabel('Range - KBR (mm)');legend('Previous independent 287','Screened code, 20-min bins','Screened code, 60-min bins');title('Same full-day phase history and 20-minute reduced-dynamic orbit basis');
t=old.tt;v=[old.g,sets{1}.g,sets{2}.g,old.acc]*1e12;v([false;diff(t)>1.1],:)=NaN;
nexttile;plot((t-16)/3600,v(:,1:2));hold on;plot((t-16)/3600,v(:,3),'--');plot((t-16)/3600,v(:,4),'k','LineWidth',1.1);xlim([0 24]);ylim([-1 1]);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, GRACE A/B, 2015-03-15');legend('Previous independent 287','Screened code, 20-min bins','Screened code, 60-min bins','ACC');title('20-minute density fit; no additional phase filtering');
exportgraphics(fig,fullfile(out,'code_history_comparison.png'),'Resolution',150);close(fig);disp(rmfield(report,{'previous287','code20min','code60min'}));
end
