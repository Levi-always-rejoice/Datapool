function report=test_kinematic_profile
% Independent full-design QR oracle for profiling and exact conditioning.
rng(74021);nt=60;ns=7;nb=8;t=(0:nt-1)'*10;q=struct('t',t,'r',repmat([7e6 0 0],nt,1),'B0',randn(nb,1),'used',true(nb,1),'labels',repmat(1:ns,nt,1),'good',true(nt,ns),'h',zeros(nt,ns,3),'elev',ones(nt,ns)*.7);
q.labels(31:end,7)=8;q.good(17,4:end)=false;B=randn(nb,1)*.5;x=randn(nt,4)*.2;q.phase=zeros(nt,ns);q.code=q.phase;
for i=1:nt,h=randn(ns,3);h=h./vecnorm(h,2,2);q.h(i,:,:)=h;G=[h ones(ns,1)];q.phase(i,:)=G*x(i,:)'+B(q.labels(i,:))+randn(ns,1)*.001;q.code(i,:)=G*x(i,:)'+randn(ns,1)*.2;end
m=gnss_kinematic_profile(q);n=gnss_condition_kinematic(m,[],[]);ids=find(m.eligible);assert(~m.eligible(17)&&numel(ids)==nt-1);M=[];y=[];
for k=1:numel(ids)
 i=ids(k);e=m.epochs{i};np=numel(e.labels);E=zeros(np,nb);E(sub2ind(size(E),(1:np)',e.labels))=1;
 a=zeros(2*np,4*numel(ids)+nb);a(:,4*(k-1)+(1:4))=[sqrt(e.wp).*e.G;sqrt(e.wc).*e.G];a(:,4*numel(ids)+(1:nb))=[sqrt(e.wp).*E;zeros(np,nb)];M=[M;a];y=[y;sqrt(e.wp).*e.yphase;sqrt(e.wc).*e.ycode]; %#ok<AGROW>
end
sol=M\y;expected=reshape(sol(1:4*numel(ids)),4,[])';got=[n.values(:,2:4)-q.r(ids,:),n.clock(:,2)];error=max(abs(got-expected),[],'all');assert(error<1e-6);assert(max(abs(n.ambiguities-(q.B0+sol(end-nb+1:end))))<1e-6);
H=zeros(1,nb);H(1:2)=[1 -1];target=H*B;k=gnss_condition_kinematic(m,H,target);C=[zeros(1,4*numel(ids)),H];rhs=target-H*q.B0;z0=C'*(rhs/(C*C'));Z=null(C);sol=z0+Z*((M*Z)\(y-M*z0));expected=reshape(sol(1:4*numel(ids)),4,[])';got=[k.values(:,2:4)-q.r(ids,:),k.clock(:,2)];fixedError=max(abs(got-expected),[],'all');assert(fixedError<1e-6);
report=struct('passed',true,'float_state_QR_error_m',error,'constrained_state_QR_error_m',fixedError,'constraint_error_m',k.integer_error,'new_track_has_separate_parameter',q.labels(30,7)~=q.labels(31,7),'under_four_signal_epoch_not_fabricated',~m.eligible(17));disp(report);
% Regression for zero-information singleton ambiguities with missing code.
q.B0(end+1)=0;q.used(end+1)=true;q.labels(17,4)=nb+1;q.good(17,1:4)=true;q.code(17,4)=NaN;
m=gnss_kinematic_profile(q);assert(~m.eligible(17)&&ismember(nb+1,m.removed_unobservable_labels));report.zero_information_singleton_rejected=true;disp(report);
end
