function block=direct_sd_basis(q,j)
% Relative dynamics around two GNSS-only geometric trajectories. The mean
% orbit is prescribed. Retain BOTH mean-position and differential-position
% gravity couplings. Columns: nominal baseline, 12 relative state/empirical
% force columns, and response to changing the independent mean reference.
mu=3.986004418e14;qa=q.qa;qb=q.qb;
RA=gnss_hermite(qa.t,qa.r,qa.v);RB=gnss_hermite(qb.t,qb.r,qb.v);
PA=spline(qa.t,(qa.known-qa.rad+mu*qa.r./vecnorm(qa.r,2,2).^3)');
PB=spline(qb.t,(qb.known-qb.rad+mu*qb.r./vecnorm(qb.r,2,2).^3)');
M0=gnss_hermite(q.mean0(:,1),q.mean0(:,2:4),q.mean0(:,5:7));M1=gnss_hermite(q.mean1(:,1),q.mean1(:,2:4),q.mean1(:,5:7));
a=q.blocks(j,1);b=q.blocks(j,2);pivot=(a+b)/2;Y=zeros(6,14);
Y(1:3,1)=ppval(RB,pivot)-ppval(RA,pivot);Y(4:6,1)=derivative(RB,pivot)-derivative(RA,pivot);
Y(1:3,2:4)=eye(3);Y(4:6,5:7)=eye(3)/600;
opts=odeset('RelTol',2e-13,'AbsTol',1e-11,'MaxStep',20);
block=struct('a',a,'b',b,'pivot',pivot,'ncol',14,'left',ode113(@rhs,[pivot a],Y(:),opts),'right',ode113(@rhs,[pivot b],Y(:),opts));
 function z=rhs(time,z)
  x=reshape(z,6,14);v=zeros(6,14);ra=ppval(RA,time);rb=ppval(RB,time);ga=gnss_gradient(ra);gb=gnss_gradient(rb);G=(ga+gb)/2;
  ma=(ra+rb)/2;b0=rb-ra;m0=ppval(M0,time);dm=ppval(M1,time)-m0;
  knownA=ppval(PA,time)-mu*ra/norm(ra)^3;knownB=ppval(PB,time)-mu*rb/norm(rb)^3;
  v(1:3,:)=x(4:6,:);v(4:6,:)=G*x(1:3,:);
  v(4:6,1)=v(4:6,1)+knownB-knownA+(gb-ga)*(m0-ma)-G*b0;
  v(4:6,8:10)=v(4:6,8:10)+eye(3)*1e-7;v(4:6,11:13)=v(4:6,11:13)+eye(3)*(time-pivot)/600*1e-7;
  v(4:6,14)=v(4:6,14)+(gb-ga)*dm;z=v(:);
 end
end
function v=derivative(P,t)
[~,piece]=histc(t,P.breaks);piece=min(max(piece,1),P.pieces);c=P.coefs((piece-1)*3+(1:3),:);u=t-P.breaks(piece);v=3*c(:,1)*u^2+2*c(:,2)*u+c(:,3);
end
