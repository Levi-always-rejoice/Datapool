function plot_integer_expansion(root,out,suffix)
z=load(fullfile(out,['comparison' suffix '.mat']));t=z.t;rv=z.rv;tt=z.tt;g=z.g;acc=z.acc;rank=z.report.fixed_rank;
rv([false;diff(t)>1.5*median(diff(t))],:)=NaN;
set(groot,'defaultFigureVisible','off');f=figure('Position',[20 20 1450 1050]);tiledlayout(3,1);
for panel=1:2
 nexttile;plot((t-16)/3600,rv(:,1:2)*1000);hold on;plot((t-16)/3600,rv(:,3)*1000,'k--');xlim([0 24]);grid on;ylabel('Range - KBR (mm)');
 if panel==1,legend('Original independent 240',sprintf('Expanded independent %d',rank),'POD integers only 358');if isfield(z.report,'plot_title'),title(z.report.plot_title);else,title('Same 20-minute reduced-dynamic model; different integer constraints only');end
 else,ylim([-25 25]);title('Same range residuals, enlarged vertical scale');end
end
old=readmatrix(fullfile(root,'reduced_dynamic_pod_integer_run','R_differential_density.csv'));[~,i,j]=intersect(tt,old(:,1));v=[old(j,2),g(i),acc(i)]*1e12;td=tt(i);v([false;diff(td)>1.1],:)=NaN;
nexttile;plot((td-16)/3600,v(:,1:2));hold on;plot((td-16)/3600,v(:,3),'k','LineWidth',1.1);xlim([0 24]);ylim([-1 1]);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');xlabel('UTC hour, GRACE A/B, 2015-03-15');legend('Original independent 240',sprintf('Expanded independent %d',rank),'ACC');title('20-minute differential density; displayed at requested vertical scale');
exportgraphics(f,fullfile(out,['comparison' suffix '.png']),'Resolution',150);close(f);
end
