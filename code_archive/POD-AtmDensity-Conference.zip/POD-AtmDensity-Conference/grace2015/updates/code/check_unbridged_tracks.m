function check_unbridged_tracks(original,auditdir,out)
T=readtable(fullfile(auditdir,'navigation_gaps.csv'));T=T(T.same_fixed_track_pairs==0,:);rows=[];
lw=299792458/(1575.42e6-1227.6e6);
for sat='AB'
 z=load(fullfile(original,[sat '_raw_design.mat']),'q');q=z.q;P=[gnss_pod_offsets(q,-1),gnss_pod_offsets(q,0),gnss_pod_offsets(q,1)];
 % Identifiability check: receiver offset labels must share a phase graph.
 edges=[];for e=1:numel(q.t),labs=q.labels(e,q.good(e,:));if numel(labs)>1,edges=[edges;repmat(labs(1),numel(labs)-1,1),labs(2:end)'];end,end %#ok<AGROW>
 comp=conncomp(graph(edges(:,1),edges(:,2),[],numel(q.B0)));
 for g=1:height(T)
  for p=2:33
   left=find(q.good(:,p)&q.t<T.start_GPS(g)&q.t>=T.start_GPS(g)-600,1,'last');right=find(q.good(:,p)&q.t>T.end_GPS(g)&q.t<=T.end_GPS(g)+600,1);
   if isempty(left)||isempty(right),continue;end
   la=q.labels(left,p);lb=q.labels(right,p);sameRaw=floor(q.ids(left,p)/100000)==floor(q.ids(right,p)/100000);sameComponent=comp(la)==comp(lb);
   before=find(q.good(:,p)&q.labels(:,p)==la&q.t<=q.t(left)&q.t>=q.t(left)-600);after=find(q.good(:,p)&q.labels(:,p)==lb&q.t>=q.t(right)&q.t<=q.t(right)+600);
   pass=sameRaw&&sameComponent;ints=nan(3,2);costs=nan(3,2);wd=NaN;
   for fold=1:3
    aa=before;bb=after;if fold>1,aa=aa(mod(aa,2)==fold-2);bb=bb(mod(bb,2)==fold-2);end
    [wa,sa]=wl(q.t(aa),q.mw(aa,p)/lw);[wb,sb]=wl(q.t(bb),q.mw(bb,p)/lw);wd=wb-wa;
    if ~isfinite(wd),pass=false;continue;end
    [ni,cost]=gnss_ils2(P(lb,fold)-P(la,fold),.01,wd,hypot(sa,sb));ints(fold,:)=ni;costs(fold,:)=cost;
    pass=pass&&cost(1)<=9.21&&cost(2)-cost(1)>=2*log(1000)&&cost(2)/max(cost(1),1e-12)>=3;
   end
   pass=pass&&all(ints==0,'all'); % Only validate unchanged raw-track ambiguity.
   rows=[rows;double(sat)-64,T.start_GPS(g),T.end_GPS(g),p-1,q.t(left),q.t(right),la,lb,sameRaw,sameComponent,P(lb,1)-P(la,1),wd,pass]; %#ok<AGROW>
  end
 end
end
tab=array2table(rows,'VariableNames',{'receiver','gap_start_GPS','gap_end_GPS','PRN','left_GPS','right_GPS','left_label','right_label','same_raw_ID','same_receiver_offset_component','POD_offset_change_m','WL_change_cycles','validated_zero_change'});writetable(tab,fullfile(out,'unbridged_track_tests.csv'));disp(tab);
end
function [v,s]=wl(t,y)
v=NaN;s=NaN;ok=isfinite(y);t=t(ok);y=y(ok);if numel(y)<6,return;end
[bins,~,ii]=unique(floor(t/60));if numel(bins)<3,return;end
means=accumarray(ii,y,[],@median);v=median(means);s=max(.035,1.4826*median(abs(means-v))/sqrt(numel(means)));
end
