function report=test_direct_sd_solution(out)
% Verify the solved constrained model and its arbitrary clock/offset datum.
% These are algebraic checks, not integer reliability or physical accuracy.
z=load(fullfile(out,'sd_linear_system.mat'));
u=load(fullfile(out,'sd_inputs.mat'),'q');q=u.q;
nb=size(q.nodes,1);ns=size(z.A,2)-nb;nc=max(z.component);
% A common offset on every GPS in a connected component is exactly absorbed
% by the receiver clock difference, and must not change the relative orbit.
datum=sparse(1:nb,z.component,1,nb,nc);
phaseGauge=full(max(abs(z.A(:,ns+(1:nb))*datum),[],'all'));
integerGauge=full(max(abs(q.H*datum),[],'all'));
assert(phaseGauge<1e-9&&integerGauge<1e-9);
% Recover a small known free-state perturbation through the actual QR factors.
% This includes relative orbit and unfixed ambiguity directions simultaneously.
rng(217);n=size(z.R,1);a=randn(n,1)*1e-3;
dx=(z.Z*(a./z.colScale'))./z.scale;
deltaY=z.A*dx;
design=(z.A./z.scale')*z.Z;design=design./z.colScale;
qa=design/z.R;
recovered=(z.Z*((z.R\(qa'*deltaY))./z.colScale'))./z.scale;
recovery=norm(recovered-dx)/norm(dx);
constraint=max(abs(z.C*recovered));
assert(recovery<1e-7&&constraint<1e-9);
actual=max(abs(z.C*z.solution-[z.d,z.ds]),[],'all');
assert(actual<1e-9);
report=struct('phase_clock_gauge_error',phaseGauge, ...
 'integer_clock_gauge_error',integerGauge, ...
 'synthetic_free_state_relative_error',recovery, ...
 'synthetic_constraint_error',constraint,'actual_constraint_error',actual, ...
 'note','Algebraic consistency checks only. No POD, KBR or ACC references are read.');
f=fopen(fullfile(out,'solution_checks.json'),'w');
fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
