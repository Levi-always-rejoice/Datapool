function report=compare_pod_integer_relations(package,root,kin,out,mode)
% Compare datum-invariant L1/L2 DD integers, NOT undifferenced IF offsets.
% Then isolate integer information in the chosen unchanged navigation model,
% added POD-assisted INTEGER constraints only, no POD positions or phase mask.
if nargin<5,mode='kinematic';end
assert(ismember(mode,{'kinematic','reduced_dynamic'}));
if ~isfolder(out),mkdir(out);end
fprintf('Integer audit mode: %s\n',mode);
source=fullfile(root,'independent_run');p=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');c=p.audit.candidate_detail;
ln=299792458/(1575.42e6+1227.60e6);cf=1227.60e6/(1575.42e6+1227.60e6)*299792458/(1575.42e6-1227.60e6);
assert(max(abs(c.target-ln*c.NL-cf*c.WL))<1e-10);rows=c.independent;Hp=c.A(rows,:);Np=c.NL(rows);Wp=c.WL(rows);
w=load(fullfile(source,'independent_graph1.mat'),'result');Aw=w.result.c.A(w.result.wideOK,:);nw=w.result.c.WL(w.result.wideOK);
[~,R,pi]=qr(Aw','vector');rw=sum(abs(diag(R))>1e-9);Hw=Aw(pi(1:rw),:);Nw=nw(pi(1:rw));
assert(max(abs(Aw*((Hw'/(Hw*Hw'))*Nw)-nw))<1e-6,'Independent WL graph contradiction');
report=struct('assisted_relations',size(c.A,1),'assisted_independent_rank',size(Hp,1),'independent_wide_lane_rank',rw);
report.navigation_mode=mode;fprintf('Comparing wide-lane subspaces\n');
report.wide_lane=compare_spaces(Hw,Nw,Hp,Wp,c.A,c.WL);
cases={fullfile(kin,'independent_joint_kinematic.mat'),fullfile(source,'independent_joint_search3m.mat')};names={'kinematic135','independent240'};
if strcmp(mode,'reduced_dynamic'),cases=cases(2);names={'reduced_dynamic240'};end
metadata=zeros(size(c.A,1),8);keys=vertcat(c.accepted.key);
for j=1:numel(c.accepted),tt=c.t(c.accepted(j).rows);metadata(j,:)=[keys(j,1:2)-1,keys(j,3:6),(min(tt)-16)/3600,(max(tt)-16)/3600];end
saved=cell(numel(cases),1);
for j=1:numel(cases)
 fprintf('Comparing dual-frequency integers: %s\n',names{j});
 z=load(cases{j},'result');g=z.result;saved{j}=g;Ng=g.integer_vector;
 Wg=(g.target-ln*Ng)/cf;assert(max(abs(Wg-round(Wg)))<1e-8);Wg=round(Wg);
 report.(names{j}).L1=compare_spaces(g.H,Ng,Hp,Np,c.A,c.NL);
 report.(names{j}).wide_lane_in_joint_space=compare_spaces(g.H,Wg,Hp,Wp,c.A,c.WL);
 report.(names{j}).L2=compare_spaces(g.H,Ng-Wg,Hp,Np-Wp,c.A,c.NL-c.WL);
 co=(g.H'\c.A')';fixed=max(abs(co*g.H-c.A),[],2)<1e-8;
 pn1=co*Ng;pw=co*Wg;pn2=pn1-pw;pn1(~fixed)=NaN;pw(~fixed)=NaN;pn2(~fixed)=NaN;
 % For unresolved rows, the fractional IF residual is NOT a wrong integer.
 if strcmp(mode,'reduced_dynamic')
  navA=load(fullfile(source,'A_L_search3m.mat'),'L');navB=load(fullfile(source,'B_L_search3m.mat'),'L');
 else
  navA=load(fullfile(kin,ternary(j==1,'A_L_kinematic.mat','A_K.mat')));navB=load(fullfile(kin,ternary(j==1,'B_L_kinematic.mat','B_K.mat')));
 end
 fa=fieldnames(navA);fb=fieldnames(navB);B=[navA.(fa{1}).ambiguities;navB.(fb{1}).ambiguities];
 phaseDifference=c.A*B-c.target;
 variables={'GPS1','GPS2','A_label1','B_label1','A_label2','B_label2','UTC_start','UTC_end','POD_N1','POD_N2','POD_WL','independent_relation_fixed','independent_N1','independent_N2','independent_WL','delta_N1_cycles','delta_N2_cycles','IF_offset_difference_mm'};
 T=array2table([metadata,c.NL,c.NL-c.WL,c.WL,double(fixed),pn1,pn2,pw,pn1-c.NL,pn2-(c.NL-c.WL),phaseDifference*1000],'VariableNames',variables);writetable(T,fullfile(out,[names{j} '_DD_comparison.csv']));
 report.(names{j}).unfixed_relation_IF_difference_percentiles_mm=prctile(abs(phaseDifference(~fixed))*1000,[50 95 99 100]);
 report.(names{j}).contradiction_in_any_shared_integer=report.(names{j}).L1.intersection_max_disagreement>1e-6||report.(names{j}).L2.intersection_max_disagreement>1e-6;
end
report.note='Relations are compared in a common DD row space with both L1 and L2 integers reconstructed explicitly. Integer-reference changes and common clock/float offsets cannot create a false disagreement. Intersection ranks count independent combinations; natural-row counts contain redundancy. An unresolved fractional IF offset is not an incorrectly fixed integer. POD-assisted integers are a benchmark, not independent ground truth.';
writejson(fullfile(out,'integer_comparison.json'),report);disp(report);
models=cell(2,1);modelFolder=kin;if strcmp(mode,'reduced_dynamic'),modelFolder=source;end
for sat='AB'
 fprintf('Loading unchanged %s model %s\n',mode,sat);z=load(fullfile(modelFolder,[sat '_float_model.mat']),'model');model=z.model;
 if ~isfield(model,'count'),model.count=accumarray(model.q.labels(model.q.good),1,[numel(model.B0) 1]);end
 models{double(sat)-64}=model;clear model z;
end
assert(size(Hp,2)==numel(models{1}.B0)+numel(models{2}.B0));
% Exact same likelihood as the prior selected model. Exclude only assisted
% rows involving a parameter with no observations in that likelihood.
count=[models{1}.count;models{2}.count];active=~any(c.A(:,count==0)~=0,2);AP=c.A(active,:);NP=c.NL(active);WP=c.WL(active);
sets=struct;sets.P=struct('H',AP,'N1',NP,'WL',WP);
g=saved{end};Wg=round((g.target-ln*g.integer_vector)/cf);sets.U=struct('H',[g.H;AP],'N1',[g.integer_vector;NP],'WL',[Wg;WP]);
B=[models{1}.B0+models{1}.db;models{2}.B0+models{2}.db];Q=blkdiag(models{1}.Q,models{2}.Q);nc=numel(models{1}.B0);controls=struct;
for tag={'P','U'}
 fprintf('Conditioning integer-only control %s\n',tag{1});
 name=tag{1};s=sets.(name);[~,R,pi]=qr(s.H','vector');rk=sum(abs(diag(R))>1e-9);take=pi(1:rk);H=s.H(take,:);N1=s.N1(take);WL=s.WL(take);
 co=(H'\s.H')';assert(max(abs(co*N1-s.N1))<1e-6&&max(abs(co*WL-s.WL))<1e-6,'Conflicting integers in union');target=ln*N1+cf*WL;
 HQ=H*Q;C=HQ*H';sc=sqrt(diag(C));CC=C./sc./sc';[~,flag]=chol((CC+CC')/2);assert(flag==0);delta=target-H*B;lagrange=(CC\(delta./sc))./sc;fixedB=B+HQ'*lagrange;Qc=Q-HQ'*((CC\(HQ./sc))./sc);
 error=max(abs(H*fixedB-target));assert(error<1e-8);controls.(name)=struct('rank',rk,'active_assisted_relations',nnz(active),'inactive_assisted_relations',nnz(~active),'max_constraint_error_m',error,'profile_cost_increase',delta'*lagrange);
 if strcmp(mode,'reduced_dynamic')
  n=gnss_condition_navigation(models{1},[],[],fixedB(1:nc));save(fullfile(out,['A_' name '.mat']),'n','-v7.3');
  n=gnss_condition_navigation(models{2},[],[],fixedB(nc+1:end));save(fullfile(out,['B_' name '.mat']),'n','-v7.3');
 else
  n=gnss_condition_kinematic(models{1},[],[],fixedB(1:nc),Qc(1:nc,1:nc));save(fullfile(out,['A_' name '.mat']),'n','-v7.3');
  n=gnss_condition_kinematic(models{2},[],[],fixedB(nc+1:end),Qc(nc+1:end,nc+1:end));save(fullfile(out,['B_' name '.mat']),'n','-v7.3');
 end
 save(fullfile(out,[name '_constraints.mat']),'H','N1','WL','target','fixedB','Qc','-v7.3');
end
writejson(fullfile(out,'integer_only_controls.json'),controls);disp(controls);
end
function result=compare_spaces(Hg,ng,Hp,np,A,expected)
[bg,rg]=qr(Hg',0);[bp,rp]=qr(Hp',0);[U,S,~]=svd(bg'*bp,'econ');same=diag(S)>1-1e-10;shared=U(:,same)'*bg';cg=(rg\(bg'*shared'))';cp=(rp\(bp'*shared'))';
assert(max(abs(cg*Hg-shared),[],'all')<1e-8&&max(abs(cp*Hp-shared),[],'all')<1e-8);
d=cg*ng-cp*np;if isempty(d),maxd=0;else,maxd=max(abs(d));end
co=(rg\(bg'*A'))';inside=max(abs(co*Hg-A),[],2)<1e-8;diff=co*ng-expected;
back=(rp\(bp'*Hg'))';reverse=max(abs(back*Hp-Hg),[],2)<1e-8;rd=back*np-ng;
result=struct('independent_rank',size(Hg,1),'assisted_rank',size(Hp,1),'intersection_rank',nnz(same),'independent_only_rank',size(Hg,1)-nnz(same),'assisted_only_rank',size(Hp,1)-nnz(same),'intersection_max_disagreement',maxd,'assisted_natural_relations_fixed',nnz(inside),'assisted_natural_relations_agree',nnz(inside&abs(diff)<1e-6),'assisted_natural_relations_disagree',nnz(inside&abs(diff)>=1e-6),'independent_stored_rows_checkable',nnz(reverse),'independent_stored_rows_disagree',nnz(reverse&abs(rd)>=1e-6));
end
function y=ternary(c,a,b),if c,y=a;else,y=b;end,end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
