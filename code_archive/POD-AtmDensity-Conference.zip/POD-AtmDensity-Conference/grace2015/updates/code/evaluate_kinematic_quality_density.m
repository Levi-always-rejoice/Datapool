function report=evaluate_kinematic_quality_density(root,source,out)
% Flagged samples are excluded using ONLY prior GNSS covariance. The same
% accepted epochs and force operator are used for all branches and ACC.
q=load(fullfile(out,'gnss_quality.mat'),'t','quality');t=q.t(q.quality);originalQualityCount=numel(t);navs=cell(2,1);refs=cell(2,1);
% Match the previous dynamic control's time domain before comparing density.
for sat='AB',z=load(fullfile(source,[sat '_L_search3m.mat']),'L');t=intersect(t,z.L.values(:,1));end
for sat='AB'
 k=double(sat)-64;z=load(fullfile(out,[sat '_K.mat']),'K');[yes,i]=ismember(t,z.K.values(:,1));assert(all(yes));navs{k}.K=struct('values',z.K.values(i,:));
 z=load(fullfile(out,[sat '_L_kinematic.mat']),'L');[yes,i]=ismember(t,z.L.values(:,1));assert(all(yes));navs{k}.L=struct('values',z.L.values(i,:));
 z=load(fullfile(source,[sat '_L_search3m.mat']),'L');[yes,i]=ismember(t,z.L.values(:,1));assert(all(yes));navs{k}.R=struct('values',z.L.values(i,:));
 refs{k}=load(fullfile(source,'fresh_force_reference',[sat '_all_density.mat']),'d','bias');
end
report=struct('GNSS_quality_epochs',originalQualityCount,'matched_navigation_epochs',numel(t));tags={'K','L','R'};
for sat='AB'
 k=double(sat)-64;v=gnss_density_kinematic_window(refs{k}.d,navs{k},1200,[-inf inf],true);
 for name=tags,z=v.(name{1}).values;z(:,4)=z(:,4)-refs{k}.bias/1e-6*z(:,6);writematrix(z,fullfile(out,[sat '_' name{1} '_quality_density.csv']));report.checks.(sat).(name{1})=rmfield(v.(name{1}),'values');end
end
old=load(fullfile(root,'bridge_force_density_run','comparison.mat'));old=old.series{1};series=cell(3,1);
for k=1:3
 a=readmatrix(fullfile(out,['A_' tags{k} '_quality_density.csv']));b=readmatrix(fullfile(out,['B_' tags{k} '_quality_density.csv']));[tt,ia,ib]=intersect(a(:,1),b(:,1));g=b(ib,2)-a(ia,2);acc=b(ib,4)-a(ia,4);series{k}=[tt,g,acc];
 [~,i,j]=intersect(tt,old.t);m=old.mask(j);report.(tags{k})=score(g(i(m)),acc(i(m)));writematrix(series{k},fullfile(out,[tags{k} '_quality_differential_density.csv']));
end
report.note='Same GNSS-only formal range-sigma flag (<=10 cm) for all branches; 20-minute density, native positions, missing observations allowed with continuous physical force fit except >600-s measurement gaps or force-reference gaps. K=kinematic with inherited240 independent integers; L=kinematic own135; R=previous reduced-dynamic240 sampled at identical epochs. Prior assisted timestamps are evaluation only; ACC retains prior constant calibration.';
f=fopen(fullfile(out,'quality_density_comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);save(fullfile(out,'quality_density_comparison.mat'),'series','report');
z=load(fullfile(out,'range_comparison.mat'),'t','rv');q=load(fullfile(out,'gnss_quality.mat'),'t','quality');[~,i,j]=intersect(z.t,q.t);m=q.quality(j)&all(isfinite(z.rv(i,:)),2);tr=z.t(i(m));rr=z.rv(i(m),:);rr([false;diff(tr)>10.1],:)=NaN;
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1500 1050]);tiledlayout(3,1);
nexttile;plot((tr-16)/3600,rr(:,[1 3 4])*1000);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title('GNSS-only uncertainty support; no range filtering');legend('Reduced dynamic240','Pure kinematic135','Kinematic inherited240');
for k=1:2
 nexttile;v=series{k};[tt,i,j]=intersect(v(:,1),old.t);m=old.mask(j);vals=v(i,2:3)*1e12;vals(~m|[false;diff(tt)>1.1],:)=NaN;plot((tt-16)/3600,vals);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('GNSS','ACC');
 if k==1,title('20-minute density: kinematic positions, inherited independent integers');else,title('20-minute density: entirely kinematic ambiguity estimation');end
end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(out,'kinematic_quality_comparison.png'),'Resolution',150);close(fig);disp(report);
end
function s=score(g,a)
m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));
end
