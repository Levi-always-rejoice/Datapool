function report=plot_grace_update_comparison(folder)
% Plot SAVED OUTPUTS only. This routine is never called to form estimator inputs.
% CSV times are GPS seconds of 2015-03-15; UTC=GPS-16 seconds.
c=readmatrix(fullfile(folder,'common_view_density.csv'));
d=readmatrix(fullfile(folder,'direct_density.csv'));
[t,ic,id]=intersect(c(:,1),d(:,1));c=c(ic,:);d=d(id,:);
report=struct;late=t>=72016;common=logical(c(:,5));support=logical(d(:,4));
names={'common_view_independent','common_view_POD_assisted','direct_independent'};
v=[c(:,2:3),d(:,2)];a=c(:,4);
for j=1:3
 aj=a;if j==3,aj=d(:,3);end
 report.(names{j})=struct('last4',score(v(late,j),aj(late)),...
 'comparison_support',score(v(common,j),aj(common)),...
 'GNSS_support',score(v(support,j),aj(support)), 'all',score(v(:,j),aj));
end
report.ACC_reference_difference_RMS=sqrt(mean((d(:,3)-a).^2,'omitnan'));
report.ACC_reference_difference_last4_RMS=sqrt(mean((d(late,3)-a(late)).^2,'omitnan'));
report.note='Saved 2015 outputs; no new filtering, fitted lag, scale or mean removal. Independent branches retain partial relative fixes. POD assistance concerns integer constraints in the common-view control. Common support and all outputs are explicitly separate. Last-four-hour comparisons use all finite available centers.';
f=fopen(fullfile(folder,'plot_metrics.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
set(groot,'defaultFigureVisible','off');colors=[0 .40 .72;.87 .34 .08];
fig=figure('Position',[20 20 1500 950]);tiledlayout(3,1,'TileSpacing','compact');
nexttile;draw(t,v(:,1:2),a,common,[0 24],[-.2 .2],colors);
title('GRACE 2015-03-15: updated common-view fit, independent vs POD-assisted integers');
legend('Independent GNSS','POD-assisted GNSS','ACC reference','Location','northoutside','Orientation','horizontal');
nexttile;draw(t,v(:,1:2),a,true(size(t)),[20 24],[-.18 .18],colors);
x=report.common_view_independent.last4;y=report.common_view_POD_assisted.last4;
title(sprintf('20-min density, last 4 h: RMS %.2f / %.2f x 10^{-14}; correlation %.3f / %.3f',x.RMS*1e14,y.RMS*1e14,x.r,y.r));
nexttile;draw(t,v(:,[3 2]),d(:,3),true(size(t)),[20 24],[-.18 .18],colors);
title('Subsequent direct carrier-difference update vs common-view POD-assisted control');
legend('Independent direct carrier differences','POD-assisted common-view fit','ACC reference','Location','northoutside','Orientation','horizontal');
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(folder,'GRACE2015_updated_independent_vs_assisted.png'),'Resolution',150);close(fig);
fig=figure('Position',[20 20 1500 760]);tiledlayout(2,1,'TileSpacing','compact');
nexttile;draw(t,v(:,1:2),a,true(size(t)),[0 24],[],colors);title('Common-view independent / assisted: all outputs, full scale');legend('Independent GNSS','POD-assisted GNSS','ACC reference');
nexttile;draw(t,v(:,[3 2]),d(:,3),true(size(t)),[0 24],[],colors);title('Direct independent / common-view assisted: all outputs, full scale');xlabel('UTC hour, 2015-03-15');
exportgraphics(fig,fullfile(folder,'GRACE2015_updated_all_outputs_fullscale.png'),'Resolution',150);close(fig);
if isfile(fullfile(folder,'range_residuals.csv'))
 r=readmatrix(fullfile(folder,'range_residuals.csv'));fig=figure('Position',[20 20 1500 750]);tiledlayout(2,1,'TileSpacing','compact');
 for k=1:2
  nexttile;rr=r(:,2:4)*1000;rr([false;diff(r(:,1))>5.1],:)=NaN;
  plot((r(:,1)-16)/3600,rr,'LineWidth',1.6);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');
  if k==1,ylim([-15 15]);title('Updated GRACE 2015 relative range; no additional filtering');else,title('Same residuals, full scale');end
 end
 legend('Independent common-view','POD-assisted common-view','Independent direct differences','Location','northoutside','Orientation','horizontal');xlabel('UTC hour, 2015-03-15');
 exportgraphics(fig,fullfile(folder,'GRACE2015_updated_range.png'),'Resolution',150);close(fig);
end
end
function draw(t,v,a,mask,xl,yl,colors)
v(~mask|[false;diff(t)>1.1],:)=NaN;a(~mask|[false;diff(t)>1.1])=NaN;hold on;
for j=1:2,plot((t-16)/3600,v(:,j)*1e12,'Color',colors(j,:),'LineWidth',1.7);end
plot((t-16)/3600,a*1e12,'k','LineWidth',1.4);grid on;xlim(xl);if ~isempty(yl),ylim(yl);end
ylabel('\Delta\rho (10^{-12} kg/m^3)');
if ~isempty(yl)
 ix=(t-16)/3600>=xl(1)&(t-16)/3600<=xl(2);z=[v(ix,:),a(ix)]*1e12;n=nnz(any(z<yl(1)|z>yl(2),2));
 if n>0,text(.99,.04,sprintf('%d centers exceed shown scale; full-scale figure included',n),'Units','normalized','HorizontalAlignment','right','FontSize',9);end
end
end
function s=score(g,a)
m=isfinite(g)&isfinite(a);cc=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',sqrt(mean((g(m)-a(m)).^2)),'r',cc(1,2));
end
