function root=grace_update_input_root(workspace)
% Raw products remain package inputs; generated checkpoints stay in the run.
marker=fullfile(workspace,'input_root.txt');
if isfile(marker),root=strtrim(fileread(marker));else,root=workspace;end
assert(isfolder(fullfile(root,'raw'))&&isfolder(fullfile(root,'models')));
end
