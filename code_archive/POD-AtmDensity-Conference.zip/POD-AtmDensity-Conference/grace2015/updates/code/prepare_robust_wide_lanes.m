function report=prepare_robust_wide_lanes(source,out,coverageAware,oldGraphFile)
% GNSS-only robust MW track relations. No reference orbit/range/ACC reads.
% One-minute medians reduce isolated code contamination. Alternating 300-s
% folds check repeatability, but are not a calibrated integer failure rate.
if nargin<3,coverageAware=false;end
if nargin<4,oldGraphFile=fullfile(source,'independent_graph1.mat');end
if ~isfolder(out),mkdir(out);end
z=load(fullfile(source,'A_float_model.mat'),'model');a=z.model.q;clear z;
z=load(fullfile(source,'B_float_model.mat'),'model');b=z.model.q;clear z;
assert(~isfield(a,'pod_r')&&~isfield(b,'pod_r'));
old=load(oldGraphFile,'result');old=old.result;
[t,ia,ib]=intersect(a.t,b.t);nc=numel(a.B0);nb=nc+numel(b.B0);
lw=299792458/(1575.42e6-1227.6e6);mw=(b.mw(ib,:)-a.mw(ia,:))/lw;
good=a.good(ia,:)&b.good(ib,:)&isfinite(mw);la=a.labels(ia,:);lb=b.labels(ib,:);
pieces=cell(numel(t),1);
for e=1:numel(t)
 ps=find(good(e,:));if numel(ps)<2,continue;end
 pr=nchoosek(ps,2);p=pr(:,1);r=pr(:,2);
 pieces{e}=[p,r,la(e,p)',lb(e,p)',la(e,r)',lb(e,r)',repmat(e,numel(p),1),(mw(e,p)-mw(e,r))'];
end
records=vertcat(pieces{:});[keys,~,grp]=unique(records(:,1:6),'rows','stable');[grp,ord]=sort(grp);records=records(ord,:);edges=[1;find(diff(grp))+1;numel(grp)+1];
accepted=old.c.accepted(old.wideOK);oldKeys=vertcat(accepted.key);
H=old.c.A(old.wideOK,:);W=old.c.WL(old.wideOK);[U,R,piv]=qr(H','econ','vector');rk=sum(abs(diag(R))>1e-9);H=H(piv(1:rk),:);W=W(piv(1:rk));U=U(:,1:rk);
% A particular WL solution permits exact graph consistency checks, including
% dependencies caused by reusing individual receiver tracking labels.
x=H'*((H*H')\W);audit=nan(numel(edges)-1,17);candidate=struct('key',{},'rows',{},'WL',{},'NL',{},'target',{},'score',{});candidateIndex=[];
for g=1:numel(edges)-1
 rec=records(edges(g):edges(g+1)-1,:);key=keys(grp(edges(g)),:);rows=rec(:,7);v=rec(:,8);audit(g,1:8)=[key,numel(rows),numel(unique(floor(t(rows)/60)))];
 if size(rec,1)<30||audit(g,8)<5,continue;end
 est=nan(1,3);se=est;counts=est;pass=true;membership=mod(floor(t(rows)/300),2);
 % Choose a validation partition from sampling support only, before looking
 % at MW values. Never try alternative partitions until an integer passes.
 if coverageAware
  enough=true;for f=0:1,enough=enough&&nnz(membership==f)>=12&&numel(unique(floor(t(rows(membership==f))/60)))>=2;end
  if ~enough,membership=zeros(size(rows));membership(floor(numel(rows)/2)+1:end)=1;end
 end
 for k=1:3
  use=true(size(rows));if k>1,use=membership==k-2;end
  [~,~,ii]=unique(floor(t(rows(use))/60));wm=accumarray(ii,v(use),[],@median);counts(k)=numel(wm);
  if nnz(use)<12||numel(wm)<2,pass=false;continue;end
  est(k)=median(wm);se(k)=max(.025,1.4826*median(abs(wm-est(k)))/sqrt(numel(wm)));
 end
 wi=round(est(1));pass=pass&&all(abs(est-wi)<.2)&&all(abs(est-wi)+3*se<.5)&&all(se<.12)&&abs(est(2)-est(3))<.25;
 audit(g,9:17)=[est,se,double(pass),wi,mean(v)-wi];
 if pass&&~ismember(key,oldKeys,'rows')
  candidate(end+1)=struct('key',key,'rows',rows,'WL',wi,'NL',NaN,'target',NaN,'score',max(se));candidateIndex(end+1)=g; %#ok<AGROW>
 end
end
[~,order]=sort([candidate.score]);rejected=0;new=0;newRank=0;
for k=order
 cc=candidate(k);key=cc.key;h=zeros(1,nb);h([key(3),nc+key(4),key(5),nc+key(6)])=[-1,1,1,-1];
 v=h' - U*(U'*h');v=v-U*(U'*v);nv=norm(v);delta=cc.WL-h*x;
 if nv<1e-8
  if abs(delta)>1e-7,rejected=rejected+1;audit(candidateIndex(k),15)=-1;continue;end
 else
  u=v/nv;x=x+u*(delta/nv);U=[U,u];newRank=newRank+1;
 end
 accepted(end+1)=cc;new=new+1; %#ok<AGROW>
end
A=zeros(numel(accepted),nb);
for j=1:numel(accepted),key=accepted(j).key;A(j,[key(3),nc+key(4),key(5),nc+key(6)])=[-1,1,1,-1];end
WL=[accepted.WL]';assert(max(abs(A*x-WL))<1e-7,'WL graph contradiction');
c=struct('A',A,'WL',WL,'accepted',{accepted},'t',t,'ia',ia,'ib',ib);
result=struct('c',c,'wideOK',true(size(WL)));
save(fullfile(out,'robust_wide_lanes.mat'),'result','audit','-v7.3');
writematrix(audit,fullfile(out,'robust_wide_lane_candidates.csv'));
report=struct('old_WL_relations',numel(old.c.WL(old.wideOK)),'old_WL_rank',rk,'tested_track_pairs',size(audit,1),'robust_pass',nnz(audit(:,15)==1),'new_relations',new,'new_independent_WL_directions',newRank,'new_WL_rank',size(U,2),'graph_conflicts_rejected',rejected,'coverage_aware_partition',coverageAware,'no_reference_inputs',true);
f=fopen(fullfile(out,'robust_wide_lanes.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
