function test_robust_wide_lanes(folder)
% Regression: a five-minute pass falls wholly in one old validation fold.
% Isolated code outliers bias a mean by >0.5 cycle, but not minute medians.
if ~isfolder(folder),mkdir(folder);end
t=(0:10:290)';n=numel(t);lw=299792458/(1575.42e6-1227.6e6);W=[0;2;-4;7];
q=struct('t',t,'B0',zeros(4,1),'labels',zeros(n,33),'good',false(n,33),'mw',nan(n,33));
q.labels(:,2:5)=repmat(1:4,n,1);q.good(:,2:5)=true;q.mw(:,2:5)=0;
model=struct('q',q);save(fullfile(folder,'A_float_model.mat'),'model');
q.mw(:,2:5)=lw*(W'+.002*sin((1:n)'*(1:4)));q.mw(3:6:end,4)=q.mw(3:6:end,4)+4*lw;
model=struct('q',q);save(fullfile(folder,'B_float_model.mat'),'model');
A=zeros(1,8);A([1,5,2,6])=[-1,1,1,-1];
cc=struct('key',[2 3 1 1 2 2],'rows',(1:n)','WL',W(1)-W(2),'NL',NaN,'target',NaN,'score',.025);
result=struct('c',struct('A',A,'WL',cc.WL,'accepted',cc),'wideOK',true);save(fullfile(folder,'independent_graph1.mat'),'result');
r0=prepare_robust_wide_lanes(folder,fullfile(folder,'old'),false);r1=prepare_robust_wide_lanes(folder,fullfile(folder,'coverage'),true);
assert(r0.new_WL_rank==1&&r1.new_WL_rank==3,'Short-pass coverage validation regression');
z=load(fullfile(folder,'coverage','robust_wide_lanes.mat'),'result');c=z.result.c;assert(max(abs(c.A*[zeros(4,1);W]-c.WL))==0,'Robust WL recovered wrong integers');
fprintf('PASS: isolated code outliers and short-pass validation preserve the true integer relations.\n');
end
