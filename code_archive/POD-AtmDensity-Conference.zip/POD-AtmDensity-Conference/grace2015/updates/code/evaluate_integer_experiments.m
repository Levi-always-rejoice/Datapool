function evaluate_integer_experiments(baseline,out,onlyJ)
% Freeze force geometry, ACC calibration and evaluation support. No score
% from KBR or ACC feeds back into integer selection or navigation fitting.
if nargin<3,onlyJ=false;end
diary(fullfile(out,'evaluation.log'));cleanup=onCleanup(@()diary('off'));names={'I','C1','C4','G'};if onlyJ,names={'J'};end;data=struct;navs=struct;
for sat='AB'
 x=load(fullfile(baseline,[sat '_all_density.mat']));z=load(fullfile(baseline,[sat '_branches.mat']));branches=struct;
 for j=1:numel(names)
  name=names{j};if strcmp(name,'I'),n=load(fullfile(out,[sat '_integer_only.mat']));branches.I=n.I;elseif strcmp(name,'J'),n=load(fullfile(out,[sat '_J.mat']));branches.J=n.J;else,n=load(fullfile(out,[sat '_' name '.mat']));branches.(name)=n.C;end
 end
 fprintf('%s: matched density operator for four integer variants\n',sat);density=gnss_density_many(x.d,branches);
 for j=1:numel(names)
  name=names{j};v=density.(name).values;v(:,4)=v(:,4)-x.bias/1e-6*v(:,6);density.(name).values=v;density.(name).supported=x.maskOriginal;
  writematrix([v,x.maskOriginal,x.maskFixed],fullfile(out,[sat '_' name '_density.csv']));
 end
 if onlyJ
  previous=load(fullfile(out,[sat '_experiment_density.mat']),'density');oldnames={'I','C1','C4','G'};
  for k=1:numel(oldnames)
   name=oldnames{k};density.(name)=previous.density.(name);
   if strcmp(name,'I'),nn=load(fullfile(out,[sat '_integer_only.mat']));branches.I=nn.I;else,nn=load(fullfile(out,[sat '_' name '.mat']));branches.(name)=nn.C;end
  end
 end
 density.F=x.density.F;density.R=x.density.R;density.P=x.density.P;branches.F=z.F;branches.R=z.R;branches.P=z.P;
 data.(sat)=struct('density',density,'d',x.d,'original',x.maskOriginal,'fixed',x.maskFixed);navs.(sat)=branches;
 save(fullfile(out,[sat '_experiment_density.mat']),'density','-v7.3');
end
names={'F','R','C1','C4','G','I','P'};if onlyJ,names={'F','R','C1','C4','G','I','J','P'};end;a=data.A;b=data.B;[t,ia,ib]=intersect(a.density.R.values(:,1),b.density.R.values(:,1));u=(t-16)/3600;
original=a.original(ia)&b.original(ib);fixed=a.fixed(ia)&b.fixed(ib);
k=load(fullfile(baseline,'range_comparison.mat'));kt=k.range.t;
PA=gnss_hermite(a.d.pod_t,a.d.pod_r,a.d.pod_v);PB=gnss_hermite(b.d.pod_t,b.d.pod_r,b.d.pod_v);podRange=vecnorm(ppval(PB,kt')'-ppval(PA,kt')',2,2);aligned=podRange-k.range.POD;
[yes,loc]=ismember(kt,t);rangeMask=false(size(kt));rangeMask(yes)=fixed(loc(yes));
report=struct;ranges=struct('t',kt,'POD',k.range.POD);
ra=interp1(a.d.t,a.d.r,t,'spline');rb=interp1(b.d.t,b.d.r,t,'spline');e=(rb-ra)./vecnorm(rb-ra,2,2);
ka=sum(e.*interp1(a.d.t,a.d.K.*a.d.drag,t,'spline'),2);kb=sum(e.*interp1(b.d.t,b.d.K.*b.d.drag,t,'spline'),2);
for j=1:numel(names)
 name=names{j};av=a.density.(name).values(ia,:);bv=b.density.(name).values(ib,:);
 x=navs.A.(name).values;y=navs.B.(name).values;
 ranges.(name)=vecnorm(interp1(x(:,1),x(:,2:4),kt)-interp1(y(:,1),y(:,2:4),kt),2,2)-aligned;
 report.(name)=struct('full_range_RMS_mm',1e3*rms(ranges.(name)),'matched_P_range_RMS_mm',1e3*rms(ranges.(name)(rangeMask)));
 report.(name).original_support=stats(av,bv,ka,kb,original);
 report.(name).fixed_support=stats(av,bv,ka,kb,fixed);
 report.(name).S1=stats(av,bv,ka,kb,fixed&u>=3.25&u<4.25);
 report.(name).S2=stats(av,bv,ka,kb,fixed&u>=9+40/60&u<10+25/60);
 % Unmasked orbital errors are reference comparisons, not fitting inputs.
 report.(name).orbit_A_RMS_m=rms(vecnorm(x(:,2:4)-ppval(PA,x(:,1)')',2,2));
 report.(name).orbit_B_RMS_m=rms(vecnorm(y(:,2:4)-ppval(PB,y(:,1)')',2,2));
end
f=fopen(fullfile(out,'comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
rows=zeros(numel(names),8);
for j=1:numel(names)
 s=report.(names{j});rows(j,:)=[s.full_range_RMS_mm,s.matched_P_range_RMS_mm,s.original_support.RMS,s.original_support.r,s.fixed_support.RMS,s.fixed_support.r,s.S1.RMS,s.S2.RMS];
end
writetable(array2table(rows,'RowNames',names,'VariableNames',{'Range_full_mm','Range_matched_mm','Density_original_RMS','Density_original_r','Density_matched_RMS','Density_matched_r','S1_RMS','S2_RMS'}),fullfile(out,'comparison.csv'),'WriteRowNames',true);
make_plots(out,t,a,b,ia,ib,original,fixed,ranges);save(fullfile(out,'range_experiments.mat'),'ranges');disp(report);
end
function s=stats(a,b,ka,kb,m)
dn=b(:,2)-a(:,2);dr=b(:,4)-a(:,4);c=corrcoef(dn(m),dr(m));err=dn(m)-dr(m);
s=struct('centers',nnz(m),'RMS',rms(err),'r',c(1,2),'bias',mean(err),'demeaned_RMS',std(err,1),'projected_drag_RMS_mps2',rms(kb(m).*(b(m,2)-b(m,4))-ka(m).*(a(m,2)-a(m,4))));
end
function make_plots(out,t,a,b,ia,ib,original,fixed,ranges)
set(groot,'defaultFigureVisible','off');u=(t-16)/3600;acc=b.density.R.values(ib,4)-a.density.R.values(ia,4);
names={'R','C1','I','P'};if isfield(a.density,'J'),names={'R','I','J','P'};end
fig=figure('Position',[20 20 1350 1050]);tiledlayout(4,1);
titles={'R: original GNSS-only, 188 integers','C1: separated-block validation','I: assisted integers only, remaining offsets estimated from GNSS','P: original assisted complete offsets and mask'};
if isfield(a.density,'J'),titles={'R: original GNSS-only integers','I: assisted integers only, original phase mask','J: connected fixed-only phase mask, common offsets estimated from GNSS','P: original assisted complete offsets and mask'};end
for j=1:4
 name=names{j};dn=b.density.(name).values(ib,2)-a.density.(name).values(ia,2);m=original;if any(strcmp(name,{'J','P'})),m=fixed;end
 dn(~m)=NaN;ref=acc;ref(~m)=NaN;nexttile;plot(u,dn*1e12,'Color',[0 .45 .7]);hold on;plot(u,ref*1e12,'k');title(titles{j});grid on;xlim([0 24]);ylim([-.8 .8]);ylabel('\Delta\rho (10^{-12})');legend('GNSS','ACC');
end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'density_integer_tests.png'),'Resolution',150);close(fig);
fig=figure('Position',[20 20 1350 700]);tiledlayout(2,1);limits=[3.25 4.25;9+40/60 10+25/60];
for k=1:2,nexttile;hold on;
 ns={'R','I','P'};if isfield(a.density,'J'),ns={'R','J','P'};end
 for name=ns
  dn=b.density.(name{1}).values(ib,2)-a.density.(name{1}).values(ia,2);dn(~fixed)=NaN;plot(u,dn*1e12,'DisplayName',name{1});
 end
 ref=acc;ref(~fixed)=NaN;plot(u,ref*1e12,'k','LineWidth',1.5,'DisplayName','ACC');grid on;xlim(limits(k,:));ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('Location','best');
end
xlabel('UTC hour');exportgraphics(fig,fullfile(out,'matched_segments.png'),'Resolution',150);close(fig);
fig=figure('Position',[20 20 1350 800]);tiledlayout(3,1);x=(ranges.t-16)/3600;
for k=1:3,nexttile;hold on;if k==1,ns={'F','R','C1'};elseif k==2,ns={'R','C4','G'};else,ns={'R','I','P'};if isfield(ranges,'J'),ns={'I','J','P'};end;end
 for name=ns,plot(x,1e3*ranges.(name{1}),'DisplayName',name{1});end
 plot(x,1e3*ranges.POD,'k','DisplayName','POD');legend;grid on;ylabel('GNSS - KBR (mm)');xlim([0 24]);
end
xlabel('UTC hour');exportgraphics(fig,fullfile(out,'range_integer_tests.png'),'Resolution',150);close(fig);
end
