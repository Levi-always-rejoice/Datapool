function test_ten_minute_density(baseline,navdir,out,verifyReference)
if nargin<4,verifyReference=true;end
if ~isfolder(out),mkdir(out);end
z=load(fullfile(navdir,'history_mask.mat'));mask=z.mask;
z=load(fullfile(navdir,'P_integer_audit.mat'));c=z.audit.candidate_detail;
z=load(fullfile(navdir,'B_raw_design.mat'),'q');b=z.q;info=zeros(numel(c.t),9);
for e=1:numel(c.t)
 ps=find(mask(e,:));if numel(ps)<2,continue;end
 h=squeeze(b.h(c.ib(e),ps,:));w=max(sin(b.elev(c.ib(e),ps)'),.25).^2;
 h=h-sum(h.*w,1)/sum(w);I=h'*(w.*h);info(e,:)=I(:)';
end
support=c.t(sum(mask,2)>=2);checks=struct;
for sat='AB'
 x=load(fullfile(baseline,[sat '_all_density.mat']));n=load(fullfile(navdir,[sat '_J.mat']));
 for minutes=[20 10]
  seconds=minutes*60;half=seconds/2;density=gnss_density_window(x.d,n,seconds);v=density.J.values;v(:,4)=v(:,4)-x.bias/1e-6*v(:,6);
  supported=false(size(v,1),1);
  for j=1:numel(supported)
   s=support(support>=v(j,1)-half&support<v(j,1)+half);use=c.t>=v(j,1)-half&c.t<v(j,1)+half;
   I=reshape(sum(info(use,:),1),3,3);eigI=eig((I+I')/2);
   supported(j)=numel(s)>=.9*seconds/10&&max(diff([v(j,1)-half;s(:);v(j,1)+half]))<=.1*seconds&&min(eigI)>1e-3&&max(eigI)/min(eigI)<1000;
  end
  if minutes==20&&verifyReference
   old=readmatrix(fullfile(navdir,[sat '_history_density.csv']));assert(isequal(v(:,1),old(:,1)));err=max(abs(v(:,2:6)-old(:,2:6)),[],'all');assert(err<1e-20,'20-minute regression mismatch');assert(isequal(supported,logical(old(:,8))));checks.(sat).regression_error=err;
  end
  checks.(sat).(['min' num2str(minutes)])=struct('injection_error',density.J.injection_error,'QR_difference',density.J.QR_difference);
  writematrix([v,supported],fullfile(out,sprintf('%s_%dmin.csv',sat,minutes)));
 end
end
f=fopen(fullfile(out,'checks.json'),'w');fprintf(f,'%s',jsonencode(checks,PrettyPrint=true));fclose(f);
results=struct;series=cell(2,1);windows=[20 10];
for k=1:2
 w=windows(k);a=readmatrix(fullfile(out,sprintf('A_%dmin.csv',w)));b=readmatrix(fullfile(out,sprintf('B_%dmin.csv',w)));[t,ia,ib]=intersect(a(:,1),b(:,1));a=a(ia,:);b=b(ib,:);
 series{k}=struct('t',t,'gnss',b(:,2)-a(:,2),'pod',b(:,3)-a(:,3),'acc',b(:,4)-a(:,4),'mask',a(:,8)>0&b(:,8)>0);
end
[~,ia,ib]=intersect(series{1}.t,series{2}.t);common=series{1}.mask(ia)&series{2}.mask(ib);indices={ia,ib};
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 850]);tiledlayout(2,1);
for k=1:2
 s=series{k};ix=indices{k};results.(['min' num2str(windows(k))])=struct('all',score(s.gnss,s.acc,s.mask),'matched',score(s.gnss(ix),s.acc(ix),common),'POD_matched',score(s.pod(ix),s.acc(ix),common));
 nexttile;bad=~s.mask|[false;diff(s.t)>1.1];v=s.gnss;v(bad)=NaN;r=s.acc;r(bad)=NaN;plot((s.t-16)/3600,v*1e12);hold on;plot((s.t-16)/3600,r*1e12,'k');grid on;xlim([0 24]);ylim([-.8 .8]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('%d-minute density window; identical navigation and integer constraints',windows(k)));legend('GNSS','ACC');
end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(out,'density_10_vs_20.png'),'Resolution',150);close(fig);
f=fopen(fullfile(out,'comparison.json'),'w');fprintf(f,'%s',jsonencode(results,PrettyPrint=true));fclose(f);save(fullfile(out,'comparison.mat'),'series','results','common','indices');disp(results);
end
function s=score(x,y,m)
c=corrcoef(x(m),y(m));s=struct('centers',nnz(m),'day_percent',nnz(m)/864,'RMS',rms(x(m)-y(m)),'r',c(1,2));
end
