function audit_13_15(package,root)
out=fullfile(root,'audit_13_15');if ~isfolder(out),mkdir(out);end
base=grace_update_baseline(package);navdir=fullfile(root,'bridge_force_run');raw=fullfile(grace_update_input_root(package),'raw');
dirs={'ten_minute_run','bridge_density_run','bridge_force_density_run','sparse_window_run'};names={'Original','Connected, old forces','Connected, repaired forces','Missing epochs allowed'};
summary=struct;series=cell(4,1);set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1500 1600]);tiledlayout(6,1);
for j=1:4,z=load(fullfile(root,dirs{j},'comparison.mat'));series{j}=z.series;end
for w=1:2
 nexttile;hold on;
 for j=[1 3 4]
  s=series{j}{w};m=s.mask&s.t>=13*3600+16&s.t<=15*3600+16;
  summary.(dirs{j}).(sprintf('min%d',30-10*w))=score(s.gnss,s.acc,s.t,m);
  v=s.gnss;v(~s.mask|[false;diff(s.t)>1.1])=NaN;plot((s.t-16)/3600,v*1e12);
 end
 s=series{4}{w};v=s.acc;v(~s.mask)=NaN;plot((s.t-16)/3600,v*1e12,'k');xlim([13 15]);grid on;ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('%d-minute density',30-10*w));legend([names([1 3 4]),{'ACC'}]);
end
r=load(fullfile(root,'bridge_force_density_run','range_comparison.mat'));nexttile;plot((r.t-16)/3600,r.rv*1e3);xlim([13 15]);grid on;ylabel('Range - KBR (mm)');legend('Original','Connected, repaired forces');
z=load(fullfile(navdir,'P_integer_audit.mat'));c=z.audit.candidate_detail;info=nan(numel(c.t),1);counts=sum(c.mask,2);pre=cell(2,1);post=cell(2,1);orbit=cell(2,1);labels=cell(2,1);known=cell(2,1);qall=cell(2,1);
for sat='AB'
 j=double(sat)-64;z=load(fullfile(navdir,[sat '_raw_design.mat']));q=z.q;qall{j}=q;z=load(fullfile(navdir,[sat '_J.mat']));n=z.J;
 if sat=='A',ii=c.ia;else,ii=c.ib;end
 lab=max(q.labels(ii,:),1);B=reshape(n.ambiguities(lab(:)),size(lab));
 pre{j}=q.phase(ii,:)-sum(q.h(ii,:,:).*reshape(q.pod_r(ii,:)-q.r(ii,:),[],1,3),3)-B;pre{j}(~c.mask)=NaN;
 [yes,ix]=ismember(q.t(ii),n.values(:,1));[yc,ic]=ismember(q.t(ii),n.clock(:,1));valid=yes&yc;
 rr=nan(size(c.mask));rr(valid,:)=q.phase(ii(valid),:)-sum(q.h(ii(valid),:,:).*reshape(n.values(ix(valid),2:4)-q.r(ii(valid),:),[],1,3),3)-n.clock(ic(valid),2)-B(valid,:);rr(~c.mask)=NaN;post{j}=rr;labels{j}=q.labels(ii,:);
 for e=1:numel(c.t)
  ps=find(c.mask(e,:));h=squeeze(q.h(ii(e),ps,:));if numel(ps)<4,continue;end
  sv=svd([h,ones(numel(ps),1)]);info(e)=sv(1)/sv(end);
 end
 z=load(fullfile(base,[sat '_all_density.mat']),'d');P=gnss_hermite(z.d.pod_t,z.d.pod_r,z.d.pod_v);p=ppval(P,n.values(:,1)')';orbit{j}=[n.values(:,1),n.values(:,2:4)-p];
 thr=read_grace_ascii(fullfile(raw,sprintf('THR1B_2015-03-15_%s_02.asc',sat)),[1 2 19:32 47]);v=thr.values;t=v(:,1)+v(:,2)*1e-6;ms=sum(v(:,3:16),2);sel=t>=13*3600+16&t<=15*3600+16&ms>0;
 summary.thrusters.(sat)=struct('positive_on_time_records_13_15',nnz(sel),'nonzero_quality_records',nnz(v(sel,end)~=0),'summed_channel_ms',sum(ms(sel)));
 writematrix([t(sel),(t(sel)-16)/3600,ms(sel),v(sel,end)],fullfile(out,[sat '_thruster_records.csv']));known{j}=[t ms];
end
nexttile;yyaxis left;stairs((c.t-16)/3600,counts);ylabel('Fixed GPS count');yyaxis right;semilogy((c.t-16)/3600,info);ylabel('Instantaneous design condition');xlim([13 15]);grid on;
P=(pre{2}-pre{1})*1e3;P=P-median(P,2,'omitnan');D=(post{2}-post{1})*1e3;
nexttile;sel=c.t>=13*3600+16&c.t<=15*3600+16;prns=find(any(c.mask(sel,:),1));plot((c.t(sel)-16)/3600,P(sel,prns));grid on;xlim([13 15]);ylabel('POD-reference phase (mm)');title('Per GPS B-A phase minus POD geometry and saved offsets; common median clock removed');legend(compose('G%02d',prns-1),'Location','eastoutside');
nexttile;hold on;for j=1:2,v=known{j};mins=floor((v(:,1)-16)/60);inside=mins>=0&mins<1440;bin=accumarray(mins(inside)+1,v(inside,2),[1440 1]);stairs((0:1439)/60,bin);end;xlim([13 15]);grid on;ylabel('Commanded channel ms/min');xlabel('UTC hour, 2015-03-15');legend('A','B');
exportgraphics(fig,fullfile(out,'diagnostics_13_15.png'),'Resolution',150);close(fig);
rows=[];
for lo=13:1/6:15-1/6
 m=c.t>=lo*3600+16&c.t<(lo+1/6)*3600+16;ph=P(m,:);po=D(m,:);cnt=counts(m);co=info(m);changed=0;
 for j=1:2,ll=labels{j};same=c.mask(2:end,:)&c.mask(1:end-1,:);jump=ll(2:end,:)~=ll(1:end-1,:)&same;changed=changed+nnz(jump(m(2:end),:));end
 rows=[rows;lo,min(cnt),median(cnt),max(co,[],'omitnan'),rms(ph(isfinite(ph))),max(abs(ph),[],'all','omitnan'),rms(po(isfinite(po))),changed]; %#ok<AGROW>
end
writetable(array2table(rows,'VariableNames',{'start_UTC_hour','minimum_fixed_GPS','median_fixed_GPS','maximum_instant_condition','POD_reference_phase_RMS_mm','POD_reference_phase_max_mm','postfit_SD_RMS_mm','selected_label_changes'}),fullfile(out,'phase_support_10min.csv'));
save(fullfile(out,'diagnostics.mat'),'P','D','c','counts','info','orbit','labels','known','summary');
f=fopen(fullfile(out,'summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
end
function s=score(x,y,t,m)
e=x(m)-y(m);tt=t(m);[peak,i]=max(abs(e));s=struct('centers',nnz(m),'RMS',rms(e),'peak_abs_error',peak,'peak_UTC_hour',(tt(i)-16)/3600);c=corrcoef(x(m),y(m));s.r=c(1,2);
end
