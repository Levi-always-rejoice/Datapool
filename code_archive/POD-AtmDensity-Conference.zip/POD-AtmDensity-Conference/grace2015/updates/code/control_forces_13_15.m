function control_forces_13_15(package,root)
out=fullfile(root,'audit_13_15');navdirs={'bridge_run','bridge_force_run'};forcedirs={fullfile(root,'bridge_force_reference'),grace_update_baseline(package)};tags={'old_nav_repaired_density_forces','repaired_nav_old_density_forces'};
summary=struct;
for test=1:2
 for sat='AB'
  z=load(fullfile(forcedirs{test},[sat '_all_density.mat']),'d','bias');n=load(fullfile(root,navdirs{test},[sat '_J.mat']));
  for minutes=[20 10]
   r=gnss_density_sparse_window(z.d,n,minutes*60,[13*3600+16 15*3600+16]);v=r.J.values;v(:,4)=v(:,4)-z.bias/1e-6*v(:,6);writematrix(v,fullfile(out,sprintf('%s_%s_%dmin.csv',tags{test},sat,minutes)));
  end
 end
 for minutes=[20 10]
  a=readmatrix(fullfile(out,sprintf('%s_A_%dmin.csv',tags{test},minutes)));b=readmatrix(fullfile(out,sprintf('%s_B_%dmin.csv',tags{test},minutes)));[t,ia,ib]=intersect(a(:,1),b(:,1));g=b(ib,2)-a(ia,2);acc=b(ib,4)-a(ia,4);err=g-acc;cc=corrcoef(g,acc);[pk,k]=max(abs(err));summary.(tags{test}).(sprintf('min%d',minutes))=struct('RMS',rms(err),'peak_abs_error',pk,'peak_UTC_hour',(t(k)-16)/3600,'r',cc(1,2));
 end
end
f=fopen(fullfile(out,'force_controls.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
end
