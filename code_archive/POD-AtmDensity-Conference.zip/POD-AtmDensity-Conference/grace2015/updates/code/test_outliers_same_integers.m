function test_outliers_same_integers(original,screened,out)
if ~isfolder(out),mkdir(out);end
z=load(fullfile(original,'P_integer_audit.mat'));audit=z.audit;new=load(fullfile(screened,'history_mask.mat'));audit.candidate_detail.mask=new.mask;
save(fullfile(out,'P_integer_audit.mat'),'audit');copyfile(fullfile(screened,'history_mask.mat'),fullfile(out,'history_mask.mat'));
for sat='AB',copyfile(fullfile(screened,[sat '_raw_design.mat']),fullfile(out,[sat '_raw_design.mat']));end
fit_connected_integer_only(out,out,@gnss_navigation_robust);
end
