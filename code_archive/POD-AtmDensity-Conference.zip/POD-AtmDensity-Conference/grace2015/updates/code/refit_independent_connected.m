function refit_independent_connected(out)
% Recover natural GPS links implied by the GNSS-only joint integer subspace.
% A derived link is exact algebra, not a new rounded reference-based decision.
z=load(fullfile(out,'independent_graph1.mat'));c=z.result.c;wideOK=z.result.wideOK;z=load(fullfile(out,'independent_joint1.mat'));j=z.result;
ln=299792458/(1575.42e6+1227.6e6);cf=1227.6e6/(1575.42e6+1227.6e6)*299792458/(1575.42e6-1227.6e6);
co=(j.H'\c.A')';inside=max(abs(co*j.H-c.A),[],2)<1e-8;target=co*j.target;nn=(target-cf*c.WL)/ln;inside=inside&wideOK&abs(nn-round(nn))<1e-7;
rows=find(inside);keys=vertcat(c.accepted.key);kk=keys(rows,:);assert(~isempty(kk),'No direct fixed links implied by joint solution');
[nodes,~,ix]=unique([kk(:,3:4);kk(:,5:6)],'rows');ne=size(kk,1);component=conncomp(graph(ix(1:ne),ix(ne+1:end),[],size(nodes,1)));qs=cell(2,1);
for sat='AB',z=load(fullfile(out,[sat '_raw_design.mat']));qs{double(sat)-64}=z.q;assert(~isfield(z.q,'pod_r'));end
a=qs{1};b=qs{2};mask=false(size(c.mask));
for e=1:numel(c.t)
 ps=find(a.good(c.ia(e),:)&b.good(c.ib(e),:));pairs=[a.labels(c.ia(e),ps)',b.labels(c.ib(e),ps)'];[yes,id]=ismember(pairs,nodes,'rows');ps=ps(yes);id=id(yes);if isempty(id),continue;end
 groups=component(id);u=unique(groups);counts=arrayfun(@(g)nnz(groups==g),u);[count,k]=max(counts);if count>=2,mask(e,ps(groups==u(k)))=true;end
end
models=cell(2,1);counts=cell(2,1);
for sat='AB'
 k=double(sat)-64;q=qs{k};q.code_good=q.good;selected=false(size(q.good));if sat=='A',ii=c.ia;else,ii=c.ib;end;selected(ii,:)=mask;q.good=q.good&selected;
 counts{k}=accumarray(q.labels(q.good),1,[numel(q.B0) 1]);fprintf('Independent fixed-connected phase and all-code navigation %s\n',sat);models{k}=gnss_navigation_code_supported(q,1200,true);
end
count=vertcat(counts{:});A=c.A(rows,:);tt=target(rows);active=~any(abs(A(:,count==0))>0,2);A=A(active,:);tt=tt(active);[~,R,piv]=qr(A','vector');rk=sum(abs(diag(R))>1e-9);H=A(piv(1:rk),:);tt=tt(piv(1:rk));
B=[models{1}.B0+models{1}.db;models{2}.B0+models{2}.db];Q=blkdiag(models{1}.Q,models{2}.Q);HQ=H*Q;S=HQ*H';sc=sqrt(diag(S));SS=S./sc./sc';assert(min(eig((SS+SS')/2))>1e-12,'Unobservable selected fixed constraints');fixed=B+HQ'*((SS\((tt-H*B)./sc))./sc);error=max(abs(H*fixed-tt));assert(error<5e-7);
n=numel(models{1}.B0);C=gnss_condition_navigation(models{1},[],[],fixed(1:n));save(fullfile(out,'A_C.mat'),'C','-v7.3');C=gnss_condition_navigation(models{2},[],[],fixed(n+1:end));save(fullfile(out,'B_C.mat'),'C','-v7.3');
result=struct('H',H,'target',tt,'fixedB',fixed,'mask',mask,'c',c,'derived_rows',rows,'fixed_rank',rk,'constraint_error_m',error);save(fullfile(out,'independent_connected.mat'),'result','-v7.3');
summary=struct('joint_fixed_rank',j.fixed_rank,'derived_natural_relations',nnz(inside),'active_fixed_rank',rk,'fixed_connected_epochs',nnz(sum(mask,2)>=2),'selected_paired_phase_observations',nnz(mask),'constraint_error_m',error,'method','Only GNSS-only joint-resolved connected carrier-phase tracks; all original eligible code retained for absolute geometry. No POD/KBR/ACC input or reference screening.');
f=fopen(fullfile(out,'independent_connected.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);disp(summary);
end
