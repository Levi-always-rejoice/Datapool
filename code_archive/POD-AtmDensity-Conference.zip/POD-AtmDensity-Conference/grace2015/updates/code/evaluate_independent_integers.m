function evaluate_independent_integers(package,root,out,doDensity,forceDirectory)
% References are loaded ONLY AFTER the independent fixes have been saved.
if nargin<4,doDensity=true;end
if nargin<5,forceDirectory=fullfile(root,'bridge_force_reference');end
assert(isfile(fullfile(out,'independent_graph.mat'))&&isfile(fullfile(out,'independent_joint.mat')));
z=load(fullfile(out,'independent_graph.mat'));graph=z.result;z=load(fullfile(out,'independent_joint.mat'));joint=z.result;
base=grace_update_baseline(package);z=load(fullfile(base,'P_integer_audit.mat'));ref=z.audit.candidate_detail;keys=vertcat(ref.accepted.key);
[shared,ix]=ismember(graph.keys,keys,'rows');same=graph.integer_WL(shared)==ref.WL(ix(shared))&graph.integer_N1(shared)==ref.NL(ix(shared));
report=struct;report.withheld_assisted_comparison.graph=struct('shared_relations',nnz(shared),'agree',nnz(same),'disagree',nnz(~same),'not_shared',nnz(~shared));
if ~isempty(joint.H)
 coefficient=(joint.H'\ref.A')';reconstruction=coefficient*joint.H;inside=max(abs(reconstruction-ref.A),[],2)<1e-8;err=coefficient*joint.target-ref.target;
 report.withheld_assisted_comparison.joint=struct('assisted_relations_in_fixed_subspace',nnz(inside),'agree',nnz(inside&abs(err)<1e-6),'disagree',nnz(inside&abs(err)>=1e-6));
end
navs=cell(2,1);refs=cell(2,1);names={'F','N','L'};
if isfile(fullfile(out,'independent_joint1.mat'))
 names=[names,{'N1','L1'}];z=load(fullfile(out,'independent_graph1.mat'));g=z.result;[shared,ix]=ismember(g.keys,keys,'rows');same=g.integer_WL(shared)==ref.WL(ix(shared))&g.integer_N1(shared)==ref.NL(ix(shared));report.withheld_assisted_comparison.graph_nominal=struct('shared_relations',nnz(shared),'agree',nnz(same),'disagree',nnz(~same),'not_shared',nnz(~shared));
 z=load(fullfile(out,'independent_joint1.mat'));j=z.result;if ~isempty(j.H),co=(j.H'\ref.A')';inside=max(abs(co*j.H-ref.A),[],2)<1e-8;err=co*j.target-ref.target;report.withheld_assisted_comparison.joint_nominal=struct('assisted_relations_in_fixed_subspace',nnz(inside),'agree',nnz(inside&abs(err)<1e-6),'disagree',nnz(inside&abs(err)>=1e-6));end
 graph=g;
end
if isfile(fullfile(out,'independent_connected.mat')),names=[names,{'C'}];z=load(fullfile(out,'independent_connected.mat'));graph=z.result;end
if isfile(fullfile(out,'independent_graph2.mat'))
 names=[names,{'N2'}];z=load(fullfile(out,'independent_graph2.mat'));g=z.result;[shared,ix]=ismember(g.keys,keys,'rows');same=g.integer_WL(shared)==ref.WL(ix(shared))&g.integer_N1(shared)==ref.NL(ix(shared));report.withheld_assisted_comparison.seeded_graph=struct('shared_relations',nnz(shared),'agree',nnz(same),'disagree',nnz(~same),'not_shared',nnz(~shared));graph=g;
end
for sat='AB'
 j=double(sat)-64;x=load(fullfile(out,[sat '_float_model.mat']),'F');y=load(fullfile(out,[sat '_N.mat']));z=load(fullfile(out,[sat '_L.mat']));navs{j}=struct('F',x.F,'N',y.N,'L',z.L);
 if numel(names)>3,y=load(fullfile(out,[sat '_N1.mat']));z=load(fullfile(out,[sat '_L1.mat']));navs{j}.N1=y.N;navs{j}.L1=z.L;end
 if any(strcmp(names,'C')),z=load(fullfile(out,[sat '_C.mat']));navs{j}.C=z.C;end
 if any(strcmp(names,'N2')),z=load(fullfile(out,[sat '_N2.mat']));navs{j}.N2=z.N;end
 z=load(fullfile(forceDirectory,[sat '_all_density.mat']),'d','bias');refs{j}=z;
 P=gnss_hermite(z.d.pod_t,z.d.pod_r,z.d.pod_v);
 for name=names,v=navs{j}.(name{1}).values;report.(name{1}).(['orbit_' sat '_RMS_m'])=rms(vecnorm(v(:,2:4)-ppval(P,v(:,1)')',2,2));end
end
% Original shared KBR datum, no extra GNSS-specific alignment or filtering.
k=load(fullfile(base,'range_comparison.mat'));t=k.range.t;pa=ppval(gnss_hermite(refs{1}.d.pod_t,refs{1}.d.pod_r,refs{1}.d.pod_v),t')';pb=ppval(gnss_hermite(refs{2}.d.pod_t,refs{2}.d.pod_r,refs{2}.d.pod_v),t')';aligned=vecnorm(pb-pa,2,2)-k.range.POD;ranges=nan(numel(t),numel(names));
for j=1:numel(names)
 a=navs{1}.(names{j}).values;b=navs{2}.(names{j}).values;[ya,ia]=ismember(t,a(:,1));[yb,ib]=ismember(t,b(:,1));m=ya&yb;rv=nan(size(t));rv(m)=vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-aligned(m);ranges(:,j)=rv;report.(names{j}).range_RMS_mm=rms(rv(m))*1000;report.(names{j}).range_epochs=nnz(m);
end
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 1200]);tiledlayout(numel(names),1);
for j=1:numel(names),nexttile;v=ranges(:,j)*1000;v([false;diff(t)>5.1|diff(k.range.segments)~=0])=NaN;plot((t-16)/3600,v);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');title(sprintf('%s: independent orbit / ambiguity experiment',names{j}));end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(out,'independent_range.png'),'Resolution',150);close(fig);
save(fullfile(out,'range_evaluation.mat'),'t','ranges','report');
f=fopen(fullfile(out,'evaluation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
if ~doDensity,return;end
if numel(names)>3,names={'F','N1','L1'};if isfield(navs{1},'C'),names=[names,{'C'}];end;if isfield(navs{1},'N2'),names=[names,{'N2'}];end;for j=1:2,navs{j}=rmfield(navs{j},{'N','L'});end;end
for sat='AB'
 j=double(sat)-64;z=refs{j};d=gnss_density_sparse_window(z.d,navs{j},1200);
 for name=names,v=d.(name{1}).values;v(:,4)=v(:,4)-z.bias/1e-6*v(:,6);writematrix(v,fullfile(out,sprintf('%s_%s_density.csv',sat,name{1})));end
end
% Geometry-only common evaluation interval, no ACC/KBR-selected samples.
for name=names
 a=readmatrix(fullfile(out,sprintf('A_%s_density.csv',name{1})));b=readmatrix(fullfile(out,sprintf('B_%s_density.csv',name{1})));[tt,ia,ib]=intersect(a(:,1),b(:,1));g=b(ib,2)-a(ia,2);acc=b(ib,4)-a(ia,4);
 support=graph.c.t(sum(graph.mask,2)>=2);count=arrayfun(@(x)nnz(support>=x-600&support<x+600),tt);supported=count>=12;
 report.(name{1}).density_all=score(g,acc,true(size(tt)));report.(name{1}).density_on_graph_support=score(g,acc,supported);
 writematrix([tt,g,acc,supported,count],fullfile(out,[name{1} '_differential_density.csv']));
end
fig=figure('Position',[20 20 1400 1200]);tiledlayout(numel(names),1);
for j=1:numel(names),v=readmatrix(fullfile(out,[names{j} '_differential_density.csv']));nexttile;plot((v(:,1)-16)/3600,v(:,2:3)*1e12);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title([names{j} ': 20-minute density, common GNSS force reference']);legend('GNSS','ACC');end
xlabel('UTC hour');exportgraphics(fig,fullfile(out,'independent_density.png'),'Resolution',150);close(fig);
report.density_reference_note=['Common force reference directory: ' forceDirectory '. No reference density enters the independent integer estimator. ACC retains its previous POD-calibrated constant bias. Full-day density includes weakly supported intervals and is not a fixed-only claim.'];
f=fopen(fullfile(out,'evaluation.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
function s=score(x,y,m)
if nnz(m)<2,s=struct('centers',nnz(m),'RMS',NaN,'r',NaN);return;end
c=corrcoef(x(m),y(m));s=struct('centers',nnz(m),'RMS',rms(x(m)-y(m)),'r',c(1,2));
end
