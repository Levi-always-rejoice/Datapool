function report=evaluate_assistance_factorial(root,out)
% Same evaluation support, KBR datum and density operator for every branch.
method=jsondecode(fileread(fullfile(out,'navigation_factors.json')));
names={'full_independent','full_addedPOD','phase_only_independent','phase_only_addedPOD','phase_and_code_independent','phase_and_code_addedPOD'};
base=load(fullfile(root,'code_history20_run','comparison_history2.mat'));ref=load(fullfile(root,'assisted_benchmark_reconciliation','comparison.mat'));
navs=cell(2,1);old=cell(2,1);forces=cell(2,1);report=struct('columns',{names},'method',method);
for s=1:2
 sat=char(64+s);old{s}=load(fullfile(root,'code_history20_run',[sat '_L_history2.mat']),'L');forces{s}=load(fullfile(root,'independent_run','fresh_force_reference',[sat '_all_density.mat']),'d','bias');
 P=gnss_hermite(forces{s}.d.pod_t,forces{s}.d.pod_r,forces{s}.d.pod_v);
 for v=1:numel(names)
  z=load(fullfile(out,names{v},[sat '_L.mat']),'L');navs{s}.(names{v})=z.L;x=z.L.values;
  assert(isequal(x(:,1),old{s}.L.values(:,1)));report.orbit_RMS_m.(names{v}).(sat)=rms(vecnorm(x(:,2:4)-ppval(P,x(:,1)')',2,2));
 end
end
t=base.t;ranges=nan(numel(t),numel(names)+1);[ya,ia]=ismember(t,old{1}.L.values(:,1));[yb,ib]=ismember(t,old{2}.L.values(:,1));m=ya&yb;
rb=vecnorm(old{2}.L.values(ib(m),2:4)-old{1}.L.values(ia(m),2:4),2,2);
for v=1:numel(names)
 a=navs{1}.(names{v}).values;b=navs{2}.(names{v}).values;ranges(m,v)=base.rv(m,2)+vecnorm(b(ib(m),2:4)-a(ia(m),2:4),2,2)-rb;
end
[~,i,j]=intersect(t,ref.tr);ranges(i,end)=ref.ranges(j,1);rm=all(isfinite(ranges),2);
report.range_common_epochs=nnz(rm);report.range_RMS_mm=rms(ranges(rm,:))*1000;report.range_columns=[names,{'original_assisted_reference'}];
writejson(fullfile(out,'comparison.json'),report);save(fullfile(out,'range_comparison.mat'),'t','ranges','rm','report');disp(report.range_RMS_mm);
dens=cell(2,1);
for s=1:2
 sat=char(64+s);fprintf('Factorial 20-minute density, receiver %s, six branches\n',sat);d=gnss_density_sparse_window(forces{s}.d,navs{s},1200);
 for v=1:numel(names)
  z=d.(names{v});vv=z.values;vv(:,4)=vv(:,4)-forces{s}.bias/1e-6*vv(:,6);dens{s}.(names{v})=vv;
  writematrix(vv,fullfile(out,names{v},[sat '_density.csv']));report.density_checks.(sat).(names{v})=rmfield(z,'values');
 end
end
[tt,ia,ib]=intersect(dens{1}.full_independent(:,1),dens{2}.full_independent(:,1));acc=dens{2}.full_independent(ib,4)-dens{1}.full_independent(ia,4);g=nan(numel(tt),numel(names)+1);
for v=1:numel(names),a=dens{1}.(names{v});b=dens{2}.(names{v});g(:,v)=b(ib,2)-a(ia,2);writematrix([tt,g(:,v),acc],fullfile(out,names{v},'differential_density.csv'));end
[~,i,j]=intersect(tt,ref.reprocessed(:,1));g(i,end)=ref.reprocessed(j,2);mask=false(size(tt));[~,i,j]=intersect(tt,ref.t);mask(i)=ref.mask(j);mask=mask&all(isfinite(g),2)&isfinite(acc);
report.density_common_centers=nnz(mask);report.density_columns=report.range_columns;
for v=1:size(g,2)
 name=report.density_columns{v};report.density.(name)=score(g(mask,v),acc(mask));report.density.(name).all=score(g(:,v),acc);report.density.(name).last4=score(g(tt>=72016,v),acc(tt>=72016));
end
[~,i,j]=intersect(tt,base.tt);report.baseline_density_max_difference=max(abs(g(i,1)-base.g(j)));assert(report.baseline_density_max_difference<1e-19);
report.effects=struct;
% Differences are deterministic ablation effects, not uncertainty estimates.
pairs=[1 2;3 4;5 6;1 3;2 4;3 5;4 6];labels={'integers_full','integers_phase_mask','integers_phase_code_mask','phase_mask_independent','phase_mask_addedPOD','code_removal_independent','code_removal_addedPOD'};
for k=1:size(pairs,1)
 p=pairs(k,:);a=report.density.(names{p(1)});b=report.density.(names{p(2)});
 report.effects.(labels{k})=struct('from',names{p(1)},'to',names{p(2)},'range_RMS_change_mm',report.range_RMS_mm(p(2))-report.range_RMS_mm(p(1)), ...
  'density_RMS_change',b.RMS-a.RMS,'correlation_change',b.r-a.r,'density_MSE_change',b.RMS^2-a.RMS^2);
end
report.note='All six are diagnostic branches of the same cached GNSS-only orbit/force model. Only the independent/full branch is POD-free. POD-derived mask contains track-connectivity selection as well as residual screening. Added-POD integer branches retain the independent seed plus 63 extra directions, not POD float offsets or positions. The historical assisted reference differs in other processing and is not one of the controlled factorial cells. Matched scores use the original valid density support; full-output scores are also retained. Existing ACC constant bias calibration is unchanged.';
writejson(fullfile(out,'comparison.json'),report);save(fullfile(out,'comparison.mat'),'t','ranges','rm','tt','g','acc','mask','names','report');plot_assistance_factorial(out);disp(report.effects);
end
function s=score(g,a),m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
