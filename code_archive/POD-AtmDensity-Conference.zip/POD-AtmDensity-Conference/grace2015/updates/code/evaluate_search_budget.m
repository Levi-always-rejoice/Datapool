function report=evaluate_search_budget(package,root,out,suffix)
% Post-estimation audit; none of these references enter integer search.
z=load(fullfile(out,['independent_joint' suffix '.mat']),'result');j=z.result;
assert(isfile(fullfile(out,['A_L' suffix '.mat']))&&isfile(fullfile(out,['B_L' suffix '.mat'])));
report=struct('fixed_rank',j.fixed_rank,'initial_supported',j.initial_supported,'search_limit',j.search_limit,'dropped',size(j.history,1),'drop_reasons',zeros(1,4));
if ~isempty(j.history),for k=1:4,report.drop_reasons(k)=sum(j.history(:,3)==k);end,end
report.drop_reason_legend={'incomplete_search','fold_disagreement','conditional_or_aggregate_cost','likelihood_separation'};
old=load(fullfile(out,'independent_joint1.mat'),'result');H=old.result.H;
co=(j.H'\H')';inside=max(abs(co*j.H-H),[],2)<1e-8;err=co*j.target-old.result.target;
report.old_fixed_directions_in_new_space=nnz(inside);report.old_fixed_directions_agree=nnz(inside&abs(err)<1e-6);
z=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');ref=z.audit.candidate_detail;
co=(j.H'\ref.A')';inside=max(abs(co*j.H-ref.A),[],2)<1e-8;err=co*j.target-ref.target;
report.withheld_assisted_comparison=struct('relations_in_space',nnz(inside),'agree',nnz(inside&abs(err)<1e-6),'disagree',nnz(inside&abs(err)>=1e-6));
z=load(fullfile(out,'range_evaluation.mat'),'t','ranges');t=z.t;newRange=nan(size(t));floatRange=nan(size(t));navs=cell(2,1);float=cell(2,1);refs=cell(2,1);
for sat='AB'
 k=double(sat)-64;x=load(fullfile(out,[sat '_L' suffix '.mat']),'L');navs{k}=x.L;
 x=load(fullfile(out,[sat '_float_model.mat']),'F');float{k}=x.F;
 refs{k}=load(fullfile(out,'fresh_force_reference',[sat '_all_density.mat']),'d','bias');
 P=gnss_hermite(refs{k}.d.pod_t,refs{k}.d.pod_r,refs{k}.d.pod_v);v=navs{k}.values;
 report.(['orbit_' sat '_RMS_m'])=rms(vecnorm(v(:,2:4)-ppval(P,v(:,1)')',2,2));
end
for mode=1:2
 if mode==1,aa=navs{1}.values;bb=navs{2}.values;else,aa=float{1}.values;bb=float{2}.values;end
 [yesA,ia]=ismember(t,aa(:,1));[yesB,ib]=ismember(t,bb(:,1));m=yesA&yesB;v=nan(size(t));v(m)=vecnorm(bb(ib(m),2:4)-aa(ia(m),2:4),2,2);
 if mode==1,newRange=v;else,floatRange=v;end
end
% Subtract exactly the same previously saved KBR datum as every older branch.
residual=z.ranges(:,1)+newRange-floatRange;
p=load(fullfile(root,'bridge_force_density_run','range_comparison.mat'),'t','rv');[~,ia,ib]=intersect(t,p.t);assisted=nan(size(t));assisted(ia)=p.rv(ib,2);
rv=[z.ranges(:,[1 5 7]),residual,assisted];m=all(isfinite(rv),2);
report.range_common_epochs=nnz(m);report.range_RMS_mm=rms(rv(m,:))*1000;
report.range_columns={'float','previous_joint220','previous_extended223','larger_search','assisted'};
dens=cell(2,1);
for sat='AB'
 k=double(sat)-64;d=gnss_density_sparse_window(refs{k}.d,struct('L',navs{k}),1200);v=d.L.values;
 v(:,4)=v(:,4)-refs{k}.bias/1e-6*v(:,6);dens{k}=v;
 writematrix(v,fullfile(out,[sat '_L' suffix '_density.csv']));
end
[tt,ia,ib]=intersect(dens{1}(:,1),dens{2}(:,1));g=dens{2}(ib,2)-dens{1}(ia,2);acc=dens{2}(ib,4)-dens{1}(ia,4);
report.density_all=score(g,acc);old=load(fullfile(root,'bridge_force_density_run','comparison.mat'));old=old.series{1};
[~,i,k]=intersect(tt,old.t);m=old.mask(k);report.density_matched=score(g(i(m)),acc(i(m)));
writematrix([tt,g,acc],fullfile(out,['L' suffix '_differential_density.csv']));
report.note='Only search budget differs from joint220. Identical nominal covariance, candidates, validation thresholds, force reference and ACC bias; no reference data in the search. All reference checks occur after saving the integer-constrained navigation. ACC benchmark retains its prior POD-calibrated constant bias. Partial fixing and batch processing remain.';
f=fopen(fullfile(out,'search_budget_comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
save(fullfile(out,'search_budget_comparison.mat'),'t','rv','tt','g','acc','report');
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 1000]);tiledlayout(3,1);
nexttile;plot((t-16)/3600,rv(:,[2 4])*1000);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');legend('Previous joint search','Larger search');title('Independent partial integer fixing; same observations and validation thresholds');
nexttile;plot((t-16)/3600,(rv(:,4)-rv(:,2))*1000);grid on;xlim([0 24]);ylabel('Range change (mm)');title('Effect of search budget only');
nexttile;v=[g acc]*1e12;v([false;diff(tt)>1.1],:)=NaN;plot((tt-16)/3600,v);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('Larger search','ACC');title('20-minute density, full available support');xlabel('UTC hour, GRACE A/B, 2015-03-15');
exportgraphics(fig,fullfile(out,'search_budget_comparison.png'),'Resolution',150);close(fig);disp(report);
end
function s=score(g,a)
m=isfinite(g)&isfinite(a);c=corrcoef(g(m),a(m));s=struct('centers',nnz(m),'RMS',rms(g(m)-a(m)),'r',c(1,2));
end
