function plot_reduced_dynamic_integer_assistance(root,out)
load(fullfile(out,'comparison.mat'),'t','rv','series','report');
z=load(fullfile(root,'bridge_force_density_run','comparison.mat'));base=z.series{1};
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1500 1120]);tiledlayout(3,1);
nexttile;vals=rv*1000;vals([false;diff(t)>5.1],:)=NaN;plot((t-16)/3600,vals);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');legend('Independent integers: 240','POD-assisted integers: 358');title('Same 20-minute reduced-dynamic model; only integer constraints change');
v=series{1};w=series{2};assert(isequal(v(:,1),w(:,1)));[tt,i,j]=intersect(v(:,1),base.t);mask=base.mask(j);vals=[v(i,2),w(i,2),v(i,3)]*1e12;vals(~mask|[false;diff(tt)>1.1],:)=NaN;
nexttile;plot((tt-16)/3600,vals);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('Independent integers','POD-assisted integers','ACC');title('20-minute density, matched evaluation support');
nexttile;plot((tt-16)/3600,vals);grid on;xlim([13 15]);ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('Independent integers','POD-assisted integers','ACC');title('13-15 UTC detail');xlabel('UTC hour, GRACE A/B, 2015-03-15');
exportgraphics(fig,fullfile(out,'reduced_dynamic_integer_comparison.png'),'Resolution',150);close(fig);
T=readtable(fullfile(out,'reduced_dynamic240_DD_comparison.csv'));fixed=logical(T.independent_relation_fixed);fig=figure('Position',[20 20 1500 850]);tiledlayout(2,1);
nexttile;plot(find(fixed),round([T.delta_N1_cycles(fixed),T.delta_N2_cycles(fixed)]),'.');grid on;ylim([-1 1]);ylabel('Integer difference (cycles)');xlabel('POD-assisted DD relation index');legend('L1','L2');title('All 466 shared natural DD relations agree; rank of the shared space = 240');
nexttile;scatter((T.UTC_start(~fixed)+T.UTC_end(~fixed))/2,T.IF_offset_difference_mm(~fixed),15,'filled');grid on;xlim([0 24]);ylabel('Unresolved IF offset - assisted (mm)');xlabel('UTC hour, midpoint of tracking-pair overlap');title('Unresolved relations retain fractional offsets: not incorrectly fixed integers');
exportgraphics(fig,fullfile(out,'integer_relation_comparison.png'),'Resolution',150);close(fig);disp(report);
end
