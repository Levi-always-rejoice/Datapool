function report=test_phase_selection_controls
% Code-only rows must survive carrier selection and enter exactly once.
rng(319);ne=30;np=6;nb=np;nx=6+ne;N=zeros(nx+nb);r=zeros(nx+nb,1);NN=N;rr=r;anchorW=zeros(nb,1);anchorY=anchorW;
codeOnly=0;phaseOnly=0;
for e=1:ne
 for p=1:np
  h=zeros(1,nx);h(1:6)=randn(1,6);h(6+e)=1;a=zeros(1,nb);a(p)=1;
  hasPhase=mod(e+2*p,4)~=0;hasCode=mod(e+p,5)~=0;wp=double(hasPhase)/(.01+.01*rand)^2;wc=double(hasCode)/(2+5*rand)^2;
  codeOnly=codeOnly+double(hasCode&&~hasPhase);phaseOnly=phaseOnly+double(hasPhase&&~hasCode);
  ph=randn;code=randn;hp=[h,a];hc=[h,zeros(1,nb)];N=N+wp*(hp'*hp)+wc*(hc'*hc);r=r+wp*hp'*ph+wc*hc'*code;
  W=wp+wc;if W==0,continue;end
  mix=(wp*ph+wc*code)/W;hh=[h,wp/W*a];NN=NN+W*(hh'*hh);rr=rr+W*hh'*mix;
  if hasPhase&&hasCode,wd=wp*wc/W;anchorW(p)=anchorW(p)+wd;anchorY(p)=anchorY(p)+wd*(ph-code);end
 end
end
NN(nx+(1:nb),nx+(1:nb))=NN(nx+(1:nb),nx+(1:nb))+diag(anchorW);rr(nx+(1:nb))=rr(nx+(1:nb))+anchorY;
report=struct('normal_relative_error',norm(NN-N,'fro')/norm(N,'fro'),'rhs_relative_error',norm(rr-r)/norm(r),'code_only_rows',codeOnly,'phase_only_rows',phaseOnly);
assert(report.normal_relative_error<1e-13&&report.rhs_relative_error<1e-13&&codeOnly>0&&phaseOnly>0);
% An unobserved phase offset must not act as a perfectly known parameter.
a=struct('B0',zeros(2,1),'db',[.7;-.2],'Q',diag([1 .5]));b=struct('B0',zeros(2,1),'db',[0;1.3],'Q',diag([0 .25]));
seed=struct('H',[1 -1 0 0;0 1 1 -1],'target',[.4;2]);
[B,info]=condition_supported_history(a,b,seed,[10;10;0;10]);
N=diag([1 2 0 4]);rhs=N*[a.db;b.db];K=[N,seed.H';seed.H,zeros(2)];solution=K\[rhs;seed.target];
report.unsupported_offset_solution_error=max(abs(B-solution(1:4)));report.active_constraint_rank=info.active_constraint_rank;
assert(report.unsupported_offset_solution_error<1e-12&&info.active_constraint_rank==1);disp(report);
end
