function report_connected_gaps(package,oldnav,newnav,olddensity,newdensity)
old=load(fullfile(olddensity,'comparison.mat'));new=load(fullfile(newdensity,'comparison.mat'));report=struct;windows=[20 10];
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 1000]);tiledlayout(3,1);
for k=1:2
 a=old.series{k};b=new.series{k};[~,ia,ib]=intersect(a.t,b.t);m=a.mask(ia)&b.mask(ib);oldvalid=a.t(a.mask);added=b.mask&~ismember(b.t,oldvalid);
 report.(['min' num2str(windows(k))])=struct('old_centers',nnz(a.mask),'new_centers',nnz(b.mask),'added_centers',nnz(added),'lost_centers',nnz(a.mask&~ismember(a.t,b.t(b.mask))),'old_common',score(a.gnss(ia),a.acc(ia),m),'new_common',score(b.gnss(ib),b.acc(ib),m),'new_added',score(b.gnss,b.acc,added),'new_all',score(b.gnss,b.acc,b.mask));
 nexttile;v=a.gnss;v(~a.mask|[false;diff(a.t)>1.1])=NaN;plot((a.t-16)/3600,v*1e12);hold on;v=b.gnss;v(~b.mask|[false;diff(b.t)>1.1])=NaN;r=b.acc;r(~b.mask|[false;diff(b.t)>1.1])=NaN;plot((b.t-16)/3600,v*1e12);plot((b.t-16)/3600,r*1e12,'k');grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('%d-minute density: five gaps dynamically connected with fixed ambiguities',windows(k)));legend('Previous','Connected','ACC');
end
nexttile;hold on;for k=1:2,a=old.series{k};b=new.series{k};full=(0:86399)';ma=ismember(full,a.t(a.mask));mb=ismember(full,b.t(b.mask));plot((full-16)/3600,double(ma)+3*(k-1));plot((full-16)/3600,double(mb)+3*(k-1)+1.2);end;grid on;xlim([0 24]);xlabel('UTC hour, 2015-03-15');title('Density coverage, before and after');legend('20 min before','20 min connected','10 min before','10 min connected');
exportgraphics(fig,fullfile(newdensity,'connected_density.png'),'Resolution',150);close(fig);
base=grace_update_baseline(package);z=load(fullfile(base,'range_comparison.mat'));da=load(fullfile(base,'A_all_density.mat'),'d');db=load(fullfile(base,'B_all_density.mat'),'d');P=gnss_hermite(da.d.pod_t,da.d.pod_r,da.d.pod_v);Q=gnss_hermite(db.d.pod_t,db.d.pod_r,db.d.pod_v);
kbr=read_grace_ascii(fullfile(grace_update_input_root(package),'raw','KBR1B_2015-03-15_X_02.asc'),1:16);kbr=kbr.values;kbr=kbr(kbr(:,16)==0,:);t=kbr(:,1);kr=kbr(:,2)+kbr(:,6)+kbr(:,9);segments=cumsum([0;diff(t)>5.1|abs(diff(kr))>100]);pr=vecnorm(ppval(Q,t')'-ppval(P,t')',2,2);
[yes,ix]=ismember(t,z.range.t);datum=nan(size(t));for seg=unique(segments)',use=segments==seg&yes;offset=mean(pr(use)-z.range.POD(ix(use))-kr(use));datum(segments==seg)=offset;end;aligned=kr+datum;
navdirs={oldnav,newnav};rv=nan(numel(t),2);
for k=1:2
 a=load(fullfile(navdirs{k},'A_J.mat'));b=load(fullfile(navdirs{k},'B_J.mat'));[ya,ia]=ismember(t,a.J.values(:,1));[yb,ib]=ismember(t,b.J.values(:,1));m=ya&yb&isfinite(aligned);rv(m,k)=vecnorm(b.J.values(ib(m),2:4)-a.J.values(ia(m),2:4),2,2)-aligned(m);
end
common=all(isfinite(rv),2);added=isfinite(rv(:,2))&~isfinite(rv(:,1));report.range=struct('common_epochs',nnz(common),'old_common_RMS_mm',rms(rv(common,1))*1000,'new_common_RMS_mm',rms(rv(common,2))*1000,'added_epochs',nnz(added),'new_added_RMS_mm',rms(rv(added,2))*1000);
fig=figure('Position',[20 20 1400 650]);gap=[false;diff(t)>5.1|diff(segments)~=0];v=rv*1000;v(gap,:)=NaN;plot((t-16)/3600,v);hold on;plot((t(added)-16)/3600,rv(added,2)*1000,'.','MarkerSize',8);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');xlabel('UTC hour');legend('Previous','Connected','Newly propagated gap epochs');title('No extra range filtering; unchanged KBR datum');exportgraphics(fig,fullfile(newdensity,'connected_range.png'),'Resolution',150);close(fig);
f=fopen(fullfile(newdensity,'bridge_comparison.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);save(fullfile(newdensity,'range_comparison.mat'),'t','rv','added','common');
end
function s=score(x,y,m)
if nnz(m)<2,s=struct('centers',nnz(m),'RMS',NaN,'r',NaN);return;end
c=corrcoef(x(m),y(m));s=struct('centers',nnz(m),'RMS',rms(x(m)-y(m)),'r',c(1,2));
end
