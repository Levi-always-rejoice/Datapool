function connect_fixed_gaps(original,auditdir,out)
if ~isfolder(out),mkdir(out);end
T=readtable(fullfile(auditdir,'navigation_gaps.csv'));approved=T.same_fixed_track_pairs>=2&T.shared_integer_graph_components>0;
intervals=[T.start_GPS(approved),T.end_GPS(approved)];assert(size(intervals,1)==5);
copyfile(fullfile(original,'P_integer_audit.mat'),fullfile(out,'P_integer_audit.mat'));copyfile(fullfile(original,'history_mask.mat'),fullfile(out,'history_mask.mat'));
for sat='AB',x=load(fullfile(original,[sat '_raw_design.mat']),'q');q=x.q;q.bridge_intervals=intervals;save(fullfile(out,[sat '_raw_design.mat']),'q');end
fit_connected_integer_only(out,out,@gnss_navigation_bridge);
z=jsondecode(fileread(fullfile(out,'connected_integer_only.json')));assert(z.fixed_rank==354);
summary=struct('connected_intervals_GPS',intervals,'remaining_intervals_GPS',[T.start_GPS(~approved),T.end_GPS(~approved)],'fixed_rank',z.fixed_rank,'method','Dynamical propagation and continuous state constraints across five gaps with unchanged fixed tracks; no synthetic phase or range interpolation');
for sat='AB'
 n=load(fullfile(out,[sat '_J.mat']));for k=1:size(intervals,1),assert(all(ismember((intervals(k,1):intervals(k,2))',n.J.values(:,1))));end
 summary.(sat)=struct('state_continuity_error',n.J.continuity_error);
end
f=fopen(fullfile(out,'bridge_summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
