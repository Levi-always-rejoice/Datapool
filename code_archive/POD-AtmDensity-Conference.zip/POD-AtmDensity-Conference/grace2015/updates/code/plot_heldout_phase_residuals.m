function plot_heldout_phase_residuals(out)
% Render saved predictions only; never change the frozen weight decisions.
names={'A','Bp','D'};labels={'GRACE A','GRACE B','B-A differential phase'};folds=cell(4,1);
for f=0:3,folds{f+1}=load(fullfile(out,sprintf('heldout_fold%d.mat',f)));end
set(groot,'defaultFigureVisible','off');fig=figure('Position',[30 30 1500 1000]);tiledlayout(3,1);
for j=1:3
 nexttile;hold on;
 for f=1:4,p=folds{f}.(names{j});m=p.support&isfinite(p.residual);scatter((p.time(m)-16)/3600,p.residual(m)*1000,3,p.prn(m),'filled');end
 ylim([-60 60]);xlim([0 24]);clim([1 32]);c=colorbar;c.Label.String='GPS PRN';grid on;ylabel('Held-out phase (mm)');
 title(sprintf('%s: excluded 5-minute GPS segments; display limited to +/-60 mm',labels{j}));
end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'heldout_phase_residuals.png'),'Resolution',150);close(fig);
end
