function audit_existing_integers(baseline,out)
a=load(fullfile(baseline,'A_float_model.mat'),'model');b=load(fullfile(baseline,'B_float_model.mat'),'model');
R=load(fullfile(baseline,'R_integer_validation.mat'));P=load(fullfile(baseline,'P_integer_audit.mat'));
c=gnss_pair_candidates(a.model.q,b.model.q,false);A=c.A;w=c.WL;H=A(c.independent,:);wi=w(c.independent);
pred=A*(H'/(H*H'))*wi;closure=pred-w;
report=struct('wide_lane_candidates',numel(w),'independent_rank',size(H,1),'inconsistent_wide_lane_relations',nnz(abs(closure)>.01),'maximum_WL_closure_cycles',max(abs(closure)));
HR=R.integers.H;AP=P.audit.candidate_detail.A;basis=orth(HR');outside=vecnorm(AP-(AP*basis)*basis',2,2);fixed=outside<1e-8;
error=AP*R.integers.fixedB-P.audit.candidate_detail.target;
report.POD_audited_DD_relations_exactly_fixed_by_R=nnz(fixed);report.contradictory_fixed_DD_relations=nnz(fixed&abs(error)>1e-6);
if any(fixed),report.maximum_shared_constraint_disagreement_m=max(abs(error(fixed)));end
% How much of the differential phase error is time-correlated after navigation?
for sat='AB'
 if sat=='A',model=a.model;else,model=b.model;end
 nav=load(fullfile(baseline,[sat '_branches.mat']),'R');nav=nav.R;q=model.q;
 pos=interp1(nav.values(:,1),nav.values(:,2:4),q.t,'linear',NaN);clock=interp1(nav.clock(:,1),nav.clock(:,2),q.t,'linear',NaN);
 labels=max(q.labels,1);phase=q.phase-sum(q.h.*reshape(pos-q.r,[],1,3),3)-reshape(nav.ambiguities(labels),size(labels))-clock;
 fitted=ismember(q.t,nav.clock(:,1))&ismember(q.t,nav.values(:,1));
 good=q.good&isfinite(phase)&fitted;pairs=good(1:end-1,:)&good(2:end,:)&q.labels(1:end-1,:)==q.labels(2:end,:)&diff(q.t)<10.1;
 x=phase(1:end-1,:);y=phase(2:end,:);cc=corrcoef(x(pairs),y(pairs));
 report.(sat)=struct('phase_RMS_m',rms(phase(good)),'adjacent_phase_residual_correlation',cc(1,2),'samples',nnz(good));
end
f=fopen(fullfile(out,'baseline_integer_audit.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
