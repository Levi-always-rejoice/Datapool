function report=grace_update_pipeline(inputs,baseline,out)
% Continue a just-generated raw baseline into the pre-GRACE-FO 2015 updates.
% All checkpoints are generated, never shipped. A completed stage can resume.
if ~isfolder(out),mkdir(out);end
put(fullfile(out,'input_root.txt'),inputs);put(fullfile(out,'baseline_path.txt'),baseline);
diary(fullfile(out,'updated_processing.log'));clean=onCleanup(@()diary('off'));
source=fullfile(out,'independent_run');
prepare_independent_integers(out,source);
if ~isfile(fullfile(source,'independent_graph1.mat')),resolve_independent_graph(source,1,'1');end
if ~isfile(fullfile(source,'independent_joint_search3m.mat'))
 resolve_independent_joint(source,1,'_search3m',struct('candidateSuffix','1','searchLimit',3000000));
end
wide=fullfile(out,'coverage_expansion_run');if ~isfolder(wide),mkdir(wide);end
if ~isfile(fullfile(wide,'robust_wide_lanes.mat')),prepare_robust_wide_lanes(source,wide,true);end
seed=fullfile(source,'independent_joint_search3m.mat');
for j=1:5
 if j==1,tag='_coverage';else,tag=sprintf('_round%d',j);end
 dest=fullfile(wide,['independent_joint' tag '.mat']);
 if isfile(dest),z=load(dest,'result');r=z.result;else,r=resolve_incremental_joint(source,wide,fullfile(wide,'robust_wide_lanes.mat'),seed,tag);end
 seed=dest;if r.added_rank==0,break;end
end
history=fullfile(out,'code_history20_run');
if ~isfile(fullfile(history,'B_fold1.mat')),prepare_long_code_history(source,history,1200);end
if ~isfile(fullfile(history,'robust_wide_lanes.mat')),prepare_robust_wide_lanes(history,history,true,fullfile(wide,'robust_wide_lanes.mat'));end
for j=1:4
 tag=sprintf('_computed_history%d',j);dest=fullfile(history,['independent_joint' tag '.mat']);
 if isfile(dest),z=load(dest,'result');r=z.result;else,r=resolve_incremental_joint(history,history,fullfile(history,'robust_wide_lanes.mat'),seed,tag);end
 seed=dest;if r.added_rank==0,break;end
end
% Legacy consumer filenames point to THIS RUN's convergence-selected values.
% No old target or result is inserted to force agreement with an example.
copyfile(seed,fullfile(history,'independent_joint_history2.mat'));
for sat='AB',copyfile(fullfile(history,[sat '_L' tag '.mat']),fullfile(history,[sat '_L_history2.mat']));end
put(fullfile(history,'selected_tag.txt'),'_history2');put(fullfile(history,'computed_selection.txt'),tag);
report=struct('independent_rank',r.fixed_rank,'computed_tag',tag,'baseline',baseline,'input_root',inputs);
common=fullfile(out,'assistance_factorial_run');
if ~isfile(fullfile(common,'common_view_method.json'))
 report.assistance=prepare_grace_common_history(out,out,common);
 run_common_view_control(out,common);
end
direct=fullfile(out,'direct_sd_run');
if ~isfile(fullfile(direct,'sd_inputs.mat')),prepare_direct_sd(out,direct);end
test_direct_sd_inputs(direct);
if ~isfile(fullfile(direct,'navigation_method.json')),solve_direct_sd(direct);end
test_direct_sd_solution(direct);direct_sd_support(direct);
% Reference force tables and all POD/KBR/ACC comparisons are downstream of
% saved independent navigation. The assisted branch is explicitly separate.
if ~isfile(fullfile(source,'fresh_force_reference','B_all_density.mat')),prepare_independent_density_reference(out,source);end
report.results=evaluate_grace_updated(out);
put(fullfile(out,'updated_run.json'),jsonencode(report,PrettyPrint=true));
end
function put(p,v),f=fopen(p,'w');assert(f>0);c=onCleanup(@()fclose(f));fprintf(f,'%s',v);end
