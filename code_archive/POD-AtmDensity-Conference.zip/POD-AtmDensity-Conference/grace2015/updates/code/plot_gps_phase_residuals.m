function plot_gps_phase_residuals(navdir,out)
if ~isfolder(out),mkdir(out);end
z=load(fullfile(navdir,'P_integer_audit.mat'));c=z.audit.candidate_detail;res=cell(2,1);podres=cell(2,1);
for sat='AB'
 k=double(sat)-64;z=load(fullfile(navdir,[sat '_raw_design.mat']),'q');q=z.q;z=load(fullfile(navdir,[sat '_J.mat']));n=z.J;
 [yr,ir]=ismember(q.t,n.values(:,1));[yc,ic]=ismember(q.t,n.clock(:,1));r=nan(size(q.phase));valid=yr&yc;
 ii=find(valid);lab=max(q.labels(ii,:),1);B=reshape(n.ambiguities(lab(:)),size(lab));
 r(ii,:)=q.phase(ii,:)-sum(q.h(ii,:,:).*reshape(n.values(ir(ii),2:4)-q.r(ii,:),[],1,3),3)-n.clock(ic(ii),2)-B;
 if sat=='A',ix=c.ia;else,ix=c.ib;end
 rr=r(ix,:);rr(~c.mask)=NaN;res{k}=rr;
 lab=max(q.labels,1);B=reshape(n.ambiguities(lab(:)),size(lab));pp=q.phase-sum(q.h.*reshape(q.pod_r-q.r,[],1,3),3)-B;pp=pp(ix,:);pp(~c.mask)=NaN;podres{k}=pp;
end
t=c.t;A=res{1}*1000;B=res{2}*1000;D=B-A;P=(podres{2}-podres{1})*1000;P=P-median(P,2,'omitnan');
rows=[];prns=[];
for p=2:33
 m=isfinite(A(:,p))&isfinite(B(:,p));if nnz(m)==0,continue;end
 prns(end+1)=p-1;rows(end+1,:)=[p-1,nnz(m),rms(A(m,p)),rms(B(m,p)),rms(D(m,p)),mean(D(m,p)),prctile(abs(D(m,p)),95)]; %#ok<AGROW>
end
T=array2table(rows,'VariableNames',{'GPS_PRN','epochs','A_RMS_mm','B_RMS_mm','BminusA_RMS_mm','BminusA_bias_mm','BminusA_abs95_mm'});
T.POD_geometry_SD_RMS_mm=nan(height(T),1);for j=1:height(T),v=P(:,T.GPS_PRN(j)+1);T.POD_geometry_SD_RMS_mm(j)=rms(v(isfinite(v)));end;writetable(T,fullfile(out,'per_GPS_residuals.csv'));
save(fullfile(out,'phase_residuals.mat'),'t','A','B','D','P','prns');
ma=isfinite(A);mb=isfinite(B);md=isfinite(D);summary=struct('A_phase_RMS_mm',rms(A(ma)),'B_phase_RMS_mm',rms(B(mb)),'BminusA_phase_RMS_mm',rms(D(md)),'observation_epochs',numel(t),'paired_observations',nnz(md),'definition','Postfit ionosphere-free carrier phase: observed minus modeled geometry, receiver clock and ambiguity offset; B-minus-A uses common GPS observations. No additional filtering.');
summary.POD_geometry_SD_RMS_mm=rms(P(isfinite(P)));summary.POD_reference_definition='Observed B-minus-A phase minus POD-predicted geometry and the saved ambiguity offsets; one common median clock term removed at each epoch, no per-GPS offset/trend refit. POD aided integer selection, so this is a consistency diagnostic, not independent integer validation.';
f=fopen(fullfile(out,'summary.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
% Preserve missing native 10-second epochs in the display grid.
gridt=(floor(min(t)/10)*10:10:ceil(max(t)/10)*10)';[~,ix]=ismember(t,gridt);set(groot,'defaultFigureVisible','off');
fig=figure('Position',[20 20 1400 1100]);tiledlayout(3,1);values={A,B,D};titles={'GRACE A: residual phase range per GPS','GRACE B: residual phase range per GPS','Between-receiver residual phase, B minus A, per GPS'};
for k=1:3
 v=nan(numel(gridt),32);v(ix,:)=values{k}(:,2:33);nexttile;im=imagesc((gridt-16)/3600,1:32,v');set(im,'AlphaData',isfinite(v'));set(gca,'YDir','normal','Color',[.85 .85 .85]);clim([-20 20]);colorbar;title([titles{k} ' (mm; colors clipped at +/-20 mm)']);ylabel('GPS PRN');xlim([0 24]);
end
xlabel('UTC hour, 2015-03-15; gray = unselected or unavailable');exportgraphics(fig,fullfile(out,'per_GPS_phase_residuals.png'),'Resolution',150);close(fig);
fig=figure('Position',[20 20 1600 1500]);tiledlayout(ceil(numel(prns)/4),4,'TileSpacing','compact');
for p=prns
 nexttile;v=P(:,p+1);v([false;diff(t)>10.1])=NaN;plot((t-16)/3600,v);grid on;xlim([0 24]);ylim([-20 20]);title(sprintf('G%02d',p));ylabel('mm');
end
sgtitle('Per-GPS B-A phase minus POD geometry and saved ambiguity; common clock removed; +/-20 mm display');exportgraphics(fig,fullfile(out,'per_GPS_POD_reference.png'),'Resolution',130);close(fig);
fig=figure('Position',[20 20 1400 500]);plot(T.GPS_PRN,T.A_RMS_mm,'o-');hold on;plot(T.GPS_PRN,T.B_RMS_mm,'o-');plot(T.GPS_PRN,T.BminusA_RMS_mm,'o-');grid on;xlabel('GPS PRN');ylabel('Residual RMS (mm)');legend('GRACE A','GRACE B','B minus A');title('Postfit carrier-phase residuals by GPS; JAXA real-time products');exportgraphics(fig,fullfile(out,'per_GPS_residual_RMS.png'),'Resolution',150);close(fig);disp(summary);
end
