function report=solve_direct_sd(out)
% Direct common-view IF carrier single differences. Epoch clock difference
% is projected out with an orthonormal weighted transform, then recovered.
% Global track-pair offsets obey inherited DD integer constraints; one real
% clock datum per connected measurement component is arbitrary and harmless.
z=load(fullfile(out,'sd_inputs.mat'),'q');q=z.q;qa=q.qa;qb=q.qb;obs=direct_sd_observations(q);nb=size(q.nodes,1);ns=12*size(q.blocks,1);nblocks=size(q.blocks,1);
RA=gnss_hermite(qa.t,qa.r,qa.v);RB=gnss_hermite(qb.t,qb.r,qb.v);M0=gnss_hermite(q.mean0(:,1),q.mean0(:,2:4),q.mean0(:,5:7));M1=gnss_hermite(q.mean1(:,1),q.mean1(:,2:4),q.mean1(:,5:7));
alpha=1575.42e6^2/(1575.42e6^2-1227.6e6^2);beta=1-alpha;blocks=cell(nblocks,1);Aparts=cell(nblocks,1);rhsParts=cell(nblocks,1);C=[];d=[];ds=[];edges=[];counts=zeros(nb,1);clockRows=cell(nblocks,1);
for j=1:nblocks
 fprintf('Direct SD orbit block %d/%d\n',j,nblocks);b=direct_sd_basis(q,j);ids=find(q.t>=b.a&q.t<b.b);st=gnss_states(b,q.t(ids));ix=(j-1)*12+(1:12);ir={};ic={};vv={};rr={};row=0;cr=cell(numel(ids),1);
 for k=1:numel(ids)
  e=ids(k);ps=find(q.good(e,:));if numel(ps)<2,continue;end
  ia=q.ia(e);ib=q.ib(e);nodes=q.node(e,ps)';ha=squeeze(qa.h(ia,ps,:));hb=squeeze(qb.h(ib,ps,:));hd=(ha+hb)/2;hm=hb-ha;
  m0=ppval(M0,q.t(e));dm=ppval(M1,q.t(e))-m0;ra=qa.r(ia,:)';rb=qb.r(ib,:)';
  off=hd*(st(1:3,1,k)-(rb-ra))+hm*(m0-(ra+rb)/2);change=hd*st(1:3,14,k)+hm*dm;
  y=obs.phase(e,ps)'-q.B0(nodes)-off;h=hd*st(1:3,2:13,k);
  sig=obs.sigma(e,ps)';variance=sig.^2;w=1./variance;
  U=null((1./sig)')';wh=U*(h./sig);wb=U./sig';wy=U*[y./sig,-change./sig];n=size(U,1);cols=[ix,ns+nodes'];H=[wh,wb];
  [ii,jj,val]=find(H);ir{end+1}=row+ii(:);ic{end+1}=reshape(cols(jj),[],1);vv{end+1}=val(:);rr{end+1}=wy;row=row+n; %#ok<AGROW>
  counts=counts+accumarray(nodes,1,[nb 1]);edges=[edges;[repmat(nodes(1),numel(nodes)-1,1),nodes(2:end)]]; %#ok<AGROW>
  cr{k}=struct('epoch',e,'nodes',nodes,'h',h,'y',y,'change',change,'w',w);
 end
 Aparts{j}=sparse(vertcat(ir{:}),vertcat(ic{:}),vertcat(vv{:}),row,ns+nb);rhsParts{j}=vertcat(rr{:});clockRows{j}=cr;
 if j>1&&abs(blocks{j-1}.b-b.a)<1e-7
  left=gnss_states(blocks{j-1},b.a);right=gnss_states(b,b.a);cc=zeros(6,ns+nb);cc(:,ix-12)=left(:,2:13);cc(:,ix)=-right(:,2:13);
  C=[C;cc];d=[d;right(:,1)-left(:,1)];ds=[ds;right(:,14)-left(:,14)]; %#ok<AGROW>
 end
 blocks{j}=b;
end
A=vertcat(Aparts{:});y=vertcat(rhsParts{:});clear Aparts rhsParts;
G=graph(edges(:,1),edges(:,2),[],nb);component=conncomp(G);gauge=sparse(component,1:nb,1,max(component),nb);gauge=gauge./sum(gauge,2);
assert(max(abs(q.H*gauge'),[],'all')<1e-8,'Clock datum would conflict with known integers');
% Offsets seen fewer than twice cannot support state information. They remain
% represented, with a pure clock gauge when isolated, not fixed to an old fit.
C=[C;zeros(size(q.H,1),ns),q.H;zeros(size(gauge,1),ns),full(gauge)];
d=[d;q.target-q.H*q.B0;zeros(size(gauge,1),1)];ds=[ds;zeros(size(q.H,1)+size(gauge,1),1)];
scale=full(sqrt(sum(A.^2,1)))';scale=max(scale,1e-8);Cs=C./scale';rowScale=vecnorm(Cs,2,2);assert(all(rowScale>0));Cs=Cs./rowScale;
part=lsqminnorm(Cs,[d,ds]./rowScale);Z=null(Cs);res=y-(A./scale')*part;design=(A./scale')*Z;
fprintf('Direct SD constrained QR: %d rows, %d free parameters\n',size(design));
colScale=max(vecnorm(design),1e-20);design=design./colScale;[Q,R]=qr(design,0);z=R\(Q'*res);clear Q design;
solution=(part+Z*(z./colScale'))./scale;check=max(abs(C*solution-[d,ds]),[],'all');assert(check<1e-6,'Relative continuity/integer constraint failure');
ratio=min(abs(diag(R)))/max(abs(diag(R)));assert(ratio>1e-10,'Direct SD state is insufficiently observable; do not silently fix a null trajectory');
% Formal covariance is conditional on the prescribed mean orbit. Changing to
% a second GNSS-only mean gives a separate geometry/force sensitivity check.
T=(Z./scale)./colScale;F=T/R;diagCov=sum(F.^2,2);
report=struct('available_phase_pairs',nnz(q.good),'phase_pairs_used',sum(counts),'clock_eliminated_rows',size(A,1),'free_parameters',size(R,1),'clock_datum_components',size(gauge,1),'fixed_rank',size(q.H,1),'constraint_error',check,'QR_diagonal_ratio',ratio,'R_reciprocal_condition',rcond(R),'residual_weighted_RMS',sqrt(sum((A*solution(:,1)-y(:,1)).^2)/size(A,1)), ...
 'unseen_pair_offsets',nnz(counts==0),'conditional_coefficient_sigma_max',sqrt(max(diagCov(1:ns))));
tags={'direct','alternate_mean'};
for v=1:2
 if v==1,c=solution(:,1);M=M0;else,c=sum(solution,2);M=M1;end
 baseline=[];clocks=[];residuals=[];formal=[];
 for j=1:nblocks
  b=blocks{j};ix=(j-1)*12+(1:12);tt=(ceil(b.a):ceil(b.b)-1)';st=gnss_states(b,tt);state=squeeze(st(:,1,:))+squeeze(sum(st(:,2:13,:).*reshape(c(ix),1,12,1),2));
  if v==2,state=state+squeeze(st(:,14,:));end
  baseline=[baseline;tt,state',repmat(j-1,numel(tt),1)]; %#ok<AGROW>
  cr=clockRows{j};
  for k=1:numel(cr)
   if isempty(cr{k}),continue;end
   r=cr{k};yy=r.y;if v==2,yy=yy-r.change;end
   innovation=yy-r.h*c(ix)-c(ns+r.nodes);clock=sum(r.w.*innovation)/sum(r.w);clocks=[clocks;q.t(r.epoch),clock,numel(r.nodes)]; %#ok<AGROW>
   residuals=[residuals;repmat(q.t(r.epoch),numel(r.nodes),1),r.nodes,innovation-clock]; %#ok<AGROW>
  end
  if v==1
   ts=q.t(q.t>=b.a&q.t<b.b);stn=gnss_states(b,ts);Pc=F(ix,:)*F(ix,:)';
   for k=1:numel(ts),p=stn(1:3,2:13,k)*Pc*stn(1:3,2:13,k)';formal=[formal;ts(k),sqrt(max(diag(p),0))'];end %#ok<AGROW>
  end
 end
 t=baseline(:,1);m=ppval(M,t')';Md=M;Md.coefs=Md.coefs(:,1:3).*[3 2 1];Md.order=3;mv=ppval(Md,t')';
 folder=fullfile(out,tags{v});if ~isfolder(folder),mkdir(folder);end
 for s=1:2
  sign=2*s-3;L=struct('values',[t,m+sign*baseline(:,2:4)/2,mv+sign*baseline(:,5:7)/2,baseline(:,8)],'integer_error',max(abs(q.H*(q.B0+c(ns+(1:nb)))-q.target)),'continuity_error',check);
  save(fullfile(folder,[char(64+s) '_L.mat']),'L','-v7.3');
 end
 relative=struct('baseline',baseline,'clock_difference_m',clocks,'postfit_phase',residuals,'pair_ambiguities',q.B0+c(ns+(1:nb)),'coefficients',c,'formal_baseline_sigma_m',formal,'report',report);save(fullfile(folder,'relative.mat'),'relative','-v7.3');
end
save(fullfile(out,'sd_linear_system.mat'),'A','y','C','d','ds','scale','part','Z','R','colScale','solution','counts','component','report','-v7.3');
report.note='Direct single-differenced common-view carrier likelihood, separate from prescribed GNSS-only mean-orbit geometry. No pseudorange or single-view carrier directly updates the baseline. Free epoch clock difference and track-pair float offsets are fitted under the inherited 297 DD constraints. Absolute/common and unresolved offsets are not integer-fixed. Formal covariance is conditional on mean geometry, not a fully joint covariance with reused GNSS observations. Alternate mean is an empirical reference-sensitivity check, not a calibrated uncertainty envelope. No KBR/POD/ACC inputs or screening.';
writejson(fullfile(out,'navigation_method.json'),report);disp(report);
end
function writejson(path,s),f=fopen(path,'w');fprintf(f,'%s',jsonencode(s,PrettyPrint=true));fclose(f);end
