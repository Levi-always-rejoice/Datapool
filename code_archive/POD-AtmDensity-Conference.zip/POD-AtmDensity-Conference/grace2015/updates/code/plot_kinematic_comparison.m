function plot_kinematic_comparison(out)
z=load(fullfile(out,'comparison.mat'));t=z.t;rv=z.rv;m=all(isfinite(rv),2);t=t(m);rv=rv(m,:);rv([false;diff(t)>10.1],:)=NaN;
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1500 1250]);tiledlayout(4,1);
nexttile;plot((t-16)/3600,rv(:,[1 3 4])*1000);grid on;xlim([0 24]);ylabel('Range - KBR (mm)');legend('Reduced dynamic, 240','Kinematic, own 135','Kinematic, inherited 240');title('Native 10-s observations: no filtering or alignment change');
nexttile;plot((t-16)/3600,rv(:,[1 3 4])*1000);grid on;xlim([0 24]);ylim([-50 50]);ylabel('Range - KBR (mm)');title('Same range comparison, +/-50 mm detail; excursions outside limits are in panel 1');
for k=1:2
 nexttile;d=z.dd{k+1};[yes,ix]=ismember(z.common,d(:,1));tt=z.common(yes);v=d(ix(yes),2:3)*1e12;v([false;diff(tt)>1.1],:)=NaN;
 plot((tt-16)/3600,v);grid on;xlim([0 24]);ylabel('\Delta\rho (10^{-12} kg/m^3)');legend('GNSS','ACC');
 if k==1,title('20-min density from purely kinematic integer solution');else,title('20-min density from kinematic positions with inherited independent integers');end
end
xlabel('UTC hour, GRACE A/B, 2015-03-15');exportgraphics(fig,fullfile(out,'kinematic_comparison.png'),'Resolution',150);close(fig);
end
