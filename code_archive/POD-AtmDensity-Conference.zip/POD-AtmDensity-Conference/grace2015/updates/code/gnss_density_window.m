function results=gnss_density_window(d,branches,windowSeconds)
assert(ismember(windowSeconds,[600 1200]));
names=fieldnames(branches);nv=numel(names);nav=branches.(names{1}).values;
for j=2:nv,assert(isequal(nav(:,1),branches.(names{j}).values(:,1)),'Branch epochs differ');end
nrhs=nv+4;
% Native configurable integrated force fit. Keep basis scaling unchanged.
mu=3.986004418e14;t=nav(:,1);qt=d.t(:);half=windowSeconds/2;stop=floor(t(end))-half;
R=gnss_hermite(qt,d.r,d.v);POD=gnss_hermite(d.pod_t,d.pod_r,d.pod_v);
pert=spline(qt,(d.known+mu*d.r./vecnorm(d.r,2,2).^3)');
dk=d.drag.*d.K(:);DK=spline(qt,dk');ref=zeros(numel(qt),3,4);
ref(:,:,2)=dk.*d.acc_rho(:);ref(:,:,3)=dk*1e-12;ref(:,:,4)=dk.*d.acc_bias_template_rho(:);
REF=spline(qt,reshape(permute(ref,[2 3 1]),12,[]));
opts=odeset('RelTol',2e-13,'AbsTol',1e-11,'MaxStep',20);rows={};checks=[];
for begin=ceil(t(1))+half:600:stop
 centers=(begin:min(begin+599,stop))';pivot=mean(centers([1 end]));ids=find(t>=centers(1)-half-1 & t<=centers(end)+half+1);tt=t(ids);
 if numel(tt)<2 || ~(tt(1)<pivot && pivot<tt(end)),continue;end
 Y=zeros(6,13);Y(1:3,1)=ppval(R,pivot);[~,piece]=histc(pivot,R.breaks);piece=min(max(piece,1),R.pieces);
 c=R.coefs((piece-1)*3+(1:3),:);u=pivot-R.breaks(piece);Y(4:6,1)=3*c(:,1)*u^2+2*c(:,2)*u+c(:,3);
 Y(1:3,2:4)=eye(3);Y(4:6,5:7)=eye(3)/600;
 block=struct('pivot',pivot,'ncol',13,'left',ode113(@rhs,[pivot tt(1)],Y(:),opts),'right',ode113(@rhs,[pivot tt(end)],Y(:),opts));
 st=gnss_states(block,tt);H=st(1:3,2:9,:);y=st(1:3,10:13,:);
 yy=zeros(3,nv,numel(tt));for branch=1:nv,nn=branches.(names{branch}).values;yy(:,branch,:)=reshape(nn(ids,2:4)'-squeeze(st(1:3,1,:)),3,1,[]);end
 y=cat(2,yy,y);
 y(:,nv+1,:)=reshape(ppval(POD,tt')-squeeze(st(1:3,1,:)),3,1,[]);
 NN=zeros(8,8,numel(tt)+1);bb=zeros(8,nrhs,numel(tt)+1);
 for k=1:numel(tt),NN(:,:,k+1)=NN(:,:,k)+H(:,:,k)'*H(:,:,k);bb(:,:,k+1)=bb(:,:,k)+H(:,:,k)'*y(:,:,k);end
 rr=zeros(numel(centers),nrhs+2);accepted=false(numel(centers),1);
 for k=1:numel(centers)
  L=find(tt>=centers(k)-half,1);U=find(tt>=centers(k)+half,1);if isempty(U),U=numel(tt)+1;end
  if isempty(L) || U-L~=windowSeconds,continue;end
  A=NN(:,:,U)-NN(:,:,L);B=bb(:,:,U)-bb(:,:,L);sc=sqrt(max(diag(A),1e-30));cc=((A./sc./sc')\(B./sc))./sc;
  u=(centers(k)-pivot)/600;rho=(cc(7,:)+u*cc(8,:))*1e-12;rr(k,:)=[centers(k),rho,U-L];accepted(k)=true;
  if mod(k-1,300)==0
   hh=reshape(permute(H(:,:,L:U-1),[1 3 2]),[],8);yy=reshape(permute(y(:,:,L:U-1),[1 3 2]),[],nrhs);ss=vecnorm(hh);qc=(hh./ss)\yy;qc=qc./ss';qr=(qc(7,:)+u*qc(8,:))*1e-12;checks(end+1)=max(abs(qr-rho)); %#ok<AGROW>
  end
 end
 rows{end+1}=rr(accepted,:); %#ok<AGROW>
 if mod(numel(rows),25)==0,fprintf('  density chunks %d\n',numel(rows));end
end
values=vertcat(rows{:});injection=max(abs(values(:,nv+4)-1e-12));assert(injection<1e-17);assert(max(checks)<1e-17);
results=struct;for branch=1:nv,results.(names{branch})=struct('values',values(:,[1,branch+1,nv+2:nv+5,nv+6]),'injection_error',injection,'QR_difference',max(checks));end
 function z=rhs(time,z)
  x=reshape(z,6,13);v=zeros(6,13);r=ppval(R,time);g=gnss_gradient(r);v(1:3,:)=x(4:6,:);v(4:6,:)=g*x(1:3,:);
  v(4:6,1)=v(4:6,1)+ppval(pert,time)-mu*r/norm(r)^3-g*r;
  v(4:6,8:9)=v(4:6,8:9)+ppval(DK,time)*[1,(time-pivot)/600]*1e-12;
  v(4:6,10:13)=v(4:6,10:13)+reshape(ppval(REF,time),3,4);z=v(:);
 end
end
