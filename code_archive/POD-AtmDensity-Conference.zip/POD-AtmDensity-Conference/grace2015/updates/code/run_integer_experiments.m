function run_integer_experiments(baseline)
% Requires baseline native MATLAB functions on path and completed raw run.
here=fileparts(mfilename('fullpath'));addpath(here);out=fullfile(here,'run');
if ~isfolder(out),mkdir(out);end
audit_existing_integers(baseline,out);
prepare_block_validation(baseline,out);
validate_blocked_integers(baseline,out,1,false);
validate_blocked_integers(baseline,out,4,false);
validate_blocked_integers(baseline,out,4,true);
fit_integer_only_control(baseline,out);
evaluate_integer_experiments(baseline,out,false);
fit_connected_integer_only(baseline,out);
evaluate_integer_experiments(baseline,out,true);
audit_hidden_slips(baseline,out);
end
