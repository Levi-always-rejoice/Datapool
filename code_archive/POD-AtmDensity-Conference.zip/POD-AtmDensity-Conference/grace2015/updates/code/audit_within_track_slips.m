function report=audit_within_track_slips(root,out)
% DIAGNOSTIC ONLY: POD coordinates remove known geometric range. No POD
% values from this routine are used to choose or fix any ambiguity.
if ~isfolder(out),mkdir(out);end
source=fullfile(root,'independent_run');f1=1575.42e6;f2=1227.6e6;c=299792458;l1=c/f1;l2=c/f2;alpha=f1^2/(f1^2-f2^2);beta=1-alpha;M=[alpha*l1,beta*l2;l1,-l2];report=struct;series=cell(2,1);
for sat='AB'
 z=load(fullfile(source,[sat '_raw_design.mat']),'q');q=z.q;z=load(fullfile(source,'fresh_force_reference',[sat '_all_density.mat']),'d');d=z.d;
 P=gnss_hermite(d.pod_t,d.pod_r,d.pod_v);dr=ppval(P,q.t')'-q.r;er=q.phase-sum(q.h.*reshape(dr,[],1,3),3);nt=numel(q.t);
 same=q.good(2:end,:)&q.good(1:end-1,:)&q.labels(2:end,:)==q.labels(1:end-1,:)&diff(q.t)<=10.1;
 di=diff(er);di(~same)=NaN;clk=median(di,2,'omitnan');count=sum(isfinite(di),2);clk(count<3)=NaN;
 innovations=di-clk;gf=diff(q.gf);gf(~same)=NaN;local=movmedian(gf,300,'omitnan','SamplePoints',q.t(2:end));gfi=gf-local;
 % Only use continuous segments with a clock estimate for local step fits.
 clock=cumsum([0;fillmissing(clk,'constant',0)]);corrected=er-clock;flags=find(abs(innovations)>.03&abs(gfi)>.03&same&isfinite(clk));events=[];
 for index=flags'
  [e,p]=ind2sub(size(innovations),index);center=(q.t(e)+q.t(e+1))/2;label=q.labels(e,p);
  ix=find(q.good(:,p)&q.labels(:,p)==label&abs(q.t-center)<=120);left=ix(q.t(ix)<center);right=ix(q.t(ix)>center);
  if numel(left)<6||numel(right)<6||any(~isfinite(clk(min(ix):max(ix)-1))),continue;end
  jump=zeros(2,1);sigma=zeros(2,1);
  for ch=1:2
   if ch==1,y=corrected(:,p);else,y=q.gf(:,p);end
   aa=robustline(q.t(left)-center,y(left));bb=robustline(q.t(right)-center,y(right));jump(ch)=bb(1)-aa(1);sigma(ch)=hypot(aa(2),bb(2));
  end
  integers=M\jump;rounded=round(integers);delta=jump-M*rounded;
  pass=any(rounded~=0)&&all(abs(integers-rounded)<.15)&&all(abs(delta)<max(.015,3*sigma))&&all(sigma<.015);
  events=[events;(center-16)/3600,p-1,label,innovations(e,p),gfi(e,p),jump',sigma',integers',rounded',double(pass)]; %#ok<AGROW>
 end
 if isempty(events),events=zeros(0,14);end
 labels=unique(q.labels(q.good));durations=zeros(numel(labels),1);boundaries=[];boundaryEvents=[];
 for j=1:numel(labels),[ii,~]=find(q.labels==labels(j)&q.good);durations(j)=max(q.t(ii))-min(q.t(ii));end
 for p=2:33
  ix=find(q.good(:,p));for j=2:numel(ix),a=ix(j-1);b=ix(j);if q.labels(a,p)==q.labels(b,p),continue;end
   sameRaw=double(floor(q.ids(b,p)/100000)==floor(q.ids(a,p)/100000));boundaries=[boundaries;(q.t(b)-16)/3600,p-1,q.t(b)-q.t(a),sameRaw]; %#ok<AGROW>
   if q.t(b)-q.t(a)>120,continue;end
   center=(q.t(a)+q.t(b))/2;left=find(q.good(:,p)&q.labels(:,p)==q.labels(a,p)&q.t>=center-120);right=find(q.good(:,p)&q.labels(:,p)==q.labels(b,p)&q.t<=center+120);
   if numel(left)<6||numel(right)<6||any(~isfinite(clk(min(left):max(right)-1))),continue;end
   jump=zeros(2,1);sigma=zeros(2,1);
   for ch=1:2
    if ch==1,y=corrected(:,p);else,y=q.gf(:,p);end
    aa=robustline(q.t(left)-center,y(left));bb=robustline(q.t(right)-center,y(right));jump(ch)=bb(1)-aa(1);sigma(ch)=hypot(aa(2),bb(2));
   end
   integers=M\jump;rounded=round(integers);delta=jump-M*rounded;
   integerLike=all(abs(integers-rounded)<.15)&&all(abs(delta)<max(.015,3*sigma))&&all(sigma<.015);
   noJump=integerLike&&all(rounded==0);slip=integerLike&&any(rounded~=0);
   boundaryEvents=[boundaryEvents;(center-16)/3600,p-1,q.labels(a,p),q.labels(b,p),sameRaw,jump',sigma',integers',rounded',double(noJump),double(slip)]; %#ok<AGROW>
  end
 end
 if isempty(boundaryEvents),boundaryEvents=zeros(0,15);end
 report.(sat)=struct('track_labels',numel(labels),'track_duration_percentiles_minutes',prctile(durations/60,[0 25 50 75 100]),'tracks_shorter_than_10min',nnz(durations<600),'native_phase_differences',nnz(same),'joint_IF_GF_threshold_crossings',numel(flags),'locally_testable_events',size(events,1),'persistent_integer_like_events',nnz(events(:,14)),'tracking_label_boundaries',size(boundaries,1),'same_raw_track_pipeline_boundaries',nnz(boundaries(:,4)),'testable_short_boundaries',size(boundaryEvents,1),'boundary_no_jump',nnz(boundaryEvents(:,14)),'boundary_integer_jump',nnz(boundaryEvents(:,15)),'same_raw_boundary_no_jump',nnz(boundaryEvents(:,5)&boundaryEvents(:,14)),'same_raw_boundary_integer_jump',nnz(boundaryEvents(:,5)&boundaryEvents(:,15)));
 writematrix(events,fullfile(out,[sat '_within_track_events.csv']));writematrix(boundaries,fullfile(out,[sat '_track_boundaries.csv']));writematrix(boundaryEvents,fullfile(out,[sat '_boundary_phase_audit.csv']));
 series{double(sat)-64}=struct('t',q.t(2:end),'IF',innovations,'GF',gfi,'same',same,'labels',q.labels(2:end,:),'events',events);disp(report.(sat));
end
report.note='Screening and event classification are diagnostic, not automatic slip correction. IF innovations use POD geometry and robust common receiver-clock differences; GF removes geometry/clock without POD. Integer-like jumps require both frequencies to support a persistent local step. Ionosphere, hardware/antenna effects and transmitter errors can still mimic events. Large pre-detected slips already start a separate tracking label, so a shortage of accepted integers is not itself evidence of within-track slips.';
save(fullfile(out,'slip_diagnostics.mat'),'series','report','-v7.3');f=fopen(fullfile(out,'slip_diagnostics.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 850]);tiledlayout(2,1);
for k=1:2,nexttile;v=series{k};plot((v.t-16)/3600,v.IF*1000,'.','MarkerSize',2);hold on;if ~isempty(v.events),e=v.events(v.events(:,14)==1,:);plot(e(:,1),e(:,4)*1000,'ro','MarkerSize',8);end;grid on;xlim([0 24]);ylim([-100 100]);ylabel('IF increment residual (mm)');title(sprintf('GRACE %s: within unchanged tracking labels; circles mark integer-like IF/GF events',char(64+k)));end
xlabel('UTC hour, 2015-03-15');exportgraphics(fig,fullfile(out,'within_track_phase_innovations.png'),'Resolution',150);close(fig);
end
function out=robustline(t,y)
X=[ones(numel(t),1),t];coef=X\y;
for j=1:5,r=y-X*coef;s=max(.001,1.4826*median(abs(r-median(r))));w=min(1,2.5*s./max(abs(r),1e-12));coef=(X.*sqrt(w))\(y.*sqrt(w));end
r=y-X*coef;s=max(.001,1.4826*median(abs(r-median(r))));Q=(X'*(w.*X))\eye(2);out=[coef(1),s*sqrt(Q(1,1))];
end
