function report=audit_expansion_remaining(package,out)
% Evaluation only: no change to candidates, integers or navigation.
z=load(fullfile(out,'robust_wide_lanes.mat'),'result','audit');w=z.result.c;candidateAudit=z.audit;
[~,r,p]=qr(w.A','vector');rk=sum(abs(diag(r))>1e-9);H=w.A(p(1:rk),:);W=w.WL(p(1:rk));
z=load(fullfile(grace_update_baseline(package),'P_integer_audit.mat'),'audit');c=z.audit.candidate_detail;Hp=c.A(c.independent,:);
z=load(fullfile(out,'independent_joint_round4.mat'),'result');g=z.result;
report.wide_lane_rank=rk;report.wide_lane_shared_rank=sharedRank(H,Hp);report.L1_L2_shared_rank=sharedRank(g.H,Hp);
report.remaining_without_independent_WL=size(Hp,1)-report.wide_lane_shared_rank;
report.remaining_with_WL_without_NL=report.wide_lane_shared_rank-report.L1_L2_shared_rank;
report.recovered_original_missing=report.L1_L2_shared_rank-240;
report.remaining_original_missing=size(Hp,1)-report.L1_L2_shared_rank;
z=load(fullfile(out,'independent_joint_round5.mat'),'result');stall=z.result;
report.stall_added_rank=stall.added_rank;report.stall_supported=stall.initial_supported;report.stall_WL_supported_space=stall.remaining_WL_supported_rank;report.stall_reason_counts=arrayfun(@(k)nnz(stall.history(:,3)==k),1:4);report.reason_legend={'search_incomplete','fold_disagreement','conditional_or_aggregate_cost','likelihood_separation'};
co=(H'\c.A')';fixedWide=max(abs(co*H-c.A),[],2)<1e-8;assert(max(abs(co(fixedWide,:)*W-c.WL(fixedWide)))<1e-6);
co=(g.H'\c.A')';fixedBoth=max(abs(co*g.H-c.A),[],2)<1e-8;
keys=vertcat(c.accepted.key);[yes,i]=ismember(keys,candidateAudit(:,1:6),'rows');status=nan(size(c.A,1),9);status(yes,:)=candidateAudit(i(yes),9:17);
T=array2table([keys(:,1:2)-1,keys(:,3:6),fixedWide,fixedBoth,status], 'VariableNames',{'GPS1','GPS2','A_label1','B_label1','A_label2','B_label2','WL_fixed','L1_L2_fixed','MW_full','MW_part0','MW_part1','SE_full','SE_part0','SE_part1','robust_pass','rounded_MW','ordinary_mean_minus_integer'});
writetable(T,fullfile(out,'remaining_relation_audit.csv'));
report.note='Counts are independent row-space dimensions; CSV natural relations are redundant. Reference is used only after independent solution is saved. No forced integer rounding is applied to failed directions.';
f=fopen(fullfile(out,'remaining_audit.json'),'w');fprintf(f,'%s',jsonencode(report,PrettyPrint=true));fclose(f);disp(report);
end
function n=sharedRank(A,B)
[a,~]=qr(A',0);[b,~]=qr(B',0);n=nnz(svd(a'*b)>1-1e-10);
end
