function fit_integer_only_control(baseline,out)
% POD supplies only previously audited integer relations. Every unresolved
% real offset and both receiver clocks are re-estimated from GNSS likelihood.
a=load(fullfile(baseline,'A_float_model.mat'),'model');b=load(fullfile(baseline,'B_float_model.mat'),'model');z=load(fullfile(baseline,'P_integer_audit.mat'));c=z.audit.candidate_detail;
H=c.A(c.independent,:);target=c.target(c.independent);B=[a.model.B0+a.model.db;b.model.B0+b.model.db];Q=blkdiag(a.model.Q,b.model.Q);
HQ=H*Q;dv=target-H*B;lambda=(HQ*H')\dv;fixed=B+HQ'*lambda;assert(max(abs(H*fixed-target))<5e-7);
n=numel(a.model.B0);I=gnss_condition_navigation(a.model,[],[],fixed(1:n));save(fullfile(out,'A_integer_only.mat'),'I','-v7.3');
I=gnss_condition_navigation(b.model,[],[],fixed(n+1:end));save(fullfile(out,'B_integer_only.mat'),'I','-v7.3');
summary=struct('integer_constraints',size(H,1),'profile_cost_increase',dv'*lambda,'maximum_integer_error_m',max(abs(H*fixed-target)),'POD_use','Integer decisions from the baseline assisted audit only; no retained real-valued POD offsets','observation_mask','original mask; comparisons must use matched density support');
f=fopen(fullfile(out,'integer_only_control.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
end
