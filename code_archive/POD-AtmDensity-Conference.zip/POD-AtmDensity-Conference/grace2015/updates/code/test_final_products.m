function test_final_products(package,navdir,gpsfolder,out)
if ~isfolder(out),mkdir(out);end
raw=fullfile(grace_update_input_root(package),'raw');models=fullfile(grace_update_input_root(package),'models');t=(0:10:86399)';
fprintf('Build final transmitter interpolation\n');final=final_transmitters(gpsfolder,t,models);
fprintf('Build original transmitter interpolation\n');rt=raw_transmitters(read_jaxa_sp3(fullfile(raw,'madoca18360.sp3.gz')),t,models);
copyfile(fullfile(navdir,'P_integer_audit.mat'),fullfile(out,'P_integer_audit.mat'));copyfile(fullfile(navdir,'history_mask.mat'),fullfile(out,'history_mask.mat'));
z=load(fullfile(navdir,'P_integer_audit.mat'));c=z.audit.candidate_detail;summary=struct;
for sat='AB'
 z=load(fullfile(navdir,[sat '_raw_design.mat']),'q');q=z.q;[rot,~]=raw_attitude(sat,q.t,raw);[receiver,ants]=raw_antennas(sat,models);windRT=nan(33,1);windFinal=windRT;delta=nan(size(q.phase));
 if sat=='A',mi=c.ia;else,mi=c.ib;end
 mask=false(size(q.good));mask(mi,:)=c.mask;
 for j=1:numel(q.t)
  i=round(q.t(j)/10)+1;ps=find(isfinite(q.phase(j,:))'&~cellfun(@isempty,ants)&isfinite(rt.clock(i,:))'&isfinite(final.clock(i,:))');if isempty(ps),continue;end
  [b0,p0,~,~,w0]=raw_observation_model(i,q.r(j,:),ps,rot(:,:,j),receiver,ants,rt,windRT);
  [b1,p1,h,el,w1]=raw_observation_model(i,q.r(j,:),ps,rot(:,:,j),receiver,ants,final,windFinal);
  windRT(ps)=w0;windFinal(ps)=w1;delta(j,ps)=(p0-p1)';q.phase(j,ps)=q.phase(j,ps)+(p0-p1)';q.code(j,ps)=q.code(j,ps)+(b0-b1)';q.h(j,ps,:)=h;q.elev(j,ps)=el;
 end
 assert(all(isfinite(delta(mask))),'Final products missing frozen selected observations');
 summary.(sat)=struct('selected',nnz(mask),'phase_model_delta_RMS_m',rms(delta(mask)),'phase_model_delta_max_m',max(abs(delta(mask))));
 save(fullfile(out,[sat '_raw_design.mat']),'q');fprintf('Observation product substitution %s done\n',sat);
end
f=fopen(fullfile(out,'product_substitution.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
fit_connected_integer_only(out,out);
end
