function finalize_13_15(root)
out=fullfile(root,'audit_13_15');dirs={'ten_minute_run','bridge_density_run','bridge_force_density_run','sparse_window_run'};summary=struct;ss=cell(4,1);
for j=1:4,z=load(fullfile(root,dirs{j},'comparison.mat'));ss{j}=z.series;end
for k=1:2
 for j=1:4
  s=ss{j}{k};m=s.mask&s.t>=46816&s.t<=54016;err=s.gnss(m)-s.acc(m);tt=s.t(m);[peak,i]=max(abs(err));cc=corrcoef(s.gnss(m),s.acc(m));summary.(dirs{j}).(sprintf('min%d',30-10*k))=struct('centers',nnz(m),'RMS',rms(err),'peak_error',peak,'peak_UTC_hour',(tt(i)-16)/3600,'r',cc(1,2));
 end
 a=ss{1}{k};b=ss{4}{k};[t,ia,ib]=intersect(a.t,b.t);m=a.mask(ia)&b.mask(ib)&t>=46816&t<=54016;
 summary.matched.(sprintf('min%d',30-10*k))=struct('centers',nnz(m),'old_RMS',rms(a.gnss(ia(m))-a.acc(ia(m))),'new_RMS',rms(b.gnss(ib(m))-b.acc(ib(m))));
end
r=load(fullfile(root,'bridge_force_density_run','range_comparison.mat'));m=r.common&r.t>=46816&r.t<=54016;summary.range=struct('common_epochs',nnz(m),'old_RMS_mm',rms(r.rv(m,1))*1e3,'new_RMS_mm',rms(r.rv(m,2))*1e3);
f=fopen(fullfile(out,'stage_comparison.json'),'w');fprintf(f,'%s',jsonencode(summary,PrettyPrint=true));fclose(f);
set(groot,'defaultFigureVisible','off');fig=figure('Position',[20 20 1400 1000]);tiledlayout(3,1);
for k=1:2
 nexttile;s=ss{4}{k};m=s.mask&s.t>=46816&s.t<=54016;plot((s.t(m)-16)/3600,[s.gnss(m),s.acc(m)]*1e12);grid on;xlim([13 15]);ylabel('\Delta\rho (10^{-12} kg/m^3)');title(sprintf('Current %d-minute retrieval, fixed integers and missing epochs allowed',30-10*k));legend('GNSS','ACC');
end
nexttile;a=ss{1}{2};b=ss{4}{2};ma=a.mask&a.t>=46816&a.t<=54016;mb=b.mask&b.t>=46816&b.t<=54016;v=a.gnss-a.acc;v(~ma|[false;diff(a.t)>1.1])=NaN;plot((a.t-16)/3600,v*1e12);hold on;plot((b.t(mb)-16)/3600,(b.gnss(mb)-b.acc(mb))*1e12);grid on;xlim([13 15]);ylabel('GNSS - ACC (10^{-12} kg/m^3)');xlabel('UTC hour, GRACE A/B, 2015-03-15');title('10-minute errors: original versus current');legend('Original','Current');exportgraphics(fig,fullfile(out,'current_and_previous.png'),'Resolution',150);close(fig);disp(summary);
end
