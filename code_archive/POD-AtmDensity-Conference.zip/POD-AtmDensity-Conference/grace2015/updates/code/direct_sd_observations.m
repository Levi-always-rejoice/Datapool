function o=direct_sd_observations(q)
% Deliberate measurement boundary: phase is read only for simultaneous
% common-view samples. No code or unmatched carrier value enters this output.
[e,p]=find(q.good);ia=sub2ind(size(q.qa.phase),q.ia(e),p);ib=sub2ind(size(q.qb.phase),q.ib(e),p);
o=struct('phase',nan(size(q.good)),'sigma',nan(size(q.good)));
o.phase(q.good)=q.qb.phase(ib)-q.qa.phase(ia);
alpha=1575.42e6^2/(1575.42e6^2-1227.6e6^2);beta=1-alpha;
sa=max(sin(q.qa.elev(ia)),.25);sb=max(sin(q.qb.elev(ib)),.25);
o.sigma(q.good)=.005*hypot(alpha,beta)*sqrt(1./sa.^2+1./sb.^2);
end
