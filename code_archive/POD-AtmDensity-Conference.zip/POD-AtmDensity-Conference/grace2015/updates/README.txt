GRACE 2015 UPDATES INCLUDED BEFORE THE GRACE-FO TRANSFER
Updated package: 2026-10-01

This directory adds the September 30 GRACE A/B development that was missing
from the earlier combined package. It is distinct from the older S/F/R/O/M/P
manuscript reproduction. The latter is retained without relabeling its results.

START WITH THE PLOTS
  examples/featured_comparison/GRACE2015_updated_independent_vs_assisted.png
  examples/featured_comparison/GRACE2015_updated_range.png
  examples/featured_comparison/GRACE2015_updated_all_outputs_fullscale.png
  examples/featured_comparison/plot_metrics.json

The close independent/assisted 2015 result is the LAST FOUR HOURS of March 15:
  Common-view independent: density RMS 3.58630e-14 kg/m^3, correlation 0.736088.
  Common-view + POD integers: RMS 3.37229e-14, correlation 0.746052.
  Subsequent independent direct carrier differences: RMS 3.36969e-14,
      correlation approximately 0.7199.
The last branch changes the relative likelihood; it is not a pure integer-only
ablation. The paired common-view branches provide that controlled comparison.
All use a 20-minute density window. No extra display filtering, fitted scale,
lag, or mean removal is applied in the featured plots. Last-four-hour scores
use all 13,774 finite available fitted centers, not a hand-picked residual mask.
The full-day comparisons remain less favorable and are included explicitly.

COMPLETE DEVELOPMENT SOURCE AND RESULTS
107 original native MATLAB routines are preserved in code/. SOURCE_PROVENANCE.json
records original and packaged hashes. Path changes resolve original raw/model
products from the package and generated baseline files from the run workspace.
Additional entry-point, evaluation, and plotting routines are clearly separate.
DEVELOPMENT_HISTORY.md preserves the original dated investigation narrative;
statements there that the old ZIP was unchanged describe that historical work.

Included developments and examples:
  - Five-degree elevation and window-level phase coverage (arc5_run).
  - Preserved tracking-label integers through dynamically connected gaps,
    and reevaluation of missing physical force epochs (bridge_force_density_run).
  - Moving density windows with missing measurement epochs (sparse_window_run).
  - Phase outlier/weighting controls and 13-15 UTC diagnostics.
  - Independent versus POD-assisted integer constraints under the same
    reduced-dynamic model (reduced_dynamic_pod_integer_run).
  - Robust one-minute MW summaries, sampling-defined validation portions,
    exact graph consistency and conditional joint integer expansion.
  - Screened pseudorange aggregated once over long intervals; code/carrier
    covariance factorization; cycle-slip diagnostics (code_history_slip_audit).
  - Held-out phase weighting, including its unsuccessful controls.
  - Controlled separation of integer assistance and POD phase screening;
    common-view independent and assisted controls (assistance_factorial_run).
  - Direct common-view differential carrier fit and alternate independent
    mean-orbit sensitivity (direct_sd_run).

RAW-INPUT REPRODUCTION
From the package root in MATLAB:
    out = run_grace_updates;
This first regenerates the original-data baseline, then independently rebuilds
the float/blocked likelihoods, robust wide-lane and joint integer histories,
screened code anchors, common-view fits and direct differential navigation.
It computes the assisted common-view control separately and applies the same
20-minute density operator. New output appears under runs/ with generated
checkpoints and updated_comparison/ figures. It never reads examples/ as input.
The 107 source routines and historical controls are included; the default
runner follows the final common-view/direct sequence, not every rejected trial.
run_grace retains the original manuscript route. run_all now also includes
the 2015 update through run_grace_updates. See root validation notes for tests.

INTEGER / DATA STATUS
The historical independent 2015 update carries 297 fixed independent relative
DD combinations; unresolved observable offsets remain float. The common-view
assisted control has 360 nested combinations. Do not describe the 2015 branch
as the later GRACE-FO fully-fixed admitted-component algorithm. The admitted
observations, common-view requirement and preserved history are documented.
Independent navigation/fixing does not use spacecraft POD, KBR or ACC. The
ACC comparison retains its historical POD-calibrated constant body-X bias.
No spacecraft POD supplies the mean geometry in the independent fit. Native
2015 GPS1B cadence is 10 seconds; one-second output is not one-second sampling.
This is full-day batch ambiguity processing with 20-minute orbit/density
parameterization, not a completed causal near-real-time demonstration.

VERSION HONESTY
The archived September 30 plots are the actual completed pre-GRACE-FO results.
They are not replaced with the older manuscript R branch. A fresh raw replay
can choose a different partial integer subset under numerical perturbations;
the known sensitivity must be inspected if the updated output departs from
these saved examples. No archived ambiguity values are shipped or injected.

The updated 2015 raw-chain integration run completed. See validation/GRACE_UPDATED_RAW_REPLAY.txt at the package root.
