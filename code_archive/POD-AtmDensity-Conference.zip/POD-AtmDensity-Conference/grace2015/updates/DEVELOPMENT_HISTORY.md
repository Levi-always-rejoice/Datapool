# Differential integer ambiguity investigation

## Direct common-view carrier difference estimator, 2026-09-30

Completed output: `direct_sd_run`. **The relative likelihood now fits common-view B-minus-A carrier differences directly, estimating the baseline and receiver-clock difference separately from a prescribed GNSS-only mean orbit.** This addresses the earlier architectural mismatch: the previous common-view branch still fitted two absolute orbits with their respective code measurements and then subtracted them. In this new fit, code and single-view carrier are excluded from the relative measurement equations. They remain useful upstream in the independent GNSS mean-orbit determination and inherited integer history.

The case remains GRACE A/B, 2015-03-15, native 10-second GPS1B with archived JAXA MADOCA real-time transmitter products. The fitted output grid is one second; that does not increase the measurement sampling rate. Navigation uses full-day history and future data, so this is a batch test, not a demonstrated causal onboard implementation. No POD, KBR or ACC reference enters the new relative estimator or its GNSS-only support policy. ACC comparison retains the previous POD-calibrated constant bias.

### Measurement and dynamics

At an epoch and GPS signal observed by both receivers, the ionosphere-free observation is `phaseB - phaseA`. There are 52,238 available common-view pairs; 52,231 enter the solved dynamic intervals. Different GPS signals may enter or leave at any epoch; an entire window need not share a constant GPS set. The covariance uses the sum of the two receivers' elevation-dependent IF phase variances. The free receiver-clock difference is removed through an orthonormal weighted projection and recovered afterward. This is algebraically the same as estimating that clock jointly, without selecting a reference GPS satellite.

With mean position `m=(rA+rB)/2` and baseline `b=rB-rA`, the linearized range correction is `(hB-hA)*dm + (hA+hB)*db/2`. Both terms are retained. The relative dynamics retain the corresponding central-gravity terms `(GB-GA)*dm + (GA+GB)*db/2` plus the existing differential known forces. Thus common motion and conservative acceleration are not assumed to cancel exactly. The 73 dynamic blocks use relative initial position/velocity and constant plus linear acceleration terms, with exact state continuity at connected boundaries. Initial baseline values set the linearization; they are not baseline priors. The existing force reference and subsequent 20-minute density operator are unchanged.

The two-receiver tracking labels map into 591 track-pair offsets. The **same 297 previously independently fixed DD constraints** are applied to these offsets; the other observable offsets remain float. No new integer search or revalidation is claimed. One arbitrary real clock/offset datum is set in each disconnected co-observation component; these are gauge choices, not extra integer fixes. The constrained system is solved by a scaled nullspace and tall QR, avoiding an orbit prior or artificial constraint on weak trajectory directions. It has 43,791 clock-projected rows and 736 free parameters; maximum inherited-integer/state-continuity equation error is 5.33e-15 m.

The principal branch prescribes the mean of the earlier full-data GNSS-only A/B orbits. A second branch uses the mean of the previous common-view GNSS-only orbits. These means differ by 4.1353 cm RMS. This second fit is a sensitivity experiment: formal covariance from the direct estimator is conditional on the prescribed mean and does not account fully for reused observations or mean-orbit uncertainty.

### Results on common support

Old and new density estimates are recomputed on exactly the same A/B navigation epoch support. This differs from some earlier all-output evaluations where A had more orbit epochs than B around gaps. The old matched-window and last-four-hour scores are unchanged; all-output scores should use the controlled values below for this comparison.

The GNSS-only support policy is frozen before reading reference data. Each 20-minute density window requires at least 108 native epochs with two or more simultaneous common-view GPS signals, no gap over 120 seconds including window edges, and adequate integrated clock-projected geometry (minimum eigenvalue above 0.001, condition below 1,000). It accepts **80,380 of 85,170 fitted centers (94.4%)**. These are diagnostic coverage/geometry thresholds, not calibrated error probabilities; the remaining results are saved and plotted as well. No POD phase gate or legacy evaluation mask enters this policy.

| Same 16,833 KBR epochs; density on same 80,380 GNSS-supported centers | Range RMS (mm) | Density RMS vs ACC (kg/m^3) | Density correlation |
|---|---:|---:|---:|
| Previous full coupled estimator | 9.2188 | 1.8387e-13 | 0.2246 |
| Previous coupled common-view estimator | 6.4538 | 9.1730e-14 | 0.4304 |
| New direct common-view carrier differences | **3.9084** | **7.2663e-14** | **0.4564** |
| Direct differences, alternate GNSS mean | 3.9216 | 7.5231e-14 | 0.4541 |

Relative to the preceding common-view branch, range RMS decreases 39.4% and supported density RMS decreases 20.8%. KBR uses the same datum across all cases; no branch-specific alignment is performed. The two new mean choices change the recovered range by only 0.2698 mm RMS, but the supported differential density by 1.9066e-14 kg/m^3 RMS: density remains more sensitive than range to reference geometry and its temporal behavior. Absolute orbit RMS against POD is 6.732/6.835 cm for A/B with the principal mean and 8.555/8.552 cm with the alternate mean.

For all 13,774 available centers in the last four hours, direct SD gives **3.3697e-14 kg/m^3 RMS, r=0.7199**, versus previous common view **3.5863e-14, r=0.7361**. RMS improves slightly, but correlation declines slightly. This is not an improvement in every metric.

Across all 85,170 outputs, direct SD has RMS **1.9416e-13**, correlation **0.2351**, versus previous common view **2.2426e-13**, **0.2343**. Substantial excursions persist, including near 15 UTC even among support-accepted windows. The new estimator improves this independent branch, but does not solve robust full-day density recovery or the remaining integer ambiguity problem. On the original 79,626 legacy accepted centers, the new branch gives **7.1600e-14, r=0.4585**, still worse than the original POD-screened benchmark **4.3365e-14, r=0.6272**. The legacy score is diagnostic only and must not be represented as independently selected coverage.

### Verification and saved files

`test_direct_sd_inputs` changes every pseudorange and every single-view phase value while holding the supplied mean geometry and integer history fixed: the actual differential observations remain exactly unchanged. The mean/baseline measurement identity agrees to 2.22e-16 m, the differential-gravity linearization check to 7.84e-16 m/s^2, and the track-pair incidence has full row rank (591), so no omitted shared-label consistency constraints are required in this dataset. The existing density unit-response and independent QR checks remain below 1.1e-23 kg/m^3. `test_direct_sd_solution` additionally tests clock-datum invariance, constrained synthetic state recovery, and the saved continuity/integer equations. These checks establish algebraic consistency, not physical validity or an integer failure rate.

Saved outputs include `comparison.json`, `comparison.mat`, `direct_sd_comparison.png`, `direct_sd_all_outputs.png`, `gnss_support.csv`, navigation and measurement check JSON files, the solved linear system, and both mean-reference variants' A/B navigation, relative baseline, clock difference, phase residuals, track-pair offsets and density CSV files. Phase residuals are diagnostics only; they do not supply an outlier gate in this run. Formal baseline sigmas are conditional on prescribed geometry and are not yet propagated into the density weighting. The original package, ZIP and manuscript are unchanged.

Reproduce from the existing GNSS-derived caches documented below (this is an experimental continuation, not a new raw-file standalone package):

```matlab
maxNumCompThreads(2);
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
out = fullfile(root,'direct_sd_run');
addpath(package,root);
prepare_direct_sd(root,out);
test_direct_sd_inputs(out);
solve_direct_sd(out);
test_direct_sd_solution(out);
direct_sd_support(out);
% External references are first used in this evaluation:
evaluate_direct_sd(root,out);
```

## Controlled assistance comparison and GNSS-only common view, 2026-09-30

Completed output: `assistance_factorial_run`. This follows the unsuccessful held-out residual weighting test below. **Observation selection has the larger effect on differential density in these controlled runs. A new GNSS-only simultaneous-common-view branch substantially improves the previously accepted comparison intervals and the last four hours, but does not solve the full-day excursions.** Preserve the old baseline and this new candidate separately; do not describe the new branch as a validated all-day replacement.

The main experiment crosses two integer-information levels with three observation selections, giving six controlled fits:

* Original independently validated 297 relative DD combinations, versus the same 297 plus 63 new POD-supported directions. The latter is a nested 360-dimensional constraint set, retaining the two independent directions outside the original POD-only 358-dimensional benchmark. Shared L1/L2 targets are checked for exact consistency. No POD-derived float offsets or positions are held.
* Full original observations; the original POD mask applied to **carrier only**, retaining all screened code; or the same mask applied to both carrier and code, reproducing the old coupled selection. The exact original mask is fixed across the two integer cases. It contains common-view/fixed-track graph selection and a 25-mm POD phase consistency gate, not just outlier rejection.

Every fit reuses the same GNSS-derived reference trajectory, force basis, 73 reduced-dynamic blocks per receiver, 20-minute state/linear-acceleration parametrization, exact continuity equations, receiver clock treatment and subsequent 20-minute density operator. GNSS products, tracking labels, native observations, code screening policy and code weights remain unchanged. Code availability is explicitly preserved in the carrier-only branches. The corresponding code-only observations enter the likelihood once, with no ambiguity coefficient. Robust phase/code offset factorization is recomputed consistently for the available observations. Changing the density retrieval, geometry or orbit-arc length is not part of this comparison.

The full carrier sets contain 66,067 A and 58,152 B samples. The original POD mask retains exactly 48,343 per receiver; retained phase values and ambiguity labels match the old pipeline exactly. Carrier-only selection keeps all 58,622 A and 57,617 B usable code samples, including 14,905/9,672 code-only rows. Applying the mask to code too leaves 43,717/47,945 code samples.

Unobserved carrier offsets need special treatment: a zero covariance entry for an absent parameter cannot be interpreted as a perfectly known ambiguity. `condition_supported_history` eliminates absent offsets from the constraint equations, conditions the observable constraint subspace, and only then reconstructs unused offsets to satisfy the full known history without influencing the orbit. Masking removes all phase data for 361 labels; the nominal 297/360 known constraint spaces have effective observed ranks 294/355 under that mask. These are not new float ambiguity decisions or periodic resets. The full and common-view-only branches retain all 297/360 effective directions.

| Same 16,833 KBR epochs and 79,626 original valid density centers | Range RMS (mm) | Density RMS vs ACC (kg/m^3) | Density correlation |
|---|---:|---:|---:|
| Full observations, independent integers | 9.2188 | 1.8378e-13 | 0.2227 |
| Full observations, add POD integers | 4.9149 | 1.6228e-13 | 0.2016 |
| POD carrier mask, independent integers, retain code | 5.9177 | 7.1259e-14 | 0.4937 |
| POD carrier mask, add POD integers, retain code | 2.3196 | 4.8199e-14 | 0.5981 |
| POD carrier+code mask, independent integers | 5.7080 | 7.0155e-14 | 0.5066 |
| POD carrier+code mask, add POD integers | 2.5680 | 4.6688e-14 | 0.6093 |
| Historical assisted benchmark, current density operator (not a controlled cell) | 2.5123 | 4.3365e-14 | 0.6272 |

Adding the missing integer information alone reduces range RMS by 46.7%, but density RMS by only 11.7%, with a slight decrease in density correlation. With independent integer values unchanged, the POD carrier mask reduces density RMS by 61.2% and raises correlation to 0.494. Removing code as well changes density RMS only about 1-3%, so pseudorange removal is not the principal source of the old favorable result. Both factors together approach the earlier assisted benchmark. The remaining difference from that historical benchmark is not attributed uniquely here; the historical branch also has different code handling and other earlier processing choices.

### GNSS-only decomposition of the selection benefit

An additional pair of controlled runs replaces the composite POD mask with **simultaneous common-view carrier support only**, determined from GNSS availability flags. At each native epoch, retain carrier observations for GPS signals seen by both receivers. Retain all original code observations. Do not require the same GPS satellites to remain visible through a whole 20-minute window, do not require continuous four-signal coverage, do not reset labels, and do not use POD/KBR phase residuals or fixed-component selection. The independent branch keeps precisely the original 297 fixes. The paired 360-fix branch is explicitly assisted and only a diagnostic.

This common-view mask keeps 52,238 phase observations per receiver. The original POD mask is a subset and removes another 3,895 paired samples. Thus much of the old selection can be reproduced without a POD reference. Ninety-five labels have no carrier support after common-view selection, but none removes an observable direction from the 297/360 fixed constraint spaces.

| Same matched support as above | Range RMS (mm) | Density RMS (kg/m^3) | Correlation |
|---|---:|---:|---:|
| GNSS common view, independent 297 | 6.4538 | 9.1003e-14 | 0.4322 |
| GNSS common view, plus POD integer directions | 2.4687 | 5.1121e-14 | 0.5830 |

The independent common-view branch improves matched range RMS by 30.0% and matched density RMS by 50.5%. This is a change in observation support, not a successful new ambiguity resolver. It suggests that dissimilar carrier support at the two receivers is a substantial contributor in this implementation. Improved cancellation of shared GPS errors is a plausible interpretation; this test does not isolate transmitter clock/orbit errors from receiver or other modeling errors. Absolute orbit RMS actually worsens from 6.76/6.86 cm to 8.67/8.43 cm while differential density improves, reinforcing that absolute orbit RMS alone is not an adequate density-quality measure.

For the **last four hours, all 13,774 available density centers**, independent common view gives RMS **3.5863e-14 kg/m^3**, correlation **0.7361**, versus baseline **1.1587e-13**, **0.4034**. The common-view plus added-POD-integer control gives **3.3723e-14**, **0.7461**; the existing independent integers are already sufficient for a close result in this particular interval.

The all-day limitation remains explicit. Across **all 85,170 fitted centers**, independent common-view RMS is **2.4151e-13**, correlation **0.0835**, versus baseline **2.5420e-13**, **0.1625**. Large excursions outside the earlier valid-output mask dominate; correlation across the complete output is worse. The good matched and last-four-hour results must not be presented as a robust full-day success. The old evaluation mask was not used in the new independent orbit estimation, but it is used for the matched table; an independently justified geometry/coverage quality assessment remains needed. This common-view follow-up is exploratory on the same day and needs validation on other days.

Implementation: `run_assistance_factorial`, `condition_supported_history`, optional `phase_good` support in `gnss_long_code_profile`, `evaluate_assistance_factorial`, `run_common_view_control`, `evaluate_common_view_control`, and `summarize_assistance_factorial`. Numerical validation checks that code-only/phase-only factorization matches direct normal equations to <4.5e-16 relative error, and that an unobserved offset is properly marginalized rather than fixed, agreeing with a direct constrained solution to 4.5e-16. Default likelihood/ambiguity covariance regression is exact. The reconditioned baseline orbit differs by at most 9.4e-10 m and density by 7.8e-23 kg/m^3. Fixed-constraint and state-continuity errors are below 1.8e-14 m. Density QR cross-check <8.9e-24, injection error <8.9e-25 kg/m^3. Numerical checks do not establish physical validity or an integer failure rate.

Saved original factors SHA256: `d229715c4a7caaf5c5d67ee6c157d95f551c46736742af6fe3e972cf75ff95e7`. Outputs include `summary.json`, `matched_results.csv`, `independent_common_view_comparison.png`, `independent_all_density_centers.png`, `controlled_assistance_comparison.png`, all eight saved navigation/constraint/density branches, and complete methods/checks. This remains native MATLAB, GRACE A/B 2015-03-15, native 10-second GPS1B, JAXA archived real-time transmitter products, full-day batch estimation and one-second fitted output. ACC retains the previous constant comparison-bias calibration. Original manuscript and ZIP are unchanged.

```matlab
maxNumCompThreads(2);
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
out = fullfile(root,'assistance_factorial_run');
addpath(package,root);
test_phase_selection_controls;
run_assistance_factorial(package,root,out);
check_heldout_weight_regression(root,out);
evaluate_assistance_factorial(root,out);
run_common_view_control(root,out);
evaluate_common_view_control(root,out);
summarize_assistance_factorial(root,out);
```

## GNSS-only held-out phase screening test, 2026-09-30

Completed experiment: `heldout_phase_run`. **Neither screening variant improves differential density over the independent 297 baseline. Do not promote these trials as a new best solution.** The earlier POD-screened 354 benchmark is preserved separately. Original package, manuscript and ZIP are unchanged.

This tests the proposed independent substitute for POD phase screening. Four deterministic folds with assignment `mod(floor(GPS_time/300)+PRN,4)` exclude entire five-minute GPS segments from both receivers. Both carrier and pseudorange of a tested segment are absent from its navigation prediction; other GPS signals and the same track's observations outside that segment estimate the orbit, receiver clock and remaining float offsets. The previous 297 independently validated DD integer relations are conditioned on throughout. No new integer search, phase correction, label reset or reference-assisted mask is used.

This is **conditional** cross-validation: the integer history and cached GNSS-derived linearization/force basis were obtained using the full-day data. It does not independently revalidate those integers, and it is not a causal real-time replay. Unsupported labels (<6 training observations) or epochs with fewer than two remaining GPS signals keep their original weights. All four prediction folds retain the full 297-dimensional seed constraint subspace.

Prediction variances include the reduced-dynamic orbit covariance, ambiguity covariance, free epoch-clock variance and cross-receiver covariance induced by fixed DD constraints. A direct synthetic constrained least-squares inverse agrees with the profiled prediction means to 6.94e-16 and variances to 4.44e-16. In this dataset formal errors are conservative. One robust scale per A, B and B-A is therefore estimated from the held-out standardized residuals (0.2022, 0.1765 and a lower-bound 0.1000), with a 3-mm final sigma floor. These empirical scales are weighting parameters, not calibrated fault probabilities.

Frozen weight policy: `max(0.001,min(1,(3*sigma/abs(residual))^2))`. The **DD-only** branch uses the B-A held-out innovation and applies the resulting weight symmetrically to both receivers. **Combined** also takes the minimum with the separate receiver weights. This downweights inconsistent observations rather than deleting epochs or changing ambiguities. DD-only affects 1,102 paired samples (62 have weight <0.1); combined affects 2,072 A and 1,819 B samples (104/75 have weight <0.1). All 66,067 A and 58,152 B observations, navigation epochs and labels remain. Code/carrier factorization is updated consistently for the changed phase variances. The maximum instantaneous code fraction becomes 0.00348 rather than the original 1.095e-5, only where carrier influence is strongly reduced.

Weights and both navigation solutions were saved before POD/KBR/ACC evaluation. SHA256 of `frozen_weights.mat`: `949a599f0bc6bee50565a5d0de91f9d79e24c7e590fecf87f597547ee696197a`. None of the thresholds or weights was changed after viewing the reference scores.

| Identical support: 16,833 KBR epochs; 79,626 previously accepted density centers | Range RMS (mm) | Density RMS vs ACC (kg/m^3) | Density correlation |
|---|---:|---:|---:|
| Previous independent 297 | 9.2188 | 1.8378e-13 | 0.2227 |
| GNSS DD-only screening, same 297 | 9.6770 | 1.9400e-13 | 0.1922 |
| GNSS combined screening, same 297 | 9.2133 | 1.8573e-13 | 0.2007 |
| Original POD-screened 354, current density operator | 2.5123 | 4.3365e-14 | 0.6272 |

The combined branch improves absolute orbit RMS from 6.756/6.856 cm (A/B) to 6.038/6.179 cm, but range improves by only 0.06%, matched density RMS worsens by 1.1%, and density correlation falls. The DD-only branch worsens both range and density. At 13-15 UTC the combined density RMS falls from 2.0221e-13 to 1.6070e-13, while correlation falls from 0.4114 to 0.3059; that interval alone is not evidence of improved physical signal recovery. Last-four-hour density also worsens: combined RMS 1.2224e-13, r=0.3989, versus baseline 1.1587e-13, r=0.4034.

On **all** 85,170 fitted density centers, baseline/DD-only/combined RMS are 2.5420e-13/2.8569e-13/2.7778e-13, with correlations 0.1625/0.1062/0.1133. These include the large excursions excluded by the earlier benchmark's valid-output mask. Reprocessing the assisted saved orbit without its valid-output mask also produces large excursions (3.5150e-13 RMS across these expanded centers); its good 4.3365e-14 score must therefore always be identified with the original matched valid support. Neither a smooth-looking selected interval nor a smaller absolute orbit RMS establishes good differential density retrieval.

This experiment does not reproduce the benefit of the old POD-assisted selection. It shows that this particular independent residual-based reweighting is insufficient; it does not establish that all phase faults have been corrected, or that every remaining error is an integer error. Slowly varying bias, geometry/force-model coupling and unresolved ambiguity directions remain possible contributors. The original assisted mask also selected connected fixed-track components, so it was more than isolated-outlier removal.

Numerical checks: optional unit phase weights reproduce the saved float ambiguities, covariance and fixed A orbit exactly. Fixed constraint and orbit continuity errors stay below 1.5e-14 m. Density unit-injection error <8.3e-25 kg/m^3 and QR cross-check discrepancy <8.7e-24. These verify numerical consistency, not physical accuracy. Native observations remain 10-second GPS1B, JAXA archived real-time transmitter products, full-day batch navigation with a 20-minute orbit basis and 20-minute density windows. The external ACC comparison retains its prior POD-calibrated constant bias.

Outputs: `heldout_phase_run/comparison.json`, `comparison.mat`, `phase_screening_comparison.png`, `heldout_phase_residuals.png`, `frozen_weights.json`, four held-out prediction MAT files, `numerical_checks.json`, and the `DD_only`/`combined` navigation and density files. Reproduce with native MATLAB:

```matlab
maxNumCompThreads(2);
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
out = fullfile(root,'heldout_phase_run');
addpath(package,root);
prepare_heldout_phase(root,out);
freeze_heldout_weights(root,out);
run_heldout_phase_navigation(root,out);
check_heldout_weight_regression(root,out);
% Reference files are first opened below, after the GNSS decisions are saved:
evaluate_heldout_phase(package,root,out);
plot_heldout_phase_residuals(out);
```

## Benchmark clarification: original POD-screened result versus integer-only control

The user's attached figure titled **20-minute density: five gaps dynamically connected with fixed ambiguities** is exactly `bridge_force_density_run/connected_density.png`. Its orange curve remains the original assisted benchmark. It must not be silently replaced by, or conflated with, the later POD-integer-only control. Use these explicit names in future comparisons:

* **Original POD-screened benchmark (354)**: `bridge_force_run/A_J.mat`, `B_J.mat`, and `bridge_force_density_run/comparison.mat`. POD helps both integer decisions and phase selection; navigation still estimates GNSS orbit states, clocks and remaining float offsets. Five approved navigation gaps are dynamically connected. The phase mask follows fixed-track graph connectivity and a 25-mm POD-referenced, common-clock-removed phase consistency gate (`test_arc_support`).
* **POD integers only (358)**: `reduced_dynamic_pod_integer_run`. POD supplies integer constraints to the broader independent observation likelihood. The earlier POD-based phase mask is intentionally absent, to isolate the effect of integer information in the independent pipeline. This is an ablation control, not an update of the original assisted benchmark.
* **Current independent (297)**: `code_history20_run` / `code_history60_run`, with GNSS-only screening and integer decisions.

The discrepancy is real on identical evaluation times; it is not explained by different plot scales or ACC reference values. The original mask retains 48,343 phase observations per receiver, versus 66,067 A and 58,152 B observations in the independent likelihood and integer-only control. On shared selected observations, phase values and GNSS reference geometry are exactly identical. The original and current ACC density references differ by only 3.71e-18 kg/m^3 RMS on the matched centers.

| Same support: 79,626 density centers and 16,833 KBR epochs | Density RMS vs ACC (kg/m^3) | Density correlation | Range RMS (mm) |
|---|---:|---:|---:|
| Original POD-screened benchmark, original density processing | 4.3095e-14 | 0.6316 | 2.512 |
| Same original saved orbit, current density processing | 4.3365e-14 | 0.6272 | 2.512 |
| POD integers only control | 1.6234e-13 | 0.2012 | 4.923 |
| Current independent 297 | 1.8378e-13 | 0.2227 | 9.219 |

`reconcile_assisted_benchmarks` re-evaluates the original saved GNSS orbit using the current independent force reference and sparse-window density operator. The RMS change in its density time series is only 1.74e-15 kg/m^3, with maximum 2.08e-14, and its good agreement with ACC survives. Therefore the change in density postprocessing/reference does not explain the large degradation; it originates upstream in the changed navigation processing. Phase selection is a major changed input, alongside the different active integer set and gap treatment. This comparison does not isolate every upstream change individually, so it should not be described as proving that the phase mask alone explains the entire difference.

The scientific implication is that the earlier favorable result depended on more than integer fixing. Reproducing it independently requires effective observation quality control as well as resolving more integers. Keep the original assisted benchmark visible, and label the integer-only control separately. No manuscript, original ZIP, old orbit, or old figure is overwritten.

Completed audit: `assisted_benchmark_reconciliation/comparison.json`, `comparison.mat`, `assisted_benchmark_reconciliation.png`, and `original_nav_current_density.csv`. The plot shows all three navigation branches on matched times, plus the original saved orbit processed by both density methods. Reproduce with:

```matlab
maxNumCompThreads(2);
addpath('outputs/wei_aeroconf2015_matlab_20260928', ...
        'outputs/robust_differential_integer_20260928');
root = 'outputs/robust_differential_integer_20260928';
reconcile_assisted_benchmarks(root, ...
    fullfile(root,'assisted_benchmark_reconciliation'));
```

## Screened long-interval code and phase-continuity diagnostic, 2026-09-30

Completed outputs: `code_history20_run`, `code_history60_run`, and `code_history_slip_audit`. These address the proposal to use pseudorange after outlier rejection over longer intervals, while historical/future carrier phase supports fixing, and the follow-up question about cycle slips. The previous estimator already used full-day phase and ambiguity continuity; its 20-minute blocks described the reduced-dynamic orbit basis, not an ambiguity reset or a 20-minute limit on phase history. This remains a full-day batch test, not a new causal fixed-lag demonstration.

Code treatment is implemented in `screen_code_history`, `gnss_long_code_profile`, and `prepare_long_code_history`. A 300-second moving median of code-minus-carrier and MW is used to screen gross code anomalies without rounding or reference integers. The threshold is 4.5 robust sigmas, with floors 0.5 m for IF code-minus-carrier and 0.10 cycle for MW. An anomaly in either code combination excludes that sample from code anchors and MW, but retains the carrier observation, tracking label and dynamic model. The screen flags 7,411/66,067 A code samples (11.2%) and 535/58,152 B samples (0.92%); these are algorithmic flags, not independently proven receiver faults.

The code/carrier likelihood is factored into decorrelated channels: with inverse-variance weights wp and wc, the carrier-like channel is `(wp*phase + wc*code)/(wp+wc)` with ambiguity coefficient `wp/(wp+wc)`, while `phase-code` observes the float carrier offset. The latter is accumulated once per tracking label and 20- or 60-minute bin. One-minute groups support robust averaging and variance inflation; aggregate variance is never below the original formal weighted-average variance. No overlapping smoothed code values are counted as independent measurements. The carrier-like channel retains a maximum code fraction of 1.095e-5 to preserve the correct white-noise covariance factorization: code is overwhelmingly a long-offset constraint, but is not literally absent from that channel.

All previous 287 independently fixed combinations and validated wide lanes are retained. Screened MW increases WL rank from 319 to 330. Conditional fixing adds ten combinations, reaching 297, then stops. Both code-averaging intervals resolve the same constraints and produce numerically identical navigation and density. The longer bin creates no additional phase observations, and aggregation of independent code observations is already a sufficient statistic for a constant offset. Typical complete tracking labels last 19-25 minutes; observed maxima are about 39 minutes, so a 60-minute bin does not generally contain 60 minutes from an individual GPS pass.

| Quantity, identical evaluation support | Previous independent 287 | Screened code 20 min | Screened code 60 min |
|---|---:|---:|---:|
| Fixed independent combinations | 287 | 297 | 297 |
| Range-minus-KBR RMS (mm), 16,833 epochs | 9.320 | 9.219 | 9.219 |
| Density-minus-ACC RMS (kg/m^3), 79,626 centers | 1.8658e-13 | 1.8378e-13 | 1.8378e-13 |
| Density correlation, same centers | 0.2251 | 0.2227 | 0.2227 |

The new fixed space has intersection rank 295 with the POD-assisted 358-dimensional benchmark. Every shared L1/L2 combination agrees; two directions are outside that benchmark and cannot be checked by it. This recovers nine additional originally missing benchmark directions, leaving 63, rather than ten: the other new direction is outside the benchmark. All 597 checkable natural DD rows agree but are redundant. Relative to the preceding 287 solution, range RMS improves only 1.1% and matched density RMS 1.5%, with slightly lower density correlation. This does not resolve the remaining density oscillation. On all 85,170 density centers, RMS is 2.5420e-13 and correlation 0.1625. Absolute orbit RMS is 6.756 cm for A and 6.856 cm for B. Navigation force geometry, density operator, carrier observations and 20-minute dynamic blocks are unchanged. ACC retains its prior POD-calibrated constant comparison bias. POD/KBR/ACC are excluded from screening, code averaging and integer decisions.

The cycle-slip diagnostic (`audit_within_track_slips`) uses POD coordinates only as an external diagnostic geometry reference. It removes robust common receiver-clock increments from IF phase and also checks geometry-free L1-L2 phase. Within unchanged labels, 252 increments exceed both 30-mm IF/GF screening thresholds. Only 81 have sufficient data on both sides for the local persistent-step test; none supports a persistent nonzero integer jump under that test. The other 171 are not ruled out: many lie near short tracks, gaps or inadequate clock support. A local test is not proof that every missed slip has been excluded.

Tracking interruptions and processing splits are a real limitation: A has 502 labels, 90 shorter than ten minutes; B has 570 labels, 209 shorter than ten minutes. There are 42 A and 55 B label boundaries created while the raw tracking identifier stays unchanged. Among 73 locally testable short boundaries, six are consistent with no jump, three support nonzero integer-like jumps, and the rest remain inconclusive. Five of the six no-jump cases are splits within the same raw track. None is automatically joined or corrected from this POD diagnostic.

The three integer-like B boundaries are GPS G13 at about 02:33 UTC (L1/L2 changes -41/-53 cycles), G19 at 17:11 (-2/-3), and G24 at 23:16 (-10/-16). All coincide with a changed raw tracking identifier and already have separate ambiguity labels. They demonstrate phase resets/reacquisition changes, not a newly discovered slip inside a label that the estimator incorrectly held constant. The evidence therefore supports code quality and fragmentation as contributors to incomplete fixing, while leaving some short or poorly observed slip candidates unresolved; it does not establish missed within-track cycle slips as the dominant explanation.

Validation: a synthetic weighted normal-equation test verifies exact code/carrier factorization and once-only aggregation. A real-data unscreened/nonrobust A regression reproduces the original float orbit to a maximum 9.4e-10 m, ambiguity offsets to 5.5e-9 m, and covariance to 2.1e-10 relative Frobenius error. Density numerical checks remain below 7.3e-24 kg/m^3. These are consistency checks; nominal covariance and repeated conditioning do not supply a calibrated integer failure rate.

Key outputs: `code_history_slip_audit/code_history_comparison.png`, `code_history_summary.json`, `slip_diagnostics.json`, `within_track_phase_innovations.png`, `A/B_within_track_events.csv`, `A/B_boundary_phase_audit.csv`, and each history directory's `evaluation_history2.json`, code-anchor audit, integer and navigation files. Original manuscript and ZIP are unchanged.

```matlab
maxNumCompThreads(2);
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
addpath(package,root);
test_code_carrier_factorization;
for minutes = [20 60]
    out = fullfile(root,sprintf('code_history%d_run',minutes));
    prepare_long_code_history(fullfile(root,'independent_run'),out,minutes*60);
    run_code_history_fix(package,root,out);
end
audit_within_track_slips(root,fullfile(root,'code_history_slip_audit'));
check_long_code_equivalence(root,fullfile(root,'code_history_slip_audit'));
summarize_code_history(root);
```

## Independent recovery of 46 of the 118 missing combinations, 2026-09-30

Completed output: `coverage_expansion_run`. The selected solution is `independent_joint_round4.mat`, with `A_L_round4.mat` and `B_L_round4.mat`. Selection uses convergence of independent acceptance tests, not reference scores. The next round adds zero combinations. POD/KBR/ACC are read only by subsequent evaluation. This preserves the 20-minute reduced-dynamic navigation model and every one of the original 240 independently accepted combinations.

The revision addresses two avoidable restrictions in the old wide-lane screening and one search limitation:

1. Estimate Melbourne-Wubbena wide lanes using one-minute medians and robust scatter rather than an ordinary mean vulnerable to isolated pseudorange contamination. The full record and both validation portions must agree with the same integer, satisfy distance <0.20 cycle, distance +3 SE <0.50 cycle, SE <0.12 cycle, and use an SE floor of 0.025 cycle. The original initial ordinary-mean gate used 0.15 cycle; this candidate-screen revision is therefore not a pure change of averaging statistic. The 0.20-cycle limit already used by the prior block validator is applied consistently. Existing validated wide lanes are retained.
2. Choose validation portions from sampling support before examining MW values. Use the old alternating 300-second blocks wherever each portion has at least 12 samples and two minute bins. Otherwise use the chronological first and second halves of the same tracking overlap, with the same sample, bin, scatter and integer-separation checks. This avoids rejecting a five-minute pass simply because it falls almost entirely in one global validation partition. It never tries multiple partitions until one passes. Phase-likelihood validation still uses the unchanged original alternating 300-second profiles.
3. Check exact wide-lane graph consistency, including dependencies from shared receiver tracking labels, then condition all three GNSS phase/code likelihoods on the independently validated integers. Search the remaining integer space, retain accepted fixes exactly, and repeat until no additions pass. Original joint-ILS acceptance thresholds and the 3,000,000-node search budget are unchanged. Full-data and both blocked-profile solutions must agree. No integer is accepted solely because rounding is close, or to reach the assisted fixing count.

The WL graph increases from rank 278 to 319. Conditional joint L1/L2 fixing progresses 240 -> 278 -> 283 -> 286 -> 287 -> 287. All original 240 relations are retained. Of the final 287 independent combinations, 286 lie in the POD-assisted 358-dimensional space and agree in both L1 and L2, to numerical roundoff below 4e-13 cycles. One new direction lies outside the assisted space and cannot be verified by that benchmark. The 582 shared natural DD rows also all agree, but are redundant and must not be counted as 582 independent fixes.

Thus 46 of the original 118 missing directions are recovered independently, with 72 still unresolved. The final WL graph overlaps 316 assisted directions: 42 of the missing 72 lack independently validated wide lanes, while 30 have WL support but not accepted joint L1/L2 resolution. At convergence, 14 transformed directions qualify for search but all fail likelihood separation; another 18 in the remaining WL-supported space do not pass initial eligibility. Search-budget exhaustion is zero. These latter 32 count the whole independent WL space and are not identical to the assisted-only remaining 30.

| Matched quantity | Original independent 240 | Revised independent 287 | POD integer-only 358 control |
|---|---:|---:|---:|
| Range-minus-KBR RMS, 16,833 epochs | 12.050 mm | 9.320 mm | 4.923 mm |
| Density-minus-ACC RMS, 79,626 centers | 1.9559e-13 | 1.8658e-13 | 1.6234e-13 |
| Density correlation, same centers | 0.2408 | 0.2251 | 0.2012 |
| 13-15 UTC density RMS | 2.2120e-13 | 2.0206e-13 | 1.2962e-13 |
| Last-four-hour density RMS | 1.1938e-13 | 1.1587e-13 | 9.6947e-14 |

Density units are kg/m^3. Range RMS improves 22.7% and matched density RMS 4.6%; density correlation declines. The revision improves integer availability and range accuracy but does not remove the density oscillation or establish better density signal fidelity. On all 85,170 available centers, revised density RMS is 2.5936e-13 with correlation 0.1567, versus original 2.6162e-13 and 0.2219. The matched mask is unchanged and was not selected for this new solution. Absolute orbit RMS versus POD is 6.740 cm (A) and 6.825 cm (B), versus 6.730/7.219 cm originally.

Observation/phase masks, code/phase weights, transmitters (JAXA archived real-time), independent GNSS geometry, force reference, 20-minute density operator, and KBR datum are unchanged. Input observations remain native 10-second GPS1B, not 1-Hz raw data. Common absolute and unresolved offsets remain float; this is partial relative integer fixing. ACC retains the previous POD-calibrated constant benchmark bias. All experiments remain full-day batch tests. The nominal covariance and repeated conditional/split-data tests do not provide a calibrated false-fix probability; the independent benchmark agreement is empirical evidence, not proof for unobserved combinations or future days.

Negative controls are retained in `robust_expansion_run`: median-based candidates with the old validation coverage give 266 fixed combinations but worsen range RMS to 14.375 mm; restarting the joint search without preserving the 240 fixed seed gives 253 and 12.375 mm. The final coverage-aware sequence preserves the original seed and all subsequent accepted integers. The largest fixed count is not by itself evidence of better navigation.

Validation: `test_robust_wide_lanes` passes a synthetic case with a five-minute pass inside one global fold and isolated code errors large enough to bias the ordinary mean by more than half a cycle; the revised process recovers the known integer graph exactly. Real-data fixed equality error is below 1e-14 m. Density QR discrepancy is below 7.3e-24 kg/m^3 and unit-density injection error below 8.3e-25. These verify implementation consistency, not physical density fidelity. Plots break lines at missing timestamps rather than joining unsupported intervals.

Key outputs: `coverage_expansion_run/comparison_round4.png`, `evaluation_round4.json`, `remaining_audit.json`, `remaining_relation_audit.csv`, `robust_wide_lane_candidates.csv`, `comparison_round4.mat`, `_round4_differential_density.csv`, and the saved integer/navigation files. Original package, ZIP and manuscript are unchanged.

```matlab
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
addpath(package,root);
run_robust_integer_expansion(package,root);
% Optional regression and post-estimation explanation of remaining gaps:
test_robust_wide_lanes('work/robust_wide_lane_test');
audit_expansion_remaining(package,fullfile(root,'coverage_expansion_run'));
```

The entry point reuses the existing GNSS-only raw-derived float/blocked profiles in `independent_run`; it does not claim to be a new standalone raw-data delivery package. `resolve_independent_joint` also gains optional candidate-file/output-directory arguments for the negative control, with its original defaults preserved.

## With versus without POD-assisted integers: SAME reduced-dynamic model

At the user's request, this comparison returns to the full-day continuous reduced-dynamic navigation model with 20-minute linear-acceleration blocks. It does not use the kinematic navigation experiments below. Code: `compare_pod_integer_relations(...,'reduced_dynamic')`, `evaluate_reduced_dynamic_integer_assistance`, and `plot_reduced_dynamic_integer_assistance`. Completed output: `reduced_dynamic_pod_integer_run`.

The ambiguity audit compares physical L1 and L2 DD integer relations after mapping both solutions into a common ambiguity-reference space. It does not compare raw undifferenced offsets, and it does not infer correctness solely from an ionosphere-free residual. The independent search's saved L1 integer vector and wide-lane vector recover L2 = L1 - wide lane. Both frequencies, the full shared constraint-space intersection, and the individual natural GPS-pair relations are checked.

Results of the integer comparison:

* Every one of the 240 independently fixed combinations lies in the POD-assisted fixed space and agrees for L1, L2 and wide lane. Maximum common-space discrepancy is below 5e-13 cycles (numerical roundoff). There are zero contradictory accepted integers relative to this benchmark.
* The same comparison can be expressed as 466 shared natural DD relations, all agreeing. These relations are redundant and must not be counted as 466 independent fixes.
* The POD-assisted candidate audit contains 754 relations of independent rank 358. It therefore provides 118 additional independent combinations. The independent solution leaves them unresolved; it does not assign them an opposing fixed integer. The prior 354-rank assisted navigation had removed four directions through phase selection; this controlled test keeps the original independent observation mask.
* Of these 118 additional directions, 82 lack independently confirmed wide-lane information and 36 lie in the confirmed wide-lane space but lack independent narrow-lane resolution. The independent wide-lane space has rank 278, of which 276 overlap the 358-rank assisted space. All shared wide lanes also agree (606 checkable natural relations).
* The remaining 288 natural assisted relations are not fixed by the independent 240-dimensional solution. Their fractional IF offset differences have median absolute magnitude 8.769 mm, 95th percentile 35.330 mm and maximum 54.721 mm. These are unresolved offsets, not evidence of a wrongly accepted integer.

Two integer-only controls are constructed from the identical GNSS likelihood: P uses the assisted integer relations; U keeps all existing independent relations and adds assisted ones. Their constraint space is the same rank 358, and their resulting states agree to below 1e-9 in native position/velocity units. No existing independent integer is reversed. All common/absolute real-valued offsets, receiver clocks and orbit parameters are re-estimated from GNSS. Maximum exact-constraint residual is below 1e-14 m.

The controlled performance comparison varies ONLY those integer constraints. Both cases use the same JAXA real-time transmitters, raw-derived observations, phase/code masks, weights, GNSS-based geometry, 20-minute reduced-dynamic model, fresh force reference, 20-minute density operator, KBR datum and evaluation timestamps. POD coordinates and POD-based phase/outlier masks are not supplied to the assisted control. The original independent density is reproduced to 5.1e-27 kg/m^3.

| Quantity | Independent integers | POD-assisted integers only |
|---|---:|---:|
| Independent fixed rank | 240 | 358 |
| Range-minus-KBR RMS, same 16,833 epochs | 12.050 mm | 4.923 mm |
| Density-minus-ACC RMS, same 79,626 centers | 1.9559e-13 kg/m^3 | 1.6234e-13 kg/m^3 |
| Density correlation on those centers | 0.2408 | 0.2012 |
| 13-15 UTC density RMS | 2.2120e-13 kg/m^3 | 1.2962e-13 kg/m^3 |
| Last-four-hour density RMS | 1.1938e-13 kg/m^3 | 9.6947e-14 kg/m^3 |

Adding the missing integer information improves range RMS by 59.1% and matched density RMS by 17.0%, while density correlation decreases. The comparison therefore identifies incomplete fixing as an important range-error source, but does not show that wrong accepted integers are responsible. Extra integer fixes alone do not reproduce the earlier assisted density quality; that earlier processing also used different phase selection. The POD-assisted integers remain a benchmark, not independent proof of truth, and this constant-ambiguity comparison does not rule out undetected within-track observation problems.

Density numerical checks pass: direct-QR discrepancies below 7.3e-24 kg/m^3 and unit-density injection discrepancies below 8.3e-25. ACC retains its prior POD-calibrated constant comparison bias; it does not enter either integer or orbit estimation. These are full-day batch experiments, not a new real-time demonstration. The manuscript and original ZIP are unchanged.

Outputs include `integer_comparison.json`, `integer_only_controls.json`, `evaluation.json`, `integer_relation_comparison.png`, `reduced_dynamic_integer_comparison.png`, and `reduced_dynamic240_DD_comparison.csv`. The CSV includes GPS pair, tracking labels, overlap times, both assisted L1/L2 integers, corresponding independent values where fixed, and unresolved fractional IF offsets. Navigation and density files are retained for both controls.

```matlab
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
out = fullfile(root,'reduced_dynamic_pod_integer_run');
addpath(package,root);
compare_pod_integer_relations(package,root, ...
    fullfile(root,'kinematic_run_v2'),out,'reduced_dynamic');
% The kinematic directory argument is unused in reduced_dynamic mode.
evaluate_reduced_dynamic_integer_assistance(root,out);
```

## Continuous-track kinematic navigation, 2026-09-30

The new `kinematic_run_v2` experiment removes every 20-minute navigation block, empirical-acceleration parameter and dynamical position/velocity continuity constraint. Position XYZ and receiver clock are free at each native 10-second observation epoch. Float carrier offsets span their existing GNSS tracking labels throughout the day; entry/exit of another GPS satellite does not reset a continuing label. No fixed reference GPS is needed. The earlier reduced-dynamic implementation already carried ambiguities across its 20-minute blocks: those blocks restricted orbit shape, not ambiguity lifetime.

`gnss_kinematic_profile` eliminates each epoch's four local parameters by QR and retains the full track-ambiguity normal matrix. `gnss_condition_kinematic` back-substitutes positions under joint DD integer constraints. The observation geometry is linearized around the existing GNSS-only code/carrier bootstrap; no bootstrap trajectory or force model is imposed as a navigation observation. Incoming tracking labels have separate offset parameters. Native epochs with insufficient geometry remain missing; no interpolated one-second positions or invented velocities are supplied. The current implementation is a full-day batch test, not a causal streaming implementation.

Two distinct ambiguity cases are tested. L resolves integers using only the new kinematic likelihood plus the unchanged GNSS-only MW candidate validation: 135 independent combinations are accepted. K retains the 240 independent integer relations from the preceding reduced-dynamic GNSS-only search, while re-estimating all positions, clocks and remaining float offsets kinematically. K inherits those integer relations only, not the earlier orbit states. F is the entirely float kinematic control. No POD/KBR/ACC feeds any of these navigation decisions. After saving the solution, all 260 assisted relations lying within L's fixed subspace agree; these are overlapping relations, not 260 independent fixes.

A numerical degeneracy was identified and repaired in the initial `kinematic_run` attempt: a singleton phase track without usable code had zero independent ambiguity information after epoch-state elimination. Rescaling QR roundoff to unit diagonal produced a spurious enormous position. Such a label is now removed from the observable solve and the affected underdetermined epoch is left missing. The unrepaired folder is diagnostic only. The regression test explicitly covers this case. Direct full-design QR versus profiled/back-substituted states agrees to 4.7e-10 m on a synthetic changing-visibility test; exact constraint error is 1.2e-16 m. The valid rerun has 8,555 A and 8,470 B position epochs, and 8,427 paired epochs. Purely kinematic positioning cannot propagate a missing epoch without an additional temporal model.

The unchanged observation model still has weak short/reacquired tracks. At all 8,386 epochs shared with the old range comparison, range-minus-KBR RMS is 12.041 mm for reduced-dynamic240, 150.575 mm for L and 148.787 mm for K. K's median absolute range residual is 5.369 mm, but its largest excursion is 12.745 m. These excursions must not be hidden by reporting only the median.

`audit_kinematic_support` propagates GNSS covariance into relative range, including cross-receiver covariance induced by the fixed integer constraints. A declared formal-sigma threshold of 0.10 m retains 8,049/8,427 paired epochs (95.52%). This flag is saved before reading KBR; it is not a KBR residual cut or a calibrated precision guarantee. On the same 8,014 flagged comparison epochs, range RMS is:

| Navigation | Fixed independent combinations | Range-minus-KBR RMS |
|---|---:|---:|
| Previous reduced dynamic | 240 | 11.966 mm |
| Kinematic, inherited independent integers K | 240 | 19.405 mm |
| Kinematic, own integer estimation L | 135 | 27.802 mm |
| Kinematic float F | 0 | 39.382 mm |

Changing the observed signal set increases K's median absolute 10-second range-residual step from 2.191 to 2.935 mm (99th percentile 21.369 versus 34.009 mm). It does not reset the fixed integers. The remaining excursions indicate weak ambiguity/geometry support, not an imposed 20-minute reset.

Density is a separate 20-minute physical-force fit to native positions. The first density comparison uses the original segment rule and all finite positions; numerical injection/QR checks pass, but outliers worsen density. The final `evaluate_kinematic_quality_density` comparison uses the GNSS-only sigma flag and identical native measurement times for K, L and the old reduced-dynamic orbit. Short missing-position intervals remain inside one density fit when force-reference support exists. Separate nuisance states are used across force-reference gaps or >600 seconds without positions. No missing positions are filled. The common force reference remains the previously reconstructed independent GNSS geometry; ACC retains its prior POD-calibrated constant benchmark bias. Thus force-window bandwidth and temporal input support are matched, but this is not a new reconstruction of forces on noisy kinematic positions.

On 79,267 matched density centers:

| Navigation supplying the positions | Density-minus-ACC RMS (kg/m^3) | Correlation |
|---|---:|---:|
| Reduced dynamic240, sampled at the same epochs | 1.9983e-13 | 0.2229 |
| Kinematic K, inherited240 | 3.3692e-13 | 0.1775 |
| Kinematic L, own135 | 4.6714e-13 | 0.1507 |

Density checks are below 1.6e-22 kg/m^3 for direct QR and 7.0e-23 for unit-density injection. These establish numerical consistency, not physical signal retention or calibrated uncertainty. Removing navigation blocks therefore demonstrates the requested separation, but does not improve fixing strength or density accuracy in this test. The larger degrees of freedom and remaining unresolved tracks require better stochastic/ambiguity treatment. Full kinematic time covariance is not yet propagated into density; the covariance here supplies an epoch-quality flag only.

Reproduce with the existing raw-derived independent observation checkpoints:

```matlab
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
source = fullfile(root,'independent_run');
out = fullfile(root,'kinematic_run_v2');
addpath(package,root);
test_kinematic_profile;
run_kinematic_independent(source,out);
evaluate_kinematic_independent(package,root,source,out);
audit_kinematic_support(out);
evaluate_kinematic_quality_density(root,source,out);
```

Principal outputs: `kinematic_run_v2/kinematic_quality_comparison.png`, `kinematic_comparison.png` (all-epoch control), `preparation.json`, `evaluation.json`, `support_audit.json`, `quality_density_comparison.json`, native navigation MAT files and density CSVs. The existing assisted solution, manuscript source and reproducibility ZIP are unchanged.

## Follow-up: formulation and integer-search audit, 2026-09-30

The current independent estimator is a pair of reduced-dynamic code/carrier fits with 20-minute blocks and linear empirical accelerations, followed by joint DD integer conditioning. It is not an epoch-by-epoch kinematic baseline estimator. `resolve_independent_joint` concatenates separately profiled ambiguities and uses their block-diagonal covariance. This is valid under the assumed independent two-receiver likelihood; a change to mean-orbit/baseline coordinates alone would not add information. Shared transmitter errors, temporal correlations and coupled differential-dynamics uncertainty are not represented by that block-diagonal construction. Earlier centimeter-level absolute orbit results also retain float ambiguity combinations and are not fully integer-resolved absolute POD benchmarks.

The saved nominal search started with 255 eligible transformed integer directions. It removed 35: 27 with an incomplete two-best search at the 300,000-node budget and eight with insufficient likelihood separation. The validated wide-lane graph contains 413 relations of rank 278 out of 595 initial relations. The four-times-covariance sensitivity branch began with only 12 eligible directions, all retained; its low fixing count is therefore not a search-budget problem. `independent_run/search_audit.json` records these findings.

The new `resolve_independent_joint` optional fourth argument makes the node budget and input candidate suffix explicit while preserving existing defaults. A separate test increases only the search budget to 3,000,000 nodes. Observation data, nominal covariance, integer candidate construction and all acceptance thresholds remain unchanged. No POD, KBR or ACC enters fixing. The new result fixes 240 directions; its 15 removals are all due to insufficient likelihood separation, with no budget-exhausted removals. The new subspace contains 219 of the previous 220 fixed directions, all with identical targets; it is not a strict superset of the old solution.

Post-estimation checks and matched results:

| Quantity | Previous joint search | Larger search |
|---|---:|---:|
| Independent fixed rank | 220 | 240 |
| Range-minus-KBR RMS, same 16,833 epochs | 13.598 mm | 12.050 mm |
| Density-minus-ACC RMS, same 79,626 centers | 1.9671e-13 kg/m^3 | 1.9559e-13 kg/m^3 |
| Density correlation with ACC on those centers | 0.2587 | 0.2408 |

All 466 assisted-reference relations lying within the new fixed subspace agree with the independent integer targets. These overlapping relations are not 466 independent fixes, nor independent truth. Absolute orbit RMS remains 6.730/7.219 cm for A/B. The assisted range benchmark is still 2.512 mm on the same range epochs. The density result is not a material improvement: RMS falls only 0.57%, while correlation falls. More completed integer searching helps range but does not solve the remaining density error. Nominal-covariance validation is still an engineering acceptance scheme, not a calibrated failure-rate guarantee.

`evaluate_search_budget` uses the same fresh GNSS-orbit force reference and 20-minute operator as the preceding independent tests; injection and direct-QR assertions pass. ACC retains the prior POD-calibrated constant comparison bias. Output files are `independent_joint_search3m.mat`, `A/B_L_search3m.mat`, corresponding density CSVs, and `search_budget_comparison.json/mat/png` in `independent_run`. The prior graph-grown 223-direction result and all earlier products are preserved. The original manuscript package and ZIP are unchanged.

```matlab
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
out = fullfile(root,'independent_run');
addpath(package,root);
resolve_independent_joint(out,1,'_search3m', ...
    struct('searchLimit',3000000,'candidateSuffix','1'));
evaluate_search_budget(package,root,out,'_search3m');
```

The next substantive development should address the joint observation/stochastic model: estimate common and differential orbit states with shared GNSS-error terms, preserve unresolved carrier information for common geometry, and validate covariance against separated data blocks. A reduced-dynamic ambiguity-estimation stage followed by a less constrained trajectory/force stage is also appropriate to test. Any tighter differential-force prior must pass signal-injection tests before being used for density, since suppressing real differential drag can make range agreement look better.

External context: [Wu and Bar-Sever's real-time GRACE demonstration](https://gdgps.jpl.nasa.gov/system-desc/papers/RT_GRACE_POD.pdf) reports approximately 80% DD fixing and 7-mm KBR range agreement using jointly estimated reference/differential states, real-time GPS products and stronger differential dynamics; its drag/dynamics setup is not identical to this atmosphere-density-independent experiment. [Arnold et al.'s Bernese study](https://www.bernese.unibe.ch/publist/2018/post/IGSWS2018_LEOAR.pdf) resolves ambiguities with reduced-dynamic processing and carries them into kinematic POD. It also distinguishes DD fixing, which cancels transmitter phase biases, from zero-difference fixing using compatible clock/phase-bias products. These precedents support further estimator development; they do not establish that a coordinate change alone will achieve their accuracy here.

## Independent integer development, 2026-09-30

New native MATLAB implementation: `prepare_independent_integers`, `resolve_independent_graph`, `resolve_independent_joint`, `refit_independent_connected`, `audit_independent_noise`, `prepare_independent_density_reference`, and `evaluate_independent_integers`. Outputs are in `independent_run`. This is a separate experiment; the assisted baseline and manuscript ZIP are unchanged.

The estimator reuses the original raw-design checkpoints but drops every POD-coordinate field before any estimation. Their phase/code geometry and force arrays were generated by the independent code/carrier bootstrap, not by POD. No assisted integer targets, assisted masks, GNV/POD observations, KBR, or ACC enter preparation, wide-lane selection, narrow-lane search, graph growth or navigation refitting. Code uses the same archived JAXA MADOCA real-time transmitters as before. This still uses ground GPS1B observations and full-day batch processing; it is not a causal onboard implementation.

Changes and validation:

1. Propagate dynamical orbit states through GNSS gaps up to 900 s when attitude is available within 5 s; compute missing force samples explicitly. Phase labels remain separate after actual reacquisition. B's 21890–22510 GPS-second gap is preserved because its attitude age reaches 140 s.
2. Extend existing raw continuity labels to 5-degree elevation using GNSS data only. No POD-referenced phase gate is used.
3. Form actual double-difference wide lanes from Melbourne–Wuebbena observations. Require repeated agreement in disjoint 300-second observation blocks. 413 of 595 initial candidate relations pass this added check.
4. Profile receiver clocks and orbit states out of the GNSS-only likelihood, retaining ambiguity covariance. Search the correlated integer lattice, rather than individually rounding ionosphere-free offsets. Partial joint search has no imposed 192-direction cap. Both best candidates must be found; incomplete searches are rejected. Gates include likelihood separation, conditional innovations, aggregate cost, and exactly matching integer vectors in separately re-estimated five-minute blocks. The search and validation reuse one day and one force model; they do not establish an operational false-fix probability.
5. Separately test natural DD edge fixing, with a 0.05-cycle uncertainty floor, separated-block disagreement, three-sigma separation, and exact integer graph closure. A final conditional graph-growth test uses ONLY the accepted GNSS joint core as its seed.

Nominal versus four-times covariance is a declared sensitivity test, not a reference-tuned weight adjustment. GNSS residual diagnostics show adjacent correlations around 0.64; low high-frequency residual noise must not be interpreted as equally low uncertainty in long-arc ambiguities.

| Variant | Fixed rank | Meaning |
|---|---:|---|
| N | 7 | Direct DD graph, covariance x4 |
| L | 12 | Joint partial ILS, covariance x4 |
| N1 | 17 | Direct DD graph, nominal covariance |
| L1 | 220 | Joint partial ILS, nominal covariance |
| N2 | 223 | L1 core plus GNSS-only conditional graph growth |
| C | 179 | Refit only natural fixed carrier links derived from L1; retain all eligible code |

L1 implies 262 directly fixed natural DD relations and 7,191 native epochs with a connected fixed pair. N2 accepts 284 natural relations and covers 7,371 such epochs (20.48 hours of sampled coverage, not guaranteed continuous tracking). These counts do not imply that every ambiguity in either absolute orbit is integer fixed; common/unresolved combinations remain float. All fitted equality residuals are below 1e-14 m.

After estimation was frozen, comparison against the assisted solution found agreement in all 387 assisted relations that lie within L1's fixed subspace. The nominal natural graph agrees on all 19 shared relations; the conservative graph agrees on all seven. These are post-estimation consistency checks, not independent truth or a calibrated failure-rate measurement. The post-estimation references do not feed target integers, selection masks or thresholds back into the estimator.

On 16,833 common KBR epochs, independent float F gives 23.73 mm range RMS; L1 gives 13.60 mm. L1's absolute A/B orbit RMS against POD is 6.72/7.23 cm. The fixed-carrier-only C experiment degrades range to 634.8 mm and absolute orbits to 1.29/1.71 m: removing unresolved carrier observations also removes information needed for common/absolute geometry. It is a negative control, not a recommended solution. Keep unresolved carrier information in the joint estimator.

The first density check reused old force-reference tables with holes not present in the new propagated orbit. That comparison is invalid for claiming density performance over newly propagated intervals and is preserved under `independent_run/previous_force_diagnostic`. `prepare_independent_density_reference` replaces it with freshly evaluated five-second forces on the independent float F orbit, common to the integer variants. POD and ACC are then loaded only for comparison columns; the ACC comparison retains the prior POD-calibrated constant bias. Results/plots distinguish that benchmark dependence from integer-estimator independence.

Completed fresh-force evaluation: N2 has range RMS 13.563 mm versus 23.733 mm for float F and 2.512 mm for the assisted benchmark, all on the same 16,833 KBR epochs and unchanged datum. N2 agrees with all 281 directly shared assisted relations; three accepted natural relations have no counterpart in that assisted candidate list. This is distinct from the 387 assisted relations inside L1's complete fixed subspace; the counts must not be added as independent constraints.

On the same 79,626 time centers used by the preceding assisted benchmark (an evaluation mask only), float density-minus-ACC RMS is 2.351e-13 kg/m^3, r=0.199; L1 is 1.967e-13, r=0.259; N2 is 1.968e-13, r=0.262. Across all 85,170 eligible centers, N2 RMS is 2.656e-13, r=0.232. Over 13–15 UTC, N2 RMS is 2.042e-13 with r=0.462. These independent partial fixes improve the float result but do not reproduce the assisted density quality. The C fixed-carrier-only negative control remains poor even after fresh force reconstruction (full density RMS 7.529e-11). Missing fixed directions, common-orbit information and correlated model/phase errors remain consequential. Agreement of accepted integers alone is insufficient to establish accurate differential density.

The density operator's injection and direct-QR assertions passed for the fresh-force run. `matched_summary.json` and `independent_summary.png` provide the principal comparison; `evaluation.json` and `independent_density.png` retain full-day and negative-control results. `candidate_graph_audit*.csv`, `independent_joint*.mat`, and `independent_graph*.mat` retain candidate decisions, transforms, block validation histories, targets and fixed equalities. No calibrated false-fix probability, fully integer-fixed day, or operational robustness is claimed. The conservative covariance sensitivity still fixes far fewer directions, so a correlated-error covariance model and additional independent days are required before promoting this to the primary retrieval.

Reproduction after the baseline raw run:

```matlab
package = 'outputs/wei_aeroconf2015_matlab_20260928';
root = 'outputs/robust_differential_integer_20260928';
out = fullfile(root,'independent_run');
addpath(package,root);
prepare_independent_integers(package,out);
audit_independent_noise(out);
resolve_independent_graph(out,4,'');
resolve_independent_joint(out,4,'');
resolve_independent_graph(out,1,'1');
resolve_independent_joint(out,1,'1');
refit_independent_connected(out);
resolve_independent_graph(out,1,'2',fullfile(out,'independent_joint1.mat'));
prepare_independent_density_reference(package,out);
evaluate_independent_integers(package,root,out,true,fullfile(out,'fresh_force_reference'));
summarize_independent_results(root,out);
```

## 13–15 UTC error diagnosis and provenance

`audit_13_15` compares the original, connected, force-repaired, and missing-epoch solutions without changing the retrieval. The large blue excursions in the earlier comparison are the ORIGINAL solution. Current 13–15 UTC performance is 2.989e-14 kg/m^3 RMS against ACC with r=0.713 (20 min), and 4.554e-14 with r=0.578 (10 min), covering all 7,201 inclusive one-second centers in this interval. The current 20-minute result is numerically identical here to the force-repaired complete-window fit; permitting missing epochs did not create errors in this interval.

The main demonstrated cause of the old spikes is the navigation gap treatment: two 39-second omissions near 14:02 and 14:50 disconnected orbit states and changed dynamic-block boundaries, despite retained fixed track connections. Connecting these gaps WITHOUT changing integers or repairing the force tables already reduces 13–15 UTC RMS to 3.134e-14 (20 min) and 4.628e-14 (10 min). Force-table repair further reduces the 20-minute RMS to 2.989e-14. This local attribution differs from some other recovered intervals, where explicit force evaluation inside gaps was crucial.

Two additional crossed controls isolate navigation-force and density-force repairs. Connected old-force navigation with repaired density forces gives RMS 3.065e-14 / 4.637e-14 (20 / 10 min). Repaired navigation with old density-force tables gives 3.053e-14 / 4.567e-14. These confirm the dominant local improvement comes from connecting the navigation arcs, not a new integer assignment. On exactly the original valid centers, RMS changes 6.761e-14 -> 3.167e-14 (20 min), and 3.252e-13 -> 4.624e-14 (10 min). Common-epoch range-minus-KBR RMS changes 2.761 -> 1.887 mm.

No selected label changes are observed between adjacent jointly selected epochs in the 13–15 UTC audit. That is not proof against hidden slips or jumps on unselected observations. POD-reference phase residuals retain roughly 2.6–7.6 mm RMS in ten-minute bins, with instantaneous geometry condition reaching 124 around 14:00 and 255 around 14:35 (when at least four signals are present). The 25-mm POD-assisted selection gate already truncates residuals. Residuals therefore are consistency diagnostics, not independent validation. THR1B contains 53 A and 98 B positive-on-time records in this interval, all with zero quality flags. Records/channel-on-time sums are not net impulse estimates. Thruster effects are not explicitly estimated in this branch; causal attribution of the smaller remaining errors to thrust versus phase/model errors has not been established.

Provenance traced through native source:

* `prepare_manuscript_raw` reads JAXA MADOCA `madoca18360.sp3.gz`, SHA256 b08c0e7d04b980428e3b3735e8248708bb616d1355e21f538b262a3c08509f4a, and `ssr18360.rtcm3` for code biases. This is the archived real-time-product branch, not ESA final. `raw_transmitters` uses the archive's 1-Hz grid with local cubic positions and bracketed linear clocks.
* `raw_bootstrap` estimates initial GRACE orbits from code/carrier and J2/empirical accelerations, without GNV/POD anchors. Current A/B states and clocks are re-estimated under partial DD integer constraints; common/unresolved ambiguities remain float.
* `raw_navigation_design` computes measurement geometry and forces on the GNSS bootstrap. `manuscript_density` evaluates the common force reference on GNSS-only integer branch R; added gap force evaluations use those GNSS reference trajectories. POD positions are not the held force geometry.
* POD DOES select the assisted integer targets and the 25-mm phase consistency mask. ACC body-X constant bias is calibrated against POD-derived density, and KBR comparison datums are POD-defined. Thus the overall pipeline is POD-assisted, not POD-free; the ACC benchmark is not completely independent of POD calibration.
* The run is retrospective full-day batch processing, with ground GPS1B observations and archived RT transmitters. It is not yet a causal onboard replay. Atmospheric density is not supplied as a retrieval target, but temperature/wind and spacecraft force models remain in use.

Outputs: `audit_13_15/current_and_previous.png`, `diagnostics_13_15.png`, `stage_comparison.json`, `force_controls.json`, `phase_support_10min.csv`, and raw-telemetry record extracts. Reproduce with `audit_13_15(package,root)`, `control_forces_13_15(package,root)`, and `finalize_13_15(root)`. Original manuscript/package remain unchanged.

## Moving windows with missing epochs, 2026-09-30

`sparse_window_run` removes the complete-epoch requirement from the 20-/10-minute density operator. Navigation and all saved integer constraints are unchanged from `bridge_force_run`. The moving window retains its nominal time span and advances by one second; unavailable orbit epochs are omitted, not synthesized. The later navigation fit already admits fewer than four GPS signals per epoch. This change does not rebuild raw epochs previously omitted by the bootstrap's four-signal requirement.

`gnss_density_sparse_window` integrates the force response separately within each available continuous navigation segment. Each segment has six independent position/velocity nuisance parameters, while density intercept and slope are shared across the entire window. This avoids interpreting unverified position jumps between the three remaining disconnected navigation intervals as drag. The fixed ambiguities within the saved navigation are untouched; this does not demonstrate unchanged integers across a genuine loss of phase continuity. The five earlier verified connections remain in place.

The support test now uses aggregate information: at least 12 native epochs with at least two connected fixed signals, positive adequate aggregate LOS information, at least 120 available one-second modeled orbit states, and numerical rank checks on the force fit. There is no 90% coverage test, maximum epoch-gap test, or per-epoch four-signal requirement. Numerical observability does not guarantee useful precision. Model states at one-second spacing are correlated, not independent measurements.

Results relative to the preceding connected/force-repaired solution:

| Window | Previous centers | New centers | New internal missing centers | RMS vs ACC on previous centers | RMS vs ACC on added centers |
|---|---:|---:|---:|---:|---:|
| 20 min | 79,626 | 85,170 | 0 | 4.309e-14 kg/m^3 | 1.355e-12 kg/m^3 |
| 10 min | 80,447 | 84,652 | 1,118 | 8.160e-14 kg/m^3 | 2.155e-12 kg/m^3 |

The 20-minute series gains 92.4 minutes and covers every eligible interior center (98.58% of the day, with only centered-window day edges excluded). However, the added intervals are much noisier. Overall 20-minute RMS is 3.481e-13 kg/m^3 and correlation 0.139, compared with 4.309e-14 and 0.632 on the previous support. Maximum absolute new density is 5.987e-12 (20 min) and 1.160e-11 (10 min). Do not describe increased coverage as improved accuracy. The original connected solution remains the better validated result.

The common-support density changes are at most 2.224e-16 (20 min) and 7.256e-16 kg/m^3 (10 min). Known-density injection errors are at most 1.045e-21, and independent direct-QR differences at most 1.372e-22 kg/m^3. These checks support numerical implementation consistency; they do not establish physical accuracy in the short available fragments. The continuous series uses a changed observation-time operator for ACC too, so ACC is compared through the same window/segment response.

`sparse_window_comparison.png` uses +/-1e-12 axes for readability and clips some excursions; `sparse_window_full_scale.png` shows all excursions. `min20_availability.csv` and `min10_availability.csv` contain GPS time, UTC hour, GNSS differential density, ACC differential density, accepted flag, newly admitted flag, and available orbit-state counts for A/B. Remaining-gap CSV columns are start/end GPS seconds, duration seconds, and start/end UTC hour. `sparse_comparison.json` separates old support from newly admitted windows.

```matlab
root = 'outputs/robust_differential_integer_20260928';
addpath('outputs/wei_aeroconf2015_matlab_20260928', root);
test_sparse_density(fullfile(root,'bridge_force_reference'), fullfile(root,'bridge_force_run'), fullfile(root,'sparse_window_run'));
report_sparse_windows(fullfile(root,'bridge_force_density_run'), fullfile(root,'sparse_window_run'));
```

The original manuscript package and ZIP remain unchanged.

## Remaining-gap and ambiguity-continuity audit

Audited the primary JAXA 5-degree solution (`arc5_run` and `ten_minute_run`), not the inferior outlier variants. Native raw GPS1B records were decoded to distinguish receiver track IDs from additional pipeline-generated ambiguity labels. Outputs: `gap_audit/summary.json`, `navigation_gaps.csv`, and the two window-specific density-gap CSVs. CSV times are GPS seconds from 2015-03-15; subtract 16 seconds for UTC.

There are eight internal common-navigation gaps totaling 1,852 seconds. Five gaps retain 2–4 identical fixed ambiguity track-pairs on both sides, also connected in the accepted integer graph: 02:28:35–02:29:33, 07:06:35–07:08:23, 14:02:15–14:02:53, 14:49:45–14:50:23, and 16:29:25–16:31:23 UTC. They are not resets of those retained ambiguities. The reduced-dynamic solver nevertheless omits the missing bootstrap intervals and imposes state continuity only between touching blocks. Thus an orbit-state break can coexist with fixed ambiguity continuity.

Three gaps have no selected fixed track-pair or integer-graph bridge across the nearest selected observations:

* 01:39:55–01:49:23 UTC (569 s): some raw track IDs continue, but no selected fixed connection remains. The pipeline additionally splits B's G25/G31 despite unchanged raw track IDs. This is evidence of a processing-generated segmentation decision, not proof of a physical slip or proof that the decision is wrong.
* 06:04:35–06:14:53 UTC (619 s): B's raw phase count reaches zero and no B raw track ID survives across the gap. This is a real data-continuity break; ambiguities must be independently revalidated across reacquisition.
* 19:26:25–19:31:23 UTC (299 s): three B raw track IDs span the gap, but no selected fixed ambiguity bridge remains. Lack of a selected bridge alone is not proof of a cycle slip.

No bootstrap exception/reset events are recorded on either receiver. The initial bootstrap still requires at least four signals above 10 degrees to write a state, whereas the later experiment allows two connected signals and a 5-degree cutoff. Thus later mask relaxation cannot restore epochs already omitted by that earlier stage. Exact reason for every skipped epoch has not been replayed with branch-level instrumentation; raw phase availability alone does not establish usable elevation/attitude/clock support.

The density operator requires all 1,200 one-second navigation states for a 20-minute window. These eight short state gaps consequently remove 11,444 density centers (3.18 hours), versus only 40 additional centers rejected by the later support screen. Day-edge handling removes another 1,230 centers, leaving 73,686. The 10-minute case has 6,644 internal missing-result centers, 650 support rejections and 630 edge exclusions, leaving 78,476.

Integers are tied to continuous phase labels across the daily solution, not reset at every displayed density window. Same labels and graph connections demonstrate software continuity, not independent proof of physical correctness. A global graph connection can use future observations and is not a causal guarantee. The next targeted repair is to propagate short weak-geometry intervals with uncertainty and maintain state continuity where existing fixed tracks bridge them; the three unbridged intervals require explicit tracking/ambiguity checks. Do not fill missing density with interpolation or force all gaps to share one ambiguity. This audit does not modify the navigation or density results.

## Outlier exclusion and robust weighting tests

Implemented and evaluated on the JAXA real-time, 5-degree, POD-assisted solution. KBR/ACC never select rejected observations, integer candidates or weights. The original branch is preserved and remains better on this day.

1. Prefit screen: for each GPS, form B-minus-A phase against the two POD geometries and saved offsets. Estimate its common clock from the OTHER GPS signals (at least three). Within each unchanged ambiguity-label pair use a robust MAD scale, floor 3 mm, and reject absolute residuals exceeding max(15 mm, 4.5 sigma). Tracks with fewer than ten usable tests are not automatically rejected. This is POD-assisted, not a POD-free detector.
2. Integer-candidate preparation: trim anomalous POD-referenced ionosphere-free double-difference and Melbourne–Wübbena samples using median/MAD checks before minute-bin aggregation. Reapply the existing wide-/narrow-lane integer validation to the SAME candidate targets. An accepted integer must equal its original value; failed candidates are withheld rather than re-rounded. Integer-graph connections are rebuilt from surviving relations.
3. Range estimation: refit the continuous reduced-dynamic orbits with exact retained integer constraints. Apply one Huber phase-weight pass from fitted residuals, robust scale floor 3 mm, cutoff 2.5 sigma, weight floor 0.05. Code weighting is unchanged for retained observations. The hard mask removes the paired signal from both receivers' phase/code fit. This is an experimental robust pass, not an iterated-to-convergence estimator or calibrated false-fix guarantee.

The prefit screen flags 566 of 48,343 paired measurements (1.17%). After connectivity checks, 47,602 remain. 727 of 754 candidate relations revalidate; 724 are active, with rank 351 versus the original 354. No retained integer value changes. The second pass downweights 2,154 A and 1,782 B phase observations. The maximum independent integer-constraint error is 3.55e-15 m.

Two controls were run. Restoring all original candidate relations with the screened measurement mask leaves rank 351 and reproduces the same result: the missing independent directions lack surviving measurement support. A separate soft-only control restores ALL original measurements and all 354 fixed directions, assigns prefit-flagged measurements weight 0.05, and retains other robust weights. It also fails to improve the range/density results. The soft-only constraint error is 7.11e-15 m; it remains integer-constrained, not a float replacement.

| Variant | Fixed rank | Supported range RMS vs KBR (mm) | 20-minute density RMS vs ACC (kg/m³) | Density r |
|---|---:|---:|---:|---:|
| Original | 354 | 2.1940 | 4.8746e-14 | 0.5528 |
| Hard screening + robust weights | 351 | 2.2236 | 5.2078e-14 | 0.5451 |
| Soft weights, original integers | 354 | 2.2216 | 5.3179e-14 | 0.5323 |

All entries use the same 14,694 KBR epochs and 73,686 density centers. Full common-epoch range RMS also worsens: 2.7601 -> 2.8811 mm (hard) or 2.9251 mm (soft). Hard screening preserves 20-minute coverage but reduces 10-minute support by 549 seconds. Its 10-minute RMS on the common 77,927 centers is 1.2704e-13 versus 1.2617e-13 originally. Soft-only retains all 78,476 centers and worsens 10-minute RMS from 1.2635e-13 to 1.4632e-13. Numerical force-injection/QR checks pass.

These tests demonstrate that outlier handling can be implemented while preserving integer-valued constraints. They do NOT demonstrate a better density estimator. Large phase residuals may reflect geometry or modeling errors as well as isolated bad measurements, and this screening can remove useful information. Persistent steps still require a continuity/slip decision rather than arbitrary integer changes. Keep the original solution as the primary result; retain these as negative controls, without optimizing thresholds against ACC.

Reproduce `test_robust_outliers(originalNav,screenedNav)` and `test_soft_outliers(originalNav,screenedNav,softNav)`. Run `test_ten_minute_density(baseline,nav,out,false)` for each, then `compare_outlier_results(originalDensity,out,originalNav,nav,baseline)`. `test_outliers_same_integers` is the restored-candidate diagnostic. Outputs are in `outlier_run`, `outlier_density_run`, `outlier_same_integer_run`, `outlier_same_integer_density_run`, `outlier_soft_run`, and `outlier_soft_density_run`. MATLAB runtime remains fully native. Original package/ZIP unchanged.

## Absolute-orbit ambiguity status: explicit clarification

The final-product A/B absolute orbits are NOT two independently fully integer-fixed absolute solutions. Both use ESA final transmitter orbits/clocks, and both are re-estimated under genuine between-receiver double-difference integer constraints. Common and unresolved phase-offset combinations remain float.

`audit_absolute_fix_status` checks the saved final orbit ambiguity vectors themselves, not just the fitting log. It finds 711 active offset parameters (353 A, 358 B), 750 active DD relations of rank 354, and 357 offset dimensions not constrained by these integer relations (including datum/gauge freedoms). WL/NL target counts are exact integers, their IF target construction is verified, and the saved ambiguity vectors satisfy all active relations to 7.55e-15 m. The constraint matrix and targets are exactly the same as the real-time run. This demonstrates partial differential integer fixing, not full absolute ambiguity fixing. Merely holding a conditioned real-valued offset vector during orbit back-substitution must not be called independent absolute integer resolution.

The reported final absolute orbit RMS of 7.56/7.50 cm against POD therefore belongs to this partially integer-constrained joint solution. The audit is stored in `final_run/absolute_integer_status.json`.

## ESA final orbit/clock substitution

`test_final_products` replaces JAXA MADOCA GPS orbit/clock corrections with locally archived ESA final products for March 14–16, 2015: `ESA0MGNFIN_201507[3-5]0000_01D_05M_ORB.SP3.gz` and matching `01D_30S_CLK.CLK.gz`. These are retrospective final products, not available in real time. They reside in `outputs/wei_gnss_reproduction_20260921/inputs/storm2015/gps` with source URL/SHA sidecars.

Interpolation uses ten-node degree-nine local orbit polynomials on the native 300-second grid, including analytic first/second derivatives; clocks are bracketed linearly at 30 seconds, without extrapolation or bridging missing clock samples. Adjacent-day orbit records supply boundary nodes. The existing rotation, transmitter-time iteration, relativity, antenna and wind-up model is then evaluated with the changed transmitters. Phase/code residuals and LOS vectors are updated at the SAME receiver linearization positions.

Frozen: the selected 48,343 paired observation epochs/signals, ambiguity labels and 354 independent integer constraints (750 active relations), code-bias corrections, receiver bootstrap, navigation settings, force reconstruction and ACC calibration. The orbit states, receiver clocks and remaining float offsets are re-estimated. Changing transmitter directions updates their tiny elevation-dependent weights; no new mask or integer decision is made. Both density windows pass an assertion of identical support and ACC references versus the real-time run. Keeping code biases/antenna conventions unchanged makes this a controlled orbit/clock substitution, not a fully retuned final-product pipeline. It remains POD-assisted for integer selection.

On the SAME 73,186 centers shared by both windows and products:

| Density window | JAXA RT RMS (kg/m³) | ESA final RMS | JAXA RT r | ESA final r |
|---|---:|---:|---:|---:|
| 20 minutes | 4.8631e-14 | 4.6152e-14 | 0.5527 | 0.5962 |
| 10 minutes | 8.6953e-14 | 6.5300e-14 | 0.3854 | 0.4573 |

The 10-minute common-support RMS improves 24.9%, but remains worse than 20 minutes. On ALL supported 10-minute centers (78,476, unchanged), RMS instead increases from 1.2635e-13 to 1.3564e-13 kg/m³, with r 0.2430 to 0.2681. Large final-product excursions occur near the day boundaries; their cause has not been isolated. Do not interpret the common-support improvement as robust improvement over every supported interval, or claim the boundary excursions are proven interpolation errors. On all 20-minute support, RMS improves from 4.8746e-14 to 4.6255e-14.

Relative range against the SAME KBR datum and 14,694 matched epochs improves from 2.1940 to 1.9798 mm RMS. Absolute orbit RMS against POD improves from 9.843/9.874 cm (A/B) to 7.556/7.502 cm. Accepted integer targets remain identical; constraint errors remain 3.55e-15 m. Density injection and direct-QR checks pass.

Outputs: `final_run` contains rebuilt native observation designs and navigation; `final_density_run` contains 10-/20-minute density, `product_comparison.json`, and `final_vs_realtime_density.png` (all supported extrema shown). `comparison.json` in that folder provides cross-window matched statistics. Reproduce `test_final_products(package,arc5Output,gpsFolder,finalNavOutput)`, then `test_ten_minute_density(baseline,finalNavOutput,finalDensityOutput,false)` and `compare_final_products(realTimeDensityOutput,finalDensityOutput,arc5Output,finalNavOutput,baseline)`. The false argument skips comparison against a previously saved identical 20-minute solution; independent numerical checks remain enabled. The original reproducibility package is unchanged.

## Ten-minute density-window test

`test_ten_minute_density` holds the latest 5-degree navigation and fixed integers unchanged and shortens ONLY the density fit from 1200 to 600 seconds. This is not a new 10-minute navigation solution; underlying navigation still has 20-minute dynamic blocks and full-day constraints. Output centers remain one second apart. The force basis and constant/linear density parameterization retain the same numerical scaling. The native density operator was generalized in a separate function, preserving the baseline package.

Both windows use 90% measurement coverage, at least two connected signals per supported measurement epoch, the same accumulated geometry screen, and a maximum unsupported span of 10% of the window (120 versus 60 seconds). ACC and POD reference densities are evaluated with the corresponding force/window operator, so their effective smoothing changes too. This is a window-matched comparison, not an identical-bandwidth resolution test.

On 73,186 common centers, GNSS-minus-ACC RMS increases from 4.8631e-14 (20 minutes) to 8.6953e-14 kg/m³ (10 minutes); correlation decreases from 0.5527 to 0.3854. Coverage increases from 73,686 centers (85.28% of the day) to 78,476 (90.83%). Over all 10-minute support the RMS is 1.2635e-13 and correlation 0.2430, reflecting larger errors in additional intervals. POD-minus-ACC RMS on common centers also increases, from 3.8108e-14 to 5.1973e-14 kg/m³. The 20-minute density window remains the preferred tested option.

Numerical checks: the 20-minute regression agrees with saved results to 5.05e-27 kg/m³, both injection checks pass (<5.5e-26), and normal-equation versus direct-QR differences are <4.2e-24. These checks establish numerical consistency, not physical accuracy. No new ambiguity choices, ACC-tuned exclusions or added filtering were applied.

Outputs are in `ten_minute_run`; `comparison.json` contains coverage and matched statistics, `checks.json` contains numerical checks, and `density_10_vs_20.png` shows the comparison. The latter uses +/-0.8e-12 axes for visibility; `density_10_vs_20_full.png` includes all supported extrema. Reproduce with `test_ten_minute_density(baseline, arc5Output, out)`.

## Arc-level support and 5-degree elevation test

The subsequent test removes the requirement for four connected fixed signals at every measurement epoch. Two or three signals still contribute to the reduced-dynamic fit after eliminating the free epoch clock. Across a 20-minute window the test requires at least 108 epochs with two connected signals, no unsupported span exceeding 120 seconds, and a nonsingular accumulated, elevation-weighted LOS information matrix (minimum eigenvalue > 0.001, condition number < 1000). This LOS check is an engineering geometry screen, not a full dynamic force covariance or a calibrated precision guarantee. The 90% coverage threshold remains; the longest allowable support gap changes from 30 to 120 seconds.

Both 10-degree and 5-degree tests retain the same accepted integer targets, arc continuity and 25-mm POD-referenced phase-consistency screen. At 5 degrees only existing ambiguity labels are extended into low-elevation observations with the SAME underlying raw continuity ID; new tracks are not silently assigned old integers. No integer re-rounding is performed. The existing elevation-weighting floor (sin elevation >= 0.25 in the weights) is retained, so this is not a separately tuned low-elevation stochastic model. The admitted low-elevation observations still merit independent slip/noise validation on other days.

| Variant | Supported day | RMS on all its support (kg/m³) | r on all support | RMS on common 55,834 centers | r on common centers |
|---|---:|---:|---:|---:|---:|
| Previous history mask, 10 degrees | 64.62% | 4.3296e-14 | 0.6263 | 4.3296e-14 | 0.6263 |
| Arc support, 10 degrees | 85.29% | 5.2200e-14 | 0.5383 | 4.3881e-14 | 0.6264 |
| Arc support, 5 degrees | 85.29% | 4.8746e-14 | 0.5528 | 4.0176e-14 | 0.6536 |

The two arc-support tests have exactly the same 73,686 supported centers. Lowering the cutoff improves RMS by 6.6% on that matched set but adds no windows. Compared with the previous history mask, relaxing epoch-level support adds 17,852 seconds (4.96 hours); admitting those intervals raises aggregate RMS because they are more difficult. On common centers, the 5-degree solution improves RMS by 7.2%. Fixed rank is 354 with 750 active relations; maximum integer constraint error is 3.55e-15 m. The 5-degree mask includes 1,003 A and 1,103 B observations below 10 degrees. It uses 62 epochs with two signals and 332 with three.

This remains a POD-assisted, full-day batch test with the unchanged 20-minute density operator and common force/ACC treatment. Remaining gaps include missing navigation/density outputs and windows failing support/geometry requirements. They are not replaced with interpolated density. Plot lines are explicitly broken across missing output times.

Reproduce `test_arc_support(baseline,out,10)` and `test_arc_support(baseline,out,5)`, followed by `report_history_connectivity` for each output. With outputs named `arc10_run` and `arc5_run` in this folder, call `compare_arc_support(root)` for matched metrics and `arc_support_comparison.png`. Full numerical results are in `arc_support_comparison.csv` and `arc_support_diagnostics.json`. Gates were set before inspecting ACC comparisons; ACC did not select individual windows or integer candidates.

## September 30: recover unnecessarily excluded density windows

The bottom two plots previously used an epoch-local connected-signal mask. A valid integer relation established elsewhere in the SAME uninterrupted track-pair history was not sufficient to connect signals at the current epoch. The 20-minute support gate then enlarged these exclusions: at least 108 native 10-second epochs and no support gap exceeding 30 seconds are required in every density window.

`test_history_connectivity` now builds a graph of unchanged A/B ambiguity-label pairs from the accepted DD relations, verifies consistency of the graph potentials, and carries those relations throughout their valid tracks. It chooses a connected component with at least four simultaneously observed signals and screens POD-referenced single differences against the component potential with a 25-mm median-centered gate. No integer targets are changed; active independent rank increases from 347 to 354 because more measurements survive. This remains POD-assisted and uses full-day information (including later observations); it is not a causal demonstration. The support thresholds and 20-minute force operator are unchanged.

Results in `history_run`: supported centers increase from 35,916 to 55,834 (41.6% to 64.6% of the 24-hour day), recovering 19,918 seconds (5.53 hours), with no previously supported centers lost. On the same old centers, density RMS improves from 4.9739e-14 to 4.7046e-14 kg/m³ and correlation from 0.5544 to 0.5752. On newly recovered centers, RMS is 3.5549e-14 and correlation 0.7203. Across all new supported centers, RMS is 4.3296e-14 and correlation 0.6263. The combined score has different coverage from the old score and is not a matched comparison.

Remaining gaps fail the same four-signal/window-support gates; this test does not justify filling them. No gap interpolation or ACC-based selection was used. The old J/P outputs and baseline package are preserved. The revised graph gate differs from the original per-edge 50-mm gate; the improvement is therefore attributed to the revised graph and screening together, not solely to history propagation.

After the baseline and previous experiment are complete, reproduce with:

```matlab
test_history_connectivity(baseline, historyOutput);
report_history_connectivity(baseline, previousExperimentOutput, historyOutput);
```

Figure: `history_run/density_gap_comparison.png`. Metrics: `history_run/comparison.json`. This is an additional tested branch, not a replacement of historical plots.

Test case: GRACE A/B, 2015-03-15. Native MATLAB experiments on the completed raw-data manuscript run. The original reproducibility ZIP is unchanged.

## Main result

The accepted baseline integers are not demonstrably wrong. GNSS wide-lane closure has zero inconsistencies among 609 candidates. All 332 POD-audited relations lying in the original fixed subspace agree with its integers. This is a consistency test, not proof of correctness for every track.

The useful change is to constrain only integer relations, rather than holding the entire POD-supported real-valued offset vector. Restricting observations to a connected integer-resolved signal set and re-estimating the remaining offsets, receiver clocks and orbital states gives branch J. It retains 741 active relations of rank 347; maximum constraint error is 4.22e-15 m. Selection of those relations and the phase mask remains POD-assisted. This is NOT an independently fixed, POD-free result.

The comparison below uses exactly the same 35,916 one-second density centers and 7,154 KBR epochs. The density centers cover 41.6% of the day and are strongly correlated by overlapping 20-minute windows.

| Result | Original assisted P | New integer-only J |
|---|---:|---:|
| Differential-density RMS against ACC, kg/m³ | 5.7484e-14 | 4.9739e-14 |
| Correlation with ACC | 0.4738 | 0.5544 |
| Projected differential-drag RMS, nm/s² | 12.784 | 11.132 |
| Relative-range RMS against KBR, mm | 1.9444 | 2.1055 |

Density RMS improves 13.5%, despite slightly worse range RMS. Improvement is not uniform: S1 (03:15–04:15 UTC) density RMS worsens from 1.7552e-14 to 3.8062e-14, and S2 (09:40–10:25) from 2.9841e-14 to 3.6493e-14 kg/m³. Gaps remain. No statistical significance or independent-day generalization has been established.

## Experiments and controls

* R: existing GNSS-only solution, 188 integer combinations.
* C1: revalidate the same integer space on alternating 120-second and 300-second blocks. 187 survive, unchanged. Density does not improve.
* C4: same validation with covariance multiplied by four. Only 36 survive; density does not improve.
* G: adaptive decorrelated search from the full GNSS wide-lane independent basis, conservative covariance and blocked validation. Only 10 survive; density does not improve.
* I: hold the larger POD-audited integer relations, but re-estimate other offsets using the original phase mask. Full-day range RMS improves from R's 17.39 to 5.33 mm, while density remains poor (original-support RMS 1.5817e-13 kg/m³).
* J: integer-only conditioning plus the connected fixed-only phase mask; best aggregate density result on the fixed support.
* P: previous assisted solution holding the complete supported offset vector; retained as control.

The block checks use complete two-best integer searches, likelihood separation, conditional-cost checks, sufficient observations in every fold, and identical integers across folds. Their numerical thresholds are engineering gates, not a calibrated integer failure-rate guarantee. The residuals are temporally correlated (adjacent correlations about 0.63 and 0.62); independence-based covariance can be optimistic.

The conditioning is B_fixed = B_float + Q H' (H Q H')^-1 (target - H B_float). Only H B = target is held. Common real-valued offsets remain estimated from GNSS. H/target represent resolved dual-frequency DD relations, not arbitrary rounding of ionosphere-free ranges. Navigation is then back-substituted and receiver clocks are re-estimated.

## Cycle-slip safeguard

`detect_dual_frequency_steps` tests within-track geometry-free and ionosphere-free changes jointly against the L1/L2 integer lattice. `validate_slip_steps` requires a confirming Melbourne–Wübbena step and a consistent shorter-window geometry-free step. Tracks with inadequate evidence remain unconfirmed; no automatic correction is made.

460 A tracks and 414 B tracks were tested. The first-stage detector returned 18 and 15 candidates, respectively, but ZERO passed confirmation. The candidates were all near the ±(7,9) integer combination, which has a small ionosphere-free signature. Large geometry-free ionospheric changes can therefore mimic this combination. These must not be declared slips from that observable alone. Some corresponding A/B events are displaced by tens of seconds, further suggesting a spatial signal. That interpretation is not independently proven.

An injected (3,4)-cycle slip, whose IF jump is only -0.0566 m, passes detection and confirmation. The same GF/IF signature without a confirming MW step is rejected. These are limited unit checks, not a comprehensive detector performance study. No new real-data corrections were applied.

## Controls and limitations

All density variants use the same 20-minute density operator, reconstructed force geometry, ACC calibration, and comparison masks. KBR and ACC scores are not used by the integer-search/validation code. This experiment isolates ambiguity treatment; it is not an end-to-end test of independently reconstructed force geometry. ACC retains the baseline single constant body-X calibration against GNV. J's integer and mask selection uses POD. Navigation is a full-day batch experiment, not a causal onboard demonstration.

Full-range statistics outside the fixed-support mask do not establish valid fixed-only density coverage. Use `fixed_support` in comparison.json for P/J claims. Nominal one-second output spacing does not imply one-second resolution; native observations here are at 10 seconds.

## Reproduce

First run `run_manuscript` in the unchanged `wei_aeroconf2015_matlab_20260928` package to generate its checkpoints from raw inputs. Then add that package and this experiment folder to the MATLAB path and call:

```matlab
run_integer_experiments('/absolute/path/to/manuscript_validation_run');
```

This experiment deliberately reuses generated checkpoints; it is not another standalone raw-input package. All estimator code is native MATLAB. Outputs go to this folder's `run` directory. No original baseline files are edited.

Outputs: `comparison.json/csv`, `baseline_integer_audit.json`, `hidden_slip_audit.json`, candidate/confirmation CSVs, native navigation and density MAT files, and three figures. Candidate CSV columns are PRN,label,time,N1,N2,GFstep,IFstep,SE_GF,SE_IF,cost. Validation CSV appends MWstep,MW_SE,expectedMW,shortGFstep,shortGF_SE,accepted.

## Assessment

The evidence points to incomplete ambiguity observability, remaining float/common offsets, phase selection and correlated modeling errors, rather than a demonstrated population of wrong fixed integers. Aggressive rounding or automatic GF-based correction would be unsafe. The next independent solution needs better stochastic modeling and additional independent integer information; the tests here do not establish that stricter rejection alone can deliver continuous full-day differential density.

## Fixed-ambiguity gap connections, 2026-09-30

The completed `bridge_force_run` / `bridge_force_density_run` experiment connects five navigation gaps with at least two unchanged fixed track pairs in the accepted DD graph. All 354 independent integer constraints (750 active relations) remain unchanged; the largest constraint residual is 3.6e-15 m. Position/velocity continuity is imposed through the gaps by the dynamical fit. No synthetic phase observations are inserted. This retains the earlier POD-assisted partial differential integer fixing; it does not make the absolute/common ambiguities integer resolved or remove the original POD assistance.

Connected UTC intervals on 2015-03-15 are 02:28:35–02:29:33, 07:06:35–07:08:23, 14:02:15–14:02:53, 14:49:45–14:50:23, and 16:29:25–16:31:23. Three intervals remain unconnected: 01:39:55–01:49:23, 06:04:35–06:14:53, and 19:26:25–19:31:23. The middle interval has an actual B phase interruption; the other two lack a verified connection of both receivers' ambiguity labels. `bridge_run/unbridged_track_tests.csv` records the checks. Apparent offset changes between disconnected ambiguity components must not be rounded into integers.

An initial connection-only run (`bridge_density_run`) produced poor density in the recovered intervals. The force reference tables also had holes: spline interpolation across these holes contaminated the differential force estimate. `fill_connected_force_gaps` explicitly evaluates the physical forces at added reference epochs, using the existing reference trajectory as a linearization point and raw attitude. It also supplies the missing ACC projection values. These epochs carry no new phase/code measurements. The completed force-repaired run is the result to use; the initial run is retained as a diagnostic.

On common epochs, range minus KBR RMS changes from 2.760 to 2.512 mm. The 69 newly covered native KBR epochs have 2.573 mm RMS. The previous KBR datum is retained, with no new GNSS-specific offset or range filtering. KBR and ACC were not fitted to obtain these connections.

The 20-minute density series gains 5,940 one-second centers (99 minutes), increasing coverage from 73,686 to 79,626 centers (92.16% of the day). On common centers, differential density RMS against ACC changes from 4.875e-14 to 4.306e-14 kg/m^3, and correlation from 0.553 to 0.632. Newly recovered centers have RMS 4.352e-14 and correlation 0.524. All new valid centers have RMS 4.309e-14 and correlation 0.632. The 10-minute series gains 1,971 centers; its overall RMS is 8.160e-14 and correlation 0.418. Shorter windows remain noisier. Additional density support/edge exclusions remain even where a propagated navigation state exists.

Density injection and QR cross-checks are saved in `bridge_force_density_run/checks.json`; maximum discrepancies are below 1e-22 kg/m^3. Observation cadence remains 10 seconds; one-second output does not imply one-second physical resolution. This is a batch continuity experiment, not a demonstrated causal real-time estimator.

Reproduce after generating the existing `arc5_run`, `gap_audit`, and `ten_minute_run` checkpoints:

```matlab
root = 'outputs/robust_differential_integer_20260928';
package = 'outputs/wei_aeroconf2015_matlab_20260928';
addpath(package, root);
connect_fixed_gaps(fullfile(root,'arc5_run'), fullfile(root,'gap_audit'), fullfile(root,'bridge_run'));
fill_connected_force_gaps(package, fullfile(root,'arc5_run'), fullfile(root,'bridge_run'), fullfile(root,'bridge_force_run'), fullfile(root,'bridge_force_reference'));
test_ten_minute_density(fullfile(root,'bridge_force_reference'), fullfile(root,'bridge_force_run'), fullfile(root,'bridge_force_density_run'), false);
report_connected_gaps(package, fullfile(root,'arc5_run'), fullfile(root,'bridge_force_run'), fullfile(root,'ten_minute_run'), fullfile(root,'bridge_force_density_run'));
```

See `bridge_force_density_run/bridge_comparison.json`, `connected_density.png`, and `connected_range.png`. The original manuscript package and ZIP were not modified.

