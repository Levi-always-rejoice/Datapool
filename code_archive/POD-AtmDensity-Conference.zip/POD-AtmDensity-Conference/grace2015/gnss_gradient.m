function G=gnss_gradient(r)
mu=3.986004418e14;r=r(:);rn=norm(r);
G=mu*(3*(r*r')/rn^5-eye(3)/rn^3);
end
