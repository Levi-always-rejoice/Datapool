# Source and model attribution

The GROOPS-derived aerodynamic/radiation surface routines and binary readers are adaptations of the supplied GROOPS source. Original source files, GPL-3.0 license, citation and source hashes are under third_party/GROOPS/. Preserve those notices when sharing the package. The modified aerodynamic diagnostic source by the project owner is also preserved.

MATLAB and Aerospace Toolbox are required commercial runtime dependencies and are not redistributed. Aerospace Toolbox supplies IAU 2006 Earth-frame calculations, EGM2008 coefficients/evaluation, NRLMSISE-00 and HWM14. Their installed model data are physical model coefficients, not saved trajectory/force/density results from this experiment.

Mission observations originate from NASA/JPL GRACE RL02, JAXA supplies the GNSS orbit/clock/code-bias archive, and public GROOPS ancillary inputs are downloaded from TU Graz. Source URLs/hashes accompany downloads; raw mission file hashes are in raw/MANIFEST.json. Published GNSS products, antenna calibrations, EOP, JPL ephemerides and CERES climatology are external scientific inputs. No package-generated correction, orbit, ambiguity, force or density array is an estimator input.
