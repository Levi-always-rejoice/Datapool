# GRACE 2015 manuscript: native MATLAB raw-input reproduction

Target: **Assessing Relative GNSS Constraints for Thermospheric Density Retrieval**, supplied `ieee_aeroconf_2027.pdf`. This is GRACE A/B on **2015-03-15**, not the older GRACE-FO 2023 draft.

## Run

Unzip the entire folder on a local disk. In MATLAB R2025a with Aerospace Toolbox:

```matlab
cd('path/to/wei_aeroconf2015_matlab_20260928')
restoredefaultpath
addpath(pwd)
out = run_manuscript;
```

The default run reconstructs inputs, fits S/F/R/O/M/P, performs 20-minute density retrievals, writes the four main figures and numerical comparisons, then runs the auxiliary 10-minute temporal ambiguity test. Allow substantial runtime and at least 8 GB of free working space. Input archives are decompressed temporarily. Every run creates a fresh `manuscript_run_*` directory.

No Python, GROOPS executable, old project directory, exported observation arrays, saved orbit, saved force tables, saved ambiguity vector or saved density results are required. MATLAB MAT files created during a run are outputs/checkpoints of that run. They are not shipped as estimator inputs. Reference metrics in the reporting code are comparison targets only.

## Experiments

| Branch | Orbit and ambiguity treatment |
|---|---|
| S | Independent code/carrier orbit, 20-minute dynamic blocks, float track offsets |
| F | Exact float precursor to R, continuous states and constant/linear empirical forces |
| R | GNSS MW wide lanes and partial joint relative L1/L2 integer constraints; even/odd validation |
| O | POD-supported real offsets held, original observation mask |
| M | Same real offsets held, integer-connected observation mask |
| P | POD-assisted integer-conditioned relative offsets held, same mask as M |
| T0/T1/TP | Auxiliary 10-minute single-satellite float / GNSS temporal repair / POD-assisted temporal repair |

Positions are initialized independently from code/carrier observations. GNV is used for **P/O/M ambiguity assistance, ACC calibration and evaluation**, not as an orbit position anchor. KBR is used only for range evaluation. Do not describe the complete comparison as POD-free or as a causal onboard demonstration. Native GPS1B sampling is 10 seconds; the one-second density outputs come from overlapping windows, not independent one-second observations.

R reproduces the archived validated experiment's 192-dimensional starting decorrelated search subspace. Adaptive conditional-cost, likelihood-gap and alternating-epoch checks decide the accepted count. The expected count of 188 is never forced. Partial fixing leaves unresolved nuisance directions real-valued. P fixes relative DD integer combinations, not every absolute receiver ambiguity.

## Results

The run writes `manuscript_metrics.json`, `manuscript_comparison.csv`, `REPRODUCTION_REVIEW.md`, per-satellite/per-branch density CSV files, range comparison data, integer audit files, and PNG figures. The review flags differences exceeding 15% in RMS, 0.05 in correlation or 10% in counts. These are diagnostic triggers, not statistical equivalence tests. Inspect reported coverage and matched support.

All six principal density estimates use one common R-based force/window operator, with raw-model forces freshly evaluated on this run's R orbit. ACC passes through the same operator. One daily body-X ACC bias is recomputed against the GNV density control, never against a GNSS estimate.

The original manuscript used legacy force/effective aerodynamic tables and a legacy POD-based ACC offset. This release reconstructs physics instead. See `RAW_PHYSICS_NOTES.md` for model assumptions, `MANUSCRIPT_TARGET.md` for source mapping, and `VALIDATION.md` for actual validation status. Approximate reproduction is intended; any significant departure is retained and investigated rather than replaced by archived answers.

## Inputs and licenses

`raw/` contains original GRACE mission and archived JAXA real-time-generated GNSS products. `models/` contains original spacecraft, antenna, Earth orientation, ephemeris, atmosphere-index and radiation model inputs, with source/checksum manifests. `third_party/` preserves source attribution/license information for adapted GROOPS formulas. This package does not execute GROOPS. MATLAB and its required toolbox are separately licensed.

Density CSV columns: GPS seconds of day; GNSS density; GNV/POD-control density; calibrated ACC density; recovered 1e-12 injection; response to 1e-6 m/s2 body-X ACC bias; window count; supported flag. Densities are kg/m3. Range CSV columns: GPS seconds, F-KBR, R-KBR, P-KBR, POD-KBR (all ranges in meters).
