function fit_manuscript_navigation(out)
% S/F/R and O/M/P use the same freshly decoded raw observations.
diary(fullfile(out,'navigation.log'));cleanup=onCleanup(@()diary('off'));
a=load(fullfile(out,'A_float_model.mat'));b=load(fullfile(out,'B_float_model.mat'));
qa=a.model.q;qb=b.model.q;nc=numel(qa.B0);B=[a.F.ambiguities;b.F.ambiguities];Q=blkdiag(a.model.Q,b.model.Q);
splits=cell(2,1);
for k=0:1
 x=load(fullfile(out,sprintf('A_split%d.mat',k)));y=load(fullfile(out,sprintf('B_split%d.mat',k)));
 splits{k+1}=struct('B',[x.B;y.B],'Q',blkdiag(x.Q,y.Q));
end
fprintf('Construct GNSS-only wide-lane candidates\n');c=gnss_pair_candidates(qa,qb,false);
integers=gnss_validate_pair_integers(c,B,Q,splits);save(fullfile(out,'R_integer_validation.mat'),'integers','-v7.3');
R_A=gnss_condition_navigation(a.model,[],[],integers.fixedB(1:nc));R_B=gnss_condition_navigation(b.model,[],[],integers.fixedB(nc+1:end));
fprintf('Construct POD-assisted integer audit and connected mask\n');c=gnss_pair_candidates(qa,qb,true);
offsetA=gnss_pod_offsets(qa,-1);offsetB=gnss_pod_offsets(qb,-1);offset=[offsetA;offsetB];
H=c.A(c.independent,:);target=c.target(c.independent);HQ=H*Q;fixed=offset+HQ'*((HQ*H')\(target-H*offset));
assert(max(abs(c.A*fixed-c.target))<5e-7,'POD-assisted integer cycle mismatch');
audit=struct('accepted_relations',size(c.A,1),'independent_rank',size(H,1),'maximum_error_m',max(abs(c.A*fixed-c.target)),'candidate_detail',c,'fixedB',fixed);
save(fullfile(out,'P_integer_audit.mat'),'audit','-v7.3');
for sat='AB'
 if sat=='A',z=a;q=qa;R=R_A;off=offsetA;fix=fixed(1:nc);ix=c.ia;else,z=b;q=qb;R=R_B;off=offsetB;fix=fixed(nc+1:end);ix=c.ib;end
 S=z.S;F=z.F;O=gnss_condition_navigation(z.model,[],[],off);
 mask=false(size(q.good));mask(ix,:)=c.mask;q.good=q.good&mask;
 fprintf('Refit masked dynamics and free clocks %s\n',sat);masked=gnss_navigation(q,1200,true);
 M=gnss_condition_navigation(masked,[],[],off);P=gnss_condition_navigation(masked,[],[],fix);
 supportOriginal=z.model.q.t(sum(z.model.q.good,2)>=4);supportFixed=q.t(sum(q.good,2)>=4);
 save(fullfile(out,[sat '_branches.mat']),'S','F','R','O','M','P','supportOriginal','supportFixed','-v7.3');
end
fprintf('Navigation branches complete\n');
end
