function test_pair_candidates
% Synthetic observations test integer signs, graph cycles and support mask.
f1=1575.42e6;f2=1227.60e6;c0=299792458;lw=c0/(f1-f2);ln=c0/(f1+f2);cf=f2/(f1+f2)*lw;
t=(0:10:1190)';n=numel(t);base=struct('t',t,'phase',nan(n,33),'mw',nan(n,33),'good',false(n,33),'labels',zeros(n,33),'B0',zeros(4,1),'h',zeros(n,33,3),'r',zeros(n,3),'pod_r',zeros(n,3));
a=base;b=base;N1=[7 12 -4 9];N2=[3 2 -8 0];offset=ln*N1+cf*(N1-N2);
for p=2:5
 a.good(:,p)=true;b.good(:,p)=true;a.labels(:,p)=p-1;b.labels(:,p)=p-1;
 a.phase(:,p)=.01*t;b.phase(:,p)=.02*t+offset(p-1);a.mw(:,p)=0;b.mw(:,p)=lw*(N1(p-1)-N2(p-1));
end
z=gnss_pair_candidates(a,b,true);assert(size(z.A,1)==6&&numel(z.independent)==3);assert(all(sum(z.mask,2)==4));
assert(max(abs(z.A*[zeros(4,1);offset']-z.target))<1e-12);
q=gnss_pair_candidates(a,b,false);assert(size(q.A,1)==6&&numel(q.independent)==3);
fprintf('Synthetic dual-frequency candidate signs, integer cycles and connected mask passed\n');
end
