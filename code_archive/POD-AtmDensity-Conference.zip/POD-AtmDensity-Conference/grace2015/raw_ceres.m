function grid=raw_ceres(models,mjd)
% Read original GROOPS CERES binary files, decompressing lossless originals.
% Current daily experiment is within one constant monthly climatology interval.
persistent root saved period
if ~isempty(root)&&strcmp(root,models)&&all(mjd>=period(1)&mjd<period(2)),grid=saved;return,end
[a,ta]=one('CERES_SYN1deg_albedo_climatology.dat.gz');[b,tb]=one('CERES_SYN1deg_longwaveFlux_climatology.dat.gz');
assert(isequal(a.points,b.points)&&isequal(ta,tb));grid=a;grid.albedo=a.values;grid.flux=b.values;grid=rmfield(grid,'values');
root=models;saved=grid;period=ta;
 function [out,interval]=one(name)
  folder=tempname;mkdir(folder);clean=onCleanup(@()rmdir(folder,'s'));files=gunzip(fullfile(models,name),folder);
  f=fopen(files{1},'r','ieee-le');c=onCleanup(@()fclose(f));assert(fread(f,1,'*char')=='B');
  typ=str;ver=str;fread(f,mod(1+numel(typ)+numel(ver),8),'*char');assert(strcmp(typ,'griddedDataTimeSeries'));
  degree=u;nt=u;nd=u;assert(degree==0&&nd==1,'Only supplied constant monthly climatology is supported');assert(u==1,'Expected rectangular grid');fread(f,2,'double');
  lon=vec;lat=vec;radius=vec;dl=vec;dp=vec;nv=u;np=numel(lon)*numel(lat);fread(f,np*nv,'double');
  times=zeros(nt,1);for kk=1:nt,times(kk)=fread(f,1,'int64=>double')+fread(f,1,'double');end
  idx=find(times<=min(mjd),1,'last');assert(~isempty(idx)&&idx<nt&&max(mjd)<times(idx+1),'Climatology request crosses an interval');
  base=ftell(f);fseek(f,base+(idx-1)*np*8,'bof');val=fread(f,np,'double');assert(numel(val)==np);
  [L,P]=ndgrid(lon,lat);rr=repmat(radius',numel(lon),1);points=[reshape(rr.*cos(P).*cos(L),[],1),reshape(rr.*cos(P).*sin(L),[],1),reshape(rr.*sin(P),[],1)];
  areas=reshape(dl*dp',[],1).*vecnorm(points,2,2).^2;assert(numel(areas)==np);
  out=struct('points',points,'areas',areas,'values',val);interval=times(idx:idx+1);clear c;
  function v=u,v=fread(f,1,'uint64=>double');end
  function v=vec,n=u;v=fread(f,n,'double');end
  function s=str,n=u;s=fread(f,n,'*char')';end
 end
end
