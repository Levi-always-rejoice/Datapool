function file=plot_gracefo_days(run1,run2,destination)
% Plot only the outputs of completed raw runs, never estimator inputs.
if nargin<3,destination=fullfile(fileparts(mfilename('fullpath')),'runs');end
if ~isfolder(destination),mkdir(destination);end
folders={run1,run2};fig=figure('Visible','off','Color','w','Position',[20 20 1500 1050]);tiledlayout(3,2,'TileSpacing','compact','Padding','compact');
colors=[0 .4 .72;.23 .56 .30];
for day=1:2
 out=fullfile(folders{day},'independent','joint','fixed_screened');r=jsondecode(fileread(fullfile(out,'comparison.json')));
 v=readmatrix(fullfile(out,'range_comparison.csv'));ax=nexttile(day);hold on;
 y=v(:,2:3)*1e3;y([false;diff(v(:,1))>5.1],:)=NaN;
 for j=1:2,plot((v(:,1)-18)/3600,y(:,j),'LineWidth',1.8,'Color',colors(j,:));end
 ylabel('Range - KBR (mm)');title(r.date);legend('Fixed relative GNSS','POD','Location','northoutside');style(ax);
 ax=nexttile(2+day);hold on;v=readmatrix(fullfile(out,'differential_density.csv'));safe=logical(v(:,5));y=v(:,2:4);y=(y-mean(y(safe,:),1,'omitnan'))*1e12;y(~safe,:)=NaN;
 for j=1:2,plot((v(:,1)-18)/3600,y(:,j),'LineWidth',1.8,'Color',colors(j,:));end
 plot((v(:,1)-18)/3600,y(:,3),'k','LineWidth',1.8);legend('Fixed relative GNSS','POD','ACT reference','Location','northoutside');ylabel('\Delta\rho variation (10^{-12} kg/m^3)');title('20-min density: supported, firing-free; full vertical scale');style(ax);
 ax=nexttile(4+day);hold on;
 for sat='CD',v=readmatrix(fullfile(out,[sat '_orbit_minus_POD.csv']));y=vecnorm(v(:,2:4),2,2);y([false;diff(v(:,1))>1.1])=NaN;plot((v(:,1)-18)/3600,y,'LineWidth',1.8,'DisplayName',['GRACE-FO ' sat]);end
 ylabel('3D orbit error vs POD (m)');legend('Location','northoutside');style(ax);
end
file=fullfile(destination,'GRACEFO_raw_two_days.png');exportgraphics(fig,file,'Resolution',170);close(fig);
end
function style(ax),grid(ax,'on');ax.GridAlpha=.15;ax.FontSize=11;ax.Box='off';xlim([0 24]);xticks(0:4:24);xlabel('UTC hour');end
