function out=run_grace()
% Reproduce all native MATLAB GRACE 2015 manuscript branches from raw products.
root=fileparts(mfilename('fullpath'));savedPath=path;clean=onCleanup(@()path(savedPath));
restoredefaultpath;addpath(root,fullfile(root,'grace2015'));maxNumCompThreads(2);check_runtime;
out=run_manuscript;
end
